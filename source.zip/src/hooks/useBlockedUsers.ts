import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

export const useBlockedUsers = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [blockedUserIds, setBlockedUserIds] = useState<string[]>([]);
  const [blockedByIds, setBlockedByIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchBlockedUsers = useCallback(async () => {
    if (!user?.id) {
      setBlockedUserIds([]);
      setBlockedByIds([]);
      setLoading(false);
      return;
    }

    try {
      const { data: blocked, error: blockedError } = await supabase
        .from('blocked_users')
        .select('blocked_user_id')
        .eq('blocker_user_id', user.id);

      if (blockedError) throw blockedError;

      const { data: blockedBy, error: blockedByError } = await supabase
        .from('blocked_users')
        .select('blocker_user_id')
        .eq('blocked_user_id', user.id);

      const blockedByList = blockedByError ? [] : (blockedBy || []);

      setBlockedUserIds(blocked?.map(b => b.blocked_user_id) || []);
      setBlockedByIds(blockedByList.map((b: any) => b.blocker_user_id));
    } catch (error) {
      console.error('Error fetching blocked users:', error);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    fetchBlockedUsers();
  }, [fetchBlockedUsers]);

  /** Invalidate all feed/marketplace queries so blocked content disappears instantly */
  const invalidateAllFeeds = useCallback(() => {
    // Invalidate all major data queries
    const keysToInvalidate = [
      'social-feed', 'marketplace', 'marketplace-mix', 'popular-near-you',
      'deals', 'services-section', 'jobs-section', 'search-results',
      'seller-ads', 'discover', 'home-feed', 'trending', 'promotions',
    ];
    keysToInvalidate.forEach(key => {
      queryClient.invalidateQueries({ queryKey: [key] });
    });
    // Also invalidate any partial matches
    queryClient.invalidateQueries({ predicate: (query) => {
      const key = query.queryKey[0];
      return typeof key === 'string' && (
        key.includes('feed') || key.includes('marketplace') || key.includes('ads') ||
        key.includes('popular') || key.includes('deals') || key.includes('search')
      );
    }});
  }, [queryClient]);

  const blockUser = useCallback(async (userIdToBlock: string, userName?: string) => {
    if (!user?.id) {
      toast.error('Please sign in to block users');
      return false;
    }

    if (userIdToBlock === user.id) {
      toast.error("You can't block yourself");
      return false;
    }

    try {
      const { error } = await supabase
        .from('blocked_users')
        .insert({
          blocker_user_id: user.id,
          blocked_user_id: userIdToBlock
        });

      if (error) {
        if (error.code === '23505') {
          toast.info('User already blocked');
          return true;
        }
        throw error;
      }

      // Update local state immediately
      setBlockedUserIds(prev => [...prev, userIdToBlock]);
      
      // Invalidate all feeds so content disappears
      invalidateAllFeeds();

      toast.success(`Blocked ${userName || 'user'}`, {
        description: "You won't see their content anymore"
      });
      return true;
    } catch (error) {
      console.error('Error blocking user:', error);
      toast.error('Failed to block user');
      return false;
    }
  }, [user?.id, invalidateAllFeeds]);

  const unblockUser = useCallback(async (userIdToUnblock: string, userName?: string) => {
    if (!user?.id) return false;

    try {
      const { error } = await supabase
        .from('blocked_users')
        .delete()
        .eq('blocker_user_id', user.id)
        .eq('blocked_user_id', userIdToUnblock);

      if (error) throw error;

      setBlockedUserIds(prev => prev.filter(id => id !== userIdToUnblock));
      invalidateAllFeeds();
      
      toast.success(`Unblocked ${userName || 'user'}`);
      return true;
    } catch (error) {
      console.error('Error unblocking user:', error);
      toast.error('Failed to unblock user');
      return false;
    }
  }, [user?.id, invalidateAllFeeds]);

  const isBlocked = useCallback((userId: string) => {
    return blockedUserIds.includes(userId) || blockedByIds.includes(userId);
  }, [blockedUserIds, blockedByIds]);

  const isBlockedByMe = useCallback((userId: string) => {
    return blockedUserIds.includes(userId);
  }, [blockedUserIds]);

  const allBlockedIds = [...new Set([...blockedUserIds, ...blockedByIds])];

  return {
    blockedUserIds,
    blockedByIds,
    allBlockedIds,
    loading,
    blockUser,
    unblockUser,
    isBlocked,
    isBlockedByMe,
    refetch: fetchBlockedUsers
  };
};
