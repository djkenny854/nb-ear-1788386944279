import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';

/**
 * Records a single business-page visit per session per seller.
 * Anonymous visitors are allowed; their identity is not exposed
 * back to the seller (RLS only returns aggregate-safe rows).
 *
 * Dedupe is enforced both client-side (sessionStorage) and at the
 * DB level (UNIQUE(seller_id, session_id)) so back-and-forth
 * navigation never inflates the count.
 */
export function useBusinessVisitTracking(
  sellerId: string | null | undefined,
  source: 'feed' | 'search' | 'direct' | 'profile' | 'other' = 'direct'
) {
  const { user } = useAuth();

  useEffect(() => {
    if (!sellerId) return;

    const storageKey = `bv_${sellerId}`;
    if (sessionStorage.getItem(storageKey)) return;

    let sessionId = sessionStorage.getItem('engagement_session_id');
    if (!sessionId) {
      sessionId = crypto.randomUUID();
      sessionStorage.setItem('engagement_session_id', sessionId);
    }

    // Mark optimistically so quick remounts don't double-fire
    sessionStorage.setItem(storageKey, '1');

    // Try to grab district from profile; fall back gracefully
    (async () => {
      let district: string | null = null;
      let region: string | null = null;
      try {
        if (user?.id) {
          const { data } = await supabase
            .from('profiles')
            .select('district, region')
            .eq('id', user.id)
            .maybeSingle();
          district = (data as any)?.district ?? null;
          region = (data as any)?.region ?? null;
        }
      } catch {
        /* ignore */
      }

      const { error } = await supabase
        .from('business_visits' as any)
        .insert({
          seller_id: sellerId,
          visitor_user_id: user?.id ?? null,
          session_id: sessionId,
          district,
          region,
          source,
        } as any);

      // Unique violation = already counted this session, that's fine.
      if (error && (error as any).code !== '23505') {
        console.warn('[business_visits] insert failed:', error.message);
      }
    })();
  }, [sellerId, user?.id, source]);
}