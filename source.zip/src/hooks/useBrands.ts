import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface Brand {
  id: string;
  name: string;
  logo_url: string | null;
  category: string;
  is_popular: boolean | null;
  created_at: string | null;
}

interface UseBrandsOptions {
  category?: string;
  searchQuery?: string;
  popularOnly?: boolean;
}

export const useBrands = (options: UseBrandsOptions = {}) => {
  const { category, searchQuery, popularOnly } = options;
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchBrands = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      let query = supabase.from('brands').select('*');

      if (category) {
        query = query.eq('category', category);
      }

      if (searchQuery) {
        query = query.ilike('name', `%${searchQuery}%`);
      }

      if (popularOnly) {
        query = query.eq('is_popular', true);
      }

      query = query.order('is_popular', { ascending: false }).order('name');

      const { data, error: fetchError } = await query;

      if (fetchError) throw fetchError;
      setBrands(data || []);
    } catch (err) {
      console.error('Error fetching brands:', err);
      setError('Failed to load brands');
    } finally {
      setLoading(false);
    }
  }, [category, searchQuery, popularOnly]);

  useEffect(() => {
    fetchBrands();
  }, [fetchBrands]);

  // Get unique categories
  const categories = useMemo(() => {
    const uniqueCategories = new Set(brands.map((b) => b.category));
    return Array.from(uniqueCategories).sort();
  }, [brands]);

  // Search brands locally for quick filtering
  const searchBrands = useCallback(
    (query: string): Brand[] => {
      if (!query) return brands;
      const lowerQuery = query.toLowerCase();
      return brands.filter((b) => b.name.toLowerCase().includes(lowerQuery));
    },
    [brands]
  );

  // Get brand by name
  const getBrandByName = useCallback(
    (name: string): Brand | undefined => {
      return brands.find((b) => b.name.toLowerCase() === name.toLowerCase());
    },
    [brands]
  );

  return {
    brands,
    loading,
    error,
    categories,
    searchBrands,
    getBrandByName,
    refetch: fetchBrands,
  };
};

// Hook for fetching all brands (for filters)
export const useAllBrands = () => {
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAllBrands = async () => {
      try {
        const { data, error } = await supabase
          .from('brands')
          .select('*')
          .order('is_popular', { ascending: false })
          .order('name');

        if (error) throw error;
        setBrands(data || []);
      } catch (err) {
        console.error('Error fetching all brands:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchAllBrands();
  }, []);

  // Group brands by category
  const brandsByCategory = useMemo(() => {
    const grouped: Record<string, Brand[]> = {};
    brands.forEach((brand) => {
      if (!grouped[brand.category]) {
        grouped[brand.category] = [];
      }
      grouped[brand.category].push(brand);
    });
    return grouped;
  }, [brands]);

  return { brands, brandsByCategory, loading };
};
