import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';

interface AccountStatus {
  status: 'active' | 'suspended' | 'banned';
  isBanned: boolean;
  isSuspended: boolean;
  banReason: string | null;
  suspensionEndDate: Date | null;
  loading: boolean;
}

export const useAccountStatus = (redirectIfBanned = true) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [accountStatus, setAccountStatus] = useState<AccountStatus>({
    status: 'active',
    isBanned: false,
    isSuspended: false,
    banReason: null,
    suspensionEndDate: null,
    loading: true,
  });

  useEffect(() => {
    const checkAccountStatus = async () => {
      if (!user) {
        setAccountStatus(prev => ({ ...prev, loading: false }));
        return;
      }

      try {
        const { data: profile, error } = await supabase
          .from('profiles')
          .select('account_status, banned_reason, suspension_end_date')
          .eq('id', user.id)
          .maybeSingle();

        if (error) {
          console.error('Error checking account status:', error);
          setAccountStatus(prev => ({ ...prev, loading: false }));
          return;
        }
        
        // Handle case when no profile exists
        if (!profile) {
          setAccountStatus(prev => ({ ...prev, loading: false }));
          return;
        }

        const status = (profile?.account_status as 'active' | 'suspended' | 'banned') || 'active';
        const isBanned = status === 'banned';
        const isSuspended = status === 'suspended';

        // Check if suspension has expired
        if (isSuspended && profile?.suspension_end_date) {
          const endDate = new Date(profile.suspension_end_date);
          if (endDate < new Date()) {
            // Suspension expired, restore account
            await supabase
              .from('profiles')
              .update({ 
                account_status: 'active', 
                banned_reason: null, 
                suspension_end_date: null 
              })
              .eq('id', user.id);
            
            setAccountStatus({
              status: 'active',
              isBanned: false,
              isSuspended: false,
              banReason: null,
              suspensionEndDate: null,
              loading: false,
            });
            return;
          }
        }

        setAccountStatus({
          status,
          isBanned,
          isSuspended,
          banReason: profile?.banned_reason || null,
          suspensionEndDate: profile?.suspension_end_date ? new Date(profile.suspension_end_date) : null,
          loading: false,
        });

        // Redirect banned users
        if (redirectIfBanned && (isBanned || isSuspended)) {
          navigate('/account-restricted');
        }
      } catch (error) {
        console.error('Error checking account status:', error);
        setAccountStatus(prev => ({ ...prev, loading: false }));
      }
    };

    checkAccountStatus();
  }, [user, navigate, redirectIfBanned]);

  return accountStatus;
};
