// This hook now acts as a bridge to the global AppSettingsContext
// for backward compatibility with existing imports

import { useGlobalSettings, AppSettings, defaultSettings } from '@/contexts/AppSettingsContext';

export { type AppSettings, defaultSettings };

export const useAppSettings = () => {
  try {
    const globalSettings = useGlobalSettings();
    return {
      settings: globalSettings.settings,
      isLoading: globalSettings.isLoading,
      isSaving: globalSettings.isSaving,
      saveSettings: globalSettings.saveSettings,
      loadSettings: globalSettings.refreshSettings,
    };
  } catch (error) {
    // Fallback for components that render outside of AppSettingsProvider
    // (e.g., during testing or in edge cases)
    console.warn('useAppSettings called outside of AppSettingsProvider, using defaults');
    return {
      settings: defaultSettings,
      isLoading: false,
      isSaving: false,
      saveSettings: async () => {},
      loadSettings: async () => {},
    };
  }
};
