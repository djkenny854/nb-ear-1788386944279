import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';
import { toast } from 'sonner';

/**
 * Defensive version of useAuth — returns { user: null } if the AuthProvider
 * is not yet mounted (during HMR / initial render race). Prevents the whole
 * app from crashing into the "Something went wrong" screen when Supabase
 * auth state churns during a sign-in callback.
 */
const useAuthSafe = (): { user: any } => {
  try {
    return useAuth();
  } catch {
    return { user: null };
  }
};

export interface AppSettings {
  theme: 'light' | 'dark' | 'system';
  accent_color: string;
  reduced_motion: boolean;
  compact_mode: boolean;
  autoplay_videos: boolean;
  autoplay_product_cards: boolean;
  autoplay_gifs: boolean;
  /** Global data saver — disables autoplay + image rotation + video stream prefetching. */
  data_saver: boolean;
  /** Automatically bypass / pause Data Saver when connected to a Wi-Fi network. */
  data_saver_wifi_bypass: boolean;
  video_quality: 'auto' | 'low' | 'medium' | 'high';
  email_notifications: boolean;
  sms_notifications: boolean;
  push_notifications: boolean;
  marketing_emails: boolean;
  notification_sound: boolean;
  two_factor_enabled: boolean;
  login_alerts: boolean;
  data_sharing: boolean;
  save_search_history: boolean;
  language: string;
  currency: string;
  // AI Settings
  ai_personality: string;
  ai_response_length: string;
  ai_auto_suggest: boolean;
  ai_show_images: boolean;
  ai_permission_analytics: boolean;
  ai_permission_listings: boolean;
  ai_permission_profile: boolean;
  ai_voice_enabled: boolean;
  ai_auto_speak: boolean;
  ai_default_model: string;
  /** Font size scale, applied globally via root font-size. */
  font_scale: 'sm' | 'md' | 'lg' | 'xl';
  /** Font family for the whole app. Client-only preference. */
  font_family: 'twitter' | 'google-sans' | 'system' | 'outfit';
}

/**
 * Synchronously checks if data saver is currently active across the application,
 * taking Wi-Fi bypass into consideration. Can be used in non-React files.
 */
export function getIsDataSaverActive(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const dataSaver = localStorage.getItem('data_saver') === 'true';
    if (!dataSaver) return false;
    const wifiBypass = localStorage.getItem('data_saver_wifi_bypass') !== 'false';
    if (wifiBypass) {
      const nav = navigator as any;
      const conn = nav.connection || nav.mozConnection || nav.webkitConnection;
      const isWifi = conn?.type === 'wifi' || conn?.type === 'ethernet';
      if (isWifi) return false;
    }
    return true;
  } catch {
    return false;
  }
}

// Google-style two-tone theme presets.
// `accent` (top half of circle) = --primary / --ring / --accent.
// `surface` (bottom half of circle) = subtle tinted surface (--surface-tint).
// `mode`: 'any' = always available; 'light-only' = only when background is light;
// 'dark-only' = only when background is dark. The Black preset is light-only
// (black accent on light bg), White preset is dark-only (white accent on dark bg).
export type ThemeMode = 'any' | 'light-only' | 'dark-only';
export interface ThemePreset {
  label: string;
  accent: string;   // HSL "H S% L%"
  surface: string;  // HSL "H S% L%"
  mode: ThemeMode;
}

export const THEME_PRESETS: Record<string, ThemePreset> = {
  orange:      { label: 'Orange',      accent: '24 92% 48%',   surface: '24 90% 92%',  mode: 'any' },
  blue:        { label: 'Blue',        accent: '217 89% 55%',  surface: '210 90% 92%', mode: 'any' },
  lavenderPink:{ label: 'Lavender Pink', accent: '290 60% 75%', surface: '320 80% 92%', mode: 'any' },
  rose:        { label: 'Rose',        accent: '345 45% 65%',  surface: '345 60% 92%', mode: 'any' },
  peach:       { label: 'Peach',       accent: '18 70% 80%',   surface: '20 90% 94%',  mode: 'any' },
  terracotta:  { label: 'Terracotta',  accent: '20 55% 50%',   surface: '24 65% 88%',  mode: 'any' },
  mustard:     { label: 'Mustard',     accent: '45 90% 45%',   surface: '45 90% 82%',  mode: 'any' },
  mocha:       { label: 'Mocha',       accent: '25 15% 45%',   surface: '20 20% 80%',  mode: 'any' },
  olive:       { label: 'Olive',       accent: '70 50% 35%',   surface: '60 55% 85%',  mode: 'any' },
  forest:      { label: 'Forest',      accent: '145 40% 35%',  surface: '130 50% 85%', mode: 'any' },
  teal:        { label: 'Teal',        accent: '175 70% 35%',  surface: '170 65% 85%', mode: 'any' },
  ocean:       { label: 'Ocean',       accent: '200 80% 35%',  surface: '195 90% 85%', mode: 'any' },
  periwinkle:  { label: 'Periwinkle',  accent: '235 50% 65%',  surface: '230 70% 92%', mode: 'any' },
  lavender:    { label: 'Lavender',    accent: '270 55% 60%',  surface: '275 70% 92%', mode: 'any' },
  black:       { label: 'Black',       accent: '0 0% 0%',      surface: '0 0% 0%',     mode: 'light-only' },
  white:       { label: 'White',       accent: '0 0% 100%',    surface: '0 0% 100%',   mode: 'dark-only' },
};

// Back-compat alias — existing code/DB rows still reference ACCENT_COLORS.
export const ACCENT_COLORS: Record<string, { label: string; hsl: string; ring: string }> =
  Object.fromEntries(
    Object.entries(THEME_PRESETS).map(([k, v]) => [k, { label: v.label, hsl: v.accent, ring: v.accent }])
  );

// Map legacy keys to new presets for users with older saved values.
const LEGACY_ACCENT_MAP: Record<string, string> = {
  spotify: 'forest',
  yellow: 'mustard',
  pink: 'rose',
  purple: 'lavender',
};

export const resolvePresetKey = (key: string | undefined | null): string => {
  if (!key) return 'orange';
  if (THEME_PRESETS[key]) return key;
  if (LEGACY_ACCENT_MAP[key] && THEME_PRESETS[LEGACY_ACCENT_MAP[key]]) return LEGACY_ACCENT_MAP[key];
  return 'orange';
};

// Detect system theme preference
const getSystemTheme = (): 'light' | 'dark' => {
  if (typeof window !== 'undefined' && window.matchMedia) {
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  return 'light';
};

const defaultSettings: AppSettings = {
  accent_color: 'orange',
  theme: 'system',
  reduced_motion: false,
  compact_mode: false,
  autoplay_videos: true,
  autoplay_product_cards: true,
  autoplay_gifs: true,
  data_saver: false,
  data_saver_wifi_bypass: true,
  video_quality: 'auto',
  email_notifications: true,
  sms_notifications: false,
  push_notifications: true,
  marketing_emails: false,
  notification_sound: true,
  two_factor_enabled: false,
  login_alerts: true,
  data_sharing: false,
  save_search_history: true,
  language: 'en',
  currency: 'UGX',
  ai_personality: 'balanced',
  ai_response_length: 'detailed',
  ai_auto_suggest: true,
  ai_show_images: true,
  ai_permission_analytics: false,
  ai_permission_listings: false,
  ai_permission_profile: false,
  ai_voice_enabled: true,
  ai_auto_speak: false,
  ai_default_model: 'auto',
  font_scale: 'md',
  font_family: 'twitter',
};

interface AppSettingsContextType {
  settings: AppSettings;
  isLoading: boolean;
  isSaving: boolean;
  /** Whether data saver restrictions are actively in effect (taking Wi-Fi bypass into account). */
  isDataSaverActive: boolean;
  /** Whether the current active connection is Wi-Fi / Ethernet. */
  isWifiConnected: boolean;
  /** Whether Data Saver is enabled by the user but currently paused because device is connected to Wi-Fi. */
  isBypassingDataSaverOnWifi: boolean;
  saveSettings: (newSettings: Partial<AppSettings>) => Promise<void>;
  refreshSettings: () => Promise<void>;
}

const AppSettingsContext = createContext<AppSettingsContextType | undefined>(undefined);

export const AppSettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuthSafe();
  const { isWifi } = useNetworkStatus();
  const [settings, setSettings] = useState<AppSettings>(() => {
    // Initialize from localStorage for immediate effect
    const stored = localStorage.getItem('app_settings');
    if (stored) {
      try {
        return { ...defaultSettings, ...JSON.parse(stored) };
      } catch {
        return defaultSettings;
      }
    }
    return defaultSettings;
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const hasLoadedRef = useRef(false);

  // Compute effective data saver state
  const isBypassingDataSaverOnWifi = Boolean(
    settings.data_saver && settings.data_saver_wifi_bypass && isWifi
  );
  const isDataSaverActive = Boolean(
    settings.data_saver && !isBypassingDataSaverOnWifi
  );

  // Load settings from database
  const loadSettings = useCallback(async () => {
    if (!user) {
      // Load from localStorage for non-authenticated users
      const stored = localStorage.getItem('app_settings');
      if (stored) {
        try {
          setSettings({ ...defaultSettings, ...JSON.parse(stored) });
        } catch {
          setSettings(defaultSettings);
        }
      }
      setIsLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('user_app_settings')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error loading settings:', error);
      }

      if (data) {
        const loadedSettings: AppSettings = {
          accent_color: (data as any).accent_color || 'orange',
          theme: data.theme as AppSettings['theme'],
          reduced_motion: data.reduced_motion,
          compact_mode: data.compact_mode,
          autoplay_videos: data.autoplay_videos,
          autoplay_product_cards: (data as any).autoplay_product_cards ?? true,
          autoplay_gifs: data.autoplay_gifs,
          data_saver: (() => {
            const stored = localStorage.getItem('data_saver');
            return stored === 'true';
          })(),
          data_saver_wifi_bypass: (() => {
            const stored = localStorage.getItem('data_saver_wifi_bypass');
            return stored === null ? true : stored === 'true';
          })(),
          video_quality: data.video_quality as AppSettings['video_quality'],
          email_notifications: data.email_notifications,
          sms_notifications: data.sms_notifications,
          push_notifications: data.push_notifications,
          marketing_emails: data.marketing_emails,
          notification_sound: data.notification_sound,
          two_factor_enabled: data.two_factor_enabled,
          login_alerts: data.login_alerts,
          data_sharing: data.data_sharing,
          save_search_history: data.save_search_history,
          language: data.language,
          currency: data.currency,
          ai_personality: data.ai_personality || 'balanced',
          ai_response_length: data.ai_response_length || 'detailed',
          ai_auto_suggest: data.ai_auto_suggest ?? true,
          ai_show_images: data.ai_show_images ?? true,
          ai_permission_analytics: data.ai_permission_analytics ?? false,
          ai_permission_listings: data.ai_permission_listings ?? false,
          ai_permission_profile: data.ai_permission_profile ?? false,
          ai_voice_enabled: data.ai_voice_enabled ?? true,
          ai_auto_speak: data.ai_auto_speak ?? false,
          ai_default_model: data.ai_default_model || 'auto',
          font_scale: ((): AppSettings['font_scale'] => {
            const stored = localStorage.getItem('font_scale');
            if (stored === 'sm' || stored === 'md' || stored === 'lg' || stored === 'xl') return stored;
            return 'md';
          })(),
          font_family: ((): AppSettings['font_family'] => {
            const stored = localStorage.getItem('font_family');
            if (stored === 'twitter' || stored === 'google-sans' || stored === 'system' || stored === 'outfit') return stored;
            return 'twitter';
          })(),
        };
        setSettings(loadedSettings);
        // Also sync to localStorage for fast access
        localStorage.setItem('app_settings', JSON.stringify(loadedSettings));
        localStorage.setItem('app_language', loadedSettings.language);
        localStorage.setItem('app_currency', loadedSettings.currency);
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  // Save settings to database and update local state immediately
  const saveSettings = useCallback(async (newSettings: Partial<AppSettings>) => {
    const updatedSettings = { ...settings, ...newSettings };
    
    // Immediately update local state for instant UI feedback
    setSettings(updatedSettings);
    
    // Sync to localStorage immediately
    localStorage.setItem('app_settings', JSON.stringify(updatedSettings));
    if (newSettings.language) {
      localStorage.setItem('app_language', newSettings.language);
      document.documentElement.lang = newSettings.language;
    }
    if (newSettings.currency) {
      localStorage.setItem('app_currency', newSettings.currency);
    }

    if (typeof newSettings.data_saver === 'boolean') {
      localStorage.setItem('data_saver', String(newSettings.data_saver));
    }
    if (typeof newSettings.data_saver_wifi_bypass === 'boolean') {
      localStorage.setItem('data_saver_wifi_bypass', String(newSettings.data_saver_wifi_bypass));
    }

    if (!user) {
      return;
    }

    setIsSaving(true);
    try {
      // Client-only preferences (no DB columns) — strip before save.
      const { font_scale: _fs, font_family: _ff, data_saver: _ds, data_saver_wifi_bypass: _dw, ...dbSettings } = updatedSettings;
      
      // First check if settings record exists for this user
      const { data: existing } = await supabase
        .from('user_app_settings')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (existing) {
        // Update existing record
        const { error } = await supabase
          .from('user_app_settings')
          .update({
            ...dbSettings,
            updated_at: new Date().toISOString(),
          })
          .eq('user_id', user.id);

        if (error) throw error;
      } else {
        // Insert new record
        const { error } = await supabase
          .from('user_app_settings')
          .insert({
            user_id: user.id,
            ...dbSettings,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          });

        if (error) throw error;
      }
    } catch (error) {
      console.error('Error saving settings:', error);
      toast.error('Failed to save settings');
    } finally {
      setIsSaving(false);
    }
  }, [user, settings]);

  // Apply theme effect.
  // NATIVE MODE: ignore any user/DB theme preference — always follow the
  // device's system theme. The DB row is left untouched; web still honors it.
  useEffect(() => {
    let native = false;
    try {
      // Avoid a hard import cycle; read the runtime flag synchronously.
      native = (window as any).Capacitor?.isNativePlatform?.() === true
        || document.documentElement.classList.contains('capacitor-native');
    } catch { native = false; }


    const applyTheme = (theme: 'light' | 'dark' | 'system') => {
      const root = document.documentElement;
      const effectiveTheme: 'light' | 'dark' = theme === 'system'
        ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
        : theme;

      if (effectiveTheme === 'dark') {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }

      localStorage.setItem('theme', theme);
    };

    const intent: 'light' | 'dark' | 'system' = native ? 'system' : settings.theme;
    applyTheme(intent);

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = () => {
      if (intent === 'system') applyTheme('system');
    };
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [settings.theme]);


  // Apply accent color + surface tint from the two-tone preset.
  // If the active preset is no longer valid for the current background mode
  // (e.g. Black selected while in dark mode), fall back to Lavender automatically.
  useEffect(() => {
    const root = document.documentElement;
    const isDark = root.classList.contains('dark');
    const key = resolvePresetKey(settings.accent_color);
    let preset = THEME_PRESETS[key];
    if (
      (preset.mode === 'light-only' && isDark) ||
      (preset.mode === 'dark-only' && !isDark)
    ) {
      preset = THEME_PRESETS.lavender;
    }
    // Choose a readable foreground for the accent (used for button labels).
    const fg = preset.accent === '0 0% 100%' ? '0 0% 0%' :
               preset.accent === '0 0% 0%' ? '0 0% 100%' :
               '0 0% 100%';
    root.style.setProperty('--primary', preset.accent);
    root.style.setProperty('--primary-foreground', fg);
    root.style.setProperty('--ring', preset.accent);
    root.style.setProperty('--accent', preset.accent);
    root.style.setProperty('--accent-foreground', fg);
    root.style.setProperty('--surface-tint', preset.surface);
  }, [settings.accent_color, settings.theme]);

  // Apply reduced motion
  useEffect(() => {
    if (settings.reduced_motion) {
      document.documentElement.classList.add('reduce-motion');
    } else {
      document.documentElement.classList.remove('reduce-motion');
    }
  }, [settings.reduced_motion]);

  // Apply font scale globally by setting root font-size.
  // Tailwind units are rem-based, so this scales every text element
  // (headings, paragraphs, buttons, inputs) across the app.
  useEffect(() => {
    const scaleMap: Record<AppSettings['font_scale'], string> = {
      sm: '14px',
      md: '16px',
      lg: '18px',
      xl: '20px',
    };
    const px = scaleMap[settings.font_scale] || '16px';
    document.documentElement.style.fontSize = px;
  }, [settings.font_scale]);

  // Apply font family globally via a CSS custom property consumed by body{}.
  useEffect(() => {
    const familyMap: Record<AppSettings['font_family'], string> = {
      twitter: `'TwitterChirp', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`,
      'google-sans': `'Google Sans', 'Google Sans Flex', 'Product Sans', Roboto, -apple-system, BlinkMacSystemFont, sans-serif`,
      system: `-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif`,
      outfit: `'Outfit', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`,
    };
    const family = familyMap[settings.font_family] || familyMap.twitter;
    document.documentElement.style.setProperty('--app-font-family', family);
    localStorage.setItem('font_family', settings.font_family);
  }, [settings.font_family]);

  // Load settings on mount and when user changes
  useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  // Apply theme on initial load — honour 'system' by reading prefers-color-scheme.
  // In native mode, always follow the OS theme and ignore any saved preference.
  useEffect(() => {
    const native = (window as any).Capacitor?.isNativePlatform?.() === true
      || document.documentElement.classList.contains('capacitor-native');
    const savedTheme = native ? 'system' : localStorage.getItem('theme');
    const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    let effective: 'light' | 'dark';

    if (!savedTheme || savedTheme === 'system') {
      effective = systemDark ? 'dark' : 'light';
      if (!savedTheme && !native) localStorage.setItem('theme', 'system');
    } else {
      effective = savedTheme === 'dark' ? 'dark' : 'light';
    }

    if (effective === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);


  return (
    <AppSettingsContext.Provider value={{
      settings,
      isLoading,
      isSaving,
      isDataSaverActive,
      isWifiConnected: isWifi,
      isBypassingDataSaverOnWifi,
      saveSettings,
      refreshSettings: loadSettings,
    }}>
      {children}
    </AppSettingsContext.Provider>
  );
};

export const useGlobalSettings = () => {
  const context = useContext(AppSettingsContext);
  if (!context) {
    throw new Error('useGlobalSettings must be used within AppSettingsProvider');
  }
  return context;
};

export const useGlobalSettingsSafe = () => {
  const context = useContext(AppSettingsContext);
  if (!context) {
    return {
      settings: defaultSettings,
      isLoading: false,
      isSaving: false,
      isDataSaverActive: getIsDataSaverActive(),
      isWifiConnected: false,
      isBypassingDataSaverOnWifi: false,
      saveSettings: async () => false,
      refreshSettings: async () => {},
    };
  }
  return context;
};

// Re-export for backward compatibility with existing useAppSettings imports
export { defaultSettings };
export type { AppSettingsContextType };
