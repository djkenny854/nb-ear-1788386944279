import React, { createContext, useContext, useState, useCallback } from 'react';

interface VideoModalContextType {
  isVideoModalOpen: boolean;
  setIsVideoModalOpen: (open: boolean) => void;
  globalMuted: boolean;
  setGlobalMuted: (muted: boolean) => void;
  pauseAllFeedVideos: () => void;
  setPauseFeedVideosCallback: (callback: () => void) => void;
}

const VideoModalContext = createContext<VideoModalContextType | undefined>(undefined);

export const VideoModalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [globalMuted, setGlobalMuted] = useState(true); // Start muted by default
  const [pauseCallback, setPauseCallback] = useState<(() => void) | null>(null);

  const handleSetIsVideoModalOpen = useCallback((open: boolean) => {
    setIsVideoModalOpen(open);
    // When modal opens, pause all feed videos
    if (open && pauseCallback) {
      pauseCallback();
    }
  }, [pauseCallback]);

  const pauseAllFeedVideos = useCallback(() => {
    if (pauseCallback) {
      pauseCallback();
    }
  }, [pauseCallback]);

  const setPauseFeedVideosCallback = useCallback((callback: () => void) => {
    setPauseCallback(() => callback);
  }, []);

  return (
    <VideoModalContext.Provider value={{ 
      isVideoModalOpen, 
      setIsVideoModalOpen: handleSetIsVideoModalOpen,
      globalMuted,
      setGlobalMuted,
      pauseAllFeedVideos,
      setPauseFeedVideosCallback
    }}>
      {children}
    </VideoModalContext.Provider>
  );
};

export const useVideoModal = () => {
  const context = useContext(VideoModalContext);
  if (!context) {
    throw new Error('useVideoModal must be used within a VideoModalProvider');
  }
  return context;
};
