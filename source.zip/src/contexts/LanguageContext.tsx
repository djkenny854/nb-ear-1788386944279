import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useGlobalSettings } from '@/contexts/AppSettingsContext';

// English translations (default)
const en = {
  // Navigation
  home: 'Home',
  search: 'Search',
  discover: 'Discover',
  messages: 'Messages',
  profile: 'Profile',
  settings: 'Settings',
  notifications: 'Notifications',
  bookmarks: 'Bookmarks',
  
  // Auth
  login: 'Login',
  signUp: 'Sign Up',
  signOut: 'Sign Out',
  email: 'Email',
  password: 'Password',
  forgotPassword: 'Forgot Password?',
  enterEmail: 'Enter your email',
  enterPassword: 'Enter your password',
  createAccount: 'Create Account',
  alreadyHaveAccount: 'Already have an account?',
  dontHaveAccount: "Don't have an account?",
  verifyEmail: 'Verify Email',
  enterOtp: 'Enter OTP',
  otpSent: 'OTP sent to your email',
  verificationCode: 'Verification Code',
  resendCode: 'Resend Code',
  verify: 'Verify',
  
  // Search & Filter
  searchPlaceholder: 'Search products, services, jobs...',
  all: 'All',
  products: 'Products',
  services: 'Services',
  jobs: 'Jobs',
  events: 'Events',
  promotions: 'Promotions',
  accounts: 'Accounts',
  filters: 'Filters',
  sortBy: 'Sort By',
  newest: 'Newest',
  priceLowToHigh: 'Price: Low to High',
  priceHighToLow: 'Price: High to Low',
  featured: 'Featured First',
  category: 'Category',
  location: 'Location',
  priceRange: 'Price Range',
  condition: 'Condition',
  
  // Product
  addToCart: 'Add to Cart',
  buyNow: 'Buy Now',
  contactSeller: 'Contact Seller',
  shareProduct: 'Share',
  saveProduct: 'Save',
  productDetails: 'Product Details',
  specifications: 'Specifications',
  reviews: 'Reviews',
  relatedProducts: 'Related Products',
  inStock: 'In Stock',
  outOfStock: 'Out of Stock',
  freeDelivery: 'Free Delivery',
  negotiable: 'Negotiable',
  
  // Seller
  verifiedSeller: 'Verified Seller',
  followSeller: 'Follow',
  following: 'Following',
  followers: 'Followers',
  products_count: 'Products',
  memberSince: 'Member Since',
  responseRate: 'Response Rate',
  sellerProfile: 'Seller Profile',
  
  // Common Actions
  save: 'Save',
  cancel: 'Cancel',
  delete: 'Delete',
  edit: 'Edit',
  share: 'Share',
  report: 'Report',
  close: 'Close',
  back: 'Back',
  next: 'Next',
  submit: 'Submit',
  loading: 'Loading...',
  seeMore: 'See More',
  seeAll: 'See All',
  viewAll: 'View All',
  showMore: 'Show More',
  showLess: 'Show Less',
  
  // Messages
  typeMessage: 'Type a message...',
  send: 'Send',
  noMessages: 'No messages yet',
  startConversation: 'Start a conversation',
  
  // Settings
  language: 'Language',
  theme: 'Theme',
  darkMode: 'Dark Mode',
  lightMode: 'Light Mode',
  systemTheme: 'System',
  pushNotifications: 'Push Notifications',
  emailNotifications: 'Email Notifications',
  privacy: 'Privacy',
  security: 'Security',
  helpSupport: 'Help & Support',
  about: 'About',
  termsOfService: 'Terms of Service',
  privacyPolicy: 'Privacy Policy',
  
  // Post Ad
  postAd: 'Post Ad',
  title: 'Title',
  description: 'Description',
  price: 'Price',
  images: 'Images',
  uploadImages: 'Upload Images',
  publish: 'Publish',
  saveDraft: 'Save Draft',
  
  // Job specific
  applyNow: 'Apply Now',
  jobType: 'Job Type',
  fullTime: 'Full Time',
  partTime: 'Part Time',
  contract: 'Contract',
  remote: 'Remote',
  salary: 'Salary',
  experience: 'Experience',
  requirements: 'Requirements',
  responsibilities: 'Responsibilities',
  
  // Empty States
  noResults: 'No results found',
  noProductsFound: 'No products found',
  noServicesFound: 'No services found',
  noJobsFound: 'No jobs found',
  tryDifferentSearch: 'Try a different search term',
  
  // Errors
  somethingWentWrong: 'Something went wrong',
  tryAgain: 'Try Again',
  networkError: 'Network error. Please check your connection.',
  
  // Success
  success: 'Success',
  savedSuccessfully: 'Saved successfully',
  updatedSuccessfully: 'Updated successfully',
  deletedSuccessfully: 'Deleted successfully',
  
  // Time
  justNow: 'Just now',
  minutesAgo: 'minutes ago',
  hoursAgo: 'hours ago',
  daysAgo: 'days ago',
  today: 'Today',
  yesterday: 'Yesterday',
};

// Swahili translations
const sw: typeof en = {
  // Navigation
  home: 'Nyumbani',
  search: 'Tafuta',
  discover: 'Gundua',
  messages: 'Ujumbe',
  profile: 'Wasifu',
  settings: 'Mipangilio',
  notifications: 'Arifa',
  bookmarks: 'Alama',
  
  // Auth
  login: 'Ingia',
  signUp: 'Jisajili',
  signOut: 'Toka',
  email: 'Barua pepe',
  password: 'Nenosiri',
  forgotPassword: 'Umesahau nenosiri?',
  enterEmail: 'Weka barua pepe yako',
  enterPassword: 'Weka nenosiri lako',
  createAccount: 'Fungua Akaunti',
  alreadyHaveAccount: 'Una akaunti tayari?',
  dontHaveAccount: 'Huna akaunti?',
  verifyEmail: 'Thibitisha Barua pepe',
  enterOtp: 'Weka OTP',
  otpSent: 'OTP imetumwa kwa barua pepe yako',
  verificationCode: 'Nambari ya Uthibitishaji',
  resendCode: 'Tuma tena Nambari',
  verify: 'Thibitisha',
  
  // Search & Filter
  searchPlaceholder: 'Tafuta bidhaa, huduma, kazi...',
  all: 'Zote',
  products: 'Bidhaa',
  services: 'Huduma',
  jobs: 'Kazi',
  events: 'Matukio',
  promotions: 'Promosheni',
  accounts: 'Akaunti',
  filters: 'Vichujio',
  sortBy: 'Panga kwa',
  newest: 'Mpya zaidi',
  priceLowToHigh: 'Bei: Chini hadi Juu',
  priceHighToLow: 'Bei: Juu hadi Chini',
  featured: 'Zilizoangaziwa Kwanza',
  category: 'Aina',
  location: 'Eneo',
  priceRange: 'Kiwango cha Bei',
  condition: 'Hali',
  
  // Product
  addToCart: 'Ongeza kwenye Kikapu',
  buyNow: 'Nunua Sasa',
  contactSeller: 'Wasiliana na Muuzaji',
  shareProduct: 'Shiriki',
  saveProduct: 'Hifadhi',
  productDetails: 'Maelezo ya Bidhaa',
  specifications: 'Vipimo',
  reviews: 'Maoni',
  relatedProducts: 'Bidhaa Zinazohusiana',
  inStock: 'Inapatikana',
  outOfStock: 'Haipo Stokini',
  freeDelivery: 'Usafirishaji Bure',
  negotiable: 'Inajadilika',
  
  // Seller
  verifiedSeller: 'Muuzaji Aliyethibitishwa',
  followSeller: 'Fuata',
  following: 'Unafuata',
  followers: 'Wafuasi',
  products_count: 'Bidhaa',
  memberSince: 'Mwanachama Tangu',
  responseRate: 'Kiwango cha Majibu',
  sellerProfile: 'Wasifu wa Muuzaji',
  
  // Common Actions
  save: 'Hifadhi',
  cancel: 'Ghairi',
  delete: 'Futa',
  edit: 'Hariri',
  share: 'Shiriki',
  report: 'Ripoti',
  close: 'Funga',
  back: 'Rudi',
  next: 'Endelea',
  submit: 'Wasilisha',
  loading: 'Inapakia...',
  seeMore: 'Ona Zaidi',
  seeAll: 'Ona Zote',
  viewAll: 'Tazama Zote',
  showMore: 'Onyesha Zaidi',
  showLess: 'Onyesha Kidogo',
  
  // Messages
  typeMessage: 'Andika ujumbe...',
  send: 'Tuma',
  noMessages: 'Hakuna ujumbe bado',
  startConversation: 'Anza mazungumzo',
  
  // Settings
  language: 'Lugha',
  theme: 'Mandhari',
  darkMode: 'Hali ya Giza',
  lightMode: 'Hali ya Mwanga',
  systemTheme: 'Mfumo',
  pushNotifications: 'Arifa za Push',
  emailNotifications: 'Arifa za Barua pepe',
  privacy: 'Faragha',
  security: 'Usalama',
  helpSupport: 'Msaada',
  about: 'Kuhusu',
  termsOfService: 'Masharti ya Huduma',
  privacyPolicy: 'Sera ya Faragha',
  
  // Post Ad
  postAd: 'Weka Tangazo',
  title: 'Kichwa',
  description: 'Maelezo',
  price: 'Bei',
  images: 'Picha',
  uploadImages: 'Pakia Picha',
  publish: 'Chapisha',
  saveDraft: 'Hifadhi Rasimu',
  
  // Job specific
  applyNow: 'Omba Sasa',
  jobType: 'Aina ya Kazi',
  fullTime: 'Wakati Wote',
  partTime: 'Nusu Wakati',
  contract: 'Mkataba',
  remote: 'Kazi ya Mbali',
  salary: 'Mshahara',
  experience: 'Uzoefu',
  requirements: 'Mahitaji',
  responsibilities: 'Majukumu',
  
  // Empty States
  noResults: 'Hakuna matokeo yaliyopatikana',
  noProductsFound: 'Hakuna bidhaa zilizopatikana',
  noServicesFound: 'Hakuna huduma zilizopatikana',
  noJobsFound: 'Hakuna kazi zilizopatikana',
  tryDifferentSearch: 'Jaribu neno tofauti la utafutaji',
  
  // Errors
  somethingWentWrong: 'Kuna tatizo limetokea',
  tryAgain: 'Jaribu Tena',
  networkError: 'Hitilafu ya mtandao. Tafadhali angalia muunganisho wako.',
  
  // Success
  success: 'Imefanikiwa',
  savedSuccessfully: 'Imehifadhiwa kikamilifu',
  updatedSuccessfully: 'Imesasishwa kikamilifu',
  deletedSuccessfully: 'Imefutwa kikamilifu',
  
  // Time
  justNow: 'Sasa hivi',
  minutesAgo: 'dakika zilizopita',
  hoursAgo: 'saa zilizopita',
  daysAgo: 'siku zilizopita',
  today: 'Leo',
  yesterday: 'Jana',
};

const translations = { en, sw };

type TranslationKey = keyof typeof en;
type Language = 'en' | 'sw';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: TranslationKey) => string;
  translations: typeof en;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { settings, saveSettings } = useGlobalSettings();
  
  // Use settings.language directly - this is reactive to changes
  const language = (settings.language === 'sw' ? 'sw' : 'en') as Language;

  // Apply language to document when it changes
  useEffect(() => {
    localStorage.setItem('app_language', language);
    document.documentElement.lang = language;
    console.log('Language changed to:', language);
  }, [language]);

  const setLanguage = useCallback((lang: Language) => {
    console.log('Setting language to:', lang);
    saveSettings({ language: lang });
    localStorage.setItem('app_language', lang);
    document.documentElement.lang = lang;
  }, [saveSettings]);

  const t = useCallback((key: TranslationKey): string => {
    return translations[language]?.[key] || translations.en[key] || key;
  }, [language]);

  const currentTranslations = translations[language] || translations.en;

  return (
    <LanguageContext.Provider value={{ 
      language, 
      setLanguage, 
      t, 
      translations: currentTranslations 
    }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    // Return a fallback for when context is not available
    return {
      language: 'en' as Language,
      setLanguage: () => {},
      t: (key: TranslationKey) => en[key] || key,
      translations: en,
    };
  }
  return context;
};

export type { TranslationKey, Language };
