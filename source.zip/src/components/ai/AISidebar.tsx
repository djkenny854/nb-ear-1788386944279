import React from 'react';
import { Link } from 'react-router-dom';
import { Search, SquarePen, Image as ImageIcon, Plus, ChevronDown, ChevronsLeft, FolderClosed, Sparkle, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import EarlyMarketAIIcon from '@/components/icons/EarlyMarketAIIcon';

export interface SidebarChat {
  id: string;
  title: string;
  updated_at: string;
}

export interface SidebarProject {
  id: string;
  title: string;
}

interface Props {
  open: boolean;
  onClose: () => void;
  onOpenSearch: () => void;
  onNewChat: () => void;
  onSelectChat: (id: string) => void;
  activeChatId?: string | null;
  history: SidebarChat[];
  projects?: SidebarProject[];
}

const AISidebar: React.FC<Props> = ({
  open, onClose, onOpenSearch, onNewChat, onSelectChat, activeChatId, history, projects = [],
}) => {
  const [projectsOpen, setProjectsOpen] = React.useState(true);
  const [historyOpen, setHistoryOpen] = React.useState(true);

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop (mobile) */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40 bg-black/30 md:hidden"
            onClick={onClose}
          />

          {/* Panel */}
          <motion.aside
            initial={{ x: -340, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -340, opacity: 0 }}
            transition={{ type: 'spring', damping: 28, stiffness: 260 }}
            className={cn(
              'fixed z-50 left-2 top-2 bottom-2',
              'w-[300px] flex flex-col',
              'rounded-3xl border border-border/60',
              'bg-card/95 backdrop-blur-xl shadow-2xl',
              'overflow-hidden',
            )}
            style={{ maxHeight: 'calc(100dvh - 1rem)' }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-4 pt-4 pb-2">
              <Link to="/" className="flex items-center" aria-label="EarlyMarket">
                <img src="/icon-512.png" alt="" className="w-7 h-7 rounded-lg" onError={(e) => ((e.target as HTMLImageElement).style.display = 'none')} />
              </Link>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors"
                aria-label="Collapse sidebar"
              >
                <ChevronsLeft className="w-4 h-4" />
              </button>
            </div>

            {/* Top actions */}
            <nav className="px-2 pt-2 space-y-0.5">
              <SidebarItem icon={<Search className="w-[18px] h-[18px]" />} label="Search" onClick={onOpenSearch} />
              <SidebarItem icon={<SquarePen className="w-[18px] h-[18px]" />} label="New Chat" onClick={onNewChat} active />
              <SidebarItem
                icon={<ImageIcon className="w-[18px] h-[18px]" />}
                label="Imagine"
                onClick={() => {/* coming soon */}}
              />
            </nav>

            {/* Scrollable area */}
            <div className="flex-1 overflow-y-auto px-2 pt-4 pb-2">
              {/* Projects */}
              <Group
                label="Projects"
                open={projectsOpen}
                onToggle={() => setProjectsOpen(v => !v)}
              >
                <SidebarItem
                  icon={<Plus className="w-[18px] h-[18px]" />}
                  label="New Project"
                  onClick={() => {/* placeholder */}}
                  muted
                />
                {projects.map(p => (
                  <SidebarItem
                    key={p.id}
                    icon={<FolderClosed className="w-[18px] h-[18px] text-emerald-500" />}
                    label={p.title}
                    onClick={() => {/* open project */}}
                  />
                ))}
              </Group>

              {/* History */}
              <div className="mt-2">
                <Group
                  label="History"
                  open={historyOpen}
                  onToggle={() => setHistoryOpen(v => !v)}
                >
                  {history.length === 0 ? (
                    <p className="px-3 py-2 text-xs text-muted-foreground">No history yet</p>
                  ) : (
                    history.slice(0, 12).map(c => (
                      <button
                        key={c.id}
                        onClick={() => onSelectChat(c.id)}
                        className={cn(
                          'w-full text-left px-3 py-2 rounded-lg text-[13px] truncate transition-colors',
                          activeChatId === c.id
                            ? 'bg-muted/60 text-foreground'
                            : 'text-foreground/80 hover:bg-muted/40 hover:text-foreground'
                        )}
                      >
                        {c.title}
                      </button>
                    ))
                  )}
                </Group>
              </div>
            </div>

            {/* Footer: Get App card */}
            <div className="p-3 border-t border-border/50">
              <Link
                to="/download"
                className="flex items-center gap-3 p-3 rounded-2xl bg-gradient-to-br from-primary/10 via-card to-card border border-border/60 hover:border-primary/40 transition-all group"
              >
                <div className="w-10 h-10 rounded-xl bg-card flex items-center justify-center flex-shrink-0 shadow-sm">
                  <EarlyMarketAIIcon className="w-7 h-7" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[13px] font-semibold text-foreground leading-tight">EarlyMarket AI Pro</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">Get the app</p>
                </div>
                <Download className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
              </Link>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
};

const SidebarItem: React.FC<{
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  active?: boolean;
  muted?: boolean;
}> = ({ icon, label, onClick, active, muted }) => (
  <button
    onClick={onClick}
    className={cn(
      'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[14px] font-medium transition-all',
      active
        ? 'bg-muted/70 text-foreground'
        : muted
          ? 'text-muted-foreground hover:bg-muted/40 hover:text-foreground'
          : 'text-foreground/85 hover:bg-muted/40'
    )}
  >
    <span className="flex-shrink-0">{icon}</span>
    <span className="truncate">{label}</span>
  </button>
);

const Group: React.FC<{
  label: string;
  open: boolean;
  onToggle: () => void;
  children: React.ReactNode;
}> = ({ label, open, onToggle, children }) => (
  <div>
    <button
      onClick={onToggle}
      className="w-full flex items-center gap-1 px-3 py-1.5 text-[13px] font-semibold text-foreground/70 hover:text-foreground"
    >
      <span>{label}</span>
      <ChevronDown className={cn('w-3.5 h-3.5 transition-transform', !open && '-rotate-90')} />
    </button>
    {open && <div className="space-y-0.5 mt-0.5">{children}</div>}
  </div>
);

export default AISidebar;
