import React, { useEffect, useMemo, useState } from 'react';
import { Search, Trash2, X, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { useIsMobile } from '@/hooks/use-mobile';

export interface SearchChatItem {
  id: string;
  title: string;
  updated_at: string;
}

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  items: SearchChatItem[];
  onSelect: (id: string) => void;
  onDelete: (id: string) => Promise<void> | void;
}

const SkeletonRow = () => (
  <div className="flex items-center gap-3 px-3 py-3 rounded-xl animate-pulse">
    <div className="w-4 h-4 rounded bg-muted" />
    <div className="flex-1 space-y-1.5">
      <div className="h-3 w-2/3 rounded bg-muted" />
      <div className="h-2 w-1/3 rounded bg-muted/70" />
    </div>
  </div>
);

const Content: React.FC<Pick<Props, 'items' | 'onSelect' | 'onDelete' | 'onOpenChange'>> = ({
  items, onSelect, onDelete, onOpenChange,
}) => {
  const [q, setQ] = useState('');
  const [searching, setSearching] = useState(false);

  // Simulate a brief skeleton phase whenever query changes
  useEffect(() => {
    if (!q) { setSearching(false); return; }
    setSearching(true);
    const t = setTimeout(() => setSearching(false), 350);
    return () => clearTimeout(t);
  }, [q]);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return items;
    return items.filter(i => i.title.toLowerCase().includes(needle));
  }, [items, q]);

  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="px-4 pt-4 pb-2 flex items-center gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            autoFocus
            value={q}
            onChange={e => setQ(e.target.value)}
            placeholder="Search your chats"
            className="w-full h-10 pl-9 pr-3 rounded-xl bg-muted/60 border border-border/40 text-sm outline-none focus:border-primary/40"
          />
        </div>
        <button
          onClick={() => onOpenChange(false)}
          className="w-9 h-9 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/60"
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-2 pb-4">
        {searching ? (
          <div className="space-y-1 mt-2">
            {Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <MessageSquare className="w-8 h-8 text-muted-foreground/40 mb-3" />
            <p className="text-sm text-muted-foreground">No chats found</p>
          </div>
        ) : (
          <ul className="space-y-0.5 mt-2">
            {filtered.map(chat => (
              <li key={chat.id} className="group flex items-center gap-2 px-3 py-2.5 rounded-xl hover:bg-muted/50">
                <button
                  onClick={() => { onSelect(chat.id); onOpenChange(false); }}
                  className="flex-1 text-left min-w-0"
                >
                  <p className="text-sm font-medium text-foreground truncate">{chat.title}</p>
                  <p className="text-[11px] text-muted-foreground">
                    {new Date(chat.updated_at).toLocaleDateString()}
                  </p>
                </button>
                <button
                  onClick={() => onDelete(chat.id)}
                  className="opacity-0 group-hover:opacity-100 w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                  aria-label="Delete chat"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

const MobileSheet: React.FC<Props> = (props) => {
  const { open, onOpenChange } = props;
  const [fullscreen, setFullscreen] = useState(false);

  const handleDragEnd = (_: any, info: PanInfo) => {
    if (info.offset.y < -80) setFullscreen(true);
    else if (info.offset.y > 120) onOpenChange(false);
  };

  useEffect(() => { if (!open) setFullscreen(false); }, [open]);

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/40"
            onClick={() => onOpenChange(false)}
          />
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0, height: fullscreen ? '100dvh' : '60dvh' }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 280 }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={0.2}
            onDragEnd={handleDragEnd}
            className={cn(
              'fixed left-0 right-0 bottom-0 z-50 bg-card rounded-t-3xl border-t border-border/60 shadow-2xl flex flex-col',
            )}
            style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
          >
            <div className="flex justify-center pt-2 pb-1 cursor-grab active:cursor-grabbing">
              <div className="w-10 h-1.5 rounded-full bg-muted-foreground/30" />
            </div>
            <div className="flex-1 min-h-0">
              <Content {...props} />
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

const AIHistorySearch: React.FC<Props> = (props) => {
  const isMobile = useIsMobile();
  if (isMobile) return <MobileSheet {...props} />;
  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent className="max-w-xl p-0 gap-0 h-[70vh]">
        <Content {...props} />
      </DialogContent>
    </Dialog>
  );
};

export default AIHistorySearch;
