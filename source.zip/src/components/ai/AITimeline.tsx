import React, { useState } from 'react';
import {
  Search, Store, MapPin, TrendingUp, Package, Shield,
  Tag, ShoppingBag, Briefcase, FileEdit,
  FolderOpen, FolderTree, Compass, BarChart3, BarChart2,
  ChevronDown, CheckCircle2, Loader2, Globe, Cloud, SlidersHorizontal,
  Cpu, Coins, Building2, ShieldCheck, CheckCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

export type TimelineIconKey =
  | 'search' | 'marketplace' | 'services' | 'jobs' | 'trending' | 'prices'
  | 'analytics' | 'listings' | 'categories' | 'sellers' | 'chart' | 'draft'
  | 'web' | 'cloud' | 'specs' | 'location' | 'reasoning' | 'filter' | 'default';

export interface TimelineSource {
  label: string;
  sublabel?: string;
  avatar?: string;
  url?: string;
  isVerified?: boolean;
}

export interface TimelineAction {
  title: string;
  description?: string;
  done?: boolean;
  type?: 'spec' | 'location' | 'category' | 'price' | 'seller' | 'search' | 'default';
}

export interface TimelineStep {
  label: string;
  icon: TimelineIconKey;
  done?: boolean;
  queries?: string[];
  sources?: TimelineSource[];
  actions?: TimelineAction[];
  details?: string;
}

const STEP_ICON: Record<TimelineIconKey, any> = {
  search: Search,
  marketplace: ShoppingBag,
  services: Briefcase,
  jobs: Building2,
  trending: TrendingUp,
  prices: Coins,
  analytics: BarChart3,
  listings: FolderOpen,
  categories: FolderTree,
  sellers: Store,
  chart: BarChart2,
  draft: FileEdit,
  web: Search,
  cloud: Cloud,
  specs: Cpu,
  location: MapPin,
  reasoning: Search,
  filter: SlidersHorizontal,
  default: Compass,
};

const getActionIcon = (action: TimelineAction) => {
  const title = (action.title || '').toLowerCase();
  if (action.type === 'location' || title.includes('district') || title.includes('location') || title.includes('region') || title.includes('uganda') || title.includes('sub-county')) {
    return <MapPin className="w-3.5 h-3.5 text-rose-500 mt-0.5 shrink-0" />;
  }
  if (action.type === 'spec' || title.includes('spec') || title.includes('technical') || title.includes('ram') || title.includes('gb') || title.includes('color')) {
    return <Cpu className="w-3.5 h-3.5 text-amber-500 mt-0.5 shrink-0" />;
  }
  if (action.type === 'category' || title.includes('category') || title.includes('subcategory')) {
    return <FolderTree className="w-3.5 h-3.5 text-indigo-500 mt-0.5 shrink-0" />;
  }
  if (action.type === 'price' || title.includes('price') || title.includes('ugx') || title.includes('budget')) {
    return <Coins className="w-3.5 h-3.5 text-emerald-500 mt-0.5 shrink-0" />;
  }
  if (action.type === 'seller' || title.includes('seller') || title.includes('verified') || title.includes('business')) {
    return <ShieldCheck className="w-3.5 h-3.5 text-blue-500 mt-0.5 shrink-0" />;
  }
  if (title.includes('search') || title.includes('query')) {
    return <Search className="w-3.5 h-3.5 text-cyan-500 mt-0.5 shrink-0" />;
  }
  return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 mt-0.5 shrink-0" />;
};

const SourceAvatar: React.FC<{ src?: string; label: string }> = ({ src, label }) => {
  const [err, setErr] = useState(false);
  if (src && !err) {
    return (
      <img
        src={src}
        alt=""
        loading="lazy"
        referrerPolicy="no-referrer"
        onError={() => setErr(true)}
        className="w-4 h-4 rounded-sm object-cover shrink-0 border border-border/30"
      />
    );
  }
  return (
    <span className="w-4 h-4 rounded-sm shrink-0 bg-primary/10 border border-primary/20 flex items-center justify-center text-[8px] font-bold text-primary uppercase">
      {label ? label.charAt(0) : 'P'}
    </span>
  );
};

const TimelineStepRow: React.FC<{
  step: TimelineStep;
  defaultOpen?: boolean;
  live?: boolean;
}> = ({ step, defaultOpen = true, live = false }) => {
  const [open, setOpen] = useState(defaultOpen);
  const [showAllSources, setShowAllSources] = useState(false);
  const Icon = STEP_ICON[step.icon] || STEP_ICON.search;
  const sources = step.sources || [];
  const queries = step.queries || [];
  const actions = step.actions || [];
  const visibleSources = showAllSources ? sources : sources.slice(0, 3);
  const hiddenCount = sources.length - visibleSources.length;

  return (
    <div className="text-sm py-1 border-l-2 border-primary/30 pl-3 ml-2 transition-all">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-2 py-1 text-foreground/90 hover:text-foreground transition-colors text-left group bg-transparent"
      >
        <div className="w-5 h-5 rounded-md bg-muted/40 flex items-center justify-center shrink-0 group-hover:bg-muted/70 transition-colors">
          <Icon className="w-3.5 h-3.5 text-primary shrink-0" />
        </div>
        <span className="flex-1 font-medium text-[13px] tracking-tight">{step.label}</span>
        {live && !step.done ? (
          <Loader2 className="w-3.5 h-3.5 text-primary animate-spin shrink-0 mr-1" />
        ) : step.done ? (
          <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0 mr-1 opacity-80" />
        ) : null}
        <ChevronDown className={cn('w-3.5 h-3.5 text-muted-foreground transition-transform shrink-0', !open && '-rotate-90')} />
      </button>

      {open && (queries.length > 0 || sources.length > 0 || actions.length > 0 || step.details) && (
        <div className="mt-1.5 space-y-2 pb-1.5 animate-in fade-in duration-200">
          {/* Sub-queries */}
          {queries.length > 0 && (
            <div className="space-y-1">
              {queries.map((q, i) => (
                <div key={`q-${i}`} className="flex items-center gap-2 text-[12px] text-muted-foreground bg-transparent px-2 py-0.5 rounded-md border border-border/20">
                  <Search className="w-3 h-3 text-muted-foreground/70 shrink-0" />
                  <span className="truncate font-mono text-[11px] text-foreground/80">{q}</span>
                </div>
              ))}
            </div>
          )}

          {/* Key actions checklist */}
          {actions.length > 0 && (
            <div className="space-y-1 bg-transparent p-2 rounded-lg border border-border/20">
              <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-1">Actions Taken</div>
              {actions.map((act, i) => (
                <div key={`act-${i}`} className="flex items-start gap-2 text-[12px] py-0.5">
                  {getActionIcon(act)}
                  <div className="flex-1">
                    <span className="font-medium text-foreground/90">{act.title}</span>
                    {act.description && (
                      <p className="text-[11px] text-muted-foreground">{act.description}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Examined / Found Sources */}
          {sources.length > 0 && (
            <div className="space-y-1">
              <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
                Examined Sources ({sources.length})
              </div>
              <div className="space-y-1">
                {visibleSources.map((s, i) => (
                  <div
                    key={`s-${i}`}
                    className="flex items-center justify-between gap-2 text-[12px] py-1 px-2 rounded-md bg-transparent hover:bg-muted/20 transition-colors border border-border/20"
                  >
                    <div className="flex items-center gap-2 min-w-0 flex-1">
                      <SourceAvatar src={s.avatar} label={s.label} />
                      <span className="truncate font-medium text-foreground/90">
                        {s.label}
                      </span>
                      {s.isVerified && (
                        <Shield className="w-3 h-3 text-primary fill-primary/20 shrink-0" aria-label="Verified Seller" />
                      )}
                    </div>
                    {s.sublabel && (
                      <span className="text-[11px] text-muted-foreground truncate shrink-0 max-w-[150px] bg-transparent px-1.5 py-0.5 rounded border border-border/20">
                        {s.sublabel}
                      </span>
                    )}
                  </div>
                ))}
              </div>
              {hiddenCount > 0 && (
                <button
                  type="button"
                  onClick={() => setShowAllSources(true)}
                  className="text-[11px] font-medium text-primary hover:underline pt-0.5 pl-1"
                >
                  +{hiddenCount} more sources
                </button>
              )}
              {showAllSources && sources.length > 3 && (
                <button
                  type="button"
                  onClick={() => setShowAllSources(false)}
                  className="text-[11px] font-medium text-muted-foreground hover:text-foreground pt-0.5 pl-1"
                >
                  Show fewer sources
                </button>
              )}
            </div>
          )}

          {/* Extra details text if present */}
          {step.details && (
            <p className="text-[11px] text-muted-foreground italic px-1">{step.details}</p>
          )}
        </div>
      )}
    </div>
  );
};

interface AITimelineProps {
  steps: TimelineStep[];
  live?: boolean;
  /** When false the whole timeline is collapsed to a "Finished N steps" header. */
  defaultExpanded?: boolean;
}

const AITimeline: React.FC<AITimelineProps> = ({ steps, live = false, defaultExpanded = false }) => {
  const [expanded, setExpanded] = useState(defaultExpanded || live);
  if (!steps.length) return null;
  const totalCount = steps.length;

  return (
    <div className="mb-3 text-[13px] bg-transparent rounded-xl border border-border/30 p-2.5 transition-all">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between text-muted-foreground hover:text-foreground transition-colors py-0.5 px-1 bg-transparent"
      >
        <div className="flex items-center gap-2">
          {live ? (
            <div className="relative flex items-center justify-center w-4 h-4">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-40" />
              <Loader2 className="w-3.5 h-3.5 text-primary animate-spin" />
            </div>
          ) : (
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          )}
          <span className="text-[13px] font-medium text-foreground/90">
            {live
              ? `Reasoning & Searching (${totalCount} ${totalCount === 1 ? 'step' : 'steps'})...`
              : `Completed ${totalCount} ${totalCount === 1 ? 'step' : 'steps'}`}
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <span>{expanded ? 'Hide details' : 'Show details'}</span>
          <ChevronDown className={cn('w-3.5 h-3.5 transition-transform duration-200', !expanded && '-rotate-90')} />
        </div>
      </button>

      {expanded && (
        <div className="mt-2.5 pt-2 border-t border-border/30 space-y-1">
          {steps.map((s, i) => (
            <TimelineStepRow
              key={i}
              step={s}
              defaultOpen={live || i === steps.length - 1}
              live={live}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default AITimeline;
