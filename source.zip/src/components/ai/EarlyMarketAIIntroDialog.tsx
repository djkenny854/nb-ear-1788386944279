import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Sparkles, ImageIcon, Lock } from 'lucide-react';
import EarlyMarketAIIcon from '@/components/icons/EarlyMarketAIIcon';

const STORAGE_KEY = 'em_ai_intro_seen';
const EVENT_NAME = 'open-ai-intro';

/**
 * Programmatic helper. Use anywhere instead of navigate('/ai').
 * If the user has already seen the intro, navigate straight to /ai.
 * Otherwise open the intro dialog.
 */
export function openEarlyMarketAI(navigate: (to: string) => void) {
  try {
    if (typeof window !== 'undefined' && localStorage.getItem(STORAGE_KEY) === 'true') {
      navigate('/ai');
      return;
    }
  } catch {}
  window.dispatchEvent(new CustomEvent(EVENT_NAME));
}

const features = [
  {
    icon: Sparkles,
    title: 'Get answers about anything in the market',
    body: 'Find products, sellers, prices and trends across Uganda’s marketplace in seconds.',
  },
  {
    icon: ImageIcon,
    title: 'Explore listings visually',
    body: 'Get smart suggestions, comparisons, and visual results tailored to what you are looking for.',
  },
  {
    icon: Lock,
    title: 'Your chats stay private',
    body: 'EarlyMarket AI only reads what you share with it. Your personal chats and account data stay private.',
  },
];

const EarlyMarketAIIntroDialog: React.FC = () => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handler = () => setOpen(true);
    window.addEventListener(EVENT_NAME, handler);
    return () => window.removeEventListener(EVENT_NAME, handler);
  }, []);

  const handleContinue = useCallback(() => {
    try { localStorage.setItem(STORAGE_KEY, 'true'); } catch {}
    setOpen(false);
    navigate('/ai');
  }, [navigate]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent
        className="max-w-[440px] w-[calc(100%-1.5rem)] p-0 gap-0 border-zinc-800 bg-[#0b0b0d] text-zinc-100 overflow-hidden rounded-2xl"
      >
        {/* Top: AI icon */}
        <div className="pt-7 pb-2 flex flex-col items-center">
          <EarlyMarketAIIcon className="h-16 w-16" />
        </div>

        {/* Headline */}
        <h2 className="text-center text-[20px] font-semibold tracking-tight text-zinc-50 px-6">
          Ask EarlyMarket AI anything
        </h2>

        {/* Features */}
        <div className="px-6 pt-6 pb-4 space-y-5">
          {features.map(({ icon: Icon, title, body }) => (
            <div key={title} className="flex gap-4">
              <div className="shrink-0 mt-0.5">
                <Icon className="w-5 h-5 text-zinc-200" strokeWidth={1.75} />
              </div>
              <div className="min-w-0">
                <p className="text-[14px] font-medium text-zinc-50 leading-tight">{title}</p>
                <p className="text-[12.5px] text-zinc-400 leading-snug mt-1">{body}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Disclaimer */}
        <div className="border-t border-zinc-800/80 px-6 py-4">
          <p className="text-[11.5px] leading-relaxed text-zinc-400">
            EarlyMarket AI is an optional service. By clicking Continue, you agree to our{' '}
            <a href="/privacy" className="text-emerald-400 hover:underline">Privacy Policy</a> and{' '}
            <a href="/terms" className="text-emerald-400 hover:underline">AI Terms</a>.{' '}
            <a href="/help" className="text-emerald-400 hover:underline">Learn more</a>
          </p>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-3 px-6 pb-6">
          <Button
            variant="ghost"
            onClick={() => setOpen(false)}
            className="text-emerald-400 hover:text-emerald-300 hover:bg-transparent"
          >
            Cancel
          </Button>
          <Button
            onClick={handleContinue}
            className="rounded-full bg-white text-black hover:bg-zinc-100 px-6"
          >
            Continue
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EarlyMarketAIIntroDialog;