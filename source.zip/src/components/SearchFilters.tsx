import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import LocationFilter from '@/components/LocationFilter';
import { useAllBrands } from '@/hooks/useBrands';
import { 
  MessageSquare, ChevronDown, Package, Briefcase, Code, Megaphone, 
  Star, Verified, Clock, Truck, CreditCard, Tag, Grid3X3
} from 'lucide-react';

interface SearchFiltersProps {
  filters: any;
  onFiltersChange: (filters: any) => void;
}

const listingTypes = [
  { id: 'product', name: 'Products', icon: Package },
  { id: 'service', name: 'Services', icon: Briefcase },
  { id: 'job', name: 'Jobs', icon: Briefcase },
  { id: 'digital', name: 'Digital', icon: Code },
  { id: 'promotion', name: 'Promotions', icon: Megaphone },
];

const deliveryOptions = ['Express', 'Standard', 'Pickup', 'Shipping Available'];
const paymentMethods = ['Cash', 'Mobile Money', 'Bank Transfer', 'Card Payment'];
const dateOptions = [
  { label: 'Any time', value: '' },
  { label: 'Last 24 hours', value: '1' },
  { label: 'Last 7 days', value: '7' },
  { label: 'Last 30 days', value: '30' },
];

const SearchFilters: React.FC<SearchFiltersProps> = ({ 
  filters, 
  onFiltersChange 
}) => {
  const [openSections, setOpenSections] = useState({
    listing: true,
    location: true,
    price: true,
    seller: false,
    features: false,
    date: false,
    delivery: false,
    brands: false,
    condition: false,
    category: false,
  });

  const [brandSearch, setBrandSearch] = useState('');

  const { brands: dbBrands, loading: brandsLoading } = useAllBrands();

  const categories = [
    'Electronics', 'Vehicles', 'Fashion', 'Home & Garden', 
    'Sports', 'Books', 'Jobs', 'Services', 'Real Estate'
  ];

  const filteredBrands = useMemo(() => {
    if (!brandSearch) return dbBrands;
    const query = brandSearch.toLowerCase();
    return dbBrands.filter(brand => 
      brand.name.toLowerCase().includes(query)
    );
  }, [dbBrands, brandSearch]);

  const toggleSection = (section: string) => {
    setOpenSections(prev => ({ ...prev, [section]: !prev[section as keyof typeof prev] }));
  };

  const handleFilterChange = (key: string, value: any) => {
    onFiltersChange({
      ...filters,
      [key]: value
    });
  };

  const toggleBrand = (brandName: string) => {
    const currentBrands = filters.brands || [];
    const newBrands = currentBrands.includes(brandName)
      ? currentBrands.filter((b: string) => b !== brandName)
      : [...currentBrands, brandName];
    handleFilterChange('brands', newBrands);
  };

  const toggleListingType = (type: string) => {
    const current = filters.listingTypes || [];
    const updated = current.includes(type)
      ? current.filter((t: string) => t !== type)
      : [...current, type];
    handleFilterChange('listingTypes', updated);
  };

  const toggleDelivery = (option: string) => {
    const current = filters.delivery || [];
    const updated = current.includes(option)
      ? current.filter((o: string) => o !== option)
      : [...current, option];
    handleFilterChange('delivery', updated);
  };

  const togglePayment = (method: string) => {
    const current = filters.payment || [];
    const updated = current.includes(method)
      ? current.filter((m: string) => m !== method)
      : [...current, method];
    handleFilterChange('payment', updated);
  };

  const pricePresets = [
    { label: 'Under 100K', range: [0, 100000] },
    { label: '100K-500K', range: [100000, 500000] },
    { label: '500K-1M', range: [500000, 1000000] },
    { label: '1M-5M', range: [1000000, 5000000] },
    { label: '5M+', range: [5000000, 10000000] },
  ];

  return (
    <div className="space-y-2">
      {/* Listing Type Filter */}
      <Collapsible 
        open={openSections.listing} 
        onOpenChange={() => toggleSection('listing')}
        className="border-b border-border pb-4"
      >
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2 hover:text-primary transition-colors">
          <div className="flex items-center gap-2">
            <Grid3X3 className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-foreground">Listing Type</h3>
            {filters.listingTypes?.length > 0 && (
              <Badge variant="secondary" className="text-xs">{filters.listingTypes.length}</Badge>
            )}
          </div>
          <ChevronDown className={`w-4 h-4 transition-transform ${openSections.listing ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-3 space-y-2">
          {listingTypes.map(({ id, name, icon: Icon }) => (
            <div key={id} className="flex items-center space-x-3 transition-all duration-200 hover:translate-x-1">
              <Checkbox 
                id={`listing-${id}`}
                checked={filters.listingTypes?.includes(id) || false}
                onCheckedChange={() => toggleListingType(id)}
              />
              <label 
                htmlFor={`listing-${id}`} 
                className="text-sm text-foreground cursor-pointer flex items-center gap-2 flex-1"
              >
                <Icon className="w-4 h-4 text-primary" />
                {name}
              </label>
            </div>
          ))}
        </CollapsibleContent>
      </Collapsible>

      {/* Location Filter */}
      <Collapsible 
        open={openSections.location} 
        onOpenChange={() => toggleSection('location')}
        className="border-b border-border pb-4"
      >
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2 hover:text-primary transition-colors">
          <h3 className="font-semibold text-foreground">Location & Region</h3>
          <ChevronDown className={`w-4 h-4 transition-transform ${openSections.location ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-3">
          <LocationFilter
            selectedRegion={filters.region || ''}
            selectedDistrict={filters.district || ''}
            selectedSubCounty={filters.subCounty || ''}
            onRegionChange={(region) => handleFilterChange('region', region)}
            onDistrictChange={(district) => handleFilterChange('district', district)}
            onSubCountyChange={(subCounty) => handleFilterChange('subCounty', subCounty)}
          />
        </CollapsibleContent>
      </Collapsible>

      {/* Price Range */}
      <Collapsible 
        open={openSections.price} 
        onOpenChange={() => toggleSection('price')}
        className="border-b border-border pb-4"
      >
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2 hover:text-primary transition-colors">
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-foreground">Price Range</h3>
          </div>
          <ChevronDown className={`w-4 h-4 transition-transform ${openSections.price ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-3 space-y-4">
          {/* Quick Presets */}
          <div className="flex flex-wrap gap-2">
            {pricePresets.map((preset) => (
              <Button
                key={preset.label}
                variant={
                  filters.priceRange?.[0] === preset.range[0] && 
                  filters.priceRange?.[1] === preset.range[1] 
                    ? "default" 
                    : "outline"
                }
                size="sm"
                onClick={() => handleFilterChange('priceRange', preset.range)}
                className="h-7 text-xs"
              >
                {preset.label}
              </Button>
            ))}
          </div>
          
          <div className="px-1 py-2">
            <Slider
              value={filters.priceRange || [0, 10000000]}
              onValueChange={(value) => handleFilterChange('priceRange', value)}
              max={10000000}
              step={50000}
              className="w-full"
            />
          </div>
          <div className="flex items-center justify-between gap-2">
            <div className="flex-1">
              <Label className="text-xs text-muted-foreground">Min</Label>
              <div className="text-sm font-medium">
                UGX {(filters.priceRange?.[0] || 0).toLocaleString()}
              </div>
            </div>
            <span className="text-muted-foreground">-</span>
            <div className="flex-1 text-right">
              <Label className="text-xs text-muted-foreground">Max</Label>
              <div className="text-sm font-medium">
                UGX {(filters.priceRange?.[1] || 10000000).toLocaleString()}
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="negotiable"
              checked={filters.negotiable || false}
              onCheckedChange={(checked) => handleFilterChange('negotiable', checked)}
            />
            <label htmlFor="negotiable" className="text-sm text-foreground cursor-pointer">
              Negotiable prices only
            </label>
          </div>
        </CollapsibleContent>
      </Collapsible>

      {/* Seller Filters */}
      <Collapsible 
        open={openSections.seller} 
        onOpenChange={() => toggleSection('seller')}
        className="border-b border-border pb-4"
      >
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2 hover:text-primary transition-colors">
          <div className="flex items-center gap-2">
            <Verified className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-foreground">Seller Options</h3>
          </div>
          <ChevronDown className={`w-4 h-4 transition-transform ${openSections.seller ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-3 space-y-4">
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="verified-sellers"
              checked={filters.verifiedOnly || false}
              onCheckedChange={(checked) => handleFilterChange('verifiedOnly', checked)}
            />
            <label htmlFor="verified-sellers" className="text-sm text-foreground cursor-pointer flex items-center gap-2">
              <Verified className="w-4 h-4 text-primary" />
              Verified sellers only
            </label>
          </div>
          
          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground">Seller Type</Label>
            <RadioGroup 
              value={filters.sellerType || 'all'} 
              onValueChange={(value) => handleFilterChange('sellerType', value)}
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="all" id="seller-all" />
                <label htmlFor="seller-all" className="text-sm cursor-pointer">All sellers</label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="regular" id="seller-regular" />
                <label htmlFor="seller-regular" className="text-sm cursor-pointer">Regular Seller</label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="registered_business" id="seller-business" />
                <label htmlFor="seller-business" className="text-sm cursor-pointer">Business Seller</label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground">Minimum Rating</Label>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((rating) => (
                <Button
                  key={rating}
                  variant={filters.minRating === rating ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleFilterChange('minRating', rating)}
                  className="h-8 w-8 p-0"
                >
                  {rating}★
                </Button>
              ))}
            </div>
          </div>
        </CollapsibleContent>
      </Collapsible>

      {/* Item Features */}
      <Collapsible 
        open={openSections.features} 
        onOpenChange={() => toggleSection('features')}
        className="border-b border-border pb-4"
      >
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2 hover:text-primary transition-colors">
          <div className="flex items-center gap-2">
            <Star className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-foreground">Item Features</h3>
          </div>
          <ChevronDown className={`w-4 h-4 transition-transform ${openSections.features ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-3 space-y-3">
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="has-images"
              checked={filters.hasImages || false}
              onCheckedChange={(checked) => handleFilterChange('hasImages', checked)}
            />
            <label htmlFor="has-images" className="text-sm text-foreground cursor-pointer">
              Has Images
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="has-video"
              checked={filters.hasVideo || false}
              onCheckedChange={(checked) => handleFilterChange('hasVideo', checked)}
            />
            <label htmlFor="has-video" className="text-sm text-foreground cursor-pointer">
              Has Video
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="featured"
              checked={filters.featured || false}
              onCheckedChange={(checked) => handleFilterChange('featured', checked)}
            />
            <label htmlFor="featured" className="text-sm text-foreground cursor-pointer">
              Featured/Boosted
            </label>
          </div>
        </CollapsibleContent>
      </Collapsible>

      {/* Date Posted */}
      <Collapsible 
        open={openSections.date} 
        onOpenChange={() => toggleSection('date')}
        className="border-b border-border pb-4"
      >
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2 hover:text-primary transition-colors">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-foreground">Date Posted</h3>
          </div>
          <ChevronDown className={`w-4 h-4 transition-transform ${openSections.date ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-3">
          <RadioGroup 
            value={filters.datePosted || ''} 
            onValueChange={(value) => handleFilterChange('datePosted', value)}
          >
            {dateOptions.map(({ label, value }) => (
              <div key={value} className="flex items-center space-x-2">
                <RadioGroupItem value={value} id={`date-${value}`} />
                <label htmlFor={`date-${value}`} className="text-sm cursor-pointer">{label}</label>
              </div>
            ))}
          </RadioGroup>
        </CollapsibleContent>
      </Collapsible>

      {/* Delivery & Payment */}
      <Collapsible 
        open={openSections.delivery} 
        onOpenChange={() => toggleSection('delivery')}
        className="border-b border-border pb-4"
      >
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2 hover:text-primary transition-colors">
          <div className="flex items-center gap-2">
            <Truck className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-foreground">Delivery & Payment</h3>
          </div>
          <ChevronDown className={`w-4 h-4 transition-transform ${openSections.delivery ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-3 space-y-4">
          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground">Delivery Options</Label>
            {deliveryOptions.map((option) => (
              <div key={option} className="flex items-center space-x-2">
                <Checkbox 
                  id={`delivery-${option}`}
                  checked={filters.delivery?.includes(option) || false}
                  onCheckedChange={() => toggleDelivery(option)}
                />
                <label htmlFor={`delivery-${option}`} className="text-sm text-foreground cursor-pointer">
                  {option}
                </label>
              </div>
            ))}
          </div>

          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground">Payment Methods</Label>
            {paymentMethods.map((method) => (
              <div key={method} className="flex items-center space-x-2">
                <Checkbox 
                  id={`payment-${method}`}
                  checked={filters.payment?.includes(method) || false}
                  onCheckedChange={() => togglePayment(method)}
                />
                <label htmlFor={`payment-${method}`} className="text-sm text-foreground cursor-pointer flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-muted-foreground" />
                  {method}
                </label>
              </div>
            ))}
          </div>
        </CollapsibleContent>
      </Collapsible>

      {/* Brands */}
      <Collapsible 
        open={openSections.brands} 
        onOpenChange={() => toggleSection('brands')}
        className="border-b border-border pb-4"
      >
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2 hover:text-primary transition-colors">
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-foreground">Brands</h3>
            {filters.brands?.length > 0 && (
              <Badge variant="secondary" className="text-xs">{filters.brands.length}</Badge>
            )}
          </div>
          <ChevronDown className={`w-4 h-4 transition-transform ${openSections.brands ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-3 space-y-3">
          <Input
            placeholder="Search brands..."
            value={brandSearch}
            onChange={(e) => setBrandSearch(e.target.value)}
            className="h-9"
          />
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {brandsLoading ? (
              <p className="text-sm text-muted-foreground">Loading brands...</p>
            ) : filteredBrands.length > 0 ? (
              filteredBrands.map((brand) => (
                <div key={brand.id} className="flex items-center space-x-2 transition-all duration-200 hover:translate-x-1">
                  <Checkbox 
                    id={`brand-${brand.id}`}
                    checked={filters.brands?.includes(brand.name) || false}
                    onCheckedChange={() => toggleBrand(brand.name)}
                  />
                  <label 
                    htmlFor={`brand-${brand.id}`} 
                    className="text-sm text-foreground cursor-pointer flex items-center gap-2"
                  >
                    {brand.logo_url && (
                      <Avatar className="h-4 w-4">
                        <AvatarImage src={brand.logo_url} alt={brand.name} />
                        <AvatarFallback className="text-[8px]">{brand.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                    )}
                    {brand.name}
                  </label>
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">No brands found</p>
            )}
          </div>
        </CollapsibleContent>
      </Collapsible>

      {/* Condition */}
      <Collapsible 
        open={openSections.condition} 
        onOpenChange={() => toggleSection('condition')}
        className="border-b border-border pb-4"
      >
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2 hover:text-primary transition-colors">
          <h3 className="font-semibold text-foreground">Condition</h3>
          <ChevronDown className={`w-4 h-4 transition-transform ${openSections.condition ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-3 space-y-2">
          {['New', 'Like New', 'Good', 'Fair', 'For Parts'].map((condition) => (
            <div key={condition} className="flex items-center space-x-2 transition-all duration-200 hover:translate-x-1">
              <Checkbox 
                id={`condition-${condition}`}
                checked={filters.condition === condition}
                onCheckedChange={(checked) => 
                  handleFilterChange('condition', checked ? condition : '')
                }
              />
              <label 
                htmlFor={`condition-${condition}`} 
                className="text-sm text-foreground cursor-pointer"
              >
                {condition}
              </label>
            </div>
          ))}
        </CollapsibleContent>
      </Collapsible>

      {/* Category */}
      <Collapsible 
        open={openSections.category} 
        onOpenChange={() => toggleSection('category')}
        className="border-b border-border pb-4"
      >
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2 hover:text-primary transition-colors">
          <h3 className="font-semibold text-foreground">Category</h3>
          <ChevronDown className={`w-4 h-4 transition-transform ${openSections.category ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-3 space-y-2 max-h-64 overflow-y-auto">
          {categories.map((category) => (
            <div key={category} className="flex items-center space-x-2 transition-all duration-200 hover:translate-x-1">
              <Checkbox 
                id={`category-${category}`}
                checked={filters.category === category}
                onCheckedChange={(checked) => 
                  handleFilterChange('category', checked ? category : '')
                }
              />
              <label 
                htmlFor={`category-${category}`} 
                className="text-sm text-foreground cursor-pointer"
              >
                {category}
              </label>
            </div>
          ))}
        </CollapsibleContent>
      </Collapsible>

      {/* Feedback Button */}
      <div className="pt-4">
        <Button 
          variant="default" 
          className="w-full"
          onClick={() => window.open('/feedback', '_blank')}
        >
          <MessageSquare className="w-4 h-4 mr-2" />
          Give Feedback
        </Button>
      </div>
    </div>
  );
};

export default SearchFilters;
