import React, { useRef } from 'react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { getSellerProfileUrl } from '@/lib/sellerUrl';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';

interface Seller {
  id: string;
  business_name: string;
  business_logo_url: string;
  is_verified: boolean;
  verification_badge_color?: BadgeColor;
  store_slug?: string;
}

interface SuggestedAccountsProps {
  sellers: Seller[];
  onFollow?: (sellerId: string) => void;
  followingStates?: { [key: string]: boolean };
}

const SuggestedAccounts: React.FC<SuggestedAccountsProps> = ({ 
  sellers, 
  onFollow, 
  followingStates = {} 
}) => {
  const navigate = useNavigate();
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  if (!sellers || sellers.length === 0) return null;

  return (
    <div className="border-b border-border py-5">
      <div className="px-4 mb-4 flex items-center justify-between">
        <h3 className="text-lg font-bold">Who to follow</h3>
        <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80 text-sm">
          Show more
        </Button>
      </div>
      
      <div className="relative px-4">
        {/* Horizontally scrollable container with Spotify/X style cards */}
        <div
          ref={scrollContainerRef}
          className="flex gap-3 overflow-x-auto scrollbar-hide scroll-smooth pb-2"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {sellers.map((seller, index) => (
            <motion.div
              key={seller.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1, duration: 0.3 }}
              className="flex-shrink-0 group cursor-pointer"
              onClick={() => navigate(getSellerProfileUrl(seller))}
            >
              {/* Spotify/X style transparent glassmorphic card */}
              <div className="relative w-[140px] rounded-2xl overflow-hidden bg-accent/5 backdrop-blur-sm border border-border/30 hover:border-border/60 hover:bg-accent/10 transition-all duration-300 group-hover:shadow-lg group-hover:shadow-primary/5">
                {/* Gradient overlay at top */}
                <div className="absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-primary/10 to-transparent" />
                
                <div className="relative p-4 pt-6 flex flex-col items-center">
                  {/* Avatar with ring */}
                  <div className="relative mb-3">
                    <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/40 to-primary/10 blur-md scale-110 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <Avatar className="w-14 h-14 ring-2 ring-border/50 group-hover:ring-primary/30 transition-all duration-300">
                      <AvatarImage src={seller.business_logo_url || ''} alt={seller.business_name} />
                      <AvatarFallback className="bg-muted text-foreground font-bold text-lg">
                        {seller.business_name.slice(0, 1).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    {/* Verified badge positioned on avatar */}
                    {seller.is_verified && (
                      <div className="absolute -bottom-0.5 -right-0.5 bg-background rounded-full p-0.5">
                        <UnifiedVerifiedBadge 
                          isVerified={seller.is_verified} 
                          badgeColor={seller.verification_badge_color}
                          size="sm" 
                        />
                      </div>
                    )}
                  </div>
                  
                  {/* Name and handle */}
                  <div className="w-full text-center mb-3">
                    <h4 className="font-bold text-sm truncate leading-tight">{seller.business_name}</h4>
                    <p className="text-xs text-muted-foreground truncate mt-0.5">
                      @{seller.store_slug || seller.id.slice(0, 8)}
                    </p>
                  </div>
                  
                  {/* Follow button - X/Spotify style */}
                  <Button
                    variant={followingStates[seller.id] ? "outline" : "default"}
                    size="sm"
                    className={`w-full rounded-full font-bold text-xs h-8 transition-all duration-200 ${
                      followingStates[seller.id] 
                        ? "bg-transparent border-border hover:border-red-500 hover:text-red-500 hover:bg-red-500/10" 
                        : "bg-foreground text-background hover:bg-foreground/90"
                    }`}
                    onClick={(e) => {
                      e.stopPropagation();
                      if (onFollow) {
                        onFollow(seller.id);
                      } else {
                        navigate(`/business/${seller.store_slug || seller.id}`);
                      }
                    }}
                  >
                    {followingStates[seller.id] ? 'Following' : 'Follow'}
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SuggestedAccounts;