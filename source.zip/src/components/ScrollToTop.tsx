import { useEffect, useRef } from 'react';
import { useLocation, useNavigationType } from 'react-router-dom';
import { setNavigatingBack } from '@/hooks/useFeedState';
import { KEEP_ALIVE_PATHS } from '@/components/routing/KeepAlive';

// Pages that should preserve scroll position on back navigation
const SCROLL_PRESERVE_PAGES = ['/discover', '/marketplace', '/search'];

const ScrollToTop = () => {
  const { pathname } = useLocation();
  const navigationType = useNavigationType();
  const prevPathname = useRef<string | null>(null);

  useEffect(() => {
    // Keep-alive pages (/discover, /marketplace) are never unmounted and
    // their scroll position is preserved natively by the browser. Do NOT
    // touch scroll for them — any reset here destroys that position on
    // return navigation, which was the bug users reported.
    if ((KEEP_ALIVE_PATHS as readonly string[]).includes(pathname)) {
      setNavigatingBack(false);
      prevPathname.current = pathname;
      return;
    }

    const isPreservePage = SCROLL_PRESERVE_PAGES.some(p => pathname.startsWith(p));
    
    // Track if we're navigating back to a scroll-preserve page
    if (navigationType === 'POP' && isPreservePage) {
      setNavigatingBack(true);
      prevPathname.current = pathname;
      return;
    }
    
    setNavigatingBack(false);

    // Only scroll to top for PUSH (new navigation) or REPLACE
    if (prevPathname.current !== pathname) {
      // Scroll window to top
      window.scrollTo(0, 0);
      
      // Reset main content scroll
      const mainContent = document.querySelector('main');
      if (mainContent) {
        mainContent.scrollTo(0, 0);
      }
    }
    
    prevPathname.current = pathname;
  }, [pathname, navigationType]);

  return null;
};

export default ScrollToTop;
