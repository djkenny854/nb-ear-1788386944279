// Capacitor Provider - Initializes all native features
import React, { useEffect, useState } from 'react';
import { useCapacitorBackButton } from '@/hooks/useCapacitorBackButton';
import { useDeepLinks } from '@/hooks/useDeepLinks';
import { useStatusBar, useSafeArea } from '@/hooks/useStatusBar';
import { useCapacitorPushNotifications } from '@/hooks/useCapacitorPushNotifications';
import { useKeyboard } from '@/hooks/useKeyboard';
import { useScreenOrientation } from '@/hooks/useScreenOrientation';
import { isCapacitorNative, isRealNativeRuntime } from '@/hooks/useCapacitor';
import { NativePermissionsGate } from '@/components/NativePermissionsGate';

interface CapacitorProviderProps {
  children: React.ReactNode;
}

export const CapacitorProvider: React.FC<CapacitorProviderProps> = ({ children }) => {
  const [isInitialized, setIsInitialized] = useState(!isCapacitorNative());
  
  // These hooks are safe to call - they check isCapacitorNative internally
  useCapacitorBackButton();
  useDeepLinks();
  useStatusBar();
  useSafeArea();
  useCapacitorPushNotifications();
  useKeyboard();
  useScreenOrientation();

  useEffect(() => {
    if (!isCapacitorNative()) {
      setIsInitialized(true);
      return;
    }

    // Only run plugin init when real Capacitor runtime exists
    if (!isRealNativeRuntime()) {
      console.log('[CapacitorProvider] Override mode — skipping native plugin init');
      setIsInitialized(true);
      return;
    }

    const setup = async () => {
      // Splash screen - wrapped individually to prevent crash cascade
      try {
        const SplashModule = await import('@capacitor/splash-screen').catch(() => null);
        if (SplashModule?.SplashScreen) {
          await SplashModule.SplashScreen.hide();
        }
      } catch { /* ignore */ }

      // Status bar - wrapped individually
      try {
        const StatusBarModule = await import('@capacitor/status-bar').catch(() => null);
        if (StatusBarModule?.StatusBar) {
          // Edge-to-edge: do not set bar background/overlay (deprecated on Android 15+).
          // Only icon style is managed (see useStatusBar). Content is padded via safe-area insets.
        }
      } catch { /* ignore */ }

      // App state listener - wrapped individually
      try {
        const AppModule = await import('@capacitor/app').catch(() => null);
        if (AppModule?.App) {
          await AppModule.App.addListener('appStateChange', ({ isActive }: { isActive: boolean }) => {
            document.body.classList.toggle('app-background', !isActive);
          });
        }
      } catch { /* ignore */ }

      setIsInitialized(true);
    };

    setup();
    
    const fallbackTimer = setTimeout(() => {
      setIsInitialized(true);
    }, 2000);

    return () => clearTimeout(fallbackTimer);
  }, []);

  return (
    <>
      <NativePermissionsGate />
      {children}
    </>
  );
};

export const hapticFeedback = {
  light: async () => {
    if (!isRealNativeRuntime()) return;
    try {
      const HapticsModule = await import('@capacitor/haptics');
      if (HapticsModule) await HapticsModule.Haptics.impact({ style: HapticsModule.ImpactStyle.Light });
    } catch { /* ignore */ }
  },
  medium: async () => {
    if (!isRealNativeRuntime()) return;
    try {
      const HapticsModule = await import('@capacitor/haptics');
      if (HapticsModule) await HapticsModule.Haptics.impact({ style: HapticsModule.ImpactStyle.Medium });
    } catch { /* ignore */ }
  },
};
