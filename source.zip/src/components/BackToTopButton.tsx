import { useEffect, useState } from 'react';
import { ArrowUp } from 'lucide-react';
import { cn } from '@/lib/utils';

/**
 * Floating "back to top" button.
 *
 * Visibility rules (per spec):
 *   • Hidden when scroll position is near the top (< 400px).
 *   • Visible when the user has scrolled down past 400px AND the last
 *     scroll direction was downward — i.e. it appears when they've gone
 *     "far" and disappears the moment they start scrolling back up.
 */
const BackToTopButton = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    let lastY = window.scrollY;
    let raf = 0;

    const update = () => {
      const y = window.scrollY;
      const goingDown = y > lastY;
      if (y < 400) {
        setVisible(false);
      } else if (goingDown) {
        setVisible(true);
      } else {
        setVisible(false);
      }
      lastY = y;
      raf = 0;
    };

    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(update);
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  const handleClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <button
      type="button"
      aria-label="Back to top"
      onClick={handleClick}
      className={cn(
        'fixed left-4 bottom-20 z-40 h-11 w-11 rounded-full bg-primary text-primary-foreground shadow-lg',
        'flex items-center justify-center transition-all duration-200',
        visible ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-3 pointer-events-none',
      )}
    >
      <ArrowUp className="w-5 h-5" />
    </button>
  );
};

export default BackToTopButton;
