// Single-screen animated onboarding for native mode.
// Follows the system default theme (light or dark) via `bg-background`.
import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { isRealNativeRuntime } from '@/hooks/useCapacitor';

const STORAGE_KEY = 'earlymarket_onboarding_complete';

const safePreferencesSet = async (key: string, value: string): Promise<void> => {
  if (!isRealNativeRuntime()) return;
  try {
    const { Preferences } = await import('@capacitor/preferences');
    await Preferences.set({ key, value });
  } catch {}
};

const ROTATING_PHRASES = [
  'Discover trusted sellers, services, and verified businesses near you.',
  'Reach thousands of buyers across the country in just a few taps.',
  'Hire skilled professionals or post jobs that fit your team perfectly.',
  'Promote your brand with smart AI-powered listings that stand out.',
  'Connect, chat, and grow a real community around what you sell.',
];

interface Props {
  onFinish: () => void;
}

const NativeOnboarding: React.FC<Props> = ({ onFinish }) => {
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setIdx((i) => (i + 1) % ROTATING_PHRASES.length), 3200);
    return () => clearInterval(t);
  }, []);

  const finish = () => {
    localStorage.setItem(STORAGE_KEY, 'true');
    safePreferencesSet(STORAGE_KEY, 'true');
    onFinish();
  };

  return (
    <div
      className="fixed inset-0 z-[100] bg-background text-foreground flex flex-col overflow-hidden"
      style={{
        paddingTop: 'env(safe-area-inset-top)',
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      {/* Irregular gradient blob shapes in the corners */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Top-left irregular blob */}
        <div
          className="absolute -top-32 -left-24 w-[460px] h-[460px] opacity-70"
          style={{
            background:
              'radial-gradient(circle at 30% 30%, hsl(var(--primary) / 0.55), transparent 65%)',
            filter: 'blur(70px)',
            borderRadius: '47% 53% 62% 38% / 41% 59% 41% 59%',
          }}
        />
        {/* Top-right irregular blob */}
        <div
          className="absolute -top-24 -right-20 w-[380px] h-[380px] opacity-60"
          style={{
            background:
              'radial-gradient(circle at 60% 40%, hsl(280 85% 60% / 0.5), transparent 70%)',
            filter: 'blur(80px)',
            borderRadius: '62% 38% 47% 53% / 55% 45% 55% 45%',
          }}
        />
        {/* Bottom-left irregular blob */}
        <div
          className="absolute -bottom-32 -left-16 w-[420px] h-[420px] opacity-65"
          style={{
            background:
              'radial-gradient(circle at 40% 60%, hsl(200 95% 55% / 0.55), transparent 70%)',
            filter: 'blur(75px)',
            borderRadius: '38% 62% 53% 47% / 47% 53% 47% 53%',
          }}
        />
        {/* Bottom-right irregular blob */}
        <div
          className="absolute -bottom-28 -right-24 w-[440px] h-[440px] opacity-65"
          style={{
            background:
              'radial-gradient(circle at 50% 50%, hsl(25 95% 60% / 0.5), transparent 70%)',
            filter: 'blur(85px)',
            borderRadius: '53% 47% 38% 62% / 59% 41% 59% 41%',
          }}
        />
        {/* Dark backdrop-filter overlay that adapts to theme */}
        <div className="absolute inset-0 bg-background/50 backdrop-blur-[3px]" />
      </div>

      {/* Center content (no top logo/brand) */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 text-center">
        <motion.h1
          className="text-4xl sm:text-5xl font-extrabold tracking-tight leading-[1.05]"
          initial={{ opacity: 0, y: 30, filter: 'blur(8px)' }}
          animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
          transition={{ duration: 0.8, delay: 0.2, ease: 'easeOut' }}
        >
          Social Business
        </motion.h1>
        <motion.h1
          className="text-4xl sm:text-5xl font-extrabold tracking-tight leading-[1.05] bg-gradient-to-r from-primary via-blue-500 to-purple-500 bg-clip-text text-transparent"
          initial={{ opacity: 0, y: 30, filter: 'blur(8px)' }}
          animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
          transition={{ duration: 0.8, delay: 0.45, ease: 'easeOut' }}
        >
          Marketplace platform.
        </motion.h1>

        <motion.p
          className="mt-6 text-base text-foreground/75 max-w-sm leading-relaxed"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.8 }}
        >
          Buy, sell, hire, and grow real businesses — all in one place.
        </motion.p>

        {/* Blur-rotating assurance text */}
        <div className="relative w-full max-w-md min-h-[72px] mt-8">
          <AnimatePresence mode="wait">
            <motion.p
              key={idx}
              initial={{ opacity: 0, y: 10, filter: 'blur(8px)' }}
              animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
              exit={{ opacity: 0, y: -10, filter: 'blur(8px)' }}
              transition={{ duration: 0.55 }}
              className="absolute inset-0 flex items-center justify-center text-base sm:text-lg font-medium text-foreground/85 leading-relaxed px-2"
            >
              {ROTATING_PHRASES[idx]}
            </motion.p>
          </AnimatePresence>
        </div>
      </div>

      {/* Bottom CTA */}
      <motion.div
        className="relative z-10 px-6 pb-8 flex justify-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 1.1 }}
      >
        <button
          onClick={finish}
          className="h-14 px-10 rounded-full bg-primary text-primary-foreground font-semibold text-base flex items-center gap-2 active:scale-[0.97] transition-transform shadow-xl shadow-primary/30"
        >
          Get Started
          <ArrowRight className="w-4 h-4" />
        </button>
      </motion.div>
    </div>
  );
};

export default NativeOnboarding;
