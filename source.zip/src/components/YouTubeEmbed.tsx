import React, { useRef, useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Play, Pause } from 'lucide-react';

interface YouTubeEmbedProps {
  url: string;
  autoPlay?: boolean;
  onInView?: boolean;
  className?: string;
  width?: string;
  height?: string;
  title?: string;
}

const YouTubeEmbed: React.FC<YouTubeEmbedProps> = ({ 
  url, 
  autoPlay = false, 
  onInView = false,
  className = '',
  width = '100%',
  height = '315',
  title = 'YouTube video'
}) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  const getYouTubeVideoId = (url: string) => {
    const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
    const match = url.match(regex);
    return match ? match[1] : null;
  };

  const videoId = getYouTubeVideoId(url);

  useEffect(() => {
    if (!onInView) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsVisible(entry.isIntersecting);
        if (entry.isIntersecting && autoPlay) {
          setIsPlaying(true);
        }
      },
      { threshold: 0.5 }
    );

    if (iframeRef.current) {
      observer.observe(iframeRef.current);
    }

    return () => observer.disconnect();
  }, [onInView, autoPlay]);

  if (!videoId) {
    return (
      <Card className={`p-4 bg-gray-50 ${className}`}>
        <div className="text-center text-gray-500">
          <Play className="w-8 h-8 mx-auto mb-2" />
          <p className="text-sm">Invalid YouTube URL</p>
        </div>
      </Card>
    );
  }

  const embedUrl = `https://www.youtube.com/embed/${videoId}?${
    (isPlaying || (autoPlay && isVisible)) ? 'autoplay=1&' : ''
  }mute=1&controls=1&rel=0&modestbranding=1&playsinline=1`;

  return (
    <div className={`relative ${className}`} style={{ width }}>
      <iframe
        ref={iframeRef}
        src={embedUrl}
        title={title}
        width="100%"
        height={height}
        frameBorder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowFullScreen
        className="rounded-lg shadow-sm"
      />
      {!isPlaying && (
        <div 
          className="absolute inset-0 flex items-center justify-center bg-black/20 rounded-lg cursor-pointer hover:bg-black/30 transition-colors"
          onClick={() => setIsPlaying(true)}
        >
          <div className="bg-red-600 rounded-full p-3 hover:bg-red-700 transition-colors">
            <Play className="w-8 h-8 text-white fill-white" />
          </div>
        </div>
      )}
    </div>
  );
};

export default YouTubeEmbed;