import React from 'react';
import { cn } from '@/lib/utils';

/**
 * Text-line placeholder skeleton for ServiceDetails.
 * Uses a shimmer animation across realistic text-shaped bars
 * instead of generic block placeholders.
 */

const Line: React.FC<{ className?: string }> = ({ className }) => (
  <div
    className={cn(
      'h-3 rounded-full bg-gradient-to-r from-muted via-muted/60 to-muted bg-[length:200%_100%] animate-[shimmer_1.6s_infinite]',
      className
    )}
  />
);

const Block: React.FC<{ className?: string }> = ({ className }) => (
  <div
    className={cn(
      'rounded-2xl bg-gradient-to-r from-muted via-muted/60 to-muted bg-[length:200%_100%] animate-[shimmer_1.6s_infinite]',
      className
    )}
  />
);

const ServiceDetailsSkeleton: React.FC = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Inline keyframes (scoped via Tailwind arbitrary animation) */}
      <style>{`
        @keyframes shimmer { 0% { background-position: 200% 0 } 100% { background-position: -200% 0 } }
      `}</style>

      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border/40">
        <div className="flex items-center justify-between px-4 py-3 max-w-7xl mx-auto">
          <div className="h-8 w-8 rounded-full bg-muted animate-pulse" />
          <div className="flex gap-2">
            <div className="h-8 w-8 rounded-full bg-muted animate-pulse" />
            <div className="h-8 w-8 rounded-full bg-muted animate-pulse" />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-4 space-y-5">
        {/* Hero / cover */}
        <Block className="w-full aspect-[16/10] md:aspect-[21/9]" />

        {/* Provider row */}
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-full bg-muted animate-pulse shrink-0" />
          <div className="flex-1 space-y-2">
            <Line className="w-40 h-4" />
            <Line className="w-24" />
          </div>
          <div className="h-9 w-24 rounded-full bg-muted animate-pulse" />
        </div>

        {/* Title + meta */}
        <div className="space-y-3">
          <Line className="w-3/4 h-5" />
          <Line className="w-1/2 h-4" />
          <div className="flex gap-2 pt-1">
            <div className="h-6 w-16 rounded-full bg-muted animate-pulse" />
            <div className="h-6 w-20 rounded-full bg-muted animate-pulse" />
            <div className="h-6 w-14 rounded-full bg-muted animate-pulse" />
          </div>
        </div>

        {/* Tabs row */}
        <div className="flex gap-2 border-b border-border/40 pb-2">
          {['Activity', 'Catalogs', 'FAQ'].map((_, i) => (
            <div key={i} className="h-8 w-24 rounded-full bg-muted animate-pulse" />
          ))}
        </div>

        {/* Description paragraph */}
        <div className="space-y-2">
          <Line className="w-full" />
          <Line className="w-[95%]" />
          <Line className="w-[88%]" />
          <Line className="w-[72%]" />
          <Line className="w-[60%]" />
        </div>

        {/* Catalog item placeholders */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="flex gap-3 p-3 rounded-2xl border border-border/40">
              <Block className="w-20 h-20 shrink-0 rounded-xl" />
              <div className="flex-1 space-y-2 py-1">
                <Line className="w-3/4 h-4" />
                <Line className="w-1/2" />
                <Line className="w-1/3 h-4 mt-1" />
              </div>
            </div>
          ))}
        </div>

        {/* Footer action bar */}
        <div className="flex gap-3 pt-4">
          <div className="flex-1 h-12 rounded-full bg-muted animate-pulse" />
          <div className="flex-1 h-12 rounded-full bg-muted animate-pulse" />
        </div>
      </div>
    </div>
  );
};

export default ServiceDetailsSkeleton;
