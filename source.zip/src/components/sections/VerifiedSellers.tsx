import React from 'react';
import SectionSkeleton from '@/components/sections/SectionSkeleton';
import { ChevronRight, ShieldCheck, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { getSellerProfileUrl } from '@/lib/sellerUrl';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';
import { useBlockedUsers } from '@/hooks/useBlockedUsers';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';
import RailScroller from '@/components/common/RailScroller';

interface VerifiedSellersProps {
  onSeeAll?: () => void;
}

const VerifiedSellers: React.FC<VerifiedSellersProps> = ({ onSeeAll }) => {
  const navigate = useNavigate();
  const { allBlockedIds } = useBlockedUsers();
  const { isOnline } = useNetworkStatus();

  const { data: sellers, isLoading } = useQuery({
    queryKey: ['verified-sellers-section'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('seller_profiles')
        .select(`
          id,
          user_id,
          business_name,
          business_logo_url,
          business_category,
          is_verified,
          verification_badge_color,
          follower_count,
          store_slug
        `)
        .eq('is_verified', true)
        .order('follower_count', { ascending: false })
        .limit(10);

      if (error) throw error;
      return data || [];
    },
    staleTime: 1000 * 60 * 5,
    enabled: isOnline,
  });

  const formatFollowers = (count: number) => {
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count?.toString() || '0';
  };

  if (isLoading && isOnline) {
    return <SectionSkeleton type="seller" count={5} />;
  }

  const filteredSellers = (sellers || []).filter(
    s => !allBlockedIds.includes(s.user_id)
  );

  if (!filteredSellers.length) {
    return null;
  }

  return (
    <section className="py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <ShieldCheck id="verified-sellers-header-icon" className="w-7 h-7 text-primary" strokeWidth={2.5} />
          <div>
            <h2 className="text-xl font-bold text-foreground tracking-tight">Verified Sellers You Can Trust</h2>
            <p className="text-xs text-muted-foreground">Shop with confidence</p>
          </div>
        </div>
        {onSeeAll && (
          <Button variant="ghost" size="sm" onClick={onSeeAll} className="text-primary">
            See All
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        )}
      </div>

      {/* Sellers Grid */}
      <RailScroller>
      <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4">
        {filteredSellers.map((seller, index) => (
          <motion.div
            key={seller.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            whileHover={{ y: -4, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => navigate(getSellerProfileUrl(seller))}
            className="group cursor-pointer flex flex-col items-center text-center min-w-[140px] max-w-[160px]"
          >
            {/* Avatar */}
            <div className="relative mb-3">
              <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-border group-hover:border-primary transition-colors duration-300">
                <img
                  src={seller.business_logo_url || '/placeholder.svg'}
                  alt={seller.business_name || 'Seller'}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              {seller.is_verified && (
                <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-background flex items-center justify-center">
                  <UnifiedVerifiedBadge 
                    isVerified={seller.is_verified} 
                    badgeColor={seller.verification_badge_color as BadgeColor}
                    size="md" 
                  />
                </div>
              )}
            </div>

            {/* Name */}
            <h3 className="font-semibold text-sm text-foreground line-clamp-1 group-hover:text-primary transition-colors">
              {seller.business_name || 'Seller'}
            </h3>

            {/* Category */}
            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">
              {seller.business_category || 'General'}
            </p>

            {/* Stats */}
            <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <Users className="w-3 h-3" />
                <span>{formatFollowers(seller.follower_count || 0)}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
      </RailScroller>
    </section>
  );
};

export default VerifiedSellers;
