import React from 'react';
import LatestJobsList from '@/components/jobs/LatestJobsList';

interface JobsSectionProps {
  onSeeAll?: () => void;
}

const JobsSection: React.FC<JobsSectionProps> = ({ onSeeAll }) => {
  return (
    <div className="py-2">
      <LatestJobsList limit={5} onSeeAll={onSeeAll} />
    </div>
  );
};

export default JobsSection;
