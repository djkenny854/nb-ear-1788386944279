import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useNavigate } from "react-router-dom";
import {
  MarketplaceIllustration,
  VerificationIllustration,
  BoostIllustration,
  ChatIllustration,
  ServicesIllustration,
  SearchIllustration,
} from "@/components/banner/BannerIllustrations";
import EMIIcon from "@/components/icons/EMIIcon";
import googlePlayBadge from "@/assets/google-play-badge.svg";
import appStoreBadge from "@/assets/app-store-badge.svg";
import { isCapacitorNative } from "@/hooks/useCapacitor";

interface BulletPoint {
  text: string;
  highlight?: boolean;
  italic?: boolean;
}

interface Banner {
  id: string;
  title: string;
  highlightedWord?: string;
  subtitle: string;
  bullets: BulletPoint[];
  illustration: React.FC<{ className?: string }>;
  gradient: { from: string; to: string };
  cta?: string;
  route?: string;
  isAppBanner?: boolean;
  isStudioBanner?: boolean;
}

const allBanners: Banner[] = [
  {
    id: "1",
    title: "Buy & Sell",
    highlightedWord: "Anything",
    subtitle: "Your social business marketplace",
    bullets: [
      { text: "Products, services, jobs & events", highlight: true },
      { text: "Verified sellers you can trust" },
      { text: "More features coming soon", italic: true },
    ],
    illustration: MarketplaceIllustration,
    gradient: { from: "hsl(221 83% 53% / 0.95)", to: "hsl(271 81% 56% / 0.95)" },
    cta: "Start Shopping",
    route: "/marketplace",
  },
  {
    id: "2",
    title: "Get Verified",
    highlightedWord: "Today",
    subtitle: "Build trust with buyers",
    bullets: [
      { text: "Earn your verification badge", highlight: true },
      { text: "Stand out from competitors" },
      { text: "Increase buyer confidence" },
    ],
    illustration: VerificationIllustration,
    gradient: { from: "hsl(152 69% 40% / 0.95)", to: "hsl(168 76% 42% / 0.95)" },
    cta: "Get Verified",
    route: "/verification",
  },
  {
    id: "3",
    title: "Boost Your",
    highlightedWord: "Listings",
    subtitle: "Reach more buyers faster",
    bullets: [
      { text: "Promoted ads get 5x more views", highlight: true },
      { text: "Flexible boost plans" },
      { text: "Track your performance", italic: true },
    ],
    illustration: BoostIllustration,
    gradient: { from: "hsl(24 95% 53% / 0.95)", to: "hsl(330 81% 60% / 0.95)" },
    cta: "Boost Now",
    route: "/boost-ad",
  },
  {
    id: "4",
    title: "Chat with",
    highlightedWord: "Sellers",
    subtitle: "Instant messaging to close deals",
    bullets: [
      { text: "Negotiate directly", highlight: true },
      { text: "Share images & voice notes" },
      { text: "Safe & private messaging" },
    ],
    illustration: ChatIllustration,
    gradient: { from: "hsl(210 100% 50% / 0.95)", to: "hsl(200 90% 45% / 0.95)" },
    cta: "Open Messages",
    route: "/messages",
  },
  {
    id: "5",
    title: "Browse",
    highlightedWord: "Services",
    subtitle: "Hire skilled professionals",
    bullets: [
      { text: "Find experts near you", highlight: true },
      { text: "Compare service providers" },
      { text: "EarlyMarket Intelligence (EMI)", italic: true },
    ],
    illustration: ServicesIllustration,
    gradient: { from: "hsl(271 81% 56% / 0.95)", to: "hsl(330 81% 60% / 0.95)" },
    cta: "Browse Services",
    route: "/marketplace?contentType=services",
  },
  {
    id: "6",
    title: "AI-Powered",
    highlightedWord: "Search",
    subtitle: "Smart matching technology",
    bullets: [
      { text: "Find exactly what you need", highlight: true },
      { text: "Powered by EarlyMarket Intelligence" },
      { text: "Discover your social feed", italic: true },
    ],
    illustration: SearchIllustration,
    gradient: { from: "hsl(330 81% 55% / 0.95)", to: "hsl(24 95% 53% / 0.95)" },
    cta: "Try Search",
    route: "/marketplace",
  },
  {
    id: "7",
    title: "Get the",
    highlightedWord: "App",
    subtitle: "EarlyMarket on your phone",
    bullets: [
      { text: "Available on Google Play Store", highlight: true },
      { text: "Apple App Store — Coming Soon", italic: true },
      { text: "All features, on the go" },
    ],
    illustration: null as unknown as React.FC<{ className?: string }>,
    gradient: { from: "hsl(145 65% 42% / 0.95)", to: "hsl(210 90% 50% / 0.95)" },
    cta: "Download App",
    route: "https://play.google.com/store",
    isAppBanner: true,
  },
  {
    id: "8",
    title: "EarlyMarket",
    highlightedWord: "Studio",
    subtitle: "Coming Soon",
    bullets: [
      { text: "Enhanced EarlyMarket Intelligence (EMI)", highlight: true },
      { text: "Advanced analytics & insights" },
      { text: "Creator tools for sellers", italic: true },
    ],
    illustration: null as unknown as React.FC<{ className?: string }>,
    gradient: { from: "hsl(271 81% 56% / 0.95)", to: "hsl(221 83% 53% / 0.95)" },
    isStudioBanner: true,
  },
];

const CYCLE_MS = 7000;

interface HeroSectionProps {
  onSearch?: (query: string) => void;
}

const HeroSection: React.FC<HeroSectionProps> = () => {
  const navigate = useNavigate();
  const [activeIndex, setActiveIndex] = useState(0);
  const [displayIndex, setDisplayIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const timerRef = useRef<number | null>(null);

  // Filter out app banner when in native mode
  const banners = useMemo(() => {
    if (isCapacitorNative()) {
      return allBanners.filter((b) => !b.isAppBanner);
    }
    return allBanners;
  }, []);

  const clearTimer = useCallback(() => {
    if (timerRef.current) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const startTimer = useCallback(() => {
    clearTimer();
    timerRef.current = window.setTimeout(() => {
      goTo((prev) => (prev + 1) % banners.length);
    }, CYCLE_MS);
  }, [clearTimer, banners.length]);

  const goTo = useCallback((indexOrFn: number | ((prev: number) => number)) => {
    setIsTransitioning(true);
    setTimeout(() => {
      setActiveIndex((prev) => {
        const next = typeof indexOrFn === "function" ? indexOrFn(prev) : indexOrFn;
        setDisplayIndex(next);
        return next;
      });
      setTimeout(() => setIsTransitioning(false), 50);
    }, 250);
  }, []);

  useEffect(() => {
    startTimer();
    return clearTimer;
  }, [activeIndex, startTimer, clearTimer]);

  const handleGoTo = useCallback((index: number) => {
    if (index === activeIndex) return;
    clearTimer();
    goTo(index);
  }, [activeIndex, clearTimer, goTo]);

  const goToPrev = useCallback(() => {
    clearTimer();
    goTo((prev) => (prev - 1 + banners.length) % banners.length);
  }, [clearTimer, goTo, banners.length]);

  const goToNext = useCallback(() => {
    clearTimer();
    goTo((prev) => (prev + 1) % banners.length);
  }, [clearTimer, goTo, banners.length]);

  const handleCtaClick = useCallback(() => {
    const banner = banners[displayIndex];
    if (banner.route?.startsWith("http")) {
      window.open(banner.route, "_blank");
    } else if (banner.route) {
      navigate(banner.route);
    }
  }, [displayIndex, navigate, banners]);

  const displayed = banners[displayIndex] || banners[0];
  const CurrentIllustration = displayed.illustration;

  const gradientCss = (g: Banner["gradient"]) =>
    `linear-gradient(135deg, ${g.from} 0%, ${g.to} 100%)`;

  return (
    <section className="relative overflow-visible mx-3 sm:mx-4 mt-3 sm:mt-4">
      <div className="relative h-[160px] sm:h-[170px] md:h-[220px] rounded-2xl overflow-hidden">
        {/* Gradient bg */}
        <div
          className="absolute inset-0 transition-all duration-700"
          style={{ background: gradientCss(displayed.gradient) }}
        />

        {/* Pattern overlay */}
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage: `radial-gradient(circle at 25% 25%, white 1px, transparent 1px), radial-gradient(circle at 75% 75%, white 1px, transparent 1px)`,
            backgroundSize: "40px 40px",
          }}
        />

        {/* Content layout */}
        <div className="relative h-full flex items-center">
          {/* Text side */}
          <div
            className="flex-1 flex flex-col justify-center pl-8 sm:pl-10 md:pl-12 pr-2 py-4 sm:py-5 md:py-8 z-10 min-w-0"
            style={{
              filter: isTransitioning ? "blur(10px)" : "blur(0px)",
              opacity: isTransitioning ? 0 : 1,
              transform: isTransitioning ? "translateY(4px)" : "translateY(0)",
              transition: "filter 250ms, opacity 250ms, transform 250ms",
            }}
          >
            {/* Title with Geom font */}
            <h1
              className="text-lg sm:text-xl md:text-3xl lg:text-4xl font-bold text-white leading-tight"
              style={{ fontFamily: "'Orbitron', 'Outfit', sans-serif" }}
            >
              {displayed.title}{" "}
              {displayed.highlightedWord && (
                <span className="text-yellow-300 drop-shadow-sm">
                  {displayed.highlightedWord}
                </span>
              )}
            </h1>

            <p className="text-[10px] sm:text-xs md:text-sm text-white/80 mt-0.5 sm:mt-1">
              {displayed.subtitle}
            </p>

            {/* Bullet points */}
            <ul className="mt-1.5 sm:mt-2 space-y-0.5 sm:space-y-1">
              {displayed.bullets.map((b, i) => (
                <li
                  key={i}
                  className="flex items-start gap-1 sm:gap-1.5 text-[9px] sm:text-[10px] md:text-xs text-white/90"
                >
                  <Check className="w-2.5 h-2.5 sm:w-3 sm:h-3 mt-0.5 shrink-0 text-yellow-300" />
                  <span
                    className={cn(
                      b.highlight && "font-semibold text-white",
                      b.italic && "italic text-white/70"
                    )}
                  >
                    {b.text}
                  </span>
                </li>
              ))}
            </ul>

            {displayed.cta && (
              <Button
                variant="secondary"
                size="sm"
                onClick={handleCtaClick}
                className="mt-2 sm:mt-3 w-fit bg-white/95 text-gray-900 hover:bg-white font-semibold text-[10px] sm:text-xs md:text-sm shadow-lg h-7 sm:h-8 px-3 sm:px-4"
              >
                {displayed.cta}
              </Button>
            )}
          </div>

          {/* Illustration — visible on all sizes, bigger on mobile */}
          <div
            className="flex items-center justify-center w-[130px] sm:w-[170px] md:w-[250px] lg:w-[300px] h-full shrink-0 pr-1 sm:pr-3 -ml-6 sm:ml-0"
            style={{
              filter: isTransitioning ? "blur(8px)" : "blur(0px)",
              opacity: isTransitioning ? 0.4 : 0.9,
              transition: "filter 250ms, opacity 250ms",
            }}
          >
            {displayed.isStudioBanner ? (
              <EMIIcon className="w-20 h-20 sm:w-24 sm:h-24 md:w-32 md:h-32" spin />
            ) : displayed.isAppBanner ? (
              <div className="flex flex-col items-center gap-1.5 sm:gap-2">
                <a href="https://play.google.com/store" target="_blank" rel="noopener noreferrer">
                  <img src={googlePlayBadge} alt="Get it on Google Play" className="h-8 sm:h-10 md:h-12 w-auto" />
                </a>
                <div className="relative">
                  <img src={appStoreBadge} alt="Download on the App Store" className="h-8 sm:h-10 md:h-12 w-auto opacity-50 grayscale" />
                  <span className="absolute -bottom-3 sm:-bottom-4 left-1/2 -translate-x-1/2 text-[7px] sm:text-[8px] text-white/70 font-medium whitespace-nowrap bg-black/30 px-1.5 py-0.5 rounded-full">
                    Coming Soon
                  </span>
                </div>
              </div>
            ) : (
              CurrentIllustration && <CurrentIllustration className="w-full h-full" />
            )}
          </div>
        </div>

        {/* Prev / Next buttons */}
        <button
          onClick={goToPrev}
          className="absolute left-1.5 sm:left-2 top-1/2 -translate-y-1/2 w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 rounded-full bg-white/15 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/30 transition-colors z-20"
          aria-label="Previous banner"
        >
          <ChevronLeft className="w-3.5 h-3.5 sm:w-4 sm:h-4 md:w-5 md:h-5" />
        </button>
        <button
          onClick={goToNext}
          className="absolute right-1.5 sm:right-2 top-1/2 -translate-y-1/2 w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 rounded-full bg-white/15 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/30 transition-colors z-20"
          aria-label="Next banner"
        >
          <ChevronRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 md:w-5 md:h-5" />
        </button>

        {/* Dots */}
        <div className="absolute bottom-2 sm:bottom-3 left-1/2 -translate-x-1/2 flex gap-1 sm:gap-1.5 z-20">
          {banners.map((_, index) => (
            <button
              key={index}
              onClick={() => handleGoTo(index)}
              className={cn(
                "h-1.5 sm:h-2 rounded-full transition-all duration-300",
                index === activeIndex
                  ? "bg-white w-4 sm:w-5 md:w-6"
                  : "bg-white/40 hover:bg-white/60 w-1.5 sm:w-2"
              )}
              aria-label={`Go to banner ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
