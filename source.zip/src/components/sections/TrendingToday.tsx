import React from 'react';
import { TrendingUp } from 'lucide-react';
import ContentCarousel from './ContentCarousel';
import ListingCard from '@/components/cards/ListingCard';
import { mockListings } from '@/data/mockData';

interface TrendingTodayProps {
  onSeeAll?: () => void;
}

const TrendingToday: React.FC<TrendingTodayProps> = ({ onSeeAll }) => {
  // Sort by views to get trending items
  const trendingItems = [...mockListings].sort((a, b) => b.views - a.views).slice(0, 10);

  return (
    <ContentCarousel
      title="Trending Today"
      subtitle="Most viewed items right now"
      icon={<TrendingUp className="w-5 h-5" />}
      onSeeAll={onSeeAll}
    >
      {trendingItems.map((listing) => (
        <div key={listing.id} style={{ scrollSnapAlign: 'start' }}>
          <ListingCard listing={listing} />
        </div>
      ))}
    </ContentCarousel>
  );
};

export default TrendingToday;
