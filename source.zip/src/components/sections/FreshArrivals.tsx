import React from 'react';
import { Sparkles } from 'lucide-react';
import ContentCarousel from './ContentCarousel';
import ListingCard from '@/components/cards/ListingCard';
import { mockListings } from '@/data/mockData';

interface FreshArrivalsProps {
  onSeeAll?: () => void;
}

const FreshArrivals: React.FC<FreshArrivalsProps> = ({ onSeeAll }) => {
  const newItems = mockListings.filter((item) => item.isNew);

  return (
    <ContentCarousel
      title="Fresh Arrivals"
      subtitle="Just landed on EarlyMarket"
      icon={<Sparkles className="w-5 h-5" />}
      onSeeAll={onSeeAll}
    >
      {mockListings.map((listing) => (
        <div key={listing.id} style={{ scrollSnapAlign: 'start' }}>
          <ListingCard listing={listing} />
        </div>
      ))}
    </ContentCarousel>
  );
};

export default FreshArrivals;
