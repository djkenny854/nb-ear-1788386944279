import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Flame, Store } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useCurrency } from '@/contexts/CurrencyContext';
import RailScroller from '@/components/common/RailScroller';

interface TrendingItem {
  id: string;
  title: string;
  price: number | null;
  images: string[] | null;
  listing_type: string | null;
  has_discount: boolean | null;
  original_price: number | null;
}

const routeFor = (item: TrendingItem) => {
  switch (item.listing_type) {
    case 'jobs':
      return `/job/${item.id}`;
    case 'services':
      return `/service/${item.id}`;
    case 'promotions':
      return `/promotion/${item.id}`;
    case 'digital_products':
      return `/digital/${item.id}`;
    default:
      return `/ad/${item.id}`;
  }
};

const CardSkeleton = () => (
  <div className="w-[120px] shrink-0">
    <div className="aspect-square rounded-xl skeleton-shimmer" />
    <div className="mt-1.5 h-3 w-full rounded skeleton-shimmer" />
    <div className="mt-1 h-3 w-12 rounded skeleton-shimmer" />
  </div>
);

/** Trending now — mirrors the compact X-style product carousel used in Discover. */
const TrendingNow: React.FC = () => {
  const navigate = useNavigate();
  const { formatPriceCompact } = useCurrency();

  const { data, isLoading } = useQuery({
    queryKey: ['home-trending-now'],
    staleTime: 3 * 60 * 1000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('ads')
        .select('id, title, price, images, listing_type, has_discount, original_price')
        .eq('status', 'active')
        .order('view_count', { ascending: false })
        .limit(14);
      if (error) throw error;
      return (data || []) as TrendingItem[];
    },
  });

  const items = useMemo(() => data || [], [data]);
  if (!isLoading && items.length === 0) return null;

  return (
    <section className="py-4">
      <div className="bg-transparent border border-border/20 rounded-xl p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-bold text-foreground">Trending now</h2>
          </div>
          <button
            onClick={() => navigate('/marketplace?algo=Trending')}
            className="text-[11px] font-semibold text-primary hover:text-primary/80"
          >
            See all
          </button>
        </div>

        <RailScroller>
        <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-1 snap-x">
          {isLoading
            ? Array.from({ length: 6 }).map((_, i) => <CardSkeleton key={i} />)
            : items.map((item) => (
                <div
                  key={item.id}
                  onClick={() => navigate(routeFor(item))}
                  className="flex-shrink-0 w-[120px] cursor-pointer group snap-start"
                >
                  <div className="relative aspect-square rounded-xl overflow-hidden mb-1.5 bg-foreground/5 border border-border/30">
                    {item.images?.[0] ? (
                      <img
                        src={item.images[0]}
                        alt={item.title}
                        loading="lazy"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                        <Store className="w-6 h-6" />
                      </div>
                    )}
                    {item.has_discount && item.original_price ? (
                      <span className="absolute top-1.5 left-1.5 rounded bg-destructive/90 backdrop-blur-sm px-1 text-[9px] font-semibold text-destructive-foreground">
                        {Math.round(
                          ((item.original_price - (item.price || 0)) / item.original_price) * 100
                        )}
                        % OFF
                      </span>
                    ) : null}
                  </div>
                  <p className="text-[11px] font-medium text-foreground line-clamp-1">{item.title}</p>
                  <div className="flex items-center gap-1">
                    {item.price ? (
                      <span className="text-[11px] font-bold text-primary">
                        {formatPriceCompact(item.price)}
                      </span>
                    ) : null}
                    {item.has_discount && item.original_price ? (
                      <span className="text-[9px] text-muted-foreground line-through">
                        {item.original_price.toLocaleString()}
                      </span>
                    ) : null}
                  </div>
                </div>
              ))}
        </div>
        </RailScroller>
      </div>
    </section>
  );
};

export default TrendingNow;
