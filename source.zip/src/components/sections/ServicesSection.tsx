import React, { useState, useEffect } from 'react';
import SectionSkeleton from '@/components/sections/SectionSkeleton';
import { Briefcase, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import HomeServiceCard from '@/components/cards/HomeServiceCard';
import { motion, AnimatePresence } from 'framer-motion';
import { useBlockedUsers } from '@/hooks/useBlockedUsers';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';

interface ServicesSectionProps {
  onSeeAll?: () => void;
}

// Rotating service titles with blur transition
const serviceTitles = [
  { title: "Services For You", subtitle: "Professional services near you" },
  { title: "Expert Help Available", subtitle: "Skilled professionals ready to assist" },
  { title: "Get Things Done", subtitle: "Find the right service provider" },
  { title: "Quality Services", subtitle: "Verified professionals at your fingertips" },
  { title: "Book a Pro Today", subtitle: "Expert services just a click away" },
];

const ServicesSection: React.FC<ServicesSectionProps> = ({ onSeeAll }) => {
  const navigate = useNavigate();
  const [titleIndex, setTitleIndex] = useState(0);
  const { allBlockedIds } = useBlockedUsers();
  const { isOnline } = useNetworkStatus();

  // Rotate titles every 4 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setTitleIndex((prev) => (prev + 1) % serviceTitles.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const { data: services, isLoading } = useQuery({
    queryKey: ['home-services'],
    queryFn: async () => {
      // First get active user IDs
      const { data: activeProfiles } = await supabase
        .from('profiles')
        .select('id, account_status')
        .or('account_status.is.null,account_status.eq.active');

      const activeUserIds = new Set(activeProfiles?.map(p => p.id) || []);

      // Get seller profiles with active accounts - prioritize verified
      const { data: activeSellers } = await supabase
        .from('seller_profiles')
        .select('id, user_id, is_verified')
        .order('is_verified', { ascending: false }); // Verified first

      const activeSellerIds = activeSellers
        ?.filter(s => activeUserIds.has(s.user_id))
        .map(s => s.id) || [];

      const { data, error } = await supabase
        .from('ads')
        .select(`
          id,
          title,
          description,
          price,
          images,
          location,
          category,
          seller_id,
          seller_profiles!ads_seller_id_fkey (
            id,
            business_name,
            business_logo_url,
            is_verified,
            verification_badge_color
          ),
          service_details (
            starting_price,
            experience_years,
            qualifications
          )
        `)
        .eq('status', 'active')
        .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`)
        .eq('listing_type', 'services')
        .in('seller_id', activeSellerIds.length > 0 ? activeSellerIds : ['00000000-0000-0000-0000-000000000000'])
        .order('created_at', { ascending: false })
        .limit(12); // Fetch more to sort by verification

      if (error) throw error;
      
      // Sort by verification status - verified sellers first
      const sorted = (data || []).sort((a, b) => {
        const aVerified = a.seller_profiles?.is_verified ? 1 : 0;
        const bVerified = b.seller_profiles?.is_verified ? 1 : 0;
        return bVerified - aVerified;
      });
      
      return sorted.slice(0, 6);
    },
    staleTime: 1000 * 60 * 5,
    gcTime: 1000 * 60 * 10,
    enabled: isOnline,
  });

  const handleSeeAll = () => {
    navigate('/search?content_type=services');
  };

  if (isLoading && isOnline) {
    return <SectionSkeleton type="listing" count={4} />;
  }

  const filteredServices = (services || []).filter(
    s => !allBlockedIds.includes((s.seller_profiles as any)?.user_id)
  );

  if (!filteredServices.length) {
    return null;
  }


  const currentTitle = serviceTitles[titleIndex];

  return (
    <section className="py-6">
      {/* Header with animated title */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <Briefcase className="w-7 h-7 text-primary" strokeWidth={2.5} />
          <div className="overflow-hidden">
            <AnimatePresence mode="wait">
              <motion.div
                key={titleIndex}
                initial={{ opacity: 0, filter: 'blur(8px)', y: 10 }}
                animate={{ opacity: 1, filter: 'blur(0px)', y: 0 }}
                exit={{ opacity: 0, filter: 'blur(8px)', y: -10 }}
                transition={{ duration: 0.4, ease: 'easeInOut' }}
              >
                <h2 className="text-xl font-bold text-foreground tracking-tight">{currentTitle.title}</h2>
                <p className="text-xs text-muted-foreground">{currentTitle.subtitle}</p>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
        <Button variant="ghost" size="sm" onClick={handleSeeAll} className="text-primary">
          See All
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      </div>

      {/* Services List */}
      <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4">
        {filteredServices.map((service) => {
          const seller = service.seller_profiles;
          const sd = Array.isArray(service.service_details) ? service.service_details[0] : service.service_details;

          return (
            <HomeServiceCard
              key={service.id}
              id={service.id}
              title={service.title}
              description={service.description}
              price={service.price}
              images={service.images || []}
              location={service.location}
              category={service.category}
              seller={seller}
              serviceDetails={sd ? {
                starting_price: sd.starting_price,
                experience_years: sd.experience_years,
                qualifications: sd.qualifications,
              } : null}
              onClick={() => navigate(`/service/${service.id}`)}
            />
          );
        })}
      </div>
    </section>
  );
};

export default ServicesSection;
