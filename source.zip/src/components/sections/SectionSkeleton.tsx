import React from 'react';
import { Skeleton } from '@/components/ui/skeleton';

interface SectionSkeletonProps {
  type?: 'listing' | 'job' | 'seller' | 'collection' | 'post';
  count?: number;
}

const SectionSkeleton: React.FC<SectionSkeletonProps> = ({ 
  type = 'listing',
  count = 4 
}) => {
  const renderSkeleton = () => {
    switch (type) {
      case 'listing':
        return (
          <div className="min-w-[180px] max-w-[220px]">
            <Skeleton className="aspect-square rounded-xl" />
            <div className="p-3 space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-5 w-20" />
              <Skeleton className="h-3 w-16" />
            </div>
          </div>
        );
      
      case 'job':
        return (
          <div className="min-w-[260px] max-w-[300px] p-4 border border-border/50 rounded-xl">
            <div className="flex gap-3">
              <Skeleton className="w-12 h-12 rounded-xl" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-3 w-20" />
              </div>
            </div>
            <div className="mt-3 space-y-2">
              <Skeleton className="h-3 w-32" />
              <Skeleton className="h-4 w-24" />
            </div>
          </div>
        );
      
      case 'seller':
        return (
          <div className="min-w-[140px] flex flex-col items-center">
            <Skeleton className="w-20 h-20 rounded-full" />
            <Skeleton className="h-4 w-24 mt-3" />
            <Skeleton className="h-3 w-16 mt-1" />
          </div>
        );
      
      case 'collection':
        return (
          <div className="min-w-[200px] max-w-[240px]">
            <Skeleton className="aspect-[4/5] rounded-2xl" />
          </div>
        );
      
      case 'post':
        return (
          <div className="min-w-[280px] max-w-[320px] border border-border/50 rounded-xl overflow-hidden">
            <Skeleton className="aspect-video" />
            <div className="p-4 space-y-3">
              <div className="flex gap-2">
                <Skeleton className="w-8 h-8 rounded-full" />
                <div className="space-y-1 flex-1">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-3 w-16" />
                </div>
              </div>
              <Skeleton className="h-4 w-full" />
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <section className="py-4">
      <div className="flex items-center justify-between mb-4 px-1">
        <div className="space-y-1">
          <Skeleton className="h-6 w-40" />
          <Skeleton className="h-4 w-32" />
        </div>
        <Skeleton className="h-8 w-16" />
      </div>
      
      <div className="flex gap-3 overflow-hidden pb-2 -mx-4 px-4">
        {Array.from({ length: count }).map((_, i) => (
          <div key={i}>{renderSkeleton()}</div>
        ))}
      </div>
    </section>
  );
};

export default SectionSkeleton;
