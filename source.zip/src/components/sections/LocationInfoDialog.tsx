import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription } from '@/components/ui/drawer';
import { useIsMobile } from '@/hooks/use-mobile';
import { MapPin, Navigation, Compass, Shield, RefreshCw, Layers } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  location?: string | null;
  subCounty?: string | null;
  hasLocation: boolean;
  onRefreshLocation?: () => void;
}

/**
 * Stylized SVG "map preview" — abstract routes and pins to suggest
 * location-aware recommendations without using any 3rd-party map provider.
 */
const MapPreviewSvg: React.FC = () => (
  <svg
    viewBox="0 0 320 140"
    className="w-full h-32 rounded-xl"
    role="img"
    aria-label="Stylized map preview"
  >
    <defs>
      <linearGradient id="mapBg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="hsl(var(--primary) / 0.08)" />
        <stop offset="100%" stopColor="hsl(var(--accent) / 0.12)" />
      </linearGradient>
      <pattern id="mapGrid" width="20" height="20" patternUnits="userSpaceOnUse">
        <path d="M 20 0 L 0 0 0 20" fill="none" stroke="hsl(var(--border))" strokeWidth="0.5" />
      </pattern>
    </defs>
    <rect width="320" height="140" fill="url(#mapBg)" />
    <rect width="320" height="140" fill="url(#mapGrid)" opacity="0.6" />
    {/* Routes */}
    <path d="M0 90 Q60 70 120 80 T240 60 T320 70" fill="none" stroke="hsl(var(--primary))" strokeWidth="2" strokeLinecap="round" opacity="0.7" />
    <path d="M20 120 Q90 110 160 95 T300 100" fill="none" stroke="hsl(var(--accent))" strokeWidth="2" strokeLinecap="round" strokeDasharray="4 4" opacity="0.6" />
    {/* Pins */}
    {[
      { x: 80, y: 78, color: 'hsl(var(--destructive))' },
      { x: 170, y: 70, color: 'hsl(var(--primary))' },
      { x: 240, y: 60, color: 'hsl(var(--primary))' },
      { x: 280, y: 95, color: 'hsl(var(--accent))' },
    ].map((p, i) => (
      <g key={i}>
        <circle cx={p.x} cy={p.y} r="10" fill={p.color} opacity="0.18" />
        <circle cx={p.x} cy={p.y} r="5" fill={p.color} />
        <circle cx={p.x} cy={p.y} r="2" fill="white" />
      </g>
    ))}
    {/* Center "you are here" pulse */}
    <g>
      <circle cx="160" cy="95" r="14" fill="hsl(var(--primary))" opacity="0.15">
        <animate attributeName="r" values="10;20;10" dur="2.5s" repeatCount="indefinite" />
        <animate attributeName="opacity" values="0.3;0;0.3" dur="2.5s" repeatCount="indefinite" />
      </circle>
      <circle cx="160" cy="95" r="6" fill="hsl(var(--primary))" />
      <circle cx="160" cy="95" r="2" fill="white" />
    </g>
  </svg>
);

const LocationInfoDialog: React.FC<Props> = ({ open, onOpenChange, location, subCounty, hasLocation, onRefreshLocation }) => {
  const isMobile = useIsMobile();

  const body = (
    <div className="space-y-4">
      {/* Map preview */}
      <MapPreviewSvg />

      {/* Current location */}
      <div className="rounded-xl border border-border/60 bg-muted/30 p-3">
        <div className="flex items-center gap-2 mb-1">
          <MapPin className="w-4 h-4 text-primary" />
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Current location</p>
        </div>
        {hasLocation && location ? (
          <p className="text-sm font-medium">
            {location}{subCounty ? `, ${subCounty}` : ''}
          </p>
        ) : (
          <p className="text-sm text-muted-foreground">Detecting your location…</p>
        )}
      </div>

      {/* How it works */}
      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">How it works</p>
        <ul className="space-y-2.5">
          <li className="flex gap-3">
            <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Compass className="w-3.5 h-3.5 text-primary" />
            </div>
            <div className="text-sm">
              <p className="font-medium">We detect your district</p>
              <p className="text-xs text-muted-foreground">Used only to surface listings physically near you.</p>
            </div>
          </li>
          <li className="flex gap-3">
            <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Layers className="w-3.5 h-3.5 text-primary" />
            </div>
            <div className="text-sm">
              <p className="font-medium">We rank by proximity & popularity</p>
              <p className="text-xs text-muted-foreground">Items in your area are boosted, then sorted by views and freshness.</p>
            </div>
          </li>
          <li className="flex gap-3">
            <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Shield className="w-3.5 h-3.5 text-primary" />
            </div>
            <div className="text-sm">
              <p className="font-medium">Privacy first</p>
              <p className="text-xs text-muted-foreground">Your precise location never leaves your device. Only the district name is used.</p>
            </div>
          </li>
        </ul>
      </div>

      {/* Refresh action */}
      {onRefreshLocation && (
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            onRefreshLocation();
            onOpenChange(false);
          }}
          className="w-full gap-2 rounded-full"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Refresh my location
        </Button>
      )}
    </div>
  );

  const headerEl = (
    <div className="flex items-center gap-3 mb-1">
      <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
        <Navigation className="w-4 h-4 text-primary" />
      </div>
      <div>
        <p className="font-semibold">Popular Near You</p>
        <p className="text-xs text-muted-foreground">Why we show these listings</p>
      </div>
    </div>
  );

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={onOpenChange}>
        <DrawerContent className="px-4 pb-8">
          <DrawerHeader className="text-left">
            <DrawerTitle className="sr-only">Popular Near You</DrawerTitle>
            <DrawerDescription className="sr-only">Information about location-based listings</DrawerDescription>
            {headerEl}
          </DrawerHeader>
          {body}
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="sr-only">Popular Near You</DialogTitle>
          <DialogDescription className="sr-only">Information about location-based listings</DialogDescription>
          {headerEl}
        </DialogHeader>
        {body}
      </DialogContent>
    </Dialog>
  );
};

export default LocationInfoDialog;
