import React, { useState } from 'react';
import { Percent } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import HomeProductCard from '@/components/cards/HomeProductCard';
import { useBlockedUsers } from '@/hooks/useBlockedUsers';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';
import { useIsMobile } from '@/hooks/use-mobile';
import HotDealsSwipeCard from '@/components/feed/HotDealsSwipeCard';
import HotDealsSkeleton from '@/components/sections/HotDealsSkeleton';
import HotDealsSourcesDialog, { DealSource } from '@/components/sections/HotDealsSourcesDialog';
import RailScroller from '@/components/common/RailScroller';

interface DealsSectionProps {
  onSeeAll?: () => void;
}

const DealsSection: React.FC<DealsSectionProps> = ({ onSeeAll }) => {
  const navigate = useNavigate();
  const { allBlockedIds } = useBlockedUsers();
  const { isOnline } = useNetworkStatus();
  const isMobile = useIsMobile();
  const [sourcesOpen, setSourcesOpen] = useState(false);

  const { data: deals, isLoading } = useQuery({
    queryKey: ['deals-section-products-only'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('ads')
        .select(`
          id, title, price, original_price, images, b2_video_url, location, view_count,
          has_discount, inventory_count, created_at, seller_id, listing_type,
          seller_profiles!ads_seller_id_fkey (
            id, user_id, business_name, business_logo_url, is_verified,
            verification_badge_color, district, sub_county, working_hours, store_slug
          )
        `)
        .eq('status', 'active')
        .in('listing_type', ['physical_products', 'digital_products'])
        .eq('has_discount', true)
        .not('price', 'is', null)
        .gt('price', 0)
        .not('original_price', 'is', null)
        .gt('original_price', 0)
        .order('created_at', { ascending: false })
        .limit(12);

      if (error) throw error;
      return (data || []).filter(item =>
        item.price && item.original_price && item.price < item.original_price
      );
    },
    staleTime: 1000 * 60 * 5,
    enabled: isOnline,
  });

  if (isLoading && isOnline) {
    return <HotDealsSkeleton />;
  }

  const filteredDeals = (deals || []).filter(
    d => !allBlockedIds.includes((d.seller_profiles as any)?.user_id)
  );

  if (!filteredDeals.length) {
    return null;
  }

  // Build sources from deals' seller profiles
  const sources: DealSource[] = filteredDeals.map(d => {
    const sp = (d.seller_profiles as any) || {};
    return {
      seller_id: sp.id || d.seller_id,
      business_name: sp.business_name || 'Seller',
      business_logo_url: sp.business_logo_url,
      is_verified: sp.is_verified,
      store_slug: sp.store_slug,
    };
  });

  // Build AI context query string from the deals
  const aiContextTitles = filteredDeals.slice(0, 5).map(d => d.title).join(' | ');
  const aiPrompt = `Tell me about the current hot deals on EarlyMarket. Examples: ${aiContextTitles}. Help me decide which to consider.`;
  const aiHref = `/ai?prompt=${encodeURIComponent(aiPrompt)}&context=hot-deals`;

  // Mobile: swipe card variant with sources props
  if (isMobile) {
    const swipeDeals = filteredDeals.map((d) => ({
      id: d.id,
      title: d.title,
      price: d.price,
      original_price: d.original_price,
      images: d.images || [],
      seller_id: d.seller_id,
      seller_name: (d.seller_profiles as any)?.business_name || 'Seller',
      seller_logo: (d.seller_profiles as any)?.business_logo_url,
      is_verified: (d.seller_profiles as any)?.is_verified,
      store_slug: (d.seller_profiles as any)?.store_slug,
    }));
    return (
      <HotDealsSwipeCard
        deals={swipeDeals}
        sources={sources}
        aiHref={aiHref}
      />
    );
  }

  return (
    <section className="py-6 -mx-4 px-1">
      {/* Header — borderless, edge-aware */}
      <div className="flex items-center justify-between mb-4 px-2">
        <div className="flex items-center gap-3">
          <Percent className="w-7 h-7 text-destructive" strokeWidth={2.5} />
          <div>
            <h2 className="text-xl font-bold text-foreground tracking-tight">Hot Deals</h2>
            <p className="text-xs text-muted-foreground">Products on discount right now</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Sources button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSourcesOpen(true)}
            className="rounded-full text-muted-foreground hover:text-foreground"
          >
            Sources
          </Button>
        </div>
      </div>

      {/* Deals row — edge to edge, no border around section */}
      <RailScroller>
      <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide px-2">
        {filteredDeals.map((deal) => (
          <HomeProductCard
            key={deal.id}
            id={deal.id}
            title={deal.title}
            price={deal.price}
            originalPrice={deal.original_price}
            images={deal.images || []}
            videoUrl={(deal as any).b2_video_url || null}
            location={deal.location}
            viewCount={deal.view_count || 0}
            hasDiscount={true}
            createdAt={deal.created_at}
            inventoryCount={deal.inventory_count || undefined}
            seller={deal.seller_profiles}
            className="w-[170px] sm:w-[195px] shrink-0"
            onClick={() => navigate(`/ad/${deal.id}`)}
          />
        ))}
      </div>
      </RailScroller>

      <HotDealsSourcesDialog
        open={sourcesOpen}
        onOpenChange={setSourcesOpen}
        sources={sources}
      />
    </section>
  );
};

export default DealsSection;
