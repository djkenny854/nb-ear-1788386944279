import React from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

// Text-line shaped placeholder with the global em-skeleton-shimmer animation.
// Matches the shimmer used by FeedCardSkeleton / ServiceDetailsSkeleton so the
// product details page reads as the same loading language across the app.
const ShimmerSkeleton = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      'em-skeleton-shimmer rounded-md',
      className
    )}
    {...props}
  />
);

const ItemDetailsSkeleton = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header Skeleton */}
      <div className="border-b border-border/40 sticky top-0 z-50 bg-background/80 backdrop-blur">
        <div className="flex items-center justify-between px-4 h-14 max-w-7xl mx-auto">
          <div className="flex items-center gap-2">
            <ShimmerSkeleton className="w-8 h-8 rounded" />
            <ShimmerSkeleton className="w-12 h-4" />
          </div>
          <div className="flex items-center gap-2">
            <ShimmerSkeleton className="w-8 h-8 rounded" />
            <ShimmerSkeleton className="w-8 h-8 rounded" />
            <ShimmerSkeleton className="w-8 h-8 rounded" />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-10">
          {/* Left — Gallery */}
          <div className="space-y-3">
            <ShimmerSkeleton className="w-full aspect-square rounded-xl" />
            <div className="flex gap-2 overflow-x-auto pb-1">
              {[...Array(5)].map((_, i) => (
                <ShimmerSkeleton key={i} className="w-16 h-16 md:w-20 md:h-20 rounded-lg shrink-0" />
              ))}
            </div>
            <div className="flex items-center justify-around pt-2">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="flex flex-col items-center gap-1.5">
                  <ShimmerSkeleton className="w-9 h-9 rounded-full" />
                  <ShimmerSkeleton className="w-10 h-2.5" />
                </div>
              ))}
            </div>
          </div>

          {/* Right — Info */}
          <div className="space-y-5">
            <div className="flex items-center gap-2">
              <ShimmerSkeleton className="w-24 h-3.5" />
              <ShimmerSkeleton className="w-4 h-4 rounded-full" />
            </div>
            <div className="space-y-2">
              <ShimmerSkeleton className="w-11/12 h-6" />
              <ShimmerSkeleton className="w-3/4 h-6" />
            </div>
            <ShimmerSkeleton className="w-40 h-8" />
            <div className="flex items-center gap-3">
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <ShimmerSkeleton key={i} className="w-4 h-4 rounded" />
                ))}
              </div>
              <ShimmerSkeleton className="w-20 h-3.5" />
            </div>
            <div className="flex flex-wrap gap-2">
              {[...Array(3)].map((_, i) => (
                <ShimmerSkeleton key={i} className="w-20 h-6 rounded-full" />
              ))}
            </div>

            {/* Seller row (flat, no card) */}
            <div className="flex items-center gap-3 pt-3 border-t border-border/40">
              <ShimmerSkeleton className="w-11 h-11 rounded-full shrink-0" />
              <div className="flex-1 space-y-2">
                <ShimmerSkeleton className="w-32 h-4" />
                <ShimmerSkeleton className="w-24 h-3" />
              </div>
              <ShimmerSkeleton className="w-20 h-8 rounded-full" />
            </div>

            {/* Description */}
            <div className="space-y-2 pt-2">
              <ShimmerSkeleton className="w-32 h-4" />
              <ShimmerSkeleton className="w-full h-3.5" />
              <ShimmerSkeleton className="w-full h-3.5" />
              <ShimmerSkeleton className="w-11/12 h-3.5" />
              <ShimmerSkeleton className="w-3/4 h-3.5" />
            </div>

            {/* Specs */}
            <div className="space-y-3 pt-2">
              <ShimmerSkeleton className="w-36 h-4" />
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex justify-between">
                  <ShimmerSkeleton className="w-24 h-3.5" />
                  <ShimmerSkeleton className="w-32 h-3.5" />
                </div>
              ))}
            </div>

            {/* Action buttons */}
            <div className="flex gap-2 pt-2">
              <ShimmerSkeleton className="flex-1 h-11 rounded-full" />
              <ShimmerSkeleton className="flex-1 h-11 rounded-full" />
            </div>
          </div>
        </div>

        {/* Comments — flat, no card */}
        <div className="mt-8 space-y-4 border-t border-border/40 pt-6">
          <ShimmerSkeleton className="w-40 h-5" />
          <div className="flex gap-3">
            <ShimmerSkeleton className="w-10 h-10 rounded-full shrink-0" />
            <div className="flex-1 space-y-2">
              <ShimmerSkeleton className="w-full h-16 rounded" />
              <div className="flex justify-end">
                <ShimmerSkeleton className="w-24 h-9 rounded-full" />
              </div>
            </div>
          </div>
          {[...Array(2)].map((_, i) => (
            <div key={i} className="flex gap-3 pt-2">
              <ShimmerSkeleton className="w-10 h-10 rounded-full shrink-0" />
              <div className="flex-1 space-y-2">
                <div className="flex items-center justify-between">
                  <ShimmerSkeleton className="w-24 h-3.5" />
                  <ShimmerSkeleton className="w-16 h-3" />
                </div>
                <ShimmerSkeleton className="w-full h-3.5" />
                <ShimmerSkeleton className="w-3/4 h-3.5" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ItemDetailsSkeleton;
