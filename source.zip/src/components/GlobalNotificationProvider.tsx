import React from 'react';
import { usePushNotifications } from '@/hooks/usePushNotifications';
import { useWebPush } from '@/hooks/useWebPush';

// This component initializes push notifications globally
export const GlobalNotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize push notifications for the entire app
  usePushNotifications({
    enableMessageNotifications: true,
    enableGeneralNotifications: true,
  });

  // FCM web push: silently re-registers the device token when permission was
  // already granted; no-ops while the Firebase env values are placeholders.
  useWebPush({ auto: true });

  return <>{children}</>;
};
