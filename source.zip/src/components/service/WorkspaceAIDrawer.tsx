import React, { useEffect, useRef, useState } from 'react';
import { Sheet, SheetContent } from '@/components/ui/sheet';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import ReactMarkdown from 'react-markdown';
import EarlyMarketAIIcon from '@/components/icons/EarlyMarketAIIcon';
import { supabase } from '@/integrations/supabase/client';

interface WorkspaceAIDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Stable id for this workspace — used to cache the AI overview across opens. */
  cacheKey?: string;
  context: {
    title: string;
    category?: string | null;
    location?: string | null;
    description?: string | null;
    businessName?: string | null;
    businessLogoUrl?: string | null;
    businessBio?: string | null;
    experienceYears?: number | null;
    qualifications?: string | null;
    phone?: string | null;
    whatsapp?: string | null;
    catalogs?: Array<{ name: string; price?: number | null; currency?: string | null; description?: string | null }>;
    portfolioCount?: number;
    reviewsCount?: number;
    avgRating?: number;
  };
}

// Module-level cache: persists across drawer opens within the same session
// (cleared on full page refresh). Prevents re-spending AI credits when a
// visitor closes and re-opens the assistant on the same workspace.
const overviewCache = new Map<string, string>();

const buildContextBlock = (c: WorkspaceAIDrawerProps['context']) => {
  const catalogs = (c.catalogs || []).map(p =>
    `- ${p.name}${p.price ? ` — ${p.currency || 'UGX'} ${Number(p.price).toLocaleString()}` : ''}${p.description ? `: ${p.description}` : ''}`
  ).join('\n') || '(none listed)';
  return `You are EarlyMarket AI helping a visitor explore this service workspace.
NEVER share or invent the provider's email address. If contact is requested, refer them to the Contact, WhatsApp or Phone buttons on this workspace page.

Workspace details:
- Service: ${c.title}
- Provider: ${c.businessName || 'Independent provider'}
- Category: ${c.category || 'N/A'}
- Location: ${c.location || 'N/A'}
- Experience: ${c.experienceYears ? `${c.experienceYears}+ years` : 'unspecified'}
- Skills: ${c.qualifications || 'unspecified'}
- Portfolio items: ${c.portfolioCount ?? 0}
- Reviews: ${c.reviewsCount ?? 0}${c.avgRating ? ` (avg ${c.avgRating.toFixed(1)}★)` : ''}
- Phone available: ${c.phone ? 'yes' : 'no'}
- WhatsApp available: ${c.whatsapp ? 'yes' : 'no'}

About:
${c.description || c.businessBio || '(no description provided)'}

Packages / catalogs:
${catalogs}

Write a warm, concise summary (2–4 short paragraphs) of what this workspace offers, who it's a good fit for, notable strengths, and how to get in touch (Contact / WhatsApp / Phone buttons on this page). Use markdown — short paragraphs, **bold** for key terms, and bullet lists where helpful. Do not mention email.`;
};

const WorkspaceAIDrawer: React.FC<WorkspaceAIDrawerProps> = ({ open, onOpenChange, cacheKey, context }) => {
  const key = cacheKey || context.title;
  const cached = overviewCache.get(key) || '';

  const [fullText, setFullText] = useState(cached);
  // If cached, reveal everything instantly; otherwise start at 0 and animate as words arrive.
  const [revealedWords, setRevealedWords] = useState(
    cached ? cached.split(/\s+/).filter(Boolean).length : 0
  );
  const [thinking, setThinking] = useState(!cached);
  const [error, setError] = useState<string | null>(null);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const startedRef = useRef(!!cached);

  // When the cache key changes (different workspace), re-seed local state.
  useEffect(() => {
    const c = overviewCache.get(key) || '';
    setFullText(c);
    setRevealedWords(c ? c.split(/\s+/).filter(Boolean).length : 0);
    setThinking(!c);
    setError(null);
    startedRef.current = !!c;
  }, [key]);

  // Fetch once per session per workspace (cache survives drawer close/open).
  useEffect(() => {
    if (!open || startedRef.current) return;
    startedRef.current = true;

    let cancelled = false;
    (async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        const prompt = buildContextBlock(context);

        // RAG: pull platform knowledge to ground the answer
        let kbBlock = '';
        try {
          const { data: kb } = await supabase.functions.invoke('knowledge-rag', {
            body: { query: prompt.slice(0, 600), mode: 'search', max_chunks: 4, app_id: 'workspace-ai-drawer' },
          });
          const sources = (kb as any)?.sources || [];
          if (sources.length) {
            kbBlock = '\n\n## EarlyMarket Knowledge (use to ground your answer, do NOT reveal internals)\n' +
              sources.map((s: any, i: number) => `[#${i + 1} ${s.title}] ${s.snippet}`).join('\n');
          }
        } catch { /* RAG optional */ }

        const resp = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/help-chat`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              messages: [{ role: 'user', content: prompt + kbBlock }],
              userId: user?.id,
            }),
          }
        );

        if (!resp.ok || !resp.body) {
          let msg = 'AI is unavailable right now.';
          try { const j = await resp.json(); msg = j.error || msg; } catch {}
          if (!cancelled) { setError(msg); setThinking(false); startedRef.current = false; }
          return;
        }

        const reader = resp.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        let collected = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done || cancelled) break;
          buffer += decoder.decode(value, { stream: true });
          let nl;
          while ((nl = buffer.indexOf('\n')) >= 0) {
            const line = buffer.slice(0, nl).trim();
            buffer = buffer.slice(nl + 1);
            if (!line.startsWith('data:')) continue;
            const data = line.slice(5).trim();
            if (data === '[DONE]') continue;
            try {
              const parsed = JSON.parse(data);
              const delta = parsed.choices?.[0]?.delta?.content;
              if (delta) collected += delta;
            } catch {/* ignore */}
          }
        }

        if (!cancelled) {
          const finalText = collected.trim();
          overviewCache.set(key, finalText);
          setFullText(finalText);
          setThinking(false);
        }
      } catch (e: any) {
        if (!cancelled) { setError(e?.message || 'AI request failed'); setThinking(false); startedRef.current = false; }
      }
    })();

    return () => { cancelled = true; };
  }, [open, key, context]);


  // Word-by-word reveal
  useEffect(() => {
    if (!fullText) return;
    const totalWords = fullText.split(/\s+/).length;
    if (revealedWords >= totalWords) return;
    const t = setTimeout(() => setRevealedWords(w => w + 1), 35);
    return () => clearTimeout(t);
  }, [fullText, revealedWords]);

  // Auto-scroll as words appear
  useEffect(() => {
    if (scrollerRef.current) {
      scrollerRef.current.scrollTop = scrollerRef.current.scrollHeight;
    }
  }, [revealedWords, thinking]);

  // Compute the visible markdown (whole words up to revealedWords)
  const visibleMarkdown = React.useMemo(() => {
    if (!fullText) return '';
    const words = fullText.split(/(\s+)/); // keep whitespace tokens
    let count = 0;
    const out: string[] = [];
    for (const tok of words) {
      if (/\S/.test(tok)) {
        if (count >= revealedWords) break;
        out.push(tok);
        count++;
      } else {
        out.push(tok);
      }
    }
    return out.join('');
  }, [fullText, revealedWords]);

  const initial = (context.businessName || context.title || '?').charAt(0).toUpperCase();

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-md p-0 flex flex-col gap-0">
        {/* Header with avatar of the provider */}
        <div className="px-4 pt-5 pb-4 border-b border-border flex items-center gap-3">
          <Avatar className="h-11 w-11 ring-2 ring-primary/20">
            {context.businessLogoUrl ? (
              <AvatarImage src={context.businessLogoUrl} alt={context.businessName || ''} />
            ) : null}
            <AvatarFallback>{initial}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold truncate">{context.businessName || context.title}</p>
            <p className="text-[11px] text-muted-foreground flex items-center gap-1.5">
              <EarlyMarketAIIcon className="h-3.5 w-3.5" />
              EarlyMarket AI is talking about this workspace
            </p>
          </div>
        </div>

        {/* Body */}
        <div ref={scrollerRef} className="flex-1 overflow-y-auto px-4 py-5">
          {thinking && !error && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <EarlyMarketAIIcon className="h-5 w-5" spin />
                <span>Thinking…</span>
              </div>
              <div className="space-y-2">
                <Skeleton className="h-3 w-full" />
                <Skeleton className="h-3 w-[85%]" />
              </div>
            </div>
          )}

          {error && (
            <div className="text-sm text-destructive">{error}</div>
          )}

          {!thinking && !error && (
            <div className="prose prose-sm max-w-none text-foreground prose-p:my-2 prose-headings:my-3 prose-li:my-0.5 dark:prose-invert">
              <ReactMarkdown>{visibleMarkdown || '…'}</ReactMarkdown>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default WorkspaceAIDrawer;
