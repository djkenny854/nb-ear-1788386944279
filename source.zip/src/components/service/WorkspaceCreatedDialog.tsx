import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  PartyPopper,
  Rocket,
  ShieldCheck,
  TrendingUp,
  Star,
  ArrowRight,
  Briefcase,
  Link2,
  Copy,
  Check,
  Eye,
  BarChart3,
  MessageSquare,
  GalleryHorizontal,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Drawer, DrawerContent } from '@/components/ui/drawer';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { getAppBaseUrl } from '@/utils/getAppUrl';

interface Workspace {
  id: string;
  name: string;
  category: string;
  goalLabel: string;
  catalogCount: number;
  publicUrl?: string;
}

interface Props {
  open: boolean;
  workspace: Workspace | null;
  onManage: () => void;
  onViewPublic?: () => void;
}

const INCLUDED = [
  { icon: MessageSquare, title: 'Updates feed', desc: 'Post work, reels, before/after, offers and news.' },
  { icon: GalleryHorizontal, title: 'Portfolio & catalog', desc: 'Show services with prices and proof in one place.' },
  { icon: Star, title: 'Reviews & testimonials', desc: 'Collect ratings and stories that build trust.' },
  { icon: BarChart3, title: 'Workspace analytics', desc: 'Track views, engagement and follower growth.' },
  { icon: Link2, title: 'Shareable URL', desc: 'A clean link you can share anywhere.' },
];

const TIPS = [
  { icon: TrendingUp, text: 'Verified workspaces rank higher in search.' },
  { icon: Rocket, text: 'Posting weekly doubles follower growth.' },
  { icon: ShieldCheck, text: 'Add a clear bio and contact to win trust fast.' },
];

function Confetti() {
  const dots = Array.from({ length: 18 });
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {dots.map((_, i) => {
        const left = Math.random() * 100;
        const delay = Math.random() * 0.6;
        const duration = 1.6 + Math.random() * 1.2;
        const colors = ['bg-primary', 'bg-yellow-400', 'bg-pink-400', 'bg-emerald-400', 'bg-sky-400'];
        const color = colors[i % colors.length];
        return (
          <motion.span
            key={i}
            initial={{ y: -20, opacity: 0, rotate: 0 }}
            animate={{ y: 320, opacity: [0, 1, 1, 0], rotate: 360 }}
            transition={{ duration, delay, repeat: Infinity, repeatDelay: 1.5 }}
            className={cn('absolute top-0 h-2 w-2 rounded-sm', color)}
            style={{ left: `${left}%` }}
          />
        );
      })}
    </div>
  );
}

function UrlRow({ url }: { url: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      toast.success('Workspace URL copied');
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error('Could not copy');
    }
  };
  return (
    <div className="mt-4 flex items-center gap-2 rounded-xl border border-border bg-muted/40 p-2.5">
      <Link2 className="h-4 w-4 text-muted-foreground shrink-0" />
      <span className="flex-1 text-xs truncate font-mono text-foreground/80">{url}</span>
      <Button size="sm" variant="ghost" className="h-7 px-2" onClick={copy}>
        {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
      </Button>
    </div>
  );
}

function Body({ workspace, onManage, onViewPublic }: { workspace: Workspace; onManage: () => void; onViewPublic?: () => void }) {
  const [stage, setStage] = useState<0 | 1>(0);
  useEffect(() => { setStage(0); }, [workspace?.id]);
  const url = workspace.publicUrl || `${getAppBaseUrl()}/service/${workspace.id}`;

  return (
    <div className="relative">
      {stage === 0 && <Confetti />}
      <AnimatePresence mode="wait">
        {stage === 0 ? (
          <motion.div
            key="details"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="relative px-6 pt-8 pb-6 text-center"
          >
            <motion.div
              initial={{ scale: 0.5, rotate: -20, opacity: 0 }}
              animate={{ scale: 1, rotate: 0, opacity: 1 }}
              transition={{ type: 'spring', stiffness: 220, damping: 14 }}
              className="mx-auto mb-4 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 text-primary"
            >
              <PartyPopper className="h-8 w-8" />
            </motion.div>

            <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight">Your workspace is live 🎉</h2>
            <p className="mt-2 text-sm sm:text-base text-muted-foreground">
              <span className="font-medium text-foreground">{workspace.name}</span> is set up and ready for the next step.
            </p>

            {/* Plain meta rows — no cards, never clip on desktop */}
            <dl className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-y-3 gap-x-6 text-left">
              <div>
                <dt className="text-[11px] uppercase tracking-wider text-muted-foreground">Category</dt>
                <dd className="mt-1 text-sm sm:text-base font-medium break-words">{workspace.category}</dd>
              </div>
              <div>
                <dt className="text-[11px] uppercase tracking-wider text-muted-foreground">Goal</dt>
                <dd className="mt-1 text-sm sm:text-base font-medium break-words">{workspace.goalLabel || '—'}</dd>
              </div>
              <div>
                <dt className="text-[11px] uppercase tracking-wider text-muted-foreground">Catalog</dt>
                <dd className="mt-1 text-sm sm:text-base font-medium">{workspace.catalogCount} items</dd>
              </div>
            </dl>

            <UrlRow url={url} />

            <Button onClick={() => setStage(1)} className="mt-5 w-full h-11 rounded-full gap-2">
              See what's included <ArrowRight className="h-4 w-4" />
            </Button>
          </motion.div>
        ) : (
          <motion.div
            key="benefits"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="px-6 pt-8 pb-6"
          >
            <div className="text-center">
              <div className="mx-auto mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                <Briefcase className="h-6 w-6" />
              </div>
              <h2 className="text-xl font-semibold tracking-tight">What's included</h2>
              <p className="mt-1 text-sm text-muted-foreground">Everything <span className="font-medium text-foreground">{workspace.name}</span> can do.</p>
            </div>

            <ul className="mt-6 space-y-4">
              {INCLUDED.map((b, i) => {
                const Icon = b.icon;
                return (
                  <motion.li
                    key={b.title}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="flex items-start gap-3"
                  >
                    <div className="h-9 w-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm sm:text-base font-medium">{b.title}</p>
                      <p className="text-xs sm:text-sm text-muted-foreground mt-0.5">{b.desc}</p>
                    </div>
                  </motion.li>
                );
              })}
            </ul>

            <div className="mt-4 rounded-xl bg-primary/5 border border-primary/15 p-3 space-y-1.5">
              {TIPS.map((t) => (
                <div key={t.text} className="flex items-center gap-2">
                  <t.icon className="h-3.5 w-3.5 text-primary" />
                  <p className="text-xs text-foreground/80">{t.text}</p>
                </div>
              ))}
            </div>

            <UrlRow url={url} />

            <div className="mt-5 grid grid-cols-2 gap-2">
              {onViewPublic && (
                <Button variant="outline" onClick={onViewPublic} className="h-11 rounded-full gap-2">
                  <Eye className="h-4 w-4" /> View public
                </Button>
              )}
              <Button
                onClick={onManage}
                className={cn('h-11 rounded-full gap-2', !onViewPublic && 'col-span-2')}
              >
                Manage workspace <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function WorkspaceCreatedDialog({ open, workspace, onManage, onViewPublic }: Props) {
  const isMobile = useIsMobile();
  if (!workspace) return null;

  if (isMobile) {
    return (
      <Drawer open={open} dismissible={false}>
        <DrawerContent className="max-h-[92vh]">
          <Body workspace={workspace} onManage={onManage} onViewPublic={onViewPublic} />
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open}>
      <DialogContent className="max-w-2xl p-0 overflow-hidden">
        <Body workspace={workspace} onManage={onManage} onViewPublic={onViewPublic} />
      </DialogContent>
    </Dialog>
  );
}
