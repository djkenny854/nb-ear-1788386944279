import React, { useRef, useState } from 'react';
import { Loader2, ImagePlus, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface Props {
  value: string | null;
  onChange: (url: string | null) => void;
  className?: string;
  /** Pixel size of the square preview (default 192) */
  size?: number;
  uploadFolder?: string;
}

/**
 * Square (1:1) cover image picker for service workspaces.
 * Uploads to the existing `product-images` Supabase bucket and returns a public URL.
 */
export const CoverImagePicker: React.FC<Props> = ({
  value,
  onChange,
  className,
  size = 192,
  uploadFolder = 'service-covers',
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const handleFiles = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      toast({ title: 'Pick an image file', variant: 'destructive' });
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast({ title: 'Image too large', description: 'Keep it under 10MB.', variant: 'destructive' });
      return;
    }
    setUploading(true);
    try {
      const ext = file.name.split('.').pop() || 'jpg';
      const fileName = `${uploadFolder}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const { error } = await supabase.storage.from('product-images').upload(fileName, file, {
        cacheControl: '3600',
        upsert: false,
      });
      if (error) throw error;
      const { data } = supabase.storage.from('product-images').getPublicUrl(fileName);
      onChange(data.publicUrl);
    } catch (e: any) {
      console.error(e);
      toast({ title: 'Upload failed', description: e.message || 'Try again', variant: 'destructive' });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className={cn('flex flex-col items-center gap-3', className)}>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        hidden
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFiles(f);
          e.target.value = '';
        }}
      />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={uploading}
        className={cn(
          'relative rounded-2xl border-2 border-dashed border-border bg-muted/30 overflow-hidden flex items-center justify-center transition-colors hover:border-primary/50',
          uploading && 'opacity-70 pointer-events-none'
        )}
        style={{ width: size, height: size }}
        aria-label="Upload cover image"
      >
        {value ? (
          <img src={value} alt="Cover" className="w-full h-full object-cover" />
        ) : uploading ? (
          <Loader2 className="w-7 h-7 animate-spin text-muted-foreground" />
        ) : (
          <div className="flex flex-col items-center gap-2 text-muted-foreground">
            <ImagePlus className="w-7 h-7" />
            <span className="text-xs">Tap to upload</span>
            <span className="text-[10px]">1:1 square recommended</span>
          </div>
        )}
        {value && !uploading && (
          <span
            onClick={(e) => {
              e.stopPropagation();
              onChange(null);
            }}
            className="absolute top-2 right-2 h-7 w-7 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black/80"
          >
            <X className="w-3.5 h-3.5" />
          </span>
        )}
      </button>
    </div>
  );
};

export default CoverImagePicker;
