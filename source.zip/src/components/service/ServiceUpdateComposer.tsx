import React, { useState } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Loader2, ImageIcon, Video, ArrowLeftRight, Megaphone, Tag, X } from 'lucide-react';
import { uploadToB2 } from '@/utils/b2Upload';
import { MAX_VIDEO_UPLOAD_BYTES, MAX_VIDEO_UPLOAD_MB } from '@/utils/uploadVideoToB2';
import { Progress } from '@/components/ui/progress';
import { useServiceUpdates, ServiceUpdateType } from '@/hooks/useServiceUpdates';
import { toast } from 'sonner';

interface ServiceUpdateComposerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  serviceId: string;
  sellerId: string;
}

export const ServiceUpdateComposer: React.FC<ServiceUpdateComposerProps> = ({
  open,
  onOpenChange,
  serviceId,
  sellerId,
}) => {
  const { createUpdate, isCreating } = useServiceUpdates(serviceId);
  const [tab, setTab] = useState<ServiceUpdateType>('work');
  const [title, setTitle] = useState('');
  const [caption, setCaption] = useState('');
  const [tags, setTags] = useState('');
  const [clientName, setClientName] = useState('');
  const [images, setImages] = useState<string[]>([]);
  // Video is kept locally as a File + preview URL until the user clicks
  // Publish. We only PUT to B2 inside submit() — matches the wizard UX.
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);
  const [beforeImg, setBeforeImg] = useState<string | null>(null);
  const [afterImg, setAfterImg] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [videoProgress, setVideoProgress] = useState(0);
  const [publishStage, setPublishStage] = useState<string | null>(null);

  const reset = () => {
    setTitle(''); setCaption(''); setTags(''); setClientName('');
    setImages([]);
    if (videoPreview) URL.revokeObjectURL(videoPreview);
    setVideoFile(null); setVideoPreview(null);
    setBeforeImg(null); setAfterImg(null);
    setVideoProgress(0); setPublishStage(null);
  };

  const handleImagesPick = async (files: FileList | null) => {
    if (!files?.length) return;
    setUploading(true);
    try {
      const uploads = await Promise.all(
        Array.from(files).slice(0, 6 - images.length).map((f) => uploadToB2(f, 'service-updates'))
      );
      setImages((prev) => [...prev, ...uploads.map((u) => u.url)]);
    } catch (e: any) {
      toast.error(e.message || 'Image upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleVideoPick = (file: File | null) => {
    if (!file) return;
    if (file.size > MAX_VIDEO_UPLOAD_BYTES) {
      toast.error(`Video too large. Keep clips under ${MAX_VIDEO_UPLOAD_MB}MB.`);
      return;
    }
    // Preserve the file in the browser only — nothing is sent to B2 yet.
    // It will be compressed + uploaded inside submit() when the user
    // clicks Publish, identical to the publish wizard flow.
    if (videoPreview) URL.revokeObjectURL(videoPreview);
    setVideoFile(file);
    setVideoPreview(URL.createObjectURL(file));
    setVideoProgress(0);
  };

  const handleSinglePick = async (file: File | null, setter: (url: string | null) => void) => {
    if (!file) return;
    setUploading(true);
    try {
      const { url } = await uploadToB2(file, 'service-updates');
      setter(url);
    } catch (e: any) {
      toast.error(e.message || 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const submit = async () => {
    if (tab === 'before_after' && (!beforeImg || !afterImg)) {
      toast.error('Add both before and after images');
      return;
    }
    if (tab === 'reel' && !videoFile) {
      toast.error('Add a video');
      return;
    }
    if (!caption.trim() && images.length === 0 && !videoFile && !beforeImg) {
      toast.error('Add a caption or media');
      return;
    }

    try {
      // Upload the video NOW (matches the wizard mechanism). If anything
      // goes wrong, the full error is surfaced via console + toast and the
      // user can retry without losing their other inputs.
      let uploadedVideoUrl: string | undefined;
      let uploadedThumbUrl: string | undefined;
      if (videoFile) {
        setPublishStage('Preparing video…');
        setVideoProgress(1);
        try {
          const { uploadVideoWithThumbnailToB2 } = await import('@/utils/uploadVideoToB2');
          const res = await uploadVideoWithThumbnailToB2(videoFile, {
            onProgress: (p) => setVideoProgress(p),
          });
          uploadedVideoUrl = res.videoUrl;
          uploadedThumbUrl = res.thumbnailUrl || undefined;
        } catch (e: any) {
          console.error('[ServiceUpdateComposer] video upload failed:', e);
          toast.error(e?.message || 'Video upload failed. Check console for details.');
          setPublishStage(null);
          return;
        }
      }

      setPublishStage('Saving update…');
      await createUpdate({
        service_id: serviceId,
        seller_id: sellerId,
        update_type: tab,
        title: title.trim() || undefined,
        caption: caption.trim() || undefined,
        images,
        video_url: uploadedVideoUrl,
        video_thumbnail_url: uploadedThumbUrl,
        before_image_url: beforeImg || undefined,
        after_image_url: afterImg || undefined,
        tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
        client_name: clientName.trim() || undefined,
      });
      reset();
      onOpenChange(false);
    } catch {
      /* toast handled in hook */
    } finally {
      setPublishStage(null);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="bottom"
        className="p-0 rounded-t-2xl flex flex-col"
        style={{ height: '92dvh', maxHeight: '92dvh' }}
      >
        {/* Header */}
        <SheetHeader className="px-4 pt-4 pb-2 shrink-0 border-b border-border">
          <SheetTitle>Add update to this service</SheetTitle>
        </SheetHeader>

        {/* Scrollable body */}
        <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4">
          <Tabs value={tab} onValueChange={(v) => setTab(v as ServiceUpdateType)}>
            <TabsList className="grid grid-cols-5 w-full">
              <TabsTrigger value="work"><ImageIcon className="w-4 h-4" /></TabsTrigger>
              <TabsTrigger value="reel"><Video className="w-4 h-4" /></TabsTrigger>
              <TabsTrigger value="before_after"><ArrowLeftRight className="w-4 h-4" /></TabsTrigger>
              <TabsTrigger value="promo"><Tag className="w-4 h-4" /></TabsTrigger>
              <TabsTrigger value="announcement"><Megaphone className="w-4 h-4" /></TabsTrigger>
            </TabsList>

            <TabsContent value="work" className="space-y-3 mt-4">
              <Label>Photos (up to 6)</Label>
              <div className="grid grid-cols-3 gap-2">
                {images.map((src, i) => (
                  <div key={src} className="relative aspect-square rounded-lg overflow-hidden">
                    <img src={src} className="w-full h-full object-cover" alt="" />
                    <button
                      type="button"
                      onClick={() => setImages((p) => p.filter((_, idx) => idx !== i))}
                      className="absolute top-1 right-1 bg-black/60 text-white rounded-full p-1"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
                {images.length < 6 && (
                  <label className="aspect-square rounded-lg border-2 border-dashed border-border flex items-center justify-center cursor-pointer hover:bg-muted">
                    <input type="file" accept="image/*" multiple className="hidden"
                      onChange={(e) => handleImagesPick(e.target.files)} />
                    <ImageIcon className="w-6 h-6 text-muted-foreground" />
                  </label>
                )}
              </div>
            </TabsContent>

            <TabsContent value="reel" className="space-y-3 mt-4">
              <Label>Video clip (max {MAX_VIDEO_UPLOAD_MB}MB)</Label>
              {videoPreview ? (
                <div className="relative rounded-lg overflow-hidden bg-black">
                  <video src={videoPreview} controls className="w-full max-h-72" />
                  <button type="button" onClick={() => {
                    if (videoPreview) URL.revokeObjectURL(videoPreview);
                    setVideoFile(null); setVideoPreview(null); setVideoProgress(0);
                  }}
                    className="absolute top-2 right-2 bg-black/60 text-white rounded-full p-1.5">
                    <X className="w-3 h-3" />
                  </button>
                  <p className="px-2 py-1.5 text-[11px] text-muted-foreground bg-background">
                    Saved on your device — will upload when you tap Publish.
                  </p>
                </div>
              ) : (
                <label className="block aspect-video rounded-lg border-2 border-dashed border-border flex items-center justify-center cursor-pointer hover:bg-muted">
                  <input type="file" accept="video/*" className="hidden"
                    onChange={(e) => handleVideoPick(e.target.files?.[0] || null)} />
                  <div className="text-center text-muted-foreground px-3">
                    <Video className="w-8 h-8 mx-auto mb-2" />
                    <p className="text-sm">Tap to upload a short clip</p>
                    <p className="text-[11px] mt-1">Up to {MAX_VIDEO_UPLOAD_MB}MB — mp4, webm or mov</p>
                  </div>
                </label>
              )}
              {/* Show upload progress only during Publish */}
              {publishStage && videoFile && (
                <div className="mt-2">
                  <Progress value={videoProgress} className="h-1.5" />
                  <p className="text-[11px] mt-1 text-muted-foreground">
                    {videoProgress < 95 ? `Uploading ${videoProgress}%` : 'Finalizing…'}
                  </p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="before_after" className="space-y-3 mt-4">
              <div className="grid grid-cols-2 gap-3">
                {(['before', 'after'] as const).map((kind) => {
                  const url = kind === 'before' ? beforeImg : afterImg;
                  const setter = kind === 'before' ? setBeforeImg : setAfterImg;
                  return (
                    <div key={kind}>
                      <Label className="capitalize">{kind}</Label>
                      {url ? (
                        <div className="relative aspect-square rounded-lg overflow-hidden mt-1">
                          <img src={url} className="w-full h-full object-cover" alt="" />
                          <button type="button" onClick={() => setter(null)}
                            className="absolute top-1 right-1 bg-black/60 text-white rounded-full p-1">
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <label className="aspect-square rounded-lg border-2 border-dashed border-border flex items-center justify-center cursor-pointer hover:bg-muted mt-1">
                          <input type="file" accept="image/*" className="hidden"
                            onChange={(e) => handleSinglePick(e.target.files?.[0] || null, setter)} />
                          <ImageIcon className="w-5 h-5 text-muted-foreground" />
                        </label>
                      )}
                    </div>
                  );
                })}
              </div>
            </TabsContent>

            <TabsContent value="promo" className="space-y-3 mt-4">
              <Label>Promo banner (optional)</Label>
              <div className="grid grid-cols-3 gap-2">
                {images.map((src) => (
                  <img key={src} src={src} className="aspect-square w-full object-cover rounded-lg" alt="" />
                ))}
                {images.length === 0 && (
                  <label className="aspect-square rounded-lg border-2 border-dashed border-border flex items-center justify-center cursor-pointer hover:bg-muted col-span-3">
                    <input type="file" accept="image/*" className="hidden"
                      onChange={(e) => handleImagesPick(e.target.files)} />
                    <Tag className="w-6 h-6 text-muted-foreground" />
                  </label>
                )}
              </div>
            </TabsContent>

            <TabsContent value="announcement" className="mt-4 text-sm text-muted-foreground">
              Share news with followers of this service — caption is required.
            </TabsContent>
          </Tabs>

          <div className="space-y-3 mt-5">
            <div>
              <Label htmlFor="su-title">Title (optional)</Label>
              <Input id="su-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. New logo animation for ACME" />
            </div>
            <div>
              <Label htmlFor="su-caption">Caption</Label>
              <Textarea id="su-caption" value={caption} onChange={(e) => setCaption(e.target.value)}
                placeholder="What did you build, fix, or finish?" rows={3} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="su-client">Client (optional)</Label>
                <Input id="su-client" value={clientName} onChange={(e) => setClientName(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="su-tags">Tags</Label>
                <Input id="su-tags" value={tags} onChange={(e) => setTags(e.target.value)} placeholder="logo, branding" />
              </div>
            </div>
          </div>
        </div>

        {/* Fixed footer — always visible, respects safe area */}
        <div
          className="shrink-0 flex gap-2 px-4 pt-3 bg-background border-t border-border"
          style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 12px)' }}
        >
          <Button variant="outline" className="flex-1" onClick={() => onOpenChange(false)} disabled={isCreating || uploading || !!publishStage}>Cancel</Button>
          <Button className="flex-1 gap-2" onClick={submit} disabled={isCreating || uploading || !!publishStage}>
            {(isCreating || uploading || publishStage) ? <Loader2 className="w-4 h-4 animate-spin" /> : <Megaphone className="w-4 h-4" />}
            {publishStage || (isCreating ? 'Publishing…' : 'Publish update')}
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default ServiceUpdateComposer;
