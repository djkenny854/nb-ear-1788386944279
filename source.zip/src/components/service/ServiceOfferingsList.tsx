import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Check, Clock, DollarSign, Tag } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ServiceOffering {
  id: string;
  title: string;
  description?: string | null;
  price: number | null;
  price_type: 'fixed' | 'starting_from' | 'hourly' | 'negotiable';
  currency: string;
  duration_estimate?: string | null;
  is_available: boolean;
  category?: string | null;
}

interface ServiceOfferingsListProps {
  offerings: ServiceOffering[];
  onContact?: (offering: ServiceOffering) => void;
  compact?: boolean;
}

const priceTypeLabels: Record<string, string> = {
  fixed: '',
  starting_from: 'From ',
  hourly: '/hr',
  negotiable: 'Negotiable',
};

export const ServiceOfferingsList: React.FC<ServiceOfferingsListProps> = ({
  offerings,
  onContact,
  compact = false,
}) => {
  if (!offerings || offerings.length === 0) {
    return null;
  }

  const formatPrice = (offering: ServiceOffering) => {
    if (offering.price_type === 'negotiable' || !offering.price) {
      return 'Contact for price';
    }
    
    const formatted = new Intl.NumberFormat('en-UG').format(offering.price);
    const prefix = offering.price_type === 'starting_from' ? 'From ' : '';
    const suffix = offering.price_type === 'hourly' ? '/hr' : '';
    
    return `${prefix}${offering.currency} ${formatted}${suffix}`;
  };

  if (compact) {
    return (
      <div className="space-y-2">
        {offerings.slice(0, 5).map((offering) => (
          <div
            key={offering.id}
            className="flex items-center justify-between p-2.5 rounded-xl bg-muted/50 hover:bg-muted transition-colors"
          >
            <div className="flex items-center gap-2 min-w-0 flex-1">
              <Check className="w-3.5 h-3.5 text-primary flex-shrink-0" />
              <span className="text-sm font-medium truncate">{offering.title}</span>
              {!offering.is_available && (
                <Badge variant="secondary" className="text-[10px] py-0">Unavailable</Badge>
              )}
            </div>
            <span className="text-sm font-semibold text-primary whitespace-nowrap">
              {formatPrice(offering)}
            </span>
          </div>
        ))}
        {offerings.length > 5 && (
          <p className="text-xs text-muted-foreground text-center pt-1">
            +{offerings.length - 5} more services
          </p>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {offerings.map((offering) => (
        <div
          key={offering.id}
          className={cn(
            "p-4 rounded-2xl border border-border bg-card/50 hover:bg-card transition-colors",
            !offering.is_available && "opacity-60"
          )}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h4 className="font-semibold text-foreground">{offering.title}</h4>
                {offering.category && (
                  <Badge variant="secondary" className="text-[10px]">{offering.category}</Badge>
                )}
                {!offering.is_available && (
                  <Badge variant="outline" className="text-[10px] text-muted-foreground">
                    Currently Unavailable
                  </Badge>
                )}
              </div>
              
              {offering.description && (
                <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                  {offering.description}
                </p>
              )}
              
              {offering.duration_estimate && (
                <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  <span>{offering.duration_estimate}</span>
                </div>
              )}
            </div>
            
            <div className="text-right flex-shrink-0">
              <div className="text-lg font-bold text-primary">
                {formatPrice(offering)}
              </div>
              {onContact && offering.is_available && (
                <Button
                  size="sm"
                  variant="outline"
                  className="mt-2 text-xs h-7"
                  onClick={() => onContact(offering)}
                >
                  Inquire
                </Button>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ServiceOfferingsList;
