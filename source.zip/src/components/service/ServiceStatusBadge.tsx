import React from 'react';
import { cn } from '@/lib/utils';
import { Circle, Clock, XCircle, AlertCircle } from 'lucide-react';

export type ServiceStatusType = 'available' | 'busy' | 'closed' | 'limited_slots';

interface ServiceStatusBadgeProps {
  status: ServiceStatusType;
  message?: string | null;
  size?: 'sm' | 'md' | 'lg';
  showMessage?: boolean;
  className?: string;
}

const statusConfig: Record<ServiceStatusType, {
  label: string;
  icon: React.ElementType;
  colors: string;
  dotColor: string;
}> = {
  available: {
    label: 'Available',
    icon: Circle,
    colors: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 border-green-200 dark:border-green-800',
    dotColor: 'bg-green-500',
  },
  busy: {
    label: 'Busy',
    icon: Clock,
    colors: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border-amber-200 dark:border-amber-800',
    dotColor: 'bg-amber-500',
  },
  closed: {
    label: 'Closed',
    icon: XCircle,
    colors: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 border-red-200 dark:border-red-800',
    dotColor: 'bg-red-500',
  },
  limited_slots: {
    label: 'Limited Slots',
    icon: AlertCircle,
    colors: 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400 border-orange-200 dark:border-orange-800',
    dotColor: 'bg-orange-500',
  },
};

export const ServiceStatusBadge: React.FC<ServiceStatusBadgeProps> = ({
  status,
  message,
  size = 'sm',
  showMessage = false,
  className,
}) => {
  const config = statusConfig[status] || statusConfig.available;
  const Icon = config.icon;

  const sizeClasses = {
    sm: 'text-[10px] px-1.5 py-0.5 gap-1',
    md: 'text-xs px-2 py-1 gap-1.5',
    lg: 'text-sm px-3 py-1.5 gap-2',
  };

  const iconSizes = {
    sm: 'w-2.5 h-2.5',
    md: 'w-3 h-3',
    lg: 'w-4 h-4',
  };

  const dotSizes = {
    sm: 'w-1.5 h-1.5',
    md: 'w-2 h-2',
    lg: 'w-2.5 h-2.5',
  };

  return (
    <div className={cn("flex items-center gap-1", className)}>
      <span
        className={cn(
          'inline-flex items-center rounded-full font-medium border',
          config.colors,
          sizeClasses[size]
        )}
      >
        <span className={cn('rounded-full animate-pulse', config.dotColor, dotSizes[size])} />
        {config.label}
      </span>
      {showMessage && message && (
        <span className="text-xs text-muted-foreground truncate max-w-[120px]">
          {message}
        </span>
      )}
    </div>
  );
};

export default ServiceStatusBadge;
