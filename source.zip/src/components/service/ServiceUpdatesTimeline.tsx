import React, { useState } from 'react';
import { Plus, Activity } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useServiceUpdates } from '@/hooks/useServiceUpdates';
import ServiceUpdateCard from './ServiceUpdateCard';
import ServiceUpdateComposer from './ServiceUpdateComposer';

interface Props {
  serviceId: string;
  sellerId: string;
  isOwner?: boolean;
}

export const ServiceUpdatesTimeline: React.FC<Props> = ({ serviceId, sellerId, isOwner }) => {
  const { updates, isLoading, deleteUpdate } = useServiceUpdates(serviceId);
  const [composerOpen, setComposerOpen] = useState(false);

  return (
    <div className="space-y-4">
      {isOwner && (
        <Button onClick={() => setComposerOpen(true)} className="w-full gap-2" size="lg">
          <Plus className="w-4 h-4" /> Add work, reel, or before/after
        </Button>
      )}

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-64 bg-muted rounded-2xl animate-pulse" />
          ))}
        </div>
      ) : updates.length === 0 ? (
        <div className="text-center py-12 border border-dashed border-border rounded-2xl">
          <Activity className="w-10 h-10 mx-auto mb-3 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            {isOwner ? 'No updates yet — share your latest work to keep this service alive.' : 'No updates yet.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {updates.map((u) => (
            <ServiceUpdateCard key={u.id} update={u} isOwner={isOwner} onDelete={deleteUpdate} />
          ))}
        </div>
      )}

      {isOwner && (
        <ServiceUpdateComposer
          open={composerOpen}
          onOpenChange={setComposerOpen}
          serviceId={serviceId}
          sellerId={sellerId}
        />
      )}
    </div>
  );
};

export default ServiceUpdatesTimeline;
