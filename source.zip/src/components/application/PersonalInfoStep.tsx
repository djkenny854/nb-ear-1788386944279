import { motion } from 'framer-motion';
import { User, Mail, Phone } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface PersonalInfoStepProps {
  formData: {
    name: string;
    email: string;
    phone: string;
  };
  setFormData: (data: any) => void;
}

export default function PersonalInfoStep({ formData, setFormData }: PersonalInfoStepProps) {
  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-2"
      >
        <h2 className="text-3xl md:text-4xl font-bold">Tell us about yourself</h2>
        <p className="text-muted-foreground text-lg">
          We'll use this information to contact you about this opportunity
        </p>
      </motion.div>

      <div className="max-w-2xl mx-auto space-y-6">
        {/* Full Name */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-3"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <User className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <Label htmlFor="name" className="text-base font-semibold">
                Full Name *
              </Label>
              <p className="text-sm text-muted-foreground">
                Your legal name as it appears on official documents
              </p>
            </div>
          </div>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData((prev: any) => ({ ...prev, name: e.target.value }))}
            placeholder="John Doe"
            required
            className="h-14 text-lg border-2"
          />
        </motion.div>

        {/* Email */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-3"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Mail className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <Label htmlFor="email" className="text-base font-semibold">
                Email Address *
              </Label>
              <p className="text-sm text-muted-foreground">
                We'll send application updates to this email
              </p>
            </div>
          </div>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData((prev: any) => ({ ...prev, email: e.target.value }))}
            placeholder="john@example.com"
            required
            className="h-14 text-lg border-2"
          />
        </motion.div>

        {/* Phone */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-3"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Phone className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <Label htmlFor="phone" className="text-base font-semibold">
                Phone Number
              </Label>
              <p className="text-sm text-muted-foreground">
                Optional - For quick contact if needed
              </p>
            </div>
          </div>
          <Input
            id="phone"
            type="tel"
            value={formData.phone}
            onChange={(e) => setFormData((prev: any) => ({ ...prev, phone: e.target.value }))}
            placeholder="+256 700 000000"
            className="h-14 text-lg border-2"
          />
        </motion.div>
      </div>
    </div>
  );
}
