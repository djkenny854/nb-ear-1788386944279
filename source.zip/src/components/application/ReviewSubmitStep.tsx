import { motion } from 'framer-motion';
import { 
  User, 
  Mail, 
  Phone, 
  FileText, 
  MessageSquare, 
  StickyNote,
  Briefcase,
  Building2,
  CheckCircle2,
  Loader2
} from 'lucide-react';

interface ReviewSubmitStepProps {
  jobDetails: any;
  formData: {
    name: string;
    email: string;
    phone: string;
    coverLetter: string;
    notes: string;
  };
  resumeFile: File | null;
  submitting: boolean;
  selectedRole?: string | null;
}

export default function ReviewSubmitStep({ 
  jobDetails, 
  formData, 
  resumeFile,
  submitting 
}: ReviewSubmitStepProps) {
  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-2"
      >
        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
          <CheckCircle2 className="w-8 h-8 text-primary" />
        </div>
        <h2 className="text-3xl md:text-4xl font-bold">Review Your Application</h2>
        <p className="text-muted-foreground text-lg">
          Please review your information before submitting
        </p>
      </motion.div>

      <div className="max-w-3xl mx-auto space-y-6">
        {/* Job Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="p-6 bg-primary/5 rounded-2xl space-y-4"
        >
          <div className="flex items-center gap-3 mb-4">
            <Briefcase className="w-6 h-6 text-primary" />
            <h3 className="text-xl font-bold">Applying For</h3>
          </div>
          <div className="space-y-2">
            <p className="text-2xl font-bold">{jobDetails?.title}</p>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Building2 className="w-4 h-4" />
              <span>{jobDetails?.seller_profiles?.business_name}</span>
            </div>
          </div>
        </motion.div>

        {/* Personal Information */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-6 rounded-2xl border-2 space-y-4"
        >
          <h3 className="text-xl font-bold mb-4">Personal Information</h3>
          
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <User className="w-5 h-5 text-primary mt-1" />
              <div>
                <p className="text-sm text-muted-foreground">Full Name</p>
                <p className="font-semibold text-lg">{formData.name}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Mail className="w-5 h-5 text-primary mt-1" />
              <div>
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="font-semibold text-lg">{formData.email}</p>
              </div>
            </div>

            {formData.phone && (
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-primary mt-1" />
                <div>
                  <p className="text-sm text-muted-foreground">Phone</p>
                  <p className="font-semibold text-lg">{formData.phone}</p>
                </div>
              </div>
            )}
          </div>
        </motion.div>

        {/* Application Materials */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="p-6 rounded-2xl border-2 space-y-4"
        >
          <h3 className="text-xl font-bold mb-4">Application Materials</h3>
          
          <div className="space-y-4">
            {resumeFile && (
              <div className="flex items-start gap-3">
                <FileText className="w-5 h-5 text-primary mt-1" />
                <div>
                  <p className="text-sm text-muted-foreground">Resume</p>
                  <p className="font-semibold">{resumeFile.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {(resumeFile.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              </div>
            )}

            {formData.coverLetter && (
              <div className="flex items-start gap-3">
                <MessageSquare className="w-5 h-5 text-primary mt-1" />
                <div className="flex-1">
                  <p className="text-sm text-muted-foreground mb-2">Cover Letter</p>
                  <p className="text-sm leading-relaxed line-clamp-4 bg-muted/30 p-4 rounded-lg">
                    {formData.coverLetter}
                  </p>
                </div>
              </div>
            )}

            {formData.notes && (
              <div className="flex items-start gap-3">
                <StickyNote className="w-5 h-5 text-primary mt-1" />
                <div className="flex-1">
                  <p className="text-sm text-muted-foreground mb-2">Additional Notes</p>
                  <p className="text-sm leading-relaxed line-clamp-3 bg-muted/30 p-4 rounded-lg">
                    {formData.notes}
                  </p>
                </div>
              </div>
            )}
          </div>
        </motion.div>

        {submitting && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center justify-center gap-3 p-6 bg-primary/10 rounded-2xl"
          >
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
            <p className="text-lg font-semibold">Submitting your application...</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
