import React, { useEffect, useMemo, useRef, useState } from 'react';
import CatalogEditor from '@/components/service/CatalogEditor';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import {
  AlertTriangle,
  Briefcase,
  Megaphone,
  Monitor,
  Package,
  Save,
  Trash2,
  Wrench,
  X,
} from 'lucide-react';
import { ugandaDistricts, getSubCounties } from '@/data/ugandaDistricts';

interface EditListingModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  listingId: string | null;
  onSuccess?: () => void;
}

type ListingFormData = {
  title: string;
  description: string;
  price: number;
  original_price: number;
  has_discount: boolean;
  category: string;
  subcategory: string;
  location: string;
  is_price_negotiable: boolean;
  listing_type: string;
  status: string;
};

type JobPosition = {
  role: string;
  quantity: number;
  job_type: string;
  salary_min: number | null;
  salary_max: number | null;
  salary_negotiable: boolean;
  requirements: string;
};

type JobFormData = {
  company_name: string;
  salary_min: number;
  salary_max: number;
  salary_currency: string;
  job_type: string;
  work_location: string;
  requirements: string;
  responsibilities: string;
  benefits: string;
  job_posting_type: string;
  positions: JobPosition[];
};

type ServiceFormData = {
  starting_price: number;
  qualifications: string;
  experience_years: number;
};

type PromotionFormData = {
  brand_name: string;
  offer_type: string;
  discount_percentage: number;
  discount_amount: number;
  promo_code: string;
  valid_until: string;
  terms_conditions: string;
};

type DigitalFormData = {
  file_type: string;
  file_size: string;
  license_type: string;
  version: string;
  system_requirements: string;
};

const DEFAULT_FORM_DATA: ListingFormData = {
  title: '',
  description: '',
  price: 0,
  original_price: 0,
  has_discount: false,
  category: '',
  subcategory: '',
  location: '',
  is_price_negotiable: false,
  listing_type: 'physical_products',
  status: 'active',
};

const DEFAULT_JOB_DATA: JobFormData = {
  company_name: '',
  salary_min: 0,
  salary_max: 0,
  salary_currency: 'UGX',
  job_type: 'full_time',
  work_location: 'on_site',
  requirements: '',
  responsibilities: '',
  benefits: '',
  job_posting_type: 'single',
  positions: [],
};

const DEFAULT_SERVICE_DATA: ServiceFormData = {
  starting_price: 0,
  qualifications: '',
  experience_years: 0,
};

const DEFAULT_PROMOTION_DATA: PromotionFormData = {
  brand_name: '',
  offer_type: 'discount',
  discount_percentage: 0,
  discount_amount: 0,
  promo_code: '',
  valid_until: '',
  terms_conditions: '',
};

const DEFAULT_DIGITAL_DATA: DigitalFormData = {
  file_type: '',
  file_size: '',
  license_type: 'personal',
  version: '',
  system_requirements: '',
};

const listingTypeMeta: Record<string, { label: string; icon: React.ElementType }> = {
  jobs: { label: 'Job', icon: Briefcase },
  services: { label: 'Service', icon: Wrench },
  promotions: { label: 'Promotion', icon: Megaphone },
  digital_products: { label: 'Digital Product', icon: Monitor },
  physical_products: { label: 'Product', icon: Package },
};

const Section = ({
  title,
  children,
  icon: Icon,
}: {
  title: string;
  children: React.ReactNode;
  icon: React.ElementType;
}) => (
  <section className="rounded-2xl border border-border bg-card p-4 space-y-4">
    <div className="flex items-center gap-3">
      <div className="rounded-xl bg-muted p-2 text-primary">
        <Icon className="h-4 w-4" />
      </div>
      <h3 className="text-sm font-semibold text-foreground">{title}</h3>
    </div>
    {children}
  </section>
);

const Field = ({
  label,
  children,
  className,
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) => (
  <div className={cn('space-y-1.5', className)}>
    <Label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</Label>
    {children}
  </div>
);

const nativeSelectClassName =
  'flex h-11 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2';

const numberValue = (value: string) => {
  if (!value.trim()) return 0;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
};

const EditModalSkeleton = () => (
  <div className="space-y-4 p-5">
    <div className="flex items-center gap-3">
      <Skeleton className="h-12 w-12 rounded-2xl" />
      <div className="flex-1 space-y-2">
        <Skeleton className="h-5 w-40" />
        <Skeleton className="h-4 w-24" />
      </div>
    </div>
    <Skeleton className="h-32 w-full rounded-2xl" />
    <Skeleton className="h-32 w-full rounded-2xl" />
  </div>
);

const EditListingModal: React.FC<EditListingModalProps> = ({
  open,
  onOpenChange,
  listingId,
  onSuccess,
}) => {
  const queryClient = useQueryClient();
  const dirtyListingFieldsRef = useRef<Set<string>>(new Set());
  const dirtyDetailsRef = useRef<Set<'job' | 'service' | 'promotion' | 'digital'>>(new Set());

  const [formData, setFormData] = useState<ListingFormData>(DEFAULT_FORM_DATA);
  const [jobData, setJobData] = useState<JobFormData>(DEFAULT_JOB_DATA);
  const [serviceData, setServiceData] = useState<ServiceFormData>(DEFAULT_SERVICE_DATA);
  const [promotionData, setPromotionData] = useState<PromotionFormData>(DEFAULT_PROMOTION_DATA);
  const [digitalData, setDigitalData] = useState<DigitalFormData>(DEFAULT_DIGITAL_DATA);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);

  // Fetch categories from DB
  const { data: dbCategories } = useQuery({
    queryKey: ['edit-modal-categories'],
    enabled: open,
    queryFn: async () => {
      const { data } = await supabase.from('categories').select('id, name').eq('is_active', true).order('name');
      return data || [];
    },
  });

  // Subcategories fetched from DB
  const [availableSubcategories, setAvailableSubcategories] = useState<{ id: string; name: string }[]>([]);

  // Fetch subcategories when category changes
  const { data: fetchedSubcategories } = useQuery({
    queryKey: ['edit-modal-subcategories', formData.category],
    enabled: open && !!formData.category,
    queryFn: async () => {
      // Find category ID from name
      const cat = dbCategories?.find(c => c.name === formData.category);
      if (!cat) return [];
      const { data } = await supabase.from('subcategories').select('id, name').eq('category_id', cat.id).order('name');
      return data || [];
    },
  });

  useEffect(() => {
    setAvailableSubcategories(fetchedSubcategories || []);
  }, [fetchedSubcategories]);

  // Location state
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const [selectedSubCounty, setSelectedSubCounty] = useState('');
  const [availableSubCounties, setAvailableSubCounties] = useState<string[]>([]);

  // Update subcounties when district changes
  useEffect(() => {
    if (selectedDistrict) {
      setAvailableSubCounties(getSubCounties(selectedDistrict));
    } else {
      setAvailableSubCounties([]);
    }
  }, [selectedDistrict]);

  const { data: listing, isLoading } = useQuery({
    queryKey: ['listing-edit', listingId],
    enabled: open && !!listingId,
    queryFn: async () => {
      const { data, error } = await supabase.from('ads').select('*').eq('id', listingId as string).single();
      if (error) throw error;
      return data;
    },
  });

  const { data: jobDetails } = useQuery({
    queryKey: ['job-details-edit', listingId],
    enabled: open && !!listingId && listing?.listing_type === 'jobs',
    queryFn: async () => {
      const { data, error } = await supabase.from('job_details').select('*').eq('ad_id', listingId as string).maybeSingle();
      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
  });

  const { data: serviceDetails } = useQuery({
    queryKey: ['service-details-edit', listingId],
    enabled: open && !!listingId && listing?.listing_type === 'services',
    queryFn: async () => {
      const { data, error } = await supabase.from('service_details').select('*').eq('ad_id', listingId as string).maybeSingle();
      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
  });

  const { data: promotionDetails } = useQuery({
    queryKey: ['promotion-details-edit', listingId],
    enabled: open && !!listingId && listing?.listing_type === 'promotions',
    queryFn: async () => {
      const { data, error } = await supabase.from('promotion_details').select('*').eq('ad_id', listingId as string).maybeSingle();
      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
  });

  const { data: digitalDetails } = useQuery({
    queryKey: ['digital-details-edit', listingId],
    enabled: open && !!listingId && listing?.listing_type === 'digital_products',
    queryFn: async () => {
      const { data, error } = await supabase.from('digital_product_details').select('*').eq('ad_id', listingId as string).maybeSingle();
      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
  });

  useEffect(() => {
    if (!open) {
      dirtyListingFieldsRef.current.clear();
      dirtyDetailsRef.current.clear();
      setIsDeleting(false);
      setIsUpdatingStatus(false);
      return;
    }

    if (!listing) return;

    // Parse location into district and sub-county
    const locationParts = (listing.location || '').split(',').map(s => s.trim());
    const district = locationParts[0] || '';
    const subCounty = locationParts[1] || '';
    setSelectedDistrict(district);
    setSelectedSubCounty(subCounty);

    setFormData({
      title: listing.title || '',
      description: listing.description || '',
      price: listing.price || 0,
      original_price: listing.original_price || listing.price || 0,
      has_discount: Boolean(listing.original_price && listing.original_price > (listing.price || 0)),
      category: listing.category || '',
      subcategory: listing.subcategory || '',
      location: listing.location || '',
      is_price_negotiable: Boolean(listing.is_price_negotiable),
      listing_type: listing.listing_type || 'physical_products',
      status: listing.status || 'active',
    });

    dirtyListingFieldsRef.current.clear();
    dirtyDetailsRef.current.clear();
  }, [open, listing]);

  useEffect(() => {
    if (!jobDetails) return;
    const positionsRaw = jobDetails.positions as any;
    const positions: JobPosition[] = Array.isArray(positionsRaw) ? positionsRaw.map((p: any) => ({
      role: p.role || '',
      quantity: p.quantity || 1,
      job_type: p.job_type || 'Full-Time',
      salary_min: p.salary_min ?? null,
      salary_max: p.salary_max ?? null,
      salary_negotiable: p.salary_negotiable || false,
      requirements: p.requirements || '',
    })) : [];
    setJobData({
      company_name: jobDetails.company_name || '',
      salary_min: jobDetails.salary_min || 0,
      salary_max: jobDetails.salary_max || 0,
      salary_currency: jobDetails.salary_currency || 'UGX',
      job_type: jobDetails.job_type || 'full_time',
      work_location: jobDetails.work_location || 'on_site',
      requirements: jobDetails.requirements || '',
      responsibilities: jobDetails.responsibilities || '',
      benefits: jobDetails.benefits || '',
      job_posting_type: (jobDetails as any).job_posting_type || 'single',
      positions,
    });
  }, [jobDetails]);

  useEffect(() => {
    if (!serviceDetails) return;
    setServiceData({
      starting_price: serviceDetails.starting_price || 0,
      qualifications: serviceDetails.qualifications || '',
      experience_years: serviceDetails.experience_years || 0,
    });
  }, [serviceDetails]);

  useEffect(() => {
    if (!promotionDetails) return;
    setPromotionData({
      brand_name: promotionDetails.brand_name || '',
      offer_type: promotionDetails.offer_type || 'discount',
      discount_percentage: promotionDetails.discount_percentage || 0,
      discount_amount: promotionDetails.discount_amount || 0,
      promo_code: promotionDetails.promo_code || '',
      valid_until: promotionDetails.valid_until ? new Date(promotionDetails.valid_until).toISOString().split('T')[0] : '',
      terms_conditions: promotionDetails.terms_conditions || '',
    });
  }, [promotionDetails]);

  useEffect(() => {
    if (!digitalDetails) return;
    setDigitalData({
      file_type: digitalDetails.file_type || '',
      file_size: digitalDetails.file_size || '',
      license_type: digitalDetails.license_type || 'personal',
      version: digitalDetails.version || '',
      system_requirements: digitalDetails.system_requirements || '',
    });
  }, [digitalDetails]);

  useEffect(() => {
    if (!open) return;

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onOpenChange(false);
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, onOpenChange]);

  const listingType = formData.listing_type || 'physical_products';
  const isJob = listingType === 'jobs';
  const isService = listingType === 'services';
  const isPromotion = listingType === 'promotions';
  const isDigital = listingType === 'digital_products';
  const isProduct = listingType === 'physical_products' || listingType === 'digital_products';

  const listingMeta = useMemo(() => {
    return listingTypeMeta[listingType] || listingTypeMeta.physical_products;
  }, [listingType]);

  const ListingIcon = listingMeta.icon;

  const discountPercentage =
    formData.has_discount && formData.original_price > formData.price && formData.original_price > 0
      ? Math.round((1 - formData.price / formData.original_price) * 100)
      : 0;

  const markFieldDirty = (field: keyof ListingFormData) => {
    dirtyListingFieldsRef.current.add(field);
  };

  const markDetailsDirty = (type: 'job' | 'service' | 'promotion' | 'digital') => {
    dirtyDetailsRef.current.add(type);
  };

  const invalidateAfterSave = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['listing-edit', listingId] }),
      queryClient.invalidateQueries({ queryKey: ['user-products'] }),
      queryClient.invalidateQueries({ queryKey: ['user-ads-stats'] }),
      queryClient.invalidateQueries({ queryKey: ['job-details-edit', listingId] }),
      queryClient.invalidateQueries({ queryKey: ['service-details-edit', listingId] }),
      queryClient.invalidateQueries({ queryKey: ['promotion-details-edit', listingId] }),
      queryClient.invalidateQueries({ queryKey: ['digital-details-edit', listingId] }),
    ]);
  };

  const updateMutation = useMutation({
    mutationFn: async () => {
      if (!listingId) throw new Error('Listing not found');

      const updates: Record<string, unknown> = {};
      dirtyListingFieldsRef.current.forEach((field) => {
        if (field === 'original_price') {
          updates.original_price = formData.has_discount ? formData.original_price : null;
          return;
        }
        updates[field] = (formData as any)[field];
      });

      if (dirtyListingFieldsRef.current.has('has_discount') && !dirtyListingFieldsRef.current.has('original_price')) {
        updates.original_price = formData.has_discount ? formData.original_price : null;
      }

      if (Object.keys(updates).length > 0) {
        const { error } = await supabase.from('ads').update(updates as any).eq('id', listingId);
        if (error) throw error;
      }

      if (dirtyDetailsRef.current.has('job')) {
        const { positions, job_posting_type, ...restJobData } = jobData;
        const payload: Record<string, unknown> = { ad_id: listingId, ...restJobData };
        if (job_posting_type === 'multiple') {
          payload.positions = positions;
          payload.job_posting_type = 'multiple';
          payload.number_of_positions = positions.reduce((sum, p) => sum + p.quantity, 0);
        }
        const { error } = await supabase.from('job_details').upsert(payload as any, { onConflict: 'ad_id' });
        if (error) throw error;
      }

      if (dirtyDetailsRef.current.has('service')) {
        const payload = { ad_id: listingId, ...serviceData };
        const { error } = await supabase.from('service_details').upsert(payload, { onConflict: 'ad_id' });
        if (error) throw error;
      }

      if (dirtyDetailsRef.current.has('promotion')) {
        const payload = {
          ad_id: listingId,
          ...promotionData,
          valid_until: promotionData.valid_until || null,
        };
        const { error } = await supabase.from('promotion_details').upsert(payload, { onConflict: 'ad_id' });
        if (error) throw error;
      }

      if (dirtyDetailsRef.current.has('digital')) {
        const payload = { ad_id: listingId, ...digitalData };
        const { error } = await supabase.from('digital_product_details').upsert(payload, { onConflict: 'ad_id' });
        if (error) throw error;
      }
    },
    onSuccess: async () => {
      toast.success('Listing updated successfully');
      dirtyListingFieldsRef.current.clear();
      dirtyDetailsRef.current.clear();
      await invalidateAfterSave();
      onSuccess?.();
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast.error(`Failed to update listing: ${error.message}`);
    },
  });

  const handleSubmit = (event?: React.FormEvent) => {
    event?.preventDefault();

    if (!dirtyListingFieldsRef.current.size && !dirtyDetailsRef.current.size) {
      toast.info('No changes to save');
      return;
    }

    updateMutation.mutate();
  };

  const handleDelete = async () => {
    if (!listingId) return;
    const confirmed = window.confirm('Delete this listing permanently?');
    if (!confirmed) return;

    try {
      setIsDeleting(true);
      const { error } = await supabase.from('ads').delete().eq('id', listingId);
      if (error) throw error;
      toast.success('Listing deleted successfully');
      await invalidateAfterSave();
      onSuccess?.();
      onOpenChange(false);
    } catch (error) {
      toast.error(`Failed to delete listing: ${(error as Error).message}`);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleStatusChange = async (status: 'active' | 'inactive' | 'sold') => {
    if (!listingId) return;
    try {
      setIsUpdatingStatus(true);
      const { error } = await supabase.from('ads').update({ status }).eq('id', listingId);
      if (error) throw error;
      setFormData((prev) => ({ ...prev, status }));
      toast.success('Status updated successfully');
      await invalidateAfterSave();
    } catch (error) {
      toast.error(`Failed to update status: ${(error as Error).message}`);
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const handleDistrictChange = (district: string) => {
    setSelectedDistrict(district);
    setSelectedSubCounty('');
    const locationStr = district;
    setFormData(prev => ({ ...prev, location: locationStr }));
    markFieldDirty('location');
  };

  const handleSubCountyChange = (subCounty: string) => {
    setSelectedSubCounty(subCounty);
    const locationStr = subCounty ? `${selectedDistrict}, ${subCounty}` : selectedDistrict;
    setFormData(prev => ({ ...prev, location: locationStr }));
    markFieldDirty('location');
  };

  const handleCategoryChange = (category: string) => {
    setFormData(prev => ({ ...prev, category, subcategory: '' }));
    markFieldDirty('category');
    markFieldDirty('subcategory' as any);
    // Subcategories will auto-fetch via react-query when category changes
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-end justify-center bg-background/80 p-0 backdrop-blur-sm md:items-center md:p-4" onClick={() => onOpenChange(false)}>
      <div
        className="flex h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-t-[28px] border border-border bg-background shadow-2xl md:h-auto md:max-h-[90vh] md:rounded-[28px]"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="mx-auto mt-2 h-1.5 w-12 rounded-full bg-muted-foreground/30 md:hidden" />

        {isLoading ? (
          <EditModalSkeleton />
        ) : !listing ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 p-8 text-center">
            <AlertTriangle className="h-8 w-8 text-destructive" />
            <p className="text-sm text-muted-foreground">Listing not found.</p>
            <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
          </div>
        ) : (
          <>
            <div className="border-b border-border/60 p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="flex min-w-0 items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-2xl bg-muted">
                    {listing.images?.[0] ? (
                      <img src={listing.images[0]} alt="Listing" className="h-full w-full object-cover" />
                    ) : (
                      <ListingIcon className="h-5 w-5 text-primary" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <h2 className="truncate text-base font-bold text-foreground">{listing.title}</h2>
                    <div className="mt-1 flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">{listingMeta.label}</span>
                      <Badge variant="secondary" className="text-xs capitalize">{formData.status}</Badge>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onOpenChange(false)}
                  className="rounded-full p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                  aria-label="Close"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="flex min-h-0 flex-1 flex-col">
              <div className="flex-1 overflow-y-auto p-5 space-y-4">
                <Section title="Basic information" icon={Package}>
                  <Field label="Title">
                    <Input
                      value={formData.title}
                      onChange={(event) => {
                        markFieldDirty('title');
                        setFormData((prev) => ({ ...prev, title: event.target.value }));
                      }}
                    />
                  </Field>

                  <Field label="Description">
                    <Textarea
                      rows={4}
                      value={formData.description}
                      onChange={(event) => {
                        markFieldDirty('description');
                        setFormData((prev) => ({ ...prev, description: event.target.value }));
                      }}
                    />
                  </Field>

                  {isProduct && (
                    <div className="grid gap-3 sm:grid-cols-2">
                      <Field label="Category">
                        <select
                          className={nativeSelectClassName}
                          value={formData.category}
                          onChange={(event) => handleCategoryChange(event.target.value)}
                        >
                          <option value="">Select category</option>
                          {dbCategories?.map((cat) => (
                            <option key={cat.id} value={cat.name}>{cat.name}</option>
                          ))}
                          {formData.category && !dbCategories?.find(c => c.name === formData.category) && (
                            <option value={formData.category}>{formData.category}</option>
                          )}
                        </select>
                      </Field>

                      <Field label="Subcategory">
                        <select
                          className={nativeSelectClassName}
                          value={formData.subcategory}
                          onChange={(event) => {
                            markFieldDirty('subcategory' as any);
                            setFormData((prev) => ({ ...prev, subcategory: event.target.value }));
                          }}
                        >
                          <option value="">Select subcategory</option>
                          {availableSubcategories.map((sc) => (
                            <option key={sc.id} value={sc.name}>{sc.name}</option>
                          ))}
                          {formData.subcategory && !availableSubcategories.find(s => s.name === formData.subcategory) && (
                            <option value={formData.subcategory}>{formData.subcategory}</option>
                          )}
                        </select>
                      </Field>
                    </div>
                  )}

                  <div className="grid gap-3 sm:grid-cols-2">
                    <Field label="District">
                      <select
                        className={nativeSelectClassName}
                        value={selectedDistrict}
                        onChange={(e) => handleDistrictChange(e.target.value)}
                      >
                        <option value="">Select district</option>
                        {ugandaDistricts.map((d) => (
                          <option key={d.id} value={d.name}>{d.name}</option>
                        ))}
                        {selectedDistrict && !ugandaDistricts.find(d => d.name === selectedDistrict) && (
                          <option value={selectedDistrict}>{selectedDistrict}</option>
                        )}
                      </select>
                    </Field>
                    <Field label="Sub-county">
                      <select
                        className={nativeSelectClassName}
                        value={selectedSubCounty}
                        onChange={(e) => handleSubCountyChange(e.target.value)}
                        disabled={!selectedDistrict}
                      >
                        <option value="">Select sub-county</option>
                        {availableSubCounties.map((sc) => (
                          <option key={sc} value={sc}>{sc}</option>
                        ))}
                        {selectedSubCounty && !availableSubCounties.includes(selectedSubCounty) && (
                          <option value={selectedSubCounty}>{selectedSubCounty}</option>
                        )}
                      </select>
                    </Field>
                  </div>
                </Section>

                <Section title="Pricing" icon={Package}>
                  {isProduct && (
                    <>
                      <div className="grid gap-3 sm:grid-cols-1">
                        <Field label="Current price">
                          <Input
                            type="number"
                            value={formData.price}
                            onChange={(event) => {
                              markFieldDirty('price');
                              setFormData((prev) => ({ ...prev, price: numberValue(event.target.value) }));
                            }}
                          />
                        </Field>
                      </div>

                      <label className="flex items-center gap-3 text-sm text-foreground">
                        <input
                          type="checkbox"
                          className="h-4 w-4 rounded border-input accent-primary"
                          checked={formData.is_price_negotiable}
                          onChange={(event) => {
                            markFieldDirty('is_price_negotiable');
                            setFormData((prev) => ({ ...prev, is_price_negotiable: event.target.checked }));
                          }}
                        />
                        Price is negotiable
                      </label>
                    </>
                  )}

                  {/* Discount section - only for physical/digital products */}
                  {isProduct && (
                    <>
                      <div className="flex items-center justify-between rounded-xl border border-border bg-muted/30 px-4 py-3">
                        <div>
                          <p className="text-sm font-medium text-foreground">Enable discount</p>
                          <p className="text-xs text-muted-foreground">Set an original price to show discount.</p>
                        </div>
                        <input
                          type="checkbox"
                          className="h-4 w-4 rounded border-input accent-primary"
                          checked={formData.has_discount}
                          onChange={(event) => {
                            markFieldDirty('has_discount');
                            markFieldDirty('original_price');
                            setFormData((prev) => ({
                              ...prev,
                              has_discount: event.target.checked,
                              original_price: event.target.checked ? prev.original_price || prev.price : prev.original_price,
                            }));
                          }}
                        />
                      </div>

                      {formData.has_discount && (
                        <Field label="Original price">
                          <Input
                            type="number"
                            value={formData.original_price}
                            onChange={(event) => {
                              markFieldDirty('original_price');
                              setFormData((prev) => ({ ...prev, original_price: numberValue(event.target.value) }));
                            }}
                          />
                        </Field>
                      )}

                      {formData.has_discount && discountPercentage > 0 && (
                        <div className="rounded-xl bg-primary/10 px-4 py-3 text-sm text-primary">
                          Current discount: {discountPercentage}% off
                        </div>
                      )}
                    </>
                  )}
                </Section>

                {isJob && (
                  <Section title="Job details" icon={Briefcase}>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <Field label="Company name">
                        <Input
                          value={jobData.company_name}
                          onChange={(event) => {
                            markDetailsDirty('job');
                            setJobData((prev) => ({ ...prev, company_name: event.target.value }));
                          }}
                        />
                      </Field>
                      <Field label="Currency">
                        <Input
                          value={jobData.salary_currency}
                          onChange={(event) => {
                            markDetailsDirty('job');
                            setJobData((prev) => ({ ...prev, salary_currency: event.target.value }));
                          }}
                        />
                      </Field>
                      <Field label="Minimum salary">
                        <Input
                          type="number"
                          value={jobData.salary_min}
                          onChange={(event) => {
                            markDetailsDirty('job');
                            setJobData((prev) => ({ ...prev, salary_min: numberValue(event.target.value) }));
                          }}
                        />
                      </Field>
                      <Field label="Maximum salary">
                        <Input
                          type="number"
                          value={jobData.salary_max}
                          onChange={(event) => {
                            markDetailsDirty('job');
                            setJobData((prev) => ({ ...prev, salary_max: numberValue(event.target.value) }));
                          }}
                        />
                      </Field>
                      <Field label="Job type">
                        <select
                          className={nativeSelectClassName}
                          value={jobData.job_type}
                          onChange={(event) => {
                            markDetailsDirty('job');
                            setJobData((prev) => ({ ...prev, job_type: event.target.value }));
                          }}
                        >
                          <option value="full_time">Full time</option>
                          <option value="part_time">Part time</option>
                          <option value="contract">Contract</option>
                          <option value="internship">Internship</option>
                          <option value="temporary">Temporary</option>
                        </select>
                      </Field>
                      <Field label="Work location">
                        <select
                          className={nativeSelectClassName}
                          value={jobData.work_location}
                          onChange={(event) => {
                            markDetailsDirty('job');
                            setJobData((prev) => ({ ...prev, work_location: event.target.value }));
                          }}
                        >
                          <option value="on_site">On site</option>
                          <option value="remote">Remote</option>
                          <option value="hybrid">Hybrid</option>
                        </select>
                      </Field>
                    </div>
                    <Field label="Requirements">
                      <Textarea
                        rows={3}
                        value={jobData.requirements}
                        onChange={(event) => {
                          markDetailsDirty('job');
                          setJobData((prev) => ({ ...prev, requirements: event.target.value }));
                        }}
                      />
                    </Field>
                    <Field label="Responsibilities">
                      <Textarea
                        rows={3}
                        value={jobData.responsibilities}
                        onChange={(event) => {
                          markDetailsDirty('job');
                          setJobData((prev) => ({ ...prev, responsibilities: event.target.value }));
                        }}
                      />
                    </Field>
                    <Field label="Benefits">
                      <Textarea
                        rows={3}
                        value={jobData.benefits}
                        onChange={(event) => {
                          markDetailsDirty('job');
                          setJobData((prev) => ({ ...prev, benefits: event.target.value }));
                        }}
                      />
                    </Field>

                    {/* Multi-position editing */}
                    {jobData.job_posting_type === 'multiple' && jobData.positions.length > 0 && (
                      <div className="space-y-3">
                        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Positions ({jobData.positions.length} roles)</p>
                        {jobData.positions.map((pos, idx) => (
                          <div key={idx} className="rounded-xl border border-border bg-muted/20 p-3 space-y-2">
                            <div className="grid gap-2 sm:grid-cols-2">
                              <Field label={`Role ${idx + 1}`}>
                                <Input
                                  value={pos.role}
                                  onChange={(e) => {
                                    markDetailsDirty('job');
                                    const updated = [...jobData.positions];
                                    updated[idx] = { ...updated[idx], role: e.target.value };
                                    setJobData(prev => ({ ...prev, positions: updated }));
                                  }}
                                />
                              </Field>
                              <Field label="Openings">
                                <Input
                                  type="number"
                                  value={pos.quantity}
                                  onChange={(e) => {
                                    markDetailsDirty('job');
                                    const updated = [...jobData.positions];
                                    updated[idx] = { ...updated[idx], quantity: numberValue(e.target.value) };
                                    setJobData(prev => ({ ...prev, positions: updated }));
                                  }}
                                />
                              </Field>
                              <Field label="Salary Min">
                                <Input
                                  type="number"
                                  value={pos.salary_min ?? ''}
                                  onChange={(e) => {
                                    markDetailsDirty('job');
                                    const updated = [...jobData.positions];
                                    updated[idx] = { ...updated[idx], salary_min: e.target.value ? numberValue(e.target.value) : null };
                                    setJobData(prev => ({ ...prev, positions: updated }));
                                  }}
                                />
                              </Field>
                              <Field label="Salary Max">
                                <Input
                                  type="number"
                                  value={pos.salary_max ?? ''}
                                  onChange={(e) => {
                                    markDetailsDirty('job');
                                    const updated = [...jobData.positions];
                                    updated[idx] = { ...updated[idx], salary_max: e.target.value ? numberValue(e.target.value) : null };
                                    setJobData(prev => ({ ...prev, positions: updated }));
                                  }}
                                />
                              </Field>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </Section>
                )}

                {isService && (
                  <Section title="Service details" icon={Wrench}>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <Field label="Starting price">
                        <Input
                          type="number"
                          value={serviceData.starting_price}
                          onChange={(event) => {
                            markDetailsDirty('service');
                            setServiceData((prev) => ({ ...prev, starting_price: numberValue(event.target.value) }));
                          }}
                        />
                      </Field>
                      <Field label="Experience years">
                        <Input
                          type="number"
                          value={serviceData.experience_years}
                          onChange={(event) => {
                            markDetailsDirty('service');
                            setServiceData((prev) => ({ ...prev, experience_years: numberValue(event.target.value) }));
                          }}
                        />
                      </Field>
                    </div>
                    <Field label="Qualifications">
                      <Textarea
                        rows={3}
                        value={serviceData.qualifications}
                        onChange={(event) => {
                          markDetailsDirty('service');
                          setServiceData((prev) => ({ ...prev, qualifications: event.target.value }));
                        }}
                      />
                    </Field>

                    {/* Service Catalog */}
                    {listingId && listing?.seller_id && (
                      <div className="pt-2 border-t border-border/50">
                        <CatalogEditor adId={listingId} sellerId={listing.seller_id} />
                      </div>
                    )}
                  </Section>
                )}

                {isPromotion && (
                  <Section title="Promotion details" icon={Megaphone}>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <Field label="Brand name">
                        <Input
                          value={promotionData.brand_name}
                          onChange={(event) => {
                            markDetailsDirty('promotion');
                            setPromotionData((prev) => ({ ...prev, brand_name: event.target.value }));
                          }}
                        />
                      </Field>
                      <Field label="Offer type">
                        <select
                          className={nativeSelectClassName}
                          value={promotionData.offer_type}
                          onChange={(event) => {
                            markDetailsDirty('promotion');
                            setPromotionData((prev) => ({ ...prev, offer_type: event.target.value }));
                          }}
                        >
                          <option value="discount">Discount</option>
                          <option value="free_trial">Free trial</option>
                          <option value="bundle">Bundle</option>
                          <option value="cashback">Cashback</option>
                        </select>
                      </Field>
                      <Field label="Discount percentage">
                        <Input
                          type="number"
                          value={promotionData.discount_percentage}
                          onChange={(event) => {
                            markDetailsDirty('promotion');
                            setPromotionData((prev) => ({ ...prev, discount_percentage: numberValue(event.target.value) }));
                          }}
                        />
                      </Field>
                      <Field label="Discount amount">
                        <Input
                          type="number"
                          value={promotionData.discount_amount}
                          onChange={(event) => {
                            markDetailsDirty('promotion');
                            setPromotionData((prev) => ({ ...prev, discount_amount: numberValue(event.target.value) }));
                          }}
                        />
                      </Field>
                      <Field label="Promo code">
                        <Input
                          value={promotionData.promo_code}
                          onChange={(event) => {
                            markDetailsDirty('promotion');
                            setPromotionData((prev) => ({ ...prev, promo_code: event.target.value }));
                          }}
                        />
                      </Field>
                      <Field label="Valid until">
                        <Input
                          type="date"
                          value={promotionData.valid_until}
                          onChange={(event) => {
                            markDetailsDirty('promotion');
                            setPromotionData((prev) => ({ ...prev, valid_until: event.target.value }));
                          }}
                        />
                      </Field>
                    </div>
                    <Field label="Terms and conditions">
                      <Textarea
                        rows={3}
                        value={promotionData.terms_conditions}
                        onChange={(event) => {
                          markDetailsDirty('promotion');
                          setPromotionData((prev) => ({ ...prev, terms_conditions: event.target.value }));
                        }}
                      />
                    </Field>
                  </Section>
                )}

                {isDigital && (
                  <Section title="Digital product details" icon={Monitor}>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <Field label="File type">
                        <Input
                          value={digitalData.file_type}
                          onChange={(event) => {
                            markDetailsDirty('digital');
                            setDigitalData((prev) => ({ ...prev, file_type: event.target.value }));
                          }}
                        />
                      </Field>
                      <Field label="File size">
                        <Input
                          value={digitalData.file_size}
                          onChange={(event) => {
                            markDetailsDirty('digital');
                            setDigitalData((prev) => ({ ...prev, file_size: event.target.value }));
                          }}
                        />
                      </Field>
                      <Field label="License type">
                        <Input
                          value={digitalData.license_type}
                          onChange={(event) => {
                            markDetailsDirty('digital');
                            setDigitalData((prev) => ({ ...prev, license_type: event.target.value }));
                          }}
                        />
                      </Field>
                      <Field label="Version">
                        <Input
                          value={digitalData.version}
                          onChange={(event) => {
                            markDetailsDirty('digital');
                            setDigitalData((prev) => ({ ...prev, version: event.target.value }));
                          }}
                        />
                      </Field>
                    </div>
                    <Field label="System requirements">
                      <Textarea
                        rows={3}
                        value={digitalData.system_requirements}
                        onChange={(event) => {
                          markDetailsDirty('digital');
                          setDigitalData((prev) => ({ ...prev, system_requirements: event.target.value }));
                        }}
                      />
                    </Field>
                  </Section>
                )}

                <Section title="Listing status" icon={AlertTriangle}>
                  <div className="flex flex-wrap gap-2">
                    <Button type="button" variant={formData.status === 'active' ? 'default' : 'outline'} disabled={isUpdatingStatus} onClick={() => handleStatusChange('active')}>
                      Active
                    </Button>
                    <Button type="button" variant={formData.status === 'inactive' ? 'default' : 'outline'} disabled={isUpdatingStatus} onClick={() => handleStatusChange('inactive')}>
                      Inactive
                    </Button>
                    {isProduct && (
                      <Button type="button" variant={formData.status === 'sold' ? 'default' : 'outline'} disabled={isUpdatingStatus} onClick={() => handleStatusChange('sold')}>
                        Sold
                      </Button>
                    )}
                  </div>
                </Section>
              </div>

              <div className="border-t border-border/60 bg-card p-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <Button type="button" variant="outline" onClick={handleDelete} disabled={isDeleting} className="gap-2">
                    <Trash2 className="h-4 w-4" />
                    {isDeleting ? 'Deleting...' : 'Delete'}
                  </Button>

                  <div className="flex gap-3">
                    <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={updateMutation.isPending} className="gap-2">
                      <Save className="h-4 w-4" />
                      {updateMutation.isPending ? 'Saving...' : 'Save changes'}
                    </Button>
                  </div>
                </div>
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default EditListingModal;
