import { useState } from 'react';
import { Link2, Copy, Check, Share2, QrCode } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';


interface Props {
  publicUrl: string;
  title: string;
}

export default function WorkspaceShareTab({ publicUrl, title }: Props) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(publicUrl);
      setCopied(true);
      toast.success('Workspace URL copied');
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error('Could not copy');
    }
  };

  const share = async () => {
    try {
      if (navigator.share) {
        await navigator.share({ title, text: title, url: publicUrl });
      } else {
        await copy();
      }
    } catch {
      /* user cancelled */
    }
  };

  const qr = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(publicUrl)}`;

  return (
    <div className="space-y-4 max-w-xl">
      <div>
        <p className="text-sm font-medium">Your workspace URL</p>
        <p className="text-xs text-muted-foreground mt-1">Share this link anywhere — clicks land directly on your workspace.</p>
      </div>

      <div className="flex items-center gap-2 rounded-xl border border-border bg-muted/40 p-2.5">
        <Link2 className="h-4 w-4 text-muted-foreground shrink-0" />
        <span className="flex-1 text-xs truncate font-mono text-foreground/80">{publicUrl}</span>
        <Button size="sm" variant="ghost" className="h-7 px-2" onClick={copy}>
          {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Button onClick={share} className="gap-2 h-11 rounded-full">
          <Share2 className="h-4 w-4" /> Share
        </Button>
        <Button variant="outline" onClick={copy} className="gap-2 h-11 rounded-full">
          <Copy className="h-4 w-4" /> Copy link
        </Button>
      </div>

      <div className="rounded-2xl border border-border bg-card p-4 flex items-center gap-4">
        <img src={qr} alt="Workspace QR code" className="h-32 w-32 rounded-lg bg-white p-2" />
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <QrCode className="h-4 w-4 text-muted-foreground" />
            <p className="text-sm font-medium">QR code</p>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Print it on flyers, receipts or stickers. Customers scan it to open your workspace instantly.
          </p>
        </div>
      </div>
    </div>
  );
}
