import EarlyMarketAIIcon from './EarlyMarketAIIcon';

/**
 * Legacy alias — renders the official EarlyMarket AI icon.
 * Kept so existing imports across the app continue to work.
 */
const EMIIcon = ({ className = 'h-6 w-6', spin = false }: { className?: string; spin?: boolean }) => {
  return <EarlyMarketAIIcon className={className} spin={spin} />;
};

export default EMIIcon;
