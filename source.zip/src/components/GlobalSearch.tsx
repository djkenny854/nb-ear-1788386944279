import React, { useState, useEffect } from 'react';
import { Search, X, Filter, MapPin, DollarSign, Calendar, Loader2, TrendingUp, Clock, Star, ShoppingBag, Heart, MessageCircle, Share2, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useSemanticSearch } from '@/hooks/useSemanticSearch';
import { useAIFeatureFlags } from '@/hooks/useAIFeatureFlags';

interface SearchResult {
  id: string;
  title: string;
  price: number;
  location: string;
  category: string;
  images: string[];
  seller_name: string;
  created_at: string;
}

interface GlobalSearchProps {
  isOpen: boolean;
  onClose: () => void;
}

const SearchSkeleton = () => (
  <div className="space-y-4">
    {Array.from({ length: 6 }).map((_, i) => (
      <Card key={i} className="overflow-hidden">
        <CardContent className="p-4">
          <div className="flex gap-4">
            <Skeleton className="h-20 w-20 rounded-lg bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 bg-[length:200%_100%] animate-shimmer" />
            <div className="flex-1 space-y-3">
              <Skeleton className="h-5 w-3/4 bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 bg-[length:200%_100%] animate-shimmer" />
              <Skeleton className="h-4 w-1/2 bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 bg-[length:200%_100%] animate-shimmer" />
              <div className="flex justify-between items-center">
                <Skeleton className="h-6 w-1/3 bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 bg-[length:200%_100%] animate-shimmer" />
                <Skeleton className="h-4 w-1/4 bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 bg-[length:200%_100%] animate-shimmer" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    ))}
  </div>
);

const EmptyState = ({ query }: { query: string }) => (
  <div className="flex flex-col items-center justify-center py-16 text-center">
    <div className="w-24 h-24 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full flex items-center justify-center mb-6">
      <Search className="w-12 h-12 text-gray-400" />
    </div>
    <h3 className="text-xl font-semibold text-gray-900 mb-2">No results found</h3>
    <p className="text-gray-500 mb-6 max-w-md">
      {query ? `We couldn't find anything matching "${query}". Try different keywords or browse our categories.` : 'Start typing to search for products, services, and sellers.'}
    </p>
    <div className="flex gap-2 flex-wrap justify-center">
      {['Electronics', 'Fashion', 'Cars', 'Home'].map((category) => (
        <Badge key={category} variant="secondary" className="cursor-pointer hover:bg-primary hover:text-white transition-colors">
          {category}
        </Badge>
      ))}
    </div>
  </div>
);

const QuickFilters = ({ onFilterClick }: { onFilterClick: (filter: string) => void }) => (
  <div className="flex gap-2 flex-wrap mb-6">
    {[
      { label: 'Recent', icon: Clock, value: 'recent' },
      { label: 'Popular', icon: TrendingUp, value: 'popular' },
      { label: 'Price: Low to High', icon: DollarSign, value: 'price_low' },
      { label: 'Near Me', icon: MapPin, value: 'nearby' }
    ].map((filter) => (
      <Button
        key={filter.value}
        variant="outline"
        size="sm"
        onClick={() => onFilterClick(filter.value)}
        className="flex items-center gap-2 hover:bg-primary hover:text-white transition-colors"
      >
        <filter.icon className="w-4 h-4" />
        {filter.label}
      </Button>
    ))}
  </div>
);

const GlobalSearch: React.FC<GlobalSearchProps> = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [useAISearch, setUseAISearch] = useState(true);
  const [aiSearchUsed, setAiSearchUsed] = useState(false);
  const [filters, setFilters] = useState({
    category: '',
    minPrice: '',
    maxPrice: '',
    location: ''
  });
  const navigate = useNavigate();
  const { search: semanticSearch, fallbackUsed } = useSemanticSearch();
  const { aiSemanticSearchEnabled } = useAIFeatureFlags();

  useEffect(() => {
    // Load recent searches from localStorage
    const saved = localStorage.getItem('recentSearches');
    if (saved) {
      setRecentSearches(JSON.parse(saved));
    }
  }, []);

  const searchAds = async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([]);
      return;
    }

    setLoading(true);
    setAiSearchUsed(false);

    try {
      // Try AI semantic search first if enabled and flag is on
      if (useAISearch && aiSemanticSearchEnabled) {
        const semanticResults = await semanticSearch(searchQuery, {
          category: filters.category || undefined,
          limit: 20,
        });

        if (semanticResults.length > 0) {
          setAiSearchUsed(!fallbackUsed);
          
          // Apply additional filters
          let filtered = semanticResults;
          if (filters.minPrice) {
            filtered = filtered.filter(r => (r.price || 0) >= parseFloat(filters.minPrice));
          }
          if (filters.maxPrice) {
            filtered = filtered.filter(r => (r.price || 0) <= parseFloat(filters.maxPrice));
          }
          if (filters.location) {
            filtered = filtered.filter(r => 
              r.location?.toLowerCase().includes(filters.location.toLowerCase())
            );
          }

          setResults(filtered.map(r => ({
            id: r.id,
            title: r.title,
            price: r.price || 0,
            location: r.location || '',
            category: r.category,
            images: r.images || [],
            seller_name: r.seller_name || 'Unknown Seller',
            created_at: r.created_at || new Date().toISOString(),
          })));
          setLoading(false);
          return;
        }
      }

      // Fallback to direct database query
      let dbQuery = supabase
        .from('ads')
        .select(`
          id,
          title,
          price,
          location,
          category,
          images,
          created_at,
          seller_id,
          seller_profiles(
            business_name,
            user_id
          )
        `)
        .eq('status', 'active');

      // Fuzzy search - split query into keywords and match any
      if (searchQuery.trim()) {
        const keywords = searchQuery.trim().toLowerCase().split(/\s+/);
        const orConditions = keywords.flatMap(keyword => [
          `title.ilike.%${keyword}%`,
          `description.ilike.%${keyword}%`,
          `category.ilike.%${keyword}%`
        ]).join(',');
        dbQuery = dbQuery.or(orConditions);
      }

      if (filters.category) {
        dbQuery = dbQuery.eq('category', filters.category);
      }
      if (filters.minPrice) {
        dbQuery = dbQuery.gte('price', parseFloat(filters.minPrice));
      }
      if (filters.maxPrice) {
        dbQuery = dbQuery.lte('price', parseFloat(filters.maxPrice));
      }
      if (filters.location) {
        dbQuery = dbQuery.ilike('location', `%${filters.location}%`);
      }

      const { data, error } = await dbQuery.limit(20);

      if (error) throw error;

      const formattedResults = data?.map(ad => ({
        id: ad.id,
        title: ad.title,
        price: ad.price || 0,
        location: ad.location,
        category: ad.category,
        images: ad.images || [],
        seller_name: (ad.seller_profiles as any)?.business_name || 'Unknown Seller',
        created_at: ad.created_at
      })) || [];

      setResults(formattedResults);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (searchQuery: string) => {
    if (!searchQuery.trim()) return;
    
    // Save to recent searches
    const updated = [searchQuery, ...recentSearches.filter(s => s !== searchQuery)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem('recentSearches', JSON.stringify(updated));
    
    searchAds(searchQuery);
  };

  const handleResultClick = (adId: string) => {
    navigate(`/ad/${adId}`);
    onClose();
  };

  const handleFilterClick = (filterType: string) => {
    // Handle quick filter logic here
    console.log('Filter clicked:', filterType);
  };

  useEffect(() => {
    if (query) {
      const debounce = setTimeout(() => {
        searchAds(query);
      }, 300);
      return () => clearTimeout(debounce);
    } else {
      setResults([]);
    }
  }, [query, filters]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-6 h-full flex flex-col max-w-6xl">
        {/* Enhanced Search Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search for products, services, or sellers..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch(query)}
              className="pl-12 pr-4 h-14 text-lg border-2 focus:border-primary rounded-xl shadow-lg bg-white"
              autoFocus
            />
            {loading && (
              <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
              </div>
            )}
          </div>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setShowFilters(!showFilters)}
            className={cn(
              "h-14 w-14 rounded-xl border-2 transition-colors",
              showFilters ? "bg-primary text-white border-primary" : "hover:border-primary"
            )}
          >
            <Filter className="h-5 w-5" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={onClose}
            className="h-14 w-14 rounded-xl border-2 hover:border-red-500 hover:text-red-500 transition-colors"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* AI Search indicator and toggle */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Button
              variant={useAISearch ? "default" : "outline"}
              size="sm"
              onClick={() => setUseAISearch(!useAISearch)}
              className={cn(
                "gap-2 transition-all",
                useAISearch && "bg-gradient-to-r from-primary to-purple-600"
              )}
            >
              <Sparkles className="h-4 w-4" />
              AI Search
            </Button>
            {aiSearchUsed && results.length > 0 && (
              <Badge variant="secondary" className="bg-primary/10 text-primary">
                Powered by AI
              </Badge>
            )}
          </div>
          {results.length > 0 && (
            <span className="text-sm text-muted-foreground">
              {results.length} results found
            </span>
          )}
        </div>

        {/* Enhanced Filters */}
        {showFilters && (
          <Card className="mb-6 shadow-lg border-0 bg-gradient-to-r from-muted/30 to-background">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Input
                  placeholder="Category"
                  value={filters.category}
                  onChange={(e) => setFilters({...filters, category: e.target.value})}
                  className="rounded-lg"
                />
                <Input
                  type="number"
                  placeholder="Min Price"
                  value={filters.minPrice}
                  onChange={(e) => setFilters({...filters, minPrice: e.target.value})}
                  className="rounded-lg"
                />
                <Input
                  type="number"
                  placeholder="Max Price"
                  value={filters.maxPrice}
                  onChange={(e) => setFilters({...filters, maxPrice: e.target.value})}
                  className="rounded-lg"
                />
                <Input
                  placeholder="Location"
                  value={filters.location}
                  onChange={(e) => setFilters({...filters, location: e.target.value})}
                  className="rounded-lg"
                />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Content */}
        <div className="flex-1 overflow-auto">
          {!query && recentSearches.length > 0 && (
            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5 text-primary" />
                Recent Searches
              </h3>
              <div className="flex flex-wrap gap-2">
                {recentSearches.map((search, index) => (
                  <Badge
                    key={index}
                    variant="secondary"
                    className="cursor-pointer hover:bg-primary hover:text-white transition-colors text-sm px-3 py-2 rounded-full"
                    onClick={() => {
                      setQuery(search);
                      handleSearch(search);
                    }}
                  >
                    {search}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {query && !loading && (
            <QuickFilters onFilterClick={handleFilterClick} />
          )}

          {loading && <SearchSkeleton />}

          {query && !loading && results.length === 0 && (
            <EmptyState query={query} />
          )}

          {results.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.map((result) => (
                <Card
                  key={result.id}
                  className="group cursor-pointer overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-500 hover:scale-[1.02] bg-white rounded-2xl"
                  onClick={() => handleResultClick(result.id)}
                >
                  <div className="relative aspect-[4/3] overflow-hidden">
                    {result.images.length > 0 ? (
                      <img
                        src={result.images[0]}
                        alt={result.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                        <ShoppingBag className="w-12 h-12 text-gray-400" />
                      </div>
                    )}
                    
                    {/* Floating Elements */}
                    <div className="absolute top-3 left-3 flex gap-2">
                      {result.category && (
                        <Badge className="bg-white/90 text-gray-800 text-xs px-2 py-1 backdrop-blur-sm">
                          {result.category}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="absolute top-3 right-3">
                      <button className="w-8 h-8 bg-white/90 rounded-full flex items-center justify-center backdrop-blur-sm hover:bg-white transition-colors">
                        <Heart className="w-4 h-4 text-gray-600" />
                      </button>
                    </div>

                    {/* Gradient Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </div>

                  <CardContent className="p-5">
                    <div className="mb-3">
                      <h3 className="font-bold text-lg line-clamp-2 mb-2 text-gray-900 group-hover:text-primary transition-colors">
                        {result.title}
                      </h3>
                      
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-1">
                          <DollarSign className="h-4 w-4 text-emerald-600" />
                          <span className="font-bold text-emerald-600 text-lg">
                            UGX {result.price?.toLocaleString() || 'Contact'}
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-1 text-sm text-gray-500">
                          <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                          <span>4.8</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 text-sm text-gray-600 mb-3">
                        <MapPin className="h-3 w-3" />
                        <span className="truncate">{result.location}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-gradient-to-r from-primary to-blue-600 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">
                            {result.seller_name.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <span className="text-sm font-medium text-gray-800 block">{result.seller_name}</span>
                          <span className="text-xs text-gray-500 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(result.created_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      
                      <div className="flex gap-1">
                        <button className="w-8 h-8 bg-gray-100 hover:bg-primary hover:text-white rounded-lg flex items-center justify-center transition-colors">
                          <MessageCircle className="w-4 h-4" />
                        </button>
                        <button className="w-8 h-8 bg-gray-100 hover:bg-primary hover:text-white rounded-lg flex items-center justify-center transition-colors">
                          <Share2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GlobalSearch;
