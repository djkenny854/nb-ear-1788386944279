import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Crown, CheckCircle2, Zap, BarChart3, Rocket, Shield, X } from 'lucide-react';
import { useSubscriptionStatus } from '@/hooks/useSubscriptionStatus';

interface PaywallModalProps {
  isOpen: boolean;
  onClose: () => void;
  feature?: 'posting' | 'analytics' | 'boosting' | 'jobs' | 'events' | 'promotions' | 'services';
}

const featureMessages: Record<string, { title: string; description: string }> = {
  posting: {
    title: 'Post Your Listings',
    description: 'Upgrade to post products, services, and more to reach thousands of buyers.',
  },
  analytics: {
    title: 'Access Analytics',
    description: 'Get detailed insights into your listings performance and buyer engagement.',
  },
  boosting: {
    title: 'Boost Your Listings',
    description: 'Get more visibility by boosting your listings to the top of search results.',
  },
  jobs: {
    title: 'Post Job Openings',
    description: 'Find the best talent by posting job opportunities on our platform.',
  },
  events: {
    title: 'Create Events',
    description: 'Promote your events and reach a wider audience.',
  },
  promotions: {
    title: 'Run Promotions',
    description: 'Create special offers and discounts to attract more customers.',
  },
  services: {
    title: 'Offer Services',
    description: 'List your professional services and connect with clients.',
  },
};

const benefits = [
  { icon: Rocket, text: 'Unlimited listings' },
  { icon: BarChart3, text: 'Analytics dashboard' },
  { icon: Zap, text: 'Priority visibility' },
  { icon: Shield, text: 'Verified seller badge' },
];

export const PaywallModal: React.FC<PaywallModalProps> = ({ isOpen, onClose, feature = 'posting' }) => {
  const navigate = useNavigate();
  const { monthlyPrice, currency } = useSubscriptionStatus();
  const featureInfo = featureMessages[feature] || featureMessages.posting;

  const handleUpgrade = () => {
    onClose();
    navigate('/payment-methods');
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden border-0">
        {/* Header with gradient */}
        <div className="relative bg-gradient-to-br from-primary via-primary/90 to-primary/70 p-6 pb-8 text-primary-foreground">
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 right-4 text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10"
            onClick={onClose}
          >
            <X className="h-4 w-4" />
          </Button>
          
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 rounded-full bg-primary-foreground/20">
              <Crown className="h-6 w-6" />
            </div>
            <Badge variant="secondary" className="bg-primary-foreground/20 text-primary-foreground border-0">
              Premium Feature
            </Badge>
          </div>
          
          <DialogHeader className="text-left space-y-2">
            <DialogTitle className="text-2xl font-bold text-primary-foreground">
              {featureInfo.title}
            </DialogTitle>
            <p className="text-primary-foreground/90 text-sm">
              {featureInfo.description}
            </p>
          </DialogHeader>
        </div>

        {/* Benefits */}
        <div className="p-6 space-y-6">
          <div className="space-y-3">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="p-1.5 rounded-full bg-primary/10">
                  <benefit.icon className="h-4 w-4 text-primary" />
                </div>
                <span className="text-sm text-foreground">{benefit.text}</span>
                <CheckCircle2 className="h-4 w-4 text-green-500 ml-auto" />
              </div>
            ))}
          </div>

          {/* Pricing */}
          <div className="text-center p-4 rounded-xl bg-muted/50 border">
            <div className="flex items-baseline justify-center gap-1">
              <span className="text-3xl font-bold text-foreground">${monthlyPrice}</span>
              <span className="text-muted-foreground">/{currency}/month</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Cancel anytime</p>
          </div>

          {/* CTAs */}
          <div className="space-y-3">
            <Button 
              onClick={handleUpgrade} 
              className="w-full h-12 text-base font-semibold"
              size="lg"
            >
              <Crown className="h-5 w-5 mr-2" />
              Upgrade Now
            </Button>
            <Button 
              variant="ghost" 
              onClick={onClose} 
              className="w-full text-muted-foreground hover:text-foreground"
            >
              Maybe Later
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
