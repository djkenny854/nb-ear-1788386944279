
import React, { useEffect, useState } from 'react';
import { useTheme } from 'next-themes';
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';

const LoadingScreen: React.FC = () => {
  const [progress, setProgress] = useState(0);
  const { theme } = useTheme();

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 2;
      });
    }, 40); // 2 seconds total (100 steps * 40ms = 4000ms, but we increment by 2)

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col items-center justify-center">
      <div className="text-center">
        <img 
          src={earlymarketLogo} 
          alt="EarlyMarket Group" 
          className="h-20 w-auto mx-auto mb-8 animate-pulse"
        />
        <div className="w-80 h-2 bg-muted rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-primary to-orange-600 rounded-full transition-all duration-100 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-sm text-muted-foreground mt-4 font-medium">Loading EarlyMarket...</p>
      </div>
    </div>
  );
};

export default LoadingScreen;
