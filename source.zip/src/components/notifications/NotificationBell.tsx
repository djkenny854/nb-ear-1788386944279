
import React, { useState, useEffect } from 'react';
import { Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { formatDistanceToNow } from 'date-fns';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface Notification {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  content: string;
  timestamp: Date;
  isRead: boolean;
}

interface NotificationBellProps {
  onChatOpen: (sellerId: string) => void;
}

const NotificationBell: React.FC<NotificationBellProps> = ({ onChatOpen }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const queryClient = useQueryClient();

  // Get current user
  useEffect(() => {
    const getCurrentUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setCurrentUserId(user.id);
      }
    };
    getCurrentUser();
  }, []);

  // Fetch notifications from database
  const { data: dbNotifications } = useQuery({
    queryKey: ['bell-notifications', currentUserId],
    queryFn: async () => {
      if (!currentUserId) return [];

      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', currentUserId)
        .or('notification_type.is.null,notification_type.neq.new_message')
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      return data || [];
    },
    enabled: !!currentUserId,
  });

  // Update notifications from database
  useEffect(() => {
    if (dbNotifications) {
      const notificationList = dbNotifications.map(n => {
        const metadata = n.metadata as any;
        return {
          id: n.id,
          senderId: metadata?.sender_id || '',
          senderName: n.title,
          senderAvatar: metadata?.sender_avatar,
          content: n.message,
          timestamp: new Date(n.created_at),
          isRead: n.is_read,
        };
      });
      
      setNotifications(notificationList);
      setUnreadCount(notificationList.filter(n => !n.isRead).length);
    }
  }, [dbNotifications]);

  // Real-time subscriptions for notifications
  useEffect(() => {
    if (!currentUserId) return;

    const channel = supabase
      .channel(`notifications-bell-${currentUserId}-${crypto.randomUUID()}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${currentUserId}`
        },
        async (payload) => {
          if (payload.new.notification_type === 'new_message') return;
          console.log('New notification received:', payload);

          const metadata = payload.new.metadata as any;
          const newNotification: Notification = {
            id: payload.new.id,
            senderId: metadata?.sender_id || '',
            senderName: payload.new.title,
            senderAvatar: metadata?.sender_avatar,
            content: payload.new.message,
            timestamp: new Date(payload.new.created_at),
            isRead: false,
          };
          
          setNotifications(prev => [newNotification, ...prev.slice(0, 9)]);
          setUnreadCount(prev => prev + 1);
          queryClient.invalidateQueries({ queryKey: ['bell-notifications'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [currentUserId, queryClient]);

  const handleNotificationClick = async (notification: Notification) => {
    // Mark as read in database
    if (!notification.isRead) {
      await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', notification.id);
    }

    // Update local state
    setNotifications(prev => 
      prev.map(n => 
        n.id === notification.id ? { ...n, isRead: true } : n
      )
    );
    setUnreadCount(prev => Math.max(0, prev - 1));
    
  };

  const markAllAsRead = async () => {
    if (!currentUserId) return;

    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('user_id', currentUserId)
      .or('notification_type.is.null,notification_type.neq.new_message')
      .eq('is_read', false);

    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    setUnreadCount(0);
    queryClient.invalidateQueries({ queryKey: ['bell-notifications'] });
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-2 -right-2 w-5 h-5 rounded-full p-0 flex items-center justify-center text-xs"
            >
              {unreadCount > 9 ? '9+' : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="p-4 border-b">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Notifications</h3>
            {unreadCount > 0 && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={markAllAsRead}
                className="text-xs"
              >
                Mark all read
              </Button>
            )}
          </div>
        </div>
        
        <div className="max-h-80 overflow-y-auto">
          {notifications.length === 0 ? (
            <div className="p-6 text-center text-gray-500">
              <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No notifications yet</p>
            </div>
          ) : (
            notifications.map((notification) => (
              <div
                key={notification.id}
                className={`p-3 border-b cursor-pointer hover:bg-gray-50 ${
                  !notification.isRead ? 'bg-blue-50' : ''
                }`}
                onClick={() => handleNotificationClick(notification)}
              >
                <div className="flex items-start gap-3">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={notification.senderAvatar} />
                    <AvatarFallback>
                      {notification.senderName.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="font-medium text-sm truncate">
                        {notification.senderName}
                      </p>
                      <span className="text-xs text-gray-500">
                        {formatDistanceToNow(notification.timestamp, { addSuffix: true })}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 truncate">
                      {notification.content}
                    </p>
                  </div>
                  
                  {!notification.isRead && (
                    <Badge className="rounded-full h-5 px-2 bg-primary text-primary-foreground text-xs font-medium flex-shrink-0">
                      New
                    </Badge>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default NotificationBell;
