import React, { useEffect, useState } from 'react';
import earlymarketLogo from '@/assets/earlymarket-clogo.png';
import StyledQRCode from '@/components/StyledQRCode';

const FEATURES: { title: string; body: string }[] = [
  { title: 'Social marketplace', body: 'Post, follow and sell in one feed' },
  { title: 'Verified sellers', body: 'Trust badges you can actually check' },
  { title: 'Service workspaces', body: 'Catalogs, updates and real reviews' },
  { title: 'Jobs & tenders', body: 'Hire or get hired across Uganda' },
  { title: 'Earlymarket AI', body: 'Ask for anything, find it in seconds' },
];

const ASSURANCES: { quote: string; name: string; handle: string }[] = [
  {
    quote: '“I listed my shop on Earlymarket and got my first three orders the same week. Buyers can see I am verified, so they trust me.”',
    name: 'Aisha N.',
    handle: 'Kampala · Fashion seller',
  },
  {
    quote: '“My service workspace keeps every catalog, update and review in one place. Clients book me straight from the feed.”',
    name: 'Brian K.',
    handle: 'Wakiso · Interior finishing',
  },
  {
    quote: '“I compare prices across districts before I buy. Nothing else in Uganda shows me sellers, prices and reviews together.”',
    name: 'Sarah A.',
    handle: 'Mbarara · Buyer',
  },
  {
    quote: '“We posted a job on Monday and hired by Friday. The applicants were local, real and easy to reach.”',
    name: 'Denis M.',
    handle: 'Jinja · Business owner',
  },
];

/** Web-only marketing panel shown beside the auth form. */
const AuthWebHero: React.FC = () => {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setIndex((i) => (i + 1) % ASSURANCES.length), 3000);
    return () => clearInterval(t);
  }, []);

  const active = ASSURANCES[index];

  return (
    <div className="hidden lg:flex lg:w-[48%] border-r border-border flex-col justify-between px-12 xl:px-16 py-10 overflow-y-auto">
      {/* Brand */}
      <div className="flex items-center gap-2.5">
        <img src={earlymarketLogo} alt="Earlymarket" className="h-8 w-8 rounded-md object-contain" />
        <span className="text-[22px] font-semibold tracking-tight text-foreground">Earlymarket</span>
      </div>

      <div className="mt-10 max-w-[560px]">
        <h1 className="text-[44px] leading-[1.05] font-semibold tracking-tight text-foreground">
          Sell anything.
          <br />
          <span className="text-muted-foreground">Grow anywhere.</span>
        </h1>

        <p className="mt-5 text-sm leading-relaxed text-muted-foreground max-w-[380px]">
          Join the Social Business Marketplace — products, services, jobs and promotions
          from verified sellers across Uganda, all in one live feed.
        </p>

        {/* Feature list */}
        <ul className="mt-7 space-y-3">
          {FEATURES.map((f) => (
            <li key={f.title} className="flex items-baseline gap-2.5 text-[13px]">
              <span className="mt-1 h-1.5 w-1.5 rounded-full bg-muted-foreground/40 shrink-0" />
              <span className="font-medium text-foreground">{f.title}</span>
              <span className="text-muted-foreground">{f.body}</span>
            </li>
          ))}
        </ul>

        {/* Rotating assurance */}
        <div className="mt-9 rounded-xl border border-border p-5 max-w-[540px]">
          <p key={index} className="text-[13px] leading-relaxed text-foreground animate-in fade-in duration-500">
            {active.quote}
          </p>
          <div className="mt-4 flex items-center gap-2 text-[13px]">
            <span className="font-medium text-foreground">{active.name}</span>
            <span className="text-muted-foreground">{active.handle}</span>
          </div>
        </div>

        {/* Progress dashes */}
        <div className="mt-4 flex items-center gap-2">
          {ASSURANCES.map((_, i) => (
            <button
              key={i}
              type="button"
              aria-label={`Show testimonial ${i + 1}`}
              onClick={() => setIndex(i)}
              className={`h-0.5 w-6 rounded-full transition-colors ${i === index ? 'bg-foreground' : 'bg-border'}`}
            />
          ))}
        </div>
      </div>

      {/* Bottom: QR + stats */}
      <div className="mt-10 pt-8 border-t border-border">
        <div className="flex items-center gap-4">
          <div className="rounded-lg border border-border bg-background p-1.5 shrink-0">
            <StyledQRCode value="/download" size={80} showDownload={false} />
          </div>

          <div>
            <p className="text-sm font-medium text-foreground">Download the app</p>
            <p className="text-xs text-muted-foreground mt-1 max-w-[220px]">
              Scan this code with your phone camera to install Earlymarket and shop on the go.
            </p>
          </div>
        </div>

        <div className="mt-7 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs">
          <span><span className="font-semibold text-foreground">10K+</span> <span className="text-muted-foreground">listings</span></span>
          <span className="text-border">|</span>
          <span><span className="font-semibold text-foreground">2K+</span> <span className="text-muted-foreground">verified sellers</span></span>
          <span className="text-border">|</span>
          <span><span className="font-semibold text-foreground">130+</span> <span className="text-muted-foreground">districts</span></span>
        </div>
      </div>
    </div>
  );
};

export default AuthWebHero;
