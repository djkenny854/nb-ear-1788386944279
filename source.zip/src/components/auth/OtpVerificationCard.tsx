import React from 'react';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import emLogo from '@/assets/earlymarket-mono.svg';

interface OtpVerificationCardProps {
  email: string;
  value: string;
  onChange: (v: string) => void;
  onSubmit: () => void;
  onResend: () => void;
  onBack?: () => void;
  resendTimer: number;
  loading?: boolean;
  title?: string;
  subtitle?: string;
  submitLabel?: string;
}

/**
 * X (Twitter)-style verification code screen. Centered logo, heading,
 * six code boxes, retry line, and a full-width Continue button.
 * Shared by email signup and forgot-password flows so they look identical.
 */
const OtpVerificationCard: React.FC<OtpVerificationCardProps> = ({
  email,
  value,
  onChange,
  onSubmit,
  onResend,
  onBack,
  resendTimer,
  loading = false,
  title = 'We have sent you a security code',
  subtitle = 'The code was sent to your email',
  submitLabel = 'Continue',
}) => {
  return (
    <div className="flex flex-col w-full">
      {onBack && (
        <button
          onClick={onBack}
          className="self-start mb-4 text-muted-foreground hover:text-foreground"
          aria-label="Back"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
      )}

      <div className="flex justify-center mb-6">
        <img src={emLogo} alt="EarlyMarket" className="w-9 h-9 text-foreground" />
      </div>

      <h2 className="text-2xl font-bold text-foreground mb-3">{title}</h2>
      <p className="text-muted-foreground text-sm mb-6">
        {subtitle}
        {email ? <span className="font-medium text-foreground"> ({email})</span> : null}
      </p>

      <div className="mb-4">
        <InputOTP maxLength={6} value={value} onChange={onChange}>
          <InputOTPGroup className="gap-2 w-full justify-between">
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <InputOTPSlot
                key={i}
                index={i}
                className="w-11 h-12 sm:w-12 sm:h-14 text-lg font-semibold rounded-md border border-border bg-secondary text-foreground"
              />
            ))}
          </InputOTPGroup>
        </InputOTP>
      </div>

      <div className="text-sm text-muted-foreground mb-8">
        Didn't receive a code?{' '}
        {resendTimer > 0 ? (
          <span className="text-foreground font-medium">Retry in {resendTimer}s</span>
        ) : (
          <button
            onClick={onResend}
            disabled={loading}
            className="text-primary hover:underline disabled:opacity-50"
          >
            Resend code
          </button>
        )}
      </div>

      <Button
        onClick={onSubmit}
        disabled={loading || value.length !== 6}
        className="w-full h-12 rounded-full font-semibold"
      >
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : submitLabel}
      </Button>
    </div>
  );
};

export default OtpVerificationCard;