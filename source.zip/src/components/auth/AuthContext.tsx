import React, { createContext, useContext, useEffect, useState, useMemo, useRef, useCallback } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase, durableAuthStorage, flushAuthStorage, clearStoredAuthSession } from '@/integrations/supabase/client';
import { checkExpiringListings } from '@/utils/expirationNotifications';
import { isRealNativeRuntime } from '@/hooks/useCapacitor';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  recovering: boolean;
  authStatus: 'booting' | 'cached' | 'refreshing' | 'verified' | 'signed_out' | 'invalid_session';
  isPasswordRecovery: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, metadata?: { phone?: string; full_name?: string }) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

/** Try to recover a session from storage when network is unavailable */
const recoverCachedSession = (): { session: Session; user: User } | null => {
  try {
    // We use the supabase client's internal storage key if possible,
    // otherwise fallback to the known key.
    const key = (supabase.auth as any).storageKey || "sb-jkzjthlfwbmptazftasj-auth-token";
    const raw = durableAuthStorage.getItem(key);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const session = parsed?.currentSession || parsed;
    if (session?.user) return { session: session as Session, user: session.user as User };
  } catch {}
  return null;
};

const isProbablyConnectivityError = (message?: string): boolean => {
  if (!message) return false;
  return /network|fetch|timeout|abort|failed to fetch|load failed|offline|temporar/i.test(message);
};

const isRetryableAuthError = (error: unknown): boolean => {
  const anyError = error as { message?: string; name?: string; status?: number } | null;
  const message = anyError?.message;
  return (
    isProbablyConnectivityError(message) ||
    anyError?.name === 'AuthRetryableFetchError' ||
    anyError?.status === 0 ||
    (!!anyError?.status && anyError.status >= 500)
  );
};

const isConfirmedInvalidRefreshError = (error: unknown): boolean => {
  const anyError = error as { message?: string; code?: string; status?: number; name?: string } | null;
  const message = anyError?.message ?? '';
  const code = anyError?.code ?? '';
  const name = anyError?.name ?? '';
  const combined = `${message} ${code} ${name}`.toLowerCase();
  return (
    ((anyError?.status === 400 || anyError?.status === 401 || anyError?.status === 403) &&
      /refresh|session|invalid|not found|already used|revoked|expired|unauthorized|bad_jwt|pgrst301/i.test(combined)) ||
    /refresh_token_not_found|invalid_grant|token is expired|jwt expired|pgrst301/i.test(combined)
  );
};

const hasRefreshToken = (session: Session | null): session is Session & { refresh_token: string } => {
  return !!session?.refresh_token;
};

const shouldRefreshNow = (session: Session | null): boolean => {
  if (!session?.expires_at) return true;
  return session.expires_at * 1000 <= Date.now() + 60_000;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [recovering, setRecovering] = useState(false);
  const [authStatus, setAuthStatus] = useState<AuthContextType['authStatus']>('booting');
  const [isPasswordRecovery, setIsPasswordRecovery] = useState(false);
  const explicitSignOutRef = useRef(false);
  const recoveryInFlightRef = useRef<Promise<boolean> | null>(null);
  const lastRepairAtRef = useRef(0);
  const mountedRef = useRef(true);
  const sessionRef = useRef<Session | null>(null);

  const applySession = useCallback((nextSession: Session | null, status: AuthContextType['authStatus']) => {
    if (!mountedRef.current) return;
    sessionRef.current = nextSession;
    setSession(nextSession);
    setUser(nextSession?.user ?? null);
    setAuthStatus(status);
    setLoading(false);
    setRecovering(false);
  }, []);

  const preserveStoredSession = useCallback((reason: string, status: AuthContextType['authStatus'] = 'cached') => {
    const cached = recoverCachedSession();
    const fallbackSession = sessionRef.current ?? cached?.session ?? null;
    if (!fallbackSession?.user) return false;

    sessionRef.current = fallbackSession;
    setSession(fallbackSession);
    setUser(fallbackSession.user);
    setAuthStatus(status);
    setLoading(false);
    setRecovering(false);
    console.warn('[Auth] Keeping stored session:', reason);
    return true;
  }, []);

  const repairSession = useCallback(async (reason: string, options: { throttle?: boolean; silent?: boolean } = {}): Promise<boolean> => {
    if (explicitSignOutRef.current) return false;

    const now = Date.now();
    if (options.throttle && now - lastRepairAtRef.current < 15_000) {
      return !!(sessionRef.current ?? recoverCachedSession()?.session);
    }
    lastRepairAtRef.current = now;

    if (recoveryInFlightRef.current) return recoveryInFlightRef.current;

    const run = (async () => {
      if (!mountedRef.current) return false;
      // A "silent" repair (e.g. window regained focus after a file picker
      // closed) must NOT flip `recovering` on when we already hold a session —
      // doing so swaps the whole app to the "Reconnecting…" screen and
      // remounts in-progress flows (like the business wizard) from scratch.
      const showRecovering = !(options.silent && !!sessionRef.current);
      if (showRecovering) setRecovering(true);

      const cached = recoverCachedSession();
      const currentSession = sessionRef.current;
      if (cached && !currentSession) {
        sessionRef.current = cached.session;
        setSession(cached.session);
        setUser(cached.user);
        setAuthStatus('cached');
      }

      if (!navigator.onLine) {
        if (cached) {
          setLoading(false);
          setRecovering(false);
          console.info('[Auth] Using cached session while offline:', reason);
          return true;
        }
        applySession(null, 'signed_out');
        return false;
      }

      const candidateSession = sessionRef.current ?? cached?.session ?? null;
      setAuthStatus('refreshing');

      try {
        let activeSession: Session | null = candidateSession;

        if (hasRefreshToken(candidateSession)) {
          const { data, error } = shouldRefreshNow(candidateSession)
            ? await supabase.auth.refreshSession(candidateSession)
            : await supabase.auth.getSession();
          if (error) {
            if (isConfirmedInvalidRefreshError(error)) {
              await clearStoredAuthSession();
              applySession(null, 'invalid_session');
              return false;
            }
            if (preserveStoredSession(`refresh failed during ${reason}${isRetryableAuthError(error) ? ' (retryable)' : ''}`)) {
              return true;
            }
            applySession(null, 'invalid_session');
            return false;
          }
          activeSession = data.session ?? activeSession;
        } else {
          const { data } = await supabase.auth.getSession();
          activeSession = data.session ?? activeSession;
        }

        if (!activeSession) {
          if (cached) {
            setLoading(false);
            setRecovering(false);
            setAuthStatus('cached');
            return true;
          }
          applySession(null, 'signed_out');
          return false;
        }

        const { data: userData, error: userError } = await supabase.auth.getUser(activeSession.access_token);
        if (userError || !userData.user) {
          if (preserveStoredSession(`user verification failed during ${reason}${isRetryableAuthError(userError) ? ' (retryable)' : ''}`)) {
            return true;
          }
          applySession(null, 'invalid_session');
          return false;
        }

        applySession({ ...activeSession, user: userData.user }, 'verified');
        await flushAuthStorage();
        return true;
      } catch (error) {
        const message = error instanceof Error ? error.message : undefined;
        if (preserveStoredSession(`repair threw during ${reason}${isProbablyConnectivityError(message) ? ' (connectivity)' : ''}`)) {
          return true;
        }
        applySession(null, 'signed_out');
        return false;
      } finally {
        recoveryInFlightRef.current = null;
      }
    })();

    recoveryInFlightRef.current = run;
    return run;
  }, [applySession, preserveStoredSession]);

  useEffect(() => {
    mountedRef.current = true;
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, currentSession) => {
        // Supabase can emit SIGNED_OUT/null after a suspended mobile refresh.
        // Only an explicit user logout should immediately clear auth state.
        if (!currentSession && event !== 'PASSWORD_RECOVERY') {
          if (explicitSignOutRef.current) {
            applySession(null, 'signed_out');
            return;
          }

          setTimeout(() => {
            repairSession(`auth-event:${event}`).catch(() => {});
          }, 0);
          return;
        }

        explicitSignOutRef.current = false;
        applySession(currentSession, currentSession ? 'verified' : 'signed_out');
        
        if (event === 'PASSWORD_RECOVERY') {
          setIsPasswordRecovery(true);
        }
        
        if (event === 'SIGNED_IN' && currentSession?.user?.id) {
          setTimeout(() => {
            checkExpiringListings(currentSession.user.id);
          }, 2000);
        }
        
        // Send welcome email for new user signups
        if (event === 'SIGNED_IN' && currentSession?.user) {
          const createdAt = new Date(currentSession.user.created_at);
          const now = new Date();
          const isNewUser = (now.getTime() - createdAt.getTime()) < 60000;
          
          if (isNewUser) {
            setTimeout(async () => {
              try {
                const userName = currentSession.user.user_metadata?.full_name || 
                                 currentSession.user.user_metadata?.name || 
                                 currentSession.user.email?.split('@')[0] || 'User';
                
                await supabase.functions.invoke('send-email', {
                  body: {
                    type: 'welcome',
                    to: currentSession.user.email,
                    data: { userName, email: currentSession.user.email }
                  }
                });
              } catch (error) {
                console.error('Failed to send welcome email:', error);
              }
            }, 1000);
          }
        }
      }
    );

    // Then get initial session
    const initSession = async () => {
      try {
        const { data: { session: initialSession } } = await supabase.auth.getSession();
        if (initialSession) {
          if (shouldRefreshNow(initialSession)) {
            const { data, error } = await supabase.auth.refreshSession(initialSession);
            if (data?.session) {
              applySession(data.session, 'verified');
            } else if (error && isConfirmedInvalidRefreshError(error)) {
              await clearStoredAuthSession();
              applySession(null, 'signed_out');
            } else {
              applySession(initialSession, 'cached');
              await repairSession('initial-session-verify');
            }
          } else {
            applySession(initialSession, 'verified');
            await repairSession('initial-session-verify');
          }
        } else {
          await repairSession('initial-session-empty');
        }
      } catch {
        await repairSession('initial-session-error');
      }
    };

    // If offline, use cached session immediately
    if (!navigator.onLine) {
      const cached = recoverCachedSession();
      if (cached) {
        applySession(cached.session, 'cached');
      } else {
        applySession(null, 'signed_out');
      }
    } else {
      initSession();
      // Safety timeout — if getSession hangs
      const timeout = setTimeout(() => {
        const cached = recoverCachedSession();
        if (cached) {
          setSession(s => {
            if (!s) sessionRef.current = cached.session;
            return s ?? cached.session;
          });
          setUser(u => u ?? cached.user);
          setAuthStatus(s => s === 'booting' ? 'cached' : s);
        }
        setLoading(false);
      }, 3000);
      return () => {
        mountedRef.current = false;
        clearTimeout(timeout);
        subscription.unsubscribe();
      };
    }

    return () => {
      mountedRef.current = false;
      subscription.unsubscribe();
    };
  }, [applySession, repairSession]);

  useEffect(() => {
    const repairOnResume = () => {
      if (document.visibilityState === 'hidden') return;
      if (isRealNativeRuntime()) {
        supabase.auth.startAutoRefresh().catch(() => {});
      }
      // Silent so tabbing back / closing a file picker never shows the
      // "Reconnecting…" screen (which would remount active flows) when we
      // already have a valid session.
      repairSession('resume-or-online', { throttle: true, silent: true }).catch(() => {});
    };

    const onVisibility = () => {
      if (document.visibilityState === 'visible') repairOnResume();
    };

    if (isRealNativeRuntime()) {
      supabase.auth.startAutoRefresh().catch(() => {});
    }

    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('focus', repairOnResume);
    window.addEventListener('online', repairOnResume);

    let appStateListener: { remove: () => void | Promise<void> } | null = null;
    import('@capacitor/app')
      .then(({ App }) => App.addListener('appStateChange', ({ isActive }) => {
        if (isActive) {
          if (isRealNativeRuntime()) {
            supabase.auth.startAutoRefresh().catch(() => {});
          }
          repairSession('capacitor-app-active', { throttle: true, silent: true }).catch(() => {});
        } else {
          flushAuthStorage()
            .finally(() => {
              if (isRealNativeRuntime()) {
                supabase.auth.stopAutoRefresh().catch(() => {});
              }
            })
            .catch(() => {});
        }
      }))
      .then((listener) => { appStateListener = listener; })
      .catch(() => {});

    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('focus', repairOnResume);
      window.removeEventListener('online', repairOnResume);
      appStateListener?.remove();
      if (isRealNativeRuntime()) {
        supabase.auth.stopAutoRefresh().catch(() => {});
      }
    };
  }, [repairSession]);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (!error) await flushAuthStorage();
    return { error };
  };

  const signUp = async (email: string, password: string, metadata?: { phone?: string; full_name?: string }) => {
    const redirectUrl = `${window.location.origin}/`;
    const { data, error } = await supabase.auth.signUp({
      email, password,
      options: { emailRedirectTo: redirectUrl, data: metadata }
    });
    if (!error && data.session) await flushAuthStorage();
    
    if (data?.user && data.user.identities && data.user.identities.length === 0) {
      return { error: { message: 'An account with this email already exists. Please sign in instead.' } };
    }
    return { error };
  };

  const signOut = async () => {
    explicitSignOutRef.current = true;
    await supabase.auth.signOut();
    await clearStoredAuthSession();
    applySession(null, 'signed_out');
  };

  const value = useMemo(() => ({
    user, session, loading, recovering, authStatus, isPasswordRecovery, signIn, signUp, signOut
  }), [user, session, loading, recovering, authStatus, isPasswordRecovery]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
