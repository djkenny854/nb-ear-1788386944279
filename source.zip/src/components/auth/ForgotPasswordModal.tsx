import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Mail, ArrowLeft, CheckCircle, KeyRound, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import OtpVerificationCard from '@/components/auth/OtpVerificationCard';
import { canRequestOtp, recordOtpRequest, minutesUntilReset } from '@/lib/otpRateLimit';

interface ForgotPasswordModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const ForgotPasswordModal: React.FC<ForgotPasswordModalProps> = ({ open, onOpenChange }) => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState<'email' | 'otp' | 'password' | 'success'>('email');
  const [otpCode, setOtpCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [resendTimer, setResendTimer] = useState(0);
  const isVerifyingRef = useRef(false);

  useEffect(() => {
    if (resendTimer > 0) {
      const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendTimer]);

  const handleSendOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      toast.error('Please enter your email address');
      return;
    }
    if (!canRequestOtp(email)) {
      toast.error(`Too many code requests. Try again in ${minutesUntilReset(email)} minutes.`);
      return;
    }
    setLoading(true);
    // Explicitly set redirectTo to the reset-password page for consistent flow
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`
    });
    if (error) {
      toast.error(error.message || 'Failed to send reset code');
    } else {
      recordOtpRequest(email);
      setStep('otp');
      setResendTimer(60);
      toast.success('Verification code sent to your email');
    }
    setLoading(false);
  };

  const handleVerifyOTP = async () => {
    if (otpCode.length !== 6 || isVerifyingRef.current) return;
    isVerifyingRef.current = true;
    setLoading(true);
    
    try {
      const { data, error } = await supabase.auth.verifyOtp({
        email,
        token: otpCode,
        type: 'recovery',
      });
      
      if (error) {
        toast.error(error.message || 'Invalid verification code');
      } else if (data?.session) {
        // OTP verified and session established — move to password step
        setStep('password');
        toast.success('Code verified! Set your new password.');
      } else {
        toast.error('Verification failed. Please try again.');
      }
    } catch (err) {
      toast.error('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
      isVerifyingRef.current = false;
    }
  };

  const handleResetPassword = async () => {
    if (newPassword.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
      toast.error(error.message || 'Failed to update password');
    } else {
      setStep('success');
    }
    setLoading(false);
  };

  const handleResendOTP = async () => {
    if (resendTimer > 0) return;
    if (!canRequestOtp(email)) {
      toast.error(`Too many code requests. Try again in ${minutesUntilReset(email)} minutes.`);
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`
    });
    if (error) {
      toast.error(error.message || 'Failed to resend code');
    } else {
      recordOtpRequest(email);
      setResendTimer(60);
      setOtpCode('');
      toast.success('New code sent!');
    }
    setLoading(false);
  };

  const handleClose = () => {
    setStep('email');
    setEmail('');
    setOtpCode('');
    setNewPassword('');
    setConfirmPassword('');
    setResendTimer(0);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => { if (!isOpen) handleClose(); }}>
      <DialogContent 
        className="w-[calc(100%-2rem)] max-w-sm rounded-2xl bg-card border-border p-5 sm:p-6"
        onInteractOutside={(e) => {
          // Prevent closing during password step or while loading
          if (step === 'password' || step === 'otp' || loading) {
            e.preventDefault();
          }
        }}
        onEscapeKeyDown={(e) => {
          if (step === 'password' || loading) {
            e.preventDefault();
          }
        }}
      >
        {step === 'success' ? (
          <div className="flex flex-col items-center text-center">
            <div className="w-14 h-14 bg-green-500/15 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="w-7 h-7 text-green-500" />
            </div>
            <DialogTitle className="text-lg font-semibold text-foreground mb-1">Password Updated</DialogTitle>
            <DialogDescription className="text-muted-foreground text-sm mb-5">
              You can now sign in with your new password.
            </DialogDescription>
            <Button onClick={handleClose} className="w-full h-11 rounded-full font-semibold">
              Done
            </Button>
          </div>
        ) : step === 'password' ? (
          <div className="flex flex-col">
            <DialogHeader className="mb-4 text-center">
              <DialogTitle className="text-lg font-semibold text-foreground">New Password</DialogTitle>
              <DialogDescription className="text-muted-foreground text-sm">
                Create a strong password for your account.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              <div className="relative">
                <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  type="password"
                  placeholder="New password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="pl-10 h-11 rounded-xl bg-secondary border-border text-foreground placeholder:text-muted-foreground"
                  autoFocus
                />
              </div>
              <div className="relative">
                <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  type="password"
                  placeholder="Confirm password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="pl-10 h-11 rounded-xl bg-secondary border-border text-foreground placeholder:text-muted-foreground"
                />
              </div>
              <Button
                onClick={handleResetPassword}
                className="w-full h-11 rounded-full font-semibold"
                disabled={loading}
              >
                {loading ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Updating...</>
                ) : 'Reset Password'}
              </Button>
            </div>
          </div>
        ) : step === 'otp' ? (
          <>
            <DialogTitle className="sr-only">Enter verification code</DialogTitle>
            <OtpVerificationCard
              email={email}
              value={otpCode}
              onChange={setOtpCode}
              onSubmit={handleVerifyOTP}
              onResend={handleResendOTP}
              onBack={() => { setStep('email'); setOtpCode(''); }}
              resendTimer={resendTimer}
              loading={loading}
            />
          </>
        ) : (
          <>
            <DialogHeader className="text-center">
              <DialogTitle className="text-lg font-semibold text-foreground">Reset Password</DialogTitle>
              <DialogDescription className="text-muted-foreground text-sm">
                Enter your email to receive a reset code.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSendOTP} className="space-y-3 mt-3">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  type="email"
                  placeholder="Email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 h-11 rounded-xl bg-secondary border-border text-foreground placeholder:text-muted-foreground"
                  required
                />
              </div>
              <Button type="submit" className="w-full h-11 rounded-full font-semibold" disabled={loading}>
                {loading ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Sending...</>
                ) : 'Send Reset Code'}
              </Button>
              <button
                type="button"
                onClick={handleClose}
                className="w-full text-center text-muted-foreground hover:text-foreground text-sm flex items-center justify-center gap-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Back to login
              </button>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default ForgotPasswordModal;
