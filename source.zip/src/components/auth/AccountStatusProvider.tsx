import React, { createContext, useContext, useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './AuthContext';

interface AccountStatusContextType {
  status: 'active' | 'suspended' | 'banned';
  isBanned: boolean;
  isSuspended: boolean;
  banReason: string | null;
  suspensionEndDate: Date | null;
  isLoading: boolean;
  canPerformAction: (action: string) => boolean;
  refreshStatus: () => Promise<void>;
}

const AccountStatusContext = createContext<AccountStatusContextType>({
  status: 'active',
  isBanned: false,
  isSuspended: false,
  banReason: null,
  suspensionEndDate: null,
  isLoading: true,
  canPerformAction: () => true,
  refreshStatus: async () => {},
});

export const useAccountStatusContext = () => useContext(AccountStatusContext);

// Pages that restricted users CAN access
const ALLOWED_PAGES_FOR_RESTRICTED = [
  '/account-restricted',
  '/auth',
  '/terms',
  '/privacy',
  '/contact',
  '/profile', // Allow viewing profile to show account status banner
];

interface AccountStatusProviderProps {
  children: React.ReactNode;
}

export const AccountStatusProvider: React.FC<AccountStatusProviderProps> = ({ children }) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [status, setStatus] = useState<'active' | 'suspended' | 'banned'>('active');
  const [banReason, setBanReason] = useState<string | null>(null);
  const [suspensionEndDate, setSuspensionEndDate] = useState<Date | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchAccountStatus = async () => {
    if (!user) {
      setStatus('active');
      setIsLoading(false);
      return;
    }

    try {
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('account_status, banned_reason, suspension_end_date')
        .eq('id', user.id)
        .maybeSingle();

      if (error) {
        console.error('Error fetching account status:', error);
        setIsLoading(false);
        return;
      }
      
      // Handle case when no profile exists
      if (!profile) {
        setStatus('active');
        setIsLoading(false);
        return;
      }

      const accountStatus = (profile?.account_status as 'active' | 'suspended' | 'banned') || 'active';

      // Check if suspension has expired
      if (accountStatus === 'suspended' && profile?.suspension_end_date) {
        const endDate = new Date(profile.suspension_end_date);
        if (endDate < new Date()) {
          // Suspension expired, restore account
          await supabase
            .from('profiles')
            .update({
              account_status: 'active',
              banned_reason: null,
              suspension_end_date: null,
            })
            .eq('id', user.id);

          setStatus('active');
          setBanReason(null);
          setSuspensionEndDate(null);
          setIsLoading(false);
          return;
        }
        setSuspensionEndDate(endDate);
      }

      setStatus(accountStatus);
      setBanReason(profile?.banned_reason || null);
      setIsLoading(false);
    } catch (error) {
      console.error('Error checking account status:', error);
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAccountStatus();
  }, [user]);

  // Redirect restricted users
  useEffect(() => {
    if (isLoading || !user) return;

    const isRestricted = status === 'banned' || status === 'suspended';
    const isOnAllowedPage = ALLOWED_PAGES_FOR_RESTRICTED.some(page =>
      location.pathname.startsWith(page)
    );

    if (isRestricted && !isOnAllowedPage) {
      navigate('/account-restricted');
    }
  }, [status, location.pathname, isLoading, user, navigate]);

  // Subscribe to realtime changes
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel(`account_status_changes-${user.id}-${crypto.randomUUID()}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: `id=eq.${user.id}`,
        },
        (payload) => {
          const newStatus = payload.new.account_status as 'active' | 'suspended' | 'banned';
          setStatus(newStatus);
          setBanReason(payload.new.banned_reason);
          if (payload.new.suspension_end_date) {
            setSuspensionEndDate(new Date(payload.new.suspension_end_date));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const canPerformAction = (action: string): boolean => {
    if (status === 'banned') return false;
    if (status === 'suspended') {
      // Suspended users can only view content, not create
      const blockedActions = ['post', 'message', 'comment', 'follow', 'boost', 'apply'];
      return !blockedActions.includes(action);
    }
    return true;
  };

  return (
    <AccountStatusContext.Provider
      value={{
        status,
        isBanned: status === 'banned',
        isSuspended: status === 'suspended',
        banReason,
        suspensionEndDate,
        isLoading,
        canPerformAction,
        refreshStatus: fetchAccountStatus,
      }}
    >
      {children}
    </AccountStatusContext.Provider>
  );
};
