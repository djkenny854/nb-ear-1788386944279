import React from 'react';
import { RotateCcw, CheckCircle2, Shield, AlertCircle, Package } from 'lucide-react';

interface ReturnPolicyProps {
  returnPolicy?: string | null;
  warrantyPolicy?: string | null;
}

const ReturnPolicy: React.FC<ReturnPolicyProps> = ({ returnPolicy, warrantyPolicy }) => {
  const hasCustomPolicy = returnPolicy || warrantyPolicy;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
          <RotateCcw className="w-4 h-4 text-primary" />
        </div>
        <h3 className="font-semibold text-foreground">Returns & Warranty</h3>
      </div>

      {/* Policy Items */}
      <div className="space-y-3">
        {/* Return Policy */}
        {returnPolicy ? (
          <div className="p-3 rounded-xl bg-green-500/5 border border-green-500/20">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-green-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground mb-1">Return Policy</p>
                <p className="text-xs text-muted-foreground whitespace-pre-wrap">{returnPolicy}</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/20">
            <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
              <AlertCircle className="w-3.5 h-3.5 text-muted-foreground" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">Returns</p>
              <p className="text-xs text-muted-foreground">Contact seller for return policy</p>
            </div>
          </div>
        )}

        {/* Warranty Policy */}
        {warrantyPolicy ? (
          <div className="p-3 rounded-xl bg-blue-500/5 border border-blue-500/20">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Shield className="w-3.5 h-3.5 text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground mb-1">Warranty</p>
                <p className="text-xs text-muted-foreground whitespace-pre-wrap">{warrantyPolicy}</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/20">
            <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
              <Package className="w-3.5 h-3.5 text-muted-foreground" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">Warranty</p>
              <p className="text-xs text-muted-foreground">Contact seller for warranty info</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReturnPolicy;
