import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { getSellerProfileUrl } from '@/lib/sellerUrl';
import { useFollow } from '@/hooks/useFollow';
import { 
  Clock, 
  MapPin, 
  Star, 
  MessageCircle, 
  Phone,
  UserPlus,
  UserCheck,
  CheckCircle2,
  ExternalLink,
  Circle
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';

interface WorkingHoursType {
  [key: string]: {
    open: string;
    close: string;
    closed?: boolean;
  };
}

interface SellerInfoCardProps {
  seller: {
    id: string;
    user_id?: string | null;
    business_name?: string | null;
    business_phone?: string | null;
    business_logo_url?: string | null;
    is_verified?: boolean;
    verification_badge_color?: BadgeColor;
    created_at?: string;
    district?: string | null;
    sub_county?: string | null;
    working_hours?: WorkingHoursType | unknown | null;
    is_online?: boolean;
    last_seen_at?: string | null;
  } | null;
  isFollowing?: boolean;
  onFollow?: () => void;
  onContact: () => void;
  onCall: () => void;
  compact?: boolean; // For product/service details page (shows Open/Closed, Online/Offline)
}

const SellerInfoCard: React.FC<SellerInfoCardProps> = ({
  seller,
  onContact,
  onCall,
  compact = false
}) => {
  const navigate = useNavigate();
  
  // Use the follow hook with the seller's user_id
  const { isFollowing, isLoading: followLoading, toggleFollow } = useFollow(seller?.user_id || '');

  // Fetch privacy settings for the seller
  const { data: privacySettings } = useQuery({
    queryKey: ['seller-privacy', seller?.user_id],
    queryFn: async () => {
      if (!seller?.user_id) return null;
      const { data } = await supabase
        .from('user_privacy_settings')
        .select('show_online_status')
        .eq('user_id', seller.user_id)
        .single();
      return data;
    },
    enabled: !!seller?.user_id,
  });

  const { data: stats, isLoading } = useQuery({
    queryKey: ['seller-stats', seller?.id, seller?.user_id],
    queryFn: async () => {
      if (!seller?.id) return null;

      // Reviews are keyed by the seller's auth user_id, not seller_profiles.id
      const reviewsUserId = seller.user_id;
      const reviewsPromise = reviewsUserId
        ? supabase.from('reviews').select('rating').eq('reviewed_user_id', reviewsUserId)
        : Promise.resolve({ data: [] as { rating: number }[] } as any);

      const [{ data: reviews }, { count: adsCount }] = await Promise.all([
        reviewsPromise,
        supabase
          .from('ads')
          .select('*', { count: 'exact', head: true })
          .eq('seller_id', seller.id)
          .eq('status', 'active'),
      ]);

      const totalReviews = reviews?.length || 0;
      const avgRating = totalReviews > 0
        ? reviews!.reduce((acc: number, r: any) => acc + r.rating, 0) / totalReviews
        : 0;

      return {
        avgRating: avgRating.toFixed(1),
        totalReviews,
        totalListings: adsCount || 0
      };
    },
    enabled: !!seller?.id
  });

  const getInitials = (name: string) => {
    return name?.split(' ').map(word => word.charAt(0)).join('').toUpperCase().slice(0, 2) || 'S';
  };

  const handleFollowClick = async () => {
    await toggleFollow();
  };

  // Calculate if business is currently open based on working hours
  const getBusinessStatus = () => {
    const workingHours = seller?.working_hours as WorkingHoursType | null | undefined;
    if (!workingHours || typeof workingHours !== 'object') return { isOpen: null, text: 'Hours not set' };
    
    const now = new Date();
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const currentDay = dayNames[now.getDay()];
    const currentTime = now.toTimeString().slice(0, 5); // "HH:MM" format
    
    const todayHours = workingHours[currentDay];
    
    if (!todayHours || todayHours.closed) {
      return { isOpen: false, text: 'Closed' };
    }
    
    const isOpen = currentTime >= todayHours.open && currentTime <= todayHours.close;
    
    if (isOpen) {
      return { isOpen: true, text: `Open · Closes ${todayHours.close}` };
    } else if (currentTime < todayHours.open) {
      return { isOpen: false, text: `Closed · Opens ${todayHours.open}` };
    } else {
      return { isOpen: false, text: 'Closed' };
    }
  };

  // Get online status - respects privacy settings
  const getOnlineStatus = () => {
    // Respect privacy: if seller disabled online status visibility
    if (privacySettings && privacySettings.show_online_status === false) {
      return { isOnline: false, text: '' };
    }

    if (seller?.is_online) {
      return { isOnline: true, text: 'Online' };
    }
    
    if (seller?.last_seen_at) {
      const lastSeen = new Date(seller.last_seen_at);
      const minutesAgo = Math.floor((Date.now() - lastSeen.getTime()) / 60000);
      
      if (minutesAgo < 5) {
        return { isOnline: true, text: 'Online' };
      } else if (minutesAgo < 60) {
        return { isOnline: false, text: `Active ${minutesAgo}m ago` };
      } else {
        return { isOnline: false, text: `Last seen ${formatDistanceToNow(lastSeen, { addSuffix: false })} ago` };
      }
    }
    
    return { isOnline: false, text: 'Offline' };
  };

  const businessStatus = getBusinessStatus();
  const onlineStatus = getOnlineStatus();

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <Skeleton className="w-14 h-14 rounded-full" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-5 w-32" />
            <Skeleton className="h-4 w-24" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Business</h3>
      </div>

      {/* Seller Profile */}
      <div 
        className="flex items-center gap-3 p-3 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer"
        onClick={() => seller && navigate(getSellerProfileUrl(seller))}
      >
        <div className="relative">
          {seller?.business_logo_url ? (
            <img
              src={seller.business_logo_url}
              alt={seller.business_name || 'Business'}
              className="w-12 h-12 rounded-full object-cover ring-2 ring-border"
            />
          ) : (
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/80 to-primary flex items-center justify-center ring-2 ring-border">
              <span className="text-primary-foreground text-base font-semibold">
                {getInitials(seller?.business_name || 'Business')}
              </span>
            </div>
          )}
          {/* Online indicator dot - only show if privacy allows */}
          {onlineStatus.text && (
            <div 
              className={cn(
                "absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-2 border-background",
                onlineStatus.isOnline ? "bg-green-500" : "bg-gray-400"
              )}
            />
          )}
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h4 className="font-semibold text-foreground truncate">
              {seller?.business_name || 'Individual Seller'}
            </h4>
            <UnifiedVerifiedBadge 
              isVerified={seller?.is_verified && !!seller?.business_name} 
              badgeColor={seller?.verification_badge_color}
              size="sm" 
            />
          </div>
          
          <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
            {stats && Number(stats.avgRating) > 0 && (
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                <span>{stats.avgRating}</span>
              </div>
            )}
            <span>{stats?.totalListings || 0} listings</span>
          </div>
        </div>
      </div>

      {/* Status Indicators (Open/Closed, Online/Offline) */}
      {compact && (
        <div className="flex items-center gap-3 flex-wrap">
          {/* Business Hours Status */}
          <div className={cn(
            "flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-full",
            businessStatus.isOpen === true 
              ? "bg-green-500/10 text-green-600" 
              : businessStatus.isOpen === false 
                ? "bg-red-500/10 text-red-500"
                : "bg-muted/50 text-muted-foreground"
          )}>
            <Clock className="w-3 h-3" />
            <span>{businessStatus.text}</span>
          </div>
          
          {/* Online Status - only show if privacy allows */}
          {onlineStatus.text && (
            <div className={cn(
              "flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-full",
              onlineStatus.isOnline 
                ? "bg-green-500/10 text-green-600" 
                : "bg-muted/50 text-muted-foreground"
            )}>
              <Circle className={cn("w-2 h-2", onlineStatus.isOnline && "fill-green-500 text-green-500")} />
              <span>{onlineStatus.text}</span>
            </div>
          )}
        </div>
      )}

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-2">
        <div className="text-center p-2 rounded-lg bg-muted/20">
          <p className="text-lg font-bold text-foreground">{stats?.totalReviews || 0}</p>
          <p className="text-xs text-muted-foreground">Reviews</p>
        </div>
        <div className="text-center p-2 rounded-lg bg-muted/20">
          <p className="text-lg font-bold text-foreground">{stats?.totalListings || 0}</p>
          <p className="text-xs text-muted-foreground">Products</p>
        </div>
        <div className="text-center p-2 rounded-lg bg-muted/20">
          <p className="text-lg font-bold text-green-500">98%</p>
          <p className="text-xs text-muted-foreground">Response</p>
        </div>
      </div>

      {/* Info Chips */}
      <div className="flex flex-wrap gap-2">
        {(seller?.district || seller?.sub_county) && (
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground bg-muted/30 px-2 py-1 rounded-full">
            <MapPin className="w-3 h-3" />
            <span>{[seller.sub_county, seller.district].filter(Boolean).join(', ')}</span>
          </div>
        )}
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground bg-muted/30 px-2 py-1 rounded-full">
          <Clock className="w-3 h-3" />
          <span>
            {seller?.created_at 
              ? formatDistanceToNow(new Date(seller.created_at), { addSuffix: false })
              : 'New'
            }
          </span>
        </div>
        {seller?.is_verified && (
          <div className="flex items-center gap-1.5 text-xs text-green-600 bg-green-500/10 px-2 py-1 rounded-full">
            <CheckCircle2 className="w-3 h-3" />
            <span>Verified</span>
          </div>
        )}
      </div>

      {/* Big Visit Store CTA */}
      <Button
        onClick={() => seller && navigate(getSellerProfileUrl(seller))}
        size="lg"
        className="w-full h-12 text-sm font-semibold gap-2 rounded-full"
      >
        <ExternalLink className="w-4 h-4" />
        Visit Store
      </Button>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-2">
        <Button
          onClick={onContact}
          size="lg"
          className="h-12 text-sm gap-2"
        >
          <MessageCircle className="w-5 h-5" />
          Message
        </Button>
        <Button
          variant="outline"
          onClick={onCall}
          size="lg"
          className="h-12 text-sm gap-2"
        >
          <Phone className="w-5 h-5" />
          Call
        </Button>
      </div>

      <Button
        variant={isFollowing ? "secondary" : "outline"}
        size="sm"
        onClick={handleFollowClick}
        disabled={followLoading || !seller?.user_id}
        className={cn(
          "w-full h-9 text-xs gap-1.5",
          isFollowing && "bg-primary/10 text-primary border-primary/30"
        )}
      >
        {isFollowing ? (
          <>
            <UserCheck className="w-3.5 h-3.5" />
            Following
          </>
        ) : (
          <>
            <UserPlus className="w-3.5 h-3.5" />
            Follow Business
          </>
        )}
      </Button>
    </div>
  );
};

export default SellerInfoCard;
