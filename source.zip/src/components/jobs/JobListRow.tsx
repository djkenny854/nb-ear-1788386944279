import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Bookmark, Share2, Briefcase, Clock, MapPin, Wallet } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useBookmarks } from '@/hooks/useBookmarks';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';

export interface JobPositionLite {
  title: string;
  quantity?: number;
}

export interface JobListItem {
  id: string;
  title: string;
  company: string;
  companyLogo?: string;
  location?: string;
  category?: string;
  jobType?: string;
  createdAt: string;
  viewCount?: number;
  applicantCount?: number;
  /** Multi-position jobs: list of distinct roles, with optional quantity each */
  positions?: JobPositionLite[];
  /** Total seats across all positions (or 1 for single role) */
  numberOfPositions?: number;
  /** 'single' | 'multiple' */
  jobPostingType?: string;
  /** Salary range (single positions) */
  salaryMin?: number | null;
  salaryMax?: number | null;
  salaryCurrency?: string;
  showSalary?: boolean;
}

interface Props {
  job: JobListItem;
  onShare?: (job: JobListItem) => void;
}

const JobListRow: React.FC<Props> = ({ job, onShare }) => {
  const navigate = useNavigate();
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const saved = isBookmarked(job.id, 'job');

  const timeAgo = (() => {
    try {
      return formatDistanceToNow(new Date(job.createdAt), { addSuffix: true });
    } catch {
      return 'recently';
    }
  })();

  const isMultiPosition =
    (job.jobPostingType === 'multiple' || (job.positions && job.positions.length > 1));
  const totalSeats = isMultiPosition
    ? (job.positions || []).reduce((sum, p) => sum + (p.quantity || 1), 0) || job.numberOfPositions || (job.positions?.length || 0)
    : (job.numberOfPositions || 1);

  const formatSalary = () => {
    if (job.showSalary === false) return null;
    const { salaryMin, salaryMax } = job;
    if (salaryMin == null && salaryMax == null) return null;
    const cur = job.salaryCurrency || 'UGX';
    const fmt = (n: number) => {
      if (n >= 1000000) return `${(n / 1000000).toFixed(n % 1000000 === 0 ? 0 : 1)}M`;
      if (n >= 1000) return `${Math.round(n / 1000)}K`;
      return n.toLocaleString();
    };
    if (salaryMin != null && salaryMax != null) return `${cur} ${fmt(salaryMin)} – ${fmt(salaryMax)}`;
    if (salaryMin != null) return `${cur} ${fmt(salaryMin)}+`;
    return `Up to ${cur} ${fmt(salaryMax as number)}`;
  };
  const salaryLabel = formatSalary();

  const metaBits = [
    timeAgo,
    job.category || job.jobType,
    job.applicantCount != null
      ? `${job.applicantCount} applicant${job.applicantCount === 1 ? '' : 's'}`
      : null,
    job.location,
  ].filter(Boolean);

  return (
    <div
      onClick={() => navigate(`/job/${job.id}`)}
      className="group cursor-pointer py-3 md:py-4 border-b border-border/40 last:border-0 hover:bg-muted/30 transition-colors px-2 md:px-3 rounded-lg"
    >
      {/* Header: avatar + title, inline */}
      <div className="flex items-start gap-3">
        <Avatar className="w-9 h-9 md:w-10 md:h-10 flex-shrink-0 border border-border/50">
          <AvatarImage src={job.companyLogo} alt={job.company} />
          <AvatarFallback className="text-xs bg-primary/10 text-primary">
            {job.company?.charAt(0)?.toUpperCase() || 'C'}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <h3 className="text-[15px] md:text-base font-bold text-foreground leading-snug line-clamp-2 group-hover:text-primary transition-colors">
            {job.title}
          </h3>

          {/* Meta row */}
          <div className="flex items-center flex-wrap gap-x-1.5 gap-y-0.5 mt-1 text-[11px] md:text-xs text-muted-foreground">
            {metaBits.map((bit, i) => (
              <React.Fragment key={i}>
                {i > 0 && <span className="opacity-50">·</span>}
                <span className="inline-flex items-center gap-1">
                  {i === 0 && <Clock className="w-3 h-3" />}
                  {bit === job.location && <MapPin className="w-3 h-3" />}
                  {bit}
                </span>
              </React.Fragment>
            ))}
          </div>

          {/* Salary range */}
          {salaryLabel && (
            <div className="mt-1.5">
              <span className="inline-flex items-center gap-1 text-[11px] md:text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 rounded-full px-2 py-0.5">
                <Wallet className="w-3 h-3" />
                {salaryLabel}
              </span>
            </div>
          )}

          {/* Multi-position badge / Positions list */}
          {isMultiPosition && job.positions && job.positions.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              <span className="inline-flex items-center gap-1 text-[10.5px] font-semibold text-primary bg-primary/10 rounded-full px-2 py-0.5">
                Hiring {totalSeats} for {job.positions.length} role{job.positions.length !== 1 ? 's' : ''}
              </span>
              {job.positions.slice(0, 3).map((p, idx) => (
                <span
                  key={idx}
                  className="text-[10.5px] text-foreground bg-muted rounded-full px-2 py-0.5 truncate max-w-[140px]"
                  title={p.title}
                >
                  {p.title}
                  {p.quantity && p.quantity > 1 ? ` ×${p.quantity}` : ''}
                </span>
              ))}
              {job.positions.length > 3 && (
                <span className="text-[10.5px] text-muted-foreground bg-muted rounded-full px-2 py-0.5">
                  +{job.positions.length - 3} more
                </span>
              )}
            </div>
          )}
          {!isMultiPosition && (job.numberOfPositions || 0) > 1 && (
            <div className="mt-2">
              <span className="inline-flex items-center gap-1 text-[10.5px] font-semibold text-primary bg-primary/10 rounded-full px-2 py-0.5">
                Hiring {job.numberOfPositions} seats
              </span>
            </div>
          )}

          {/* Action row */}
          <div className="flex items-center gap-2 mt-2.5">
            <Button
              size="sm"
              className="h-7 px-3 text-xs rounded-full"
              onClick={(e) => {
                e.stopPropagation();
                navigate(`/jobs/${job.id}/apply`);
              }}
            >
              <Briefcase className="w-3 h-3 mr-1" />
              Apply
            </Button>
            <button
              aria-label={saved ? 'Unsave job' : 'Save job'}
              onClick={(e) => {
                e.stopPropagation();
                toggleBookmark(job.id, 'job');
              }}
              className="inline-flex items-center justify-center h-7 w-7 rounded-full hover:bg-muted"
            >
              <Bookmark
                className={cn(
                  'w-4 h-4',
                  saved ? 'fill-primary text-primary' : 'text-muted-foreground'
                )}
              />
            </button>
            <button
              aria-label="Share job"
              onClick={(e) => {
                e.stopPropagation();
                onShare?.(job);
              }}
              className="inline-flex items-center justify-center h-7 w-7 rounded-full hover:bg-muted text-muted-foreground"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

function formatCount(n: number) {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `${(n / 1000).toFixed(n >= 10000 ? 0 : 1)}K`;
  return String(n);
}

export default JobListRow;
