import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Briefcase, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import JobListRow, { JobListItem } from './JobListRow';
import JobListRowSkeleton from './JobListRowSkeleton';
import ShareModal from '@/components/ShareModal';
import { useBlockedUsers } from '@/hooks/useBlockedUsers';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';

interface Props {
  limit?: number;
  showHeader?: boolean;
  onSeeAll?: () => void;
  /** Pre-fetched jobs (used by marketplace tab to avoid double fetch). */
  externalJobs?: JobListItem[];
  externalLoading?: boolean;
}

const LatestJobsList: React.FC<Props> = ({
  limit = 5,
  showHeader = true,
  onSeeAll,
  externalJobs,
  externalLoading,
}) => {
  const { allBlockedIds } = useBlockedUsers();
  const { isOnline } = useNetworkStatus();
  const [shareJob, setShareJob] = useState<JobListItem | null>(null);

  const { data: fetchedJobs, isLoading } = useQuery({
    queryKey: ['latest-jobs-list', limit],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('ads')
        .select(`
          id,
          title,
          location,
          category,
          view_count,
          created_at,
          seller_id,
          seller_profiles!ads_seller_id_fkey ( id, user_id, business_name, business_logo_url ),
          job_details ( company_name, company_logo_url, job_type, application_deadline, positions, number_of_positions, job_posting_type, salary_min, salary_max, salary_currency, show_salary )
        `)
        .eq('status', 'active')
        .eq('listing_type', 'jobs')
        .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`)
        .order('created_at', { ascending: false })
        .limit(Math.max(limit * 2, 10));
      if (error) throw error;

      const now = new Date();
      return (data || [])
        .filter((j: any) => {
          const dl = j.job_details?.[0]?.application_deadline;
          return !dl || new Date(dl) >= now;
        })
        .map<JobListItem>((j: any) => {
          const jd = j.job_details?.[0];
          const seller = j.seller_profiles;
          return {
            id: j.id,
            title: j.title,
            company: jd?.company_name || seller?.business_name || 'Company',
            companyLogo: jd?.company_logo_url || seller?.business_logo_url,
            location: j.location,
            category: j.category,
            jobType: jd?.job_type,
            createdAt: j.created_at,
            viewCount: j.view_count || 0,
            positions: Array.isArray(jd?.positions) ? jd.positions : undefined,
            numberOfPositions: jd?.number_of_positions,
            jobPostingType: jd?.job_posting_type,
            salaryMin: jd?.salary_min ?? null,
            salaryMax: jd?.salary_max ?? null,
            salaryCurrency: jd?.salary_currency || 'UGX',
            showSalary: jd?.show_salary !== false,
          };
        });
    },
    staleTime: 1000 * 60 * 5,
    enabled: !externalJobs && isOnline,
  });

  const loading = externalLoading ?? isLoading;
  const rawJobs = externalJobs ?? fetchedJobs ?? [];
  const jobs = rawJobs
    .filter((j) => !allBlockedIds.includes((j as any).user_id))
    .slice(0, limit);

  if (loading) {
    return (
      <section className={showHeader ? 'py-4' : ''}>
        {showHeader && <HeaderRow />}
        <div className="space-y-0">
          {Array.from({ length: limit }).map((_, i) => (
            <JobListRowSkeleton key={i} />
          ))}
        </div>
      </section>
    );
  }

  if (!jobs.length) return null;

  return (
    <section className={showHeader ? 'py-4' : ''}>
      {showHeader && <HeaderRow onSeeAll={onSeeAll} />}
      <div className="space-y-0">
        {jobs.map((job) => (
          <JobListRow key={job.id} job={job} onShare={setShareJob} />
        ))}
      </div>
      {onSeeAll && (
        <button
          onClick={onSeeAll}
          className="mt-3 text-sm text-primary font-medium inline-flex items-center gap-1 hover:underline"
        >
          See all jobs <ChevronRight className="w-4 h-4" />
        </button>
      )}
      {shareJob && (
        <ShareModal
          open={!!shareJob}
          onOpenChange={(o) => !o && setShareJob(null)}
          title={shareJob.title}
          url={`${window.location.origin}/job/${shareJob.id}`}
        />
      )}
    </section>
  );
};

const HeaderRow: React.FC<{ onSeeAll?: () => void }> = ({ onSeeAll }) => (
  <div className="flex items-center justify-between mb-3">
    <div className="flex items-center gap-3">
      <Briefcase className="w-7 h-7 text-emerald-500" strokeWidth={2.5} />
      <div>
        <h2 className="text-xl font-bold text-foreground tracking-tight">Latest Jobs</h2>
        <p className="text-xs text-muted-foreground">Find your next opportunity</p>
      </div>
    </div>
    {onSeeAll && (
      <Button variant="ghost" size="sm" onClick={onSeeAll} className="text-primary">
        See All <ChevronRight className="w-4 h-4 ml-1" />
      </Button>
    )}
  </div>
);

export default LatestJobsList;
