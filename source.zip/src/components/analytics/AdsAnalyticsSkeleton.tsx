import React from 'react';

export const AdsAnalyticsSkeleton = () => {
  return (
    <div className="w-full min-h-screen bg-[#fafafa] dark:bg-background text-foreground pb-16">
      <div className="w-full max-w-[1400px] mx-auto px-3 sm:px-6 py-4 space-y-4">
        {/* Top Controls Bar Skeleton */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
            {/* Search Input Skeleton */}
            <div className="h-9 w-64 max-w-full rounded-lg bg-gray-200/80 dark:bg-muted animate-pulse" />
            
            {/* Filters Button Skeleton */}
            <div className="h-9 w-20 rounded-lg bg-gray-200/80 dark:bg-muted animate-pulse" />
            
            {/* Shield Icon Button Skeleton */}
            <div className="h-9 w-9 rounded-lg bg-gray-200/80 dark:bg-muted animate-pulse" />
            
            {/* Current / Archived Pill Skeleton */}
            <div className="h-9 w-32 rounded-lg bg-gray-200/80 dark:bg-muted animate-pulse hidden sm:block" />
          </div>

          <div className="flex items-center gap-2">
            {/* Date Range Skeleton */}
            <div className="h-9 w-52 rounded-lg bg-gray-200/80 dark:bg-muted animate-pulse" />
            
            {/* Create Campaign Button Skeleton */}
            <div className="h-9 w-36 rounded-lg bg-gray-300 dark:bg-muted-foreground/30 animate-pulse" />
          </div>
        </div>

        {/* Top Metrics Card with Waveform/Bar Chart Skeleton */}
        <div className="bg-white dark:bg-card border border-gray-200 dark:border-border rounded-2xl p-4 sm:p-6 shadow-sm space-y-6">
          {/* Metrics Row Skeleton */}
          <div className="flex flex-wrap items-start justify-between gap-4 border-b border-gray-100 dark:border-border/60 pb-4">
            <div className="flex flex-wrap items-center gap-6 sm:gap-10">
              {/* Metric 1 */}
              <div className="space-y-2 min-w-[100px]">
                <div className="h-3 w-20 bg-gray-200/80 dark:bg-muted rounded animate-pulse" />
                <div className="h-7 w-24 bg-gray-200/80 dark:bg-muted rounded animate-pulse" />
                <div className="h-0.5 w-16 bg-gray-300 dark:bg-muted-foreground/40 rounded" />
              </div>

              {/* Metric 2 */}
              <div className="space-y-2 min-w-[90px]">
                <div className="h-3 w-16 bg-gray-200/80 dark:bg-muted rounded animate-pulse" />
                <div className="h-7 w-20 bg-gray-200/80 dark:bg-muted rounded animate-pulse" />
              </div>

              {/* Metric 3 */}
              <div className="space-y-2 min-w-[90px]">
                <div className="h-3 w-18 bg-gray-200/80 dark:bg-muted rounded animate-pulse" />
                <div className="h-7 w-12 bg-gray-200/80 dark:bg-muted rounded animate-pulse" />
              </div>

              {/* Metric 4 */}
              <div className="space-y-2 min-w-[90px] hidden sm:block">
                <div className="h-3 w-18 bg-gray-200/80 dark:bg-muted rounded animate-pulse" />
                <div className="h-7 w-12 bg-gray-200/80 dark:bg-muted rounded animate-pulse" />
              </div>

              {/* Metric 5 */}
              <div className="space-y-2 min-w-[110px] hidden md:block">
                <div className="h-3 w-24 bg-gray-200/80 dark:bg-muted rounded animate-pulse" />
                <div className="h-7 w-16 bg-gray-200/80 dark:bg-muted rounded animate-pulse" />
              </div>
            </div>

            {/* Top Right Chart Actions */}
            <div className="flex items-center gap-2">
              <div className="h-8 w-24 rounded-lg bg-gray-200/80 dark:bg-muted animate-pulse" />
              <div className="h-8 w-8 rounded-lg bg-gray-200/80 dark:bg-muted animate-pulse" />
              <div className="h-8 w-8 rounded-lg bg-gray-200/80 dark:bg-muted animate-pulse" />
            </div>
          </div>

          {/* Vertical Bars / Waveform Chart Skeleton (Matching Screenshot 2) */}
          <div className="pt-2">
            <div className="h-44 w-full flex items-end justify-between gap-1.5 sm:gap-2.5 px-2">
              {[
                45, 60, 85, 110, 70, 95, 55, 80, 120, 100, 
                65, 85, 130, 90, 75, 115, 60, 80, 105, 70, 
                90, 110, 50, 85
              ].map((height, i) => (
                <div
                  key={i}
                  style={{ height: `${height}px` }}
                  className="w-full bg-gray-200/90 dark:bg-muted rounded-t-md animate-pulse"
                />
              ))}
            </div>

            {/* X-Axis Date Placeholders */}
            <div className="flex items-center justify-between pt-4 px-2">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-3 w-12 bg-gray-200/80 dark:bg-muted rounded animate-pulse" />
              ))}
            </div>
          </div>
        </div>

        {/* Audience Insights Banner Skeleton */}
        <div className="h-12 w-full rounded-2xl bg-gray-200/80 dark:bg-muted animate-pulse flex items-center px-4" />

        {/* Table & Sub-tabs Skeleton */}
        <div className="bg-white dark:bg-card border border-gray-200 dark:border-border rounded-2xl shadow-sm overflow-hidden">
          {/* Sub-tabs Row */}
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3.5 border-b border-gray-100 dark:border-border/60">
            <div className="flex items-center gap-6">
              <div className="h-4 w-28 bg-gray-200/80 dark:bg-muted rounded animate-pulse" />
              <div className="h-4 w-20 bg-gray-300 dark:bg-muted-foreground/30 rounded animate-pulse" />
              <div className="h-4 w-18 bg-gray-200/80 dark:bg-muted rounded animate-pulse hidden sm:block" />
              <div className="h-4 w-12 bg-gray-200/80 dark:bg-muted rounded animate-pulse hidden sm:block" />
            </div>

            <div className="flex items-center gap-2">
              <div className="h-8 w-28 bg-gray-200/80 dark:bg-muted rounded-lg animate-pulse" />
              <div className="h-8 w-8 bg-gray-200/80 dark:bg-muted rounded-full animate-pulse" />
            </div>
          </div>

          {/* Table Header Skeleton */}
          <div className="grid grid-cols-12 gap-2 px-4 py-3 bg-gray-50/70 dark:bg-muted/30 border-b border-gray-100 dark:border-border text-xs">
            <div className="col-span-1 flex items-center gap-2">
              <div className="h-4 w-4 rounded bg-gray-200 dark:bg-muted animate-pulse" />
              <div className="h-3 w-8 bg-gray-200 dark:bg-muted rounded animate-pulse hidden md:block" />
            </div>
            <div className="col-span-5 md:col-span-4">
              <div className="h-3 w-16 bg-gray-200 dark:bg-muted rounded animate-pulse" />
            </div>
            <div className="col-span-2 hidden md:block">
              <div className="h-3 w-20 bg-gray-200 dark:bg-muted rounded animate-pulse" />
            </div>
            <div className="col-span-2 hidden lg:block">
              <div className="h-3 w-16 bg-gray-200 dark:bg-muted rounded animate-pulse" />
            </div>
            <div className="col-span-2 md:col-span-3 lg:col-span-1">
              <div className="h-3 w-12 bg-gray-200 dark:bg-muted rounded animate-pulse" />
            </div>
            <div className="col-span-2 md:col-span-2 lg:col-span-2">
              <div className="h-3 w-12 bg-gray-200 dark:bg-muted rounded animate-pulse" />
            </div>
          </div>

          {/* Total for X campaigns summary row */}
          <div className="px-4 py-2.5 bg-gray-50/40 dark:bg-muted/10 border-b border-gray-100 dark:border-border/40">
            <div className="h-3.5 w-36 bg-gray-200/80 dark:bg-muted rounded animate-pulse" />
          </div>

          {/* Table Row Skeletons */}
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="grid grid-cols-12 gap-2 items-center px-4 py-4 border-b border-gray-100 dark:border-border/40 last:border-0"
            >
              <div className="col-span-1 flex items-center gap-2">
                <div className="h-4 w-4 rounded bg-gray-200 dark:bg-muted animate-pulse" />
                <div className="h-5 w-8 rounded-full bg-gray-200 dark:bg-muted animate-pulse hidden md:block" />
              </div>
              <div className="col-span-5 md:col-span-4 space-y-2">
                <div className="h-3.5 w-3/4 bg-gray-200 dark:bg-muted rounded animate-pulse" />
                <div className="h-3 w-1/3 bg-gray-200/70 dark:bg-muted/70 rounded animate-pulse" />
              </div>
              <div className="col-span-2 hidden md:block">
                <div className="h-3.5 w-16 bg-gray-200 dark:bg-muted rounded animate-pulse" />
              </div>
              <div className="col-span-2 hidden lg:block">
                <div className="h-3.5 w-14 bg-gray-200 dark:bg-muted rounded animate-pulse" />
              </div>
              <div className="col-span-2 md:col-span-3 lg:col-span-1">
                <div className="h-3.5 w-16 bg-gray-200 dark:bg-muted rounded animate-pulse" />
              </div>
              <div className="col-span-2 md:col-span-2 lg:col-span-2">
                <div className="h-3.5 w-16 bg-gray-200 dark:bg-muted rounded animate-pulse" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdsAnalyticsSkeleton;
