import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar
} from 'recharts';
import { Button } from '@/components/ui/button';
import { Clock, Calendar, BarChart3, Activity } from 'lucide-react';

interface HourlyActivityChartProps {
  hourlyData: { hour: string; activity: number }[];
  dailyData: { day: string; activity: number }[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-card border border-border rounded-xl p-3 shadow-xl"
      >
        <p className="font-medium text-sm mb-1">{label}</p>
        <p className="text-xs">
          <span className="text-muted-foreground">Activity: </span>
          <span className="font-medium text-primary">{payload[0].value.toLocaleString()}</span>
        </p>
      </motion.div>
    );
  }
  return null;
};

export default function HourlyActivityChart({ hourlyData, dailyData }: HourlyActivityChartProps) {
  const [view, setView] = useState<'hourly' | 'daily'>('daily');
  const [chartType, setChartType] = useState<'area' | 'bar'>('area');
  const today = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });

  const data = view === 'hourly' ? hourlyData : dailyData;

  return (
    <div className="w-full">
      {/* Controls */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <Button
              variant={view === 'daily' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setView('daily')}
              className="gap-1.5"
            >
              <Calendar className="w-3.5 h-3.5" />
              Daily
            </Button>
            <Button
              variant={view === 'hourly' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setView('hourly')}
              className="gap-1.5"
            >
              <Clock className="w-3.5 h-3.5" />
              Hourly
            </Button>
          </div>
          {view === 'hourly' && (
            <span className="text-xs text-muted-foreground">{today}</span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant={chartType === 'area' ? 'secondary' : 'ghost'}
            size="icon"
            className="w-8 h-8"
            onClick={() => setChartType('area')}
          >
            <Activity className="w-4 h-4" />
          </Button>
          <Button
            variant={chartType === 'bar' ? 'secondary' : 'ghost'}
            size="icon"
            className="w-8 h-8"
            onClick={() => setChartType('bar')}
          >
            <BarChart3 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Chart */}
      <motion.div
        key={`${view}-${chartType}`}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="h-[250px]"
      >
        <ResponsiveContainer width="100%" height="100%">
          {chartType === 'area' ? (
            <AreaChart data={data}>
              <defs>
                <linearGradient id="activityGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="hsl(var(--muted))"
                opacity={0.2}
                vertical={false}
              />
              <XAxis
                dataKey={view === 'hourly' ? 'hour' : 'day'}
                axisLine={false}
                tickLine={false}
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
                interval={view === 'hourly' ? 3 : 0}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="monotone"
                dataKey="activity"
                stroke="hsl(var(--primary))"
                fill="url(#activityGradient)"
                strokeWidth={2}
                dot={false}
                animationDuration={1500}
                animationEasing="ease-out"
              />
            </AreaChart>
          ) : (
            <BarChart data={data}>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="hsl(var(--muted))"
                opacity={0.2}
                vertical={false}
              />
              <XAxis
                dataKey={view === 'hourly' ? 'hour' : 'day'}
                axisLine={false}
                tickLine={false}
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
                interval={view === 'hourly' ? 3 : 0}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar
                dataKey="activity"
                fill="hsl(var(--primary))"
                radius={[4, 4, 0, 0]}
                animationDuration={1500}
                animationEasing="ease-out"
              />
            </BarChart>
          )}
        </ResponsiveContainer>
      </motion.div>
    </div>
  );
}
