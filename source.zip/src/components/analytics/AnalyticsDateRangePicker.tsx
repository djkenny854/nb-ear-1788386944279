import React, { useState } from 'react';
import { 
  format, subDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth, 
  subMonths, startOfQuarter, endOfQuarter, subQuarters, startOfYear, endOfYear,
  eachDayOfInterval, isSameDay, isWithinInterval, isSameMonth, addMonths, subMonths as subCalendarMonths
} from 'date-fns';
import { 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  ChevronDown,
  Clock,
  X
} from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';

export interface DateRangeSelection {
  startDate: Date;
  endDate: Date;
  presetKey?: string;
  isUtc?: boolean;
}

interface AnalyticsDateRangePickerProps {
  value: DateRangeSelection;
  onChange: (range: DateRangeSelection) => void;
  className?: string;
}

const PRESETS = [
  { key: 'today', label: 'Today', getRange: () => ({ start: new Date(), end: new Date() }) },
  { key: 'yesterday', label: 'Yesterday', getRange: () => ({ start: subDays(new Date(), 1), end: subDays(new Date(), 1) }) },
  { key: 'last7d', label: 'Last 7 days', getRange: () => ({ start: subDays(new Date(), 6), end: new Date() }) },
  { key: 'last30d', label: 'Last 30 days', getRange: () => ({ start: subDays(new Date(), 29), end: new Date() }) },
  { key: 'thisMonth', label: 'This month', getRange: () => ({ start: startOfMonth(new Date()), end: new Date() }) },
  { key: 'lastMonth', label: 'Last month', getRange: () => {
    const prev = subMonths(new Date(), 1);
    return { start: startOfMonth(prev), end: endOfMonth(prev) };
  }},
  { key: 'thisQuarter', label: 'This quarter', getRange: () => ({ start: startOfQuarter(new Date()), end: new Date() }) },
  { key: 'lastQuarter', label: 'Last quarter', getRange: () => {
    const prev = subQuarters(new Date(), 1);
    return { start: startOfQuarter(prev), end: endOfQuarter(prev) };
  }},
  { key: 'thisYear', label: 'This year', getRange: () => ({ start: startOfYear(new Date()), end: new Date() }) },
  { key: 'lifetime', label: 'Lifetime', getRange: () => ({ start: new Date(2025, 0, 1), end: new Date() }) },
];

export const AnalyticsDateRangePicker: React.FC<AnalyticsDateRangePickerProps> = ({
  value,
  onChange,
  className,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [viewMonth, setViewMonth] = useState<Date>(value.endDate || new Date());
  const [selectedStart, setSelectedStart] = useState<Date>(value.startDate);
  const [selectedEnd, setSelectedEnd] = useState<Date>(value.endDate);
  const [activePreset, setActivePreset] = useState<string>(value.presetKey || 'last7d');
  const [activeInput, setActiveInput] = useState<'start' | 'end'>('end');
  const [isUtc, setIsUtc] = useState<boolean>(value.isUtc || false);

  const handleOpenToggle = () => {
    setIsOpen(!isOpen);
    if (!isOpen) {
      setSelectedStart(value.startDate);
      setSelectedEnd(value.endDate);
      setViewMonth(value.endDate);
    }
  };

  const handleSelectPreset = (preset: typeof PRESETS[0]) => {
    const range = preset.getRange();
    setSelectedStart(range.start);
    setSelectedEnd(range.end);
    setActivePreset(preset.key);
    setViewMonth(range.end);
    onChange({
      startDate: range.start,
      endDate: range.end,
      presetKey: preset.key,
      isUtc,
    });
    setIsOpen(false);
  };

  const handleDateClick = (day: Date) => {
    if (activeInput === 'start') {
      if (day > selectedEnd) {
        setSelectedStart(day);
        setSelectedEnd(day);
        setActiveInput('end');
      } else {
        setSelectedStart(day);
        setActiveInput('end');
      }
      setActivePreset('custom');
    } else {
      if (day < selectedStart) {
        setSelectedStart(day);
        setSelectedEnd(day);
      } else {
        setSelectedEnd(day);
      }
      setActivePreset('custom');
      // Apply immediately
      onChange({
        startDate: selectedStart < day ? selectedStart : day,
        endDate: selectedStart < day ? day : selectedStart,
        presetKey: 'custom',
        isUtc,
      });
    }
  };

  const daysOfWeek = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

  // Calculate calendar grid days
  const monthStart = startOfMonth(viewMonth);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart);
  const endDate = endOfWeek(monthEnd);
  const calendarDays = eachDayOfInterval({ start: startDate, end: endDate });

  const formattedRange = `${format(value.startDate, 'MMM d, yyyy')} – ${format(value.endDate, 'MMM d, yyyy')}`;

  return (
    <div className={cn('relative inline-block text-left', className)}>
      {/* Trigger Button */}
      <button
        type="button"
        onClick={handleOpenToggle}
        className={cn(
          'flex items-center gap-2 px-3 py-1.5 h-9 text-xs sm:text-sm font-medium rounded-lg border transition-all select-none',
          'bg-white dark:bg-card border-gray-200 dark:border-border text-foreground hover:bg-gray-50 dark:hover:bg-accent shadow-sm',
          isOpen && 'ring-2 ring-sky-500/30 border-sky-500'
        )}
      >
        <CalendarIcon className="h-4 w-4 text-gray-500 dark:text-muted-foreground shrink-0" />
        <span className="truncate">{formattedRange}</span>
      </button>

      {/* Popover Dropdown (Matches Screenshot 3) */}
      {isOpen && (
        <>
          {/* Backdrop click dismiss */}
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />

          <div className="absolute right-0 top-full mt-1.5 z-50 w-[95vw] sm:w-[580px] bg-white dark:bg-card border border-gray-200 dark:border-border rounded-2xl shadow-xl overflow-hidden animate-in fade-in-50 zoom-in-95">
            <div className="flex flex-col sm:flex-row">
              {/* Left Column: Presets List */}
              <div className="w-full sm:w-44 border-b sm:border-b-0 sm:border-r border-gray-100 dark:border-border/60 py-2 sm:py-3 px-2 flex flex-row sm:flex-col overflow-x-auto sm:overflow-x-visible shrink-0">
                {PRESETS.map((preset) => {
                  const isSelected = activePreset === preset.key;
                  return (
                    <button
                      key={preset.key}
                      type="button"
                      onClick={() => handleSelectPreset(preset)}
                      className={cn(
                        'text-left px-3 py-2 text-xs sm:text-sm rounded-lg whitespace-nowrap transition-colors',
                        isSelected
                          ? 'font-semibold text-foreground bg-gray-100 dark:bg-accent'
                          : 'text-gray-600 dark:text-muted-foreground hover:bg-gray-50 dark:hover:bg-accent/50 hover:text-foreground'
                      )}
                    >
                      {preset.label}
                    </button>
                  );
                })}
              </div>

              {/* Right Column: Calendar */}
              <div className="flex-1 p-4 space-y-4">
                {/* Start & End Date Input Boxes */}
                <div className="grid grid-cols-2 gap-3">
                  {/* Start Box */}
                  <div
                    onClick={() => setActiveInput('start')}
                    className={cn(
                      'p-2.5 rounded-xl border text-left cursor-pointer transition-all',
                      activeInput === 'start'
                        ? 'border-sky-500 bg-sky-50/60 dark:bg-sky-950/30 ring-1 ring-sky-500'
                        : 'border-gray-200 dark:border-border bg-white dark:bg-card'
                    )}
                  >
                    <div className="text-[11px] font-medium text-gray-500 dark:text-muted-foreground">
                      Start
                    </div>
                    <div className="text-sm font-semibold text-foreground mt-0.5">
                      {format(selectedStart, 'MMM d')}
                    </div>
                  </div>

                  {/* End Box */}
                  <div
                    onClick={() => setActiveInput('end')}
                    className={cn(
                      'p-2.5 rounded-xl border text-left cursor-pointer transition-all',
                      activeInput === 'end'
                        ? 'border-sky-500 bg-sky-50/60 dark:bg-sky-950/30 ring-1 ring-sky-500'
                        : 'border-gray-200 dark:border-border bg-white dark:bg-card'
                    )}
                  >
                    <div className="text-[11px] font-medium text-gray-500 dark:text-muted-foreground">
                      End
                    </div>
                    <div className="text-sm font-semibold text-foreground mt-0.5">
                      {format(selectedEnd, 'MMM d')}
                    </div>
                  </div>
                </div>

                {/* Month Navigation */}
                <div className="flex items-center justify-between px-1">
                  <button
                    type="button"
                    onClick={() => setViewMonth(subCalendarMonths(viewMonth, 1))}
                    className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-accent text-gray-600 dark:text-muted-foreground transition-colors"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </button>

                  <div className="flex items-center gap-1 font-semibold text-sm text-foreground">
                    <span>{format(viewMonth, 'MMMM yyyy')}</span>
                    <ChevronDown className="h-3.5 w-3.5 text-gray-500" />
                  </div>

                  <button
                    type="button"
                    onClick={() => setViewMonth(addMonths(viewMonth, 1))}
                    className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-accent text-gray-600 dark:text-muted-foreground transition-colors"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>

                {/* Days of Week Header */}
                <div className="grid grid-cols-7 text-center text-xs font-medium text-gray-400 dark:text-muted-foreground">
                  {daysOfWeek.map((day, idx) => (
                    <div key={idx} className="py-1">
                      {day}
                    </div>
                  ))}
                </div>

                {/* Calendar Days Grid */}
                <div className="grid grid-cols-7 gap-y-1 text-center text-xs sm:text-sm">
                  {calendarDays.map((day, idx) => {
                    const isCurrentMonth = isSameMonth(day, viewMonth);
                    const isStart = isSameDay(day, selectedStart);
                    const isEnd = isSameDay(day, selectedEnd);
                    const inRange =
                      isWithinInterval(day, { start: selectedStart, end: selectedEnd }) &&
                      !isStart &&
                      !isEnd;

                    return (
                      <div
                        key={idx}
                        className={cn(
                          'relative py-1 flex items-center justify-center',
                          inRange && 'bg-sky-50 dark:bg-sky-950/30'
                        )}
                      >
                        <button
                          type="button"
                          onClick={() => handleDateClick(day)}
                          className={cn(
                            'h-8 w-8 rounded-full flex items-center justify-center transition-all text-xs font-medium',
                            !isCurrentMonth && 'text-gray-300 dark:text-muted-foreground/30',
                            isCurrentMonth && !isStart && !isEnd && 'text-gray-700 dark:text-foreground hover:bg-gray-100 dark:hover:bg-accent',
                            (isStart || isEnd) && 'bg-sky-500 text-white font-semibold shadow-sm hover:bg-sky-600',
                            inRange && 'text-sky-900 dark:text-sky-200'
                          )}
                        >
                          {format(day, 'd')}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Bottom Footer (Timezone & UTC switch) */}
            <div className="border-t border-gray-100 dark:border-border/60 px-4 py-3 bg-gray-50/50 dark:bg-muted/20 flex items-center justify-between text-xs text-gray-500 dark:text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5" />
                <span>Showing East Africa Time (EAT)</span>
              </div>

              <div className="flex items-center gap-2">
                <span className="font-medium text-foreground">UTC</span>
                <Switch
                  checked={isUtc}
                  onCheckedChange={(checked) => {
                    setIsUtc(checked);
                    onChange({
                      startDate: selectedStart,
                      endDate: selectedEnd,
                      presetKey: activePreset,
                      isUtc: checked,
                    });
                  }}
                />
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default AnalyticsDateRangePicker;
