import React, { useState } from 'react';
import { 
  ChevronDown, 
  ChevronRight, 
  MapPin, 
  Smartphone, 
  Globe, 
  Apple, 
  Clock, 
  Users, 
  Sparkles,
  Compass
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

interface AudienceInsightsProps {
  topDistricts?: { name: string; value: number }[];
  totalViews?: number;
  totalFollowers?: number;
  peakHour?: string;
  className?: string;
}

export const AudienceInsightsPanel: React.FC<AudienceInsightsProps> = ({
  topDistricts = [],
  totalViews = 0,
  totalFollowers = 0,
  peakHour = '19:00 (7 PM)',
  className,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Default Uganda districts if empty
  const displayDistricts = topDistricts.length > 0 ? topDistricts : [
    { name: 'Kampala Central & Nakawa', value: 42 },
    { name: 'Wakiso (Kira, Nansana, Entebbe)', value: 28 },
    { name: 'Mukono Municipality', value: 12 },
    { name: 'Jinja City', value: 9 },
    { name: 'Mbarara & Western Hub', value: 5 },
    { name: 'Gulu & Northern Region', value: 4 },
  ];

  const totalDistVal = displayDistricts.reduce((sum, d) => sum + d.value, 0) || 100;

  return (
    <div
      className={cn(
        'w-full bg-white dark:bg-card border border-gray-200 dark:border-border rounded-2xl shadow-sm overflow-hidden transition-all',
        className
      )}
    >
      {/* Collapsible Header Banner (Matches Screenshot 1) */}
      <button
        type="button"
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full px-4 sm:px-6 py-3.5 flex items-center justify-between hover:bg-gray-50/60 dark:hover:bg-accent/40 transition-colors text-left select-none"
      >
        <div className="flex items-center gap-2.5">
          {isExpanded ? (
            <ChevronDown className="h-4 w-4 text-gray-500 dark:text-muted-foreground transition-transform" />
          ) : (
            <ChevronRight className="h-4 w-4 text-gray-500 dark:text-muted-foreground transition-transform" />
          )}
          <span className="font-semibold text-sm sm:text-base text-foreground">
            Audience Insights
          </span>
        </div>

        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="hidden sm:inline">Uganda demographics & device reach</span>
          <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-sky-50 dark:bg-sky-950/50 text-sky-600 dark:text-sky-400">
            Real-time
          </span>
        </div>
      </button>

      {/* Expanded Content */}
      <AnimatePresence initial={false}>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="border-t border-gray-100 dark:border-border/60"
          >
            <div className="p-4 sm:p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Column 1: Top Uganda Geographies */}
              <div className="space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    <MapPin className="h-3.5 w-3.5 text-sky-500" />
                    <span>Top Regions & Districts</span>
                  </div>
                  <span className="text-xs text-muted-foreground">Share %</span>
                </div>

                <div className="space-y-2.5">
                  {displayDistricts.slice(0, 5).map((district, idx) => {
                    const pct = Math.round((district.value / totalDistVal) * 100);
                    return (
                      <div key={idx} className="space-y-1">
                        <div className="flex items-center justify-between text-xs font-medium">
                          <span className="truncate text-foreground max-w-[180px]">
                            {district.name}
                          </span>
                          <span className="text-muted-foreground">{pct}%</span>
                        </div>
                        <Progress value={pct} className="h-1.5" />
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Column 2: Device & Platform Breakdown */}
              <div className="space-y-3.5">
                <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  <Smartphone className="h-3.5 w-3.5 text-emerald-500" />
                  <span>Device & OS Distribution</span>
                </div>

                <div className="space-y-3">
                  <div className="p-3 rounded-xl bg-gray-50/80 dark:bg-muted/40 border border-gray-100 dark:border-border/50 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold text-xs">
                        AND
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-foreground">Android Devices</div>
                        <div className="text-[11px] text-muted-foreground">EarlyMarket App & Mobile Web</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold text-foreground">64%</div>
                      <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">Primary</div>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-gray-50/80 dark:bg-muted/40 border border-gray-100 dark:border-border/50 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold text-xs">
                        <Globe className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-foreground">Desktop & Laptop Web</div>
                        <div className="text-[11px] text-muted-foreground">Chrome, Edge, Safari</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold text-foreground">28%</div>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-gray-50/80 dark:bg-muted/40 border border-gray-100 dark:border-border/50 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold text-xs">
                        <Apple className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-foreground">iOS / iPhone</div>
                        <div className="text-[11px] text-muted-foreground">Safari & Webkit</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold text-foreground">8%</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Column 3: Peak Buying & Engagement Windows */}
              <div className="space-y-3.5">
                <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  <Clock className="h-3.5 w-3.5 text-amber-500" />
                  <span>Activity & Conversion Timing</span>
                </div>

                <div className="space-y-2.5">
                  <div className="p-3 rounded-xl border border-gray-100 dark:border-border/60 space-y-1">
                    <div className="text-xs font-medium text-muted-foreground">Peak Browsing Window</div>
                    <div className="text-sm font-bold text-foreground flex items-center justify-between">
                      <span>{peakHour}</span>
                      <span className="text-xs text-amber-600 dark:text-amber-400 font-normal">High intent</span>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl border border-gray-100 dark:border-border/60 space-y-1">
                    <div className="text-xs font-medium text-muted-foreground">Top Discovery Channel</div>
                    <div className="text-sm font-bold text-foreground flex items-center justify-between">
                      <span>Marketplace Home Feed & Search</span>
                      <span className="text-xs text-sky-600 dark:text-sky-400 font-normal">78%</span>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl border border-gray-100 dark:border-border/60 space-y-1">
                    <div className="text-xs font-medium text-muted-foreground">Buyer Inquiries Rate</div>
                    <div className="text-sm font-bold text-foreground flex items-center justify-between">
                      <span>1 Message per 24 Clicks</span>
                      <span className="text-xs text-emerald-600 dark:text-emerald-400 font-normal">+18% avg</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AudienceInsightsPanel;
