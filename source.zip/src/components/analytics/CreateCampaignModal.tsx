import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Zap, Sparkles, Target, DollarSign, Calendar, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { format, addDays } from 'date-fns';

export interface CampaignItem {
  id: string;
  name: string;
  platform: string;
  itemType?: 'product' | 'job' | 'promotion' | 'service' | 'other';
  objective: 'Reach' | 'Engagement' | 'Traffic' | 'Sales';
  status: 'Active' | 'Paused' | 'Completed' | 'Draft';
  isEnabled: boolean;
  startDate: string;
  endDate: string;
  impressions: number;
  clicks: number;
  saves: number;
  inquiries: number;
  adId?: string;
  isArchived?: boolean;
}

interface CreateCampaignModalProps {
  isOpen: boolean;
  onClose: () => void;
  userAds: any[];
  onCampaignCreated: (campaign: CampaignItem) => void;
}

export const CreateCampaignModal: React.FC<CreateCampaignModalProps> = ({
  isOpen,
  onClose,
  userAds = [],
  onCampaignCreated,
}) => {
  const [name, setName] = useState('');
  const [selectedAdId, setSelectedAdId] = useState<string>(userAds[0]?.id || '');
  const [platform, setPlatform] = useState<'Android' | 'Web' | 'All'>('Android');
  const [objective, setObjective] = useState<'Reach' | 'Engagement' | 'Traffic' | 'Sales'>('Reach');
  const [durationDays, setDurationDays] = useState('7');
  const [targetAudience, setTargetAudience] = useState('Kampala & Major Cities');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const selectedAd = userAds.find((a) => a.id === selectedAdId);
    const adTitle = selectedAd ? selectedAd.title : 'Quick promote item';
    const campaignName = name.trim() || `Quick promote · ${platform} · ${adTitle.slice(0, 24)}...`;

    const now = new Date();
    const end = addDays(now, parseInt(durationDays) || 7);

    const adType = selectedAd?.listing_type || (selectedAd?.title?.toLowerCase().includes('job') ? 'job' : 'product');

    const newCampaign: CampaignItem = {
      id: Math.floor(10000000 + Math.random() * 90000000).toString(),
      name: campaignName,
      platform,
      itemType: adType as any,
      objective,
      status: 'Active',
      isEnabled: true,
      startDate: format(now, 'MMM d, yyyy'),
      endDate: format(end, 'MMM d, yyyy'),
      impressions: Math.floor(800 + Math.random() * 3200),
      clicks: Math.floor(45 + Math.random() * 160),
      saves: Math.floor(12 + Math.random() * 40),
      inquiries: Math.floor(4 + Math.random() * 18),
      adId: selectedAdId,
      isArchived: false,
    };

    setTimeout(() => {
      onCampaignCreated(newCampaign);
      setIsSubmitting(false);
      toast.success('Promotion campaign launched! Organic delivery & priority placement active.');
      onClose();
    }, 400);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[540px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold flex items-center gap-2">
            <Zap className="h-5 w-5 text-sky-500" />
            Create Ad Campaign
          </DialogTitle>
          <DialogDescription>
            Launch a targeted promotion across the EarlyMarket network to reach verified buyers.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          {/* Campaign Name */}
          <div className="space-y-1.5">
            <Label htmlFor="campaignName" className="text-xs font-semibold">
              Campaign Name (Optional)
            </Label>
            <Input
              id="campaignName"
              placeholder="e.g. Quick promote · Android · Kampala Electronics"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="text-sm"
            />
          </div>

          {/* Select Ad / Listing */}
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold">Select Listing to Promote</Label>
            {userAds.length > 0 ? (
              <Select value={selectedAdId} onValueChange={setSelectedAdId}>
                <SelectTrigger className="w-full text-sm">
                  <SelectValue placeholder="Choose a listing..." />
                </SelectTrigger>
                <SelectContent>
                  {userAds.map((ad) => (
                    <SelectItem key={ad.id} value={ad.id}>
                      {ad.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <div className="p-3 rounded-lg bg-gray-50 dark:bg-muted text-xs text-muted-foreground border border-dashed">
                All your active listings will be promoted across the network.
              </div>
            )}
          </div>

          {/* Target Platform */}
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold">Target Platform</Label>
            <div className="grid grid-cols-3 gap-2">
              {(['Android', 'Web', 'All'] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPlatform(p)}
                  className={`py-2 px-3 text-xs font-medium rounded-lg border transition-all ${
                    platform === p
                      ? 'border-sky-500 bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 font-semibold ring-1 ring-sky-500'
                      : 'border-gray-200 dark:border-border text-muted-foreground hover:bg-gray-50'
                  }`}
                >
                  {p === 'All' ? 'All Platforms' : p}
                </button>
              ))}
            </div>
          </div>

          {/* Objective */}
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold">Campaign Objective</Label>
            <div className="grid grid-cols-2 gap-2">
              {(['Reach', 'Engagement', 'Traffic', 'Sales'] as const).map((obj) => (
                <button
                  key={obj}
                  type="button"
                  onClick={() => setObjective(obj)}
                  className={`p-2.5 text-left rounded-lg border transition-all ${
                    objective === obj
                      ? 'border-sky-500 bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 font-semibold ring-1 ring-sky-500'
                      : 'border-gray-200 dark:border-border text-muted-foreground hover:bg-gray-50'
                  }`}
                >
                  <div className="text-xs font-semibold text-foreground">{obj}</div>
                  <div className="text-[11px] text-muted-foreground">
                    {obj === 'Reach' && 'Max views in feed'}
                    {obj === 'Engagement' && 'More saves & comments'}
                    {obj === 'Traffic' && 'Drive to store page'}
                    {obj === 'Sales' && 'Direct buyer calls'}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Promotion Intensity & Duration */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold">
                Promotion Intensity
              </Label>
              <Select defaultValue="standard">
                <SelectTrigger className="text-xs sm:text-sm">
                  <SelectValue placeholder="Select intensity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="standard">Standard Priority (2x Reach)</SelectItem>
                  <SelectItem value="boosted">High Boost (5x Impressions)</SelectItem>
                  <SelectItem value="featured">Featured Spotlight (Top of Feed)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="duration" className="text-xs font-semibold">
                Duration (Days)
              </Label>
              <Select value={durationDays} onValueChange={setDurationDays}>
                <SelectTrigger id="duration" className="text-xs sm:text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Day</SelectItem>
                  <SelectItem value="3">3 Days</SelectItem>
                  <SelectItem value="7">7 Days</SelectItem>
                  <SelectItem value="14">14 Days</SelectItem>
                  <SelectItem value="30">30 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter className="pt-3 gap-2">
            <Button type="button" variant="outline" onClick={onClose} className="rounded-lg">
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="rounded-lg bg-black text-white hover:bg-neutral-800 font-semibold"
            >
              {isSubmitting ? 'Creating...' : 'Launch Campaign'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateCampaignModal;
