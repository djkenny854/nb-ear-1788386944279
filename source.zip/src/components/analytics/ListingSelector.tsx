import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Package, Briefcase, Megaphone, Calendar, FileText, 
  ChevronDown, Eye, Bookmark, MessageCircle, TrendingUp,
  Search, X, Check
} from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';

interface ListingSelectorProps {
  sellerId: string;
  selectedListing: any | null;
  onSelectListing: (listing: any | null) => void;
}

type ListingType = 'all' | 'product' | 'jobs' | 'promotions' | 'event' | 'services' | 'physical_products';

const listingTypeConfig: Record<string, { icon: any; label: string; color: string }> = {
  all: { icon: Package, label: 'All Listings', color: 'text-foreground' },
  product: { icon: Package, label: 'Products', color: 'text-blue-500' },
  physical_products: { icon: Package, label: 'Products', color: 'text-blue-500' },
  jobs: { icon: Briefcase, label: 'Jobs', color: 'text-emerald-500' },
  promotions: { icon: Megaphone, label: 'Promotions', color: 'text-amber-500' },
  event: { icon: Calendar, label: 'Events', color: 'text-purple-500' },
  services: { icon: FileText, label: 'Services', color: 'text-pink-500' },
};

export default function ListingSelector({ sellerId, selectedListing, onSelectListing }: ListingSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeType, setActiveType] = useState<ListingType>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch all listings (ads, jobs, events, promotions, services)
  const { data: listings, isLoading } = useQuery({
    queryKey: ['seller-all-listings', sellerId],
    queryFn: async () => {
      const allListings: any[] = [];

      // Fetch ads (products)
      const { data: ads } = await supabase
        .from('ads')
        .select('id, title, view_count, save_count, images, listing_type, created_at')
        .eq('seller_id', sellerId)
        .order('created_at', { ascending: false });
      
      if (ads) {
        // For jobs, fetch job_details to get apply_method
        const jobAds = ads.filter(ad => ad.listing_type === 'jobs');
        const jobIds = jobAds.map(ad => ad.id);
        
        let jobDetailsMap: Record<string, any> = {};
        if (jobIds.length > 0) {
          const { data: jobDetails } = await supabase
            .from('job_details')
            .select('ad_id, apply_method, use_earlymarket_system')
            .in('ad_id', jobIds);
          
          if (jobDetails) {
            jobDetails.forEach(jd => {
              jobDetailsMap[jd.ad_id] = jd;
            });
          }
        }

        ads.forEach(ad => {
          // Normalize the listing type to match DB values
          let type = ad.listing_type || 'physical_products';
          const jobDetail = jobDetailsMap[ad.id];
          
          allListings.push({
            ...ad,
            type: type === 'jobs' ? 'job' : type,
            image: ad.images?.[0],
            applyMethod: jobDetail?.apply_method || (jobDetail?.use_earlymarket_system ? 'earlymarket' : null)
          });
        });
      }

      // Fetch events
      const { data: events } = await supabase
        .from('events')
        .select('id, title, view_count, cover_image, created_at')
        .eq('seller_id', sellerId)
        .order('created_at', { ascending: false });
      
      if (events) {
        events.forEach(event => {
          allListings.push({
            ...event,
            type: 'event',
            image: event.cover_image,
            save_count: 0
          });
        });
      }

      // Fetch posts
      const { data: posts } = await supabase
        .from('posts')
        .select('id, title, view_count, like_count, images, created_at')
        .eq('seller_id', sellerId)
        .order('created_at', { ascending: false });
      
      if (posts) {
        posts.forEach(post => {
          allListings.push({
            ...post,
            type: 'post',
            image: post.images?.[0],
            save_count: post.like_count || 0
          });
        });
      }

      return allListings;
    },
    enabled: !!sellerId,
  });

  const filteredListings = listings?.filter(listing => {
    // Handle type matching with both singular and plural forms
    let matchesType = activeType === 'all';
    if (!matchesType) {
      const typeMap: Record<string, string[]> = {
        'physical_products': ['physical_products', 'product'],
        'jobs': ['jobs', 'job'],
        'promotions': ['promotions', 'promotion'],
        'services': ['services', 'service'],
        'event': ['event', 'events'],
      };
      matchesType = typeMap[activeType]?.includes(listing.type) || listing.type === activeType;
    }
    const matchesSearch = listing.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  }) || [];

  const typeButtons: ListingType[] = ['all', 'physical_products', 'jobs', 'promotions', 'event', 'services'];

  return (
    <div className="relative">
      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-3 px-4 py-2.5 rounded-xl bg-background/60 hover:bg-background/80 border border-border/30 transition-all group"
      >
        {selectedListing ? (
          <>
            {selectedListing.image ? (
              <img 
                src={selectedListing.image} 
                alt="" 
                className="w-8 h-8 rounded-lg object-cover"
              />
            ) : (
              <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center">
                <Package className="w-4 h-4 text-muted-foreground" />
              </div>
            )}
            <div className="text-left">
              <p className="text-sm font-medium truncate max-w-[150px]">{selectedListing.title}</p>
              <p className="text-xs text-muted-foreground capitalize">{selectedListing.type}</p>
            </div>
          </>
        ) : (
          <>
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Package className="w-4 h-4 text-primary" />
            </div>
            <div className="text-left">
              <p className="text-sm font-medium">All Listings</p>
              <p className="text-xs text-muted-foreground">Overview analytics</p>
            </div>
          </>
        )}
        <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Dropdown */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <div 
              className="fixed inset-0 z-40"
              onClick={() => setIsOpen(false)}
            />
            
            {/* Dropdown Content */}
            <motion.div
              initial={{ opacity: 0, y: -10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              className="absolute top-full right-0 mt-2 w-[min(360px,calc(100vw-2rem))] bg-card/95 backdrop-blur-xl rounded-2xl border border-border/50 shadow-2xl z-50 overflow-hidden"
            >
              {/* Search */}
              <div className="p-3 border-b border-border/30">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search listings..."
                    className="w-full pl-9 pr-4 py-2 text-sm bg-background/60 rounded-lg border border-border/30 focus:outline-none focus:ring-2 focus:ring-primary/30"
                  />
                  {searchQuery && (
                    <button 
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2"
                    >
                      <X className="w-4 h-4 text-muted-foreground" />
                    </button>
                  )}
                </div>
              </div>

              {/* Type Filters */}
              <div className="p-2 border-b border-border/30 flex gap-1 overflow-x-auto">
                {typeButtons.map((type) => {
                  const config = listingTypeConfig[type];
                  const Icon = config.icon;
                  return (
                    <button
                      key={type}
                      onClick={() => setActiveType(type)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                        activeType === type 
                          ? 'bg-primary text-primary-foreground' 
                          : 'bg-muted/50 hover:bg-muted text-muted-foreground'
                      }`}
                    >
                      <Icon className="w-3 h-3" />
                      {config.label}
                    </button>
                  );
                })}
              </div>

              {/* All Listings Option */}
              <button
                onClick={() => {
                  onSelectListing(null);
                  setIsOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-muted/50 transition-colors border-b border-border/20 ${
                  !selectedListing ? 'bg-primary/5' : ''
                }`}
              >
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm font-medium">All Listings Overview</p>
                  <p className="text-xs text-muted-foreground">Combined analytics for all your content</p>
                </div>
                {!selectedListing && (
                  <Check className="w-4 h-4 text-primary" />
                )}
              </button>

              {/* Listings */}
              <ScrollArea className="max-h-[300px]">
                {isLoading ? (
                  <div className="p-4 space-y-3">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="flex items-center gap-3">
                        <Skeleton className="w-10 h-10 rounded-lg" />
                        <div className="flex-1">
                          <Skeleton className="h-4 w-32 mb-1" />
                          <Skeleton className="h-3 w-20" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : filteredListings.length === 0 ? (
                  <div className="p-8 text-center">
                    <Package className="w-10 h-10 text-muted-foreground mx-auto mb-2 opacity-50" />
                    <p className="text-sm text-muted-foreground">No listings found</p>
                  </div>
                ) : (
                  <div className="p-2">
                    {filteredListings.map((listing) => {
                      const config = listingTypeConfig[listing.type as ListingType] || listingTypeConfig.product;
                      const Icon = config.icon;
                      const isSelected = selectedListing?.id === listing.id;
                      
                      return (
                        <button
                          key={`${listing.type}-${listing.id}`}
                          onClick={() => {
                            onSelectListing(listing);
                            setIsOpen(false);
                          }}
                          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-muted/50 transition-colors ${
                            isSelected ? 'bg-primary/5' : ''
                          }`}
                        >
                          {listing.image ? (
                            <img 
                              src={listing.image} 
                              alt="" 
                              className="w-10 h-10 rounded-lg object-cover"
                            />
                          ) : (
                            <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                              <Icon className={`w-5 h-5 ${config.color}`} />
                            </div>
                          )}
                          <div className="flex-1 min-w-0 text-left">
                            <p className="text-sm font-medium truncate">{listing.title}</p>
                            <div className="flex items-center gap-3 mt-0.5">
                              <Badge variant="secondary" className="text-[10px] capitalize px-1.5 py-0">
                                {listing.type}
                              </Badge>
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <Eye className="w-3 h-3" />
                                {listing.view_count || 0}
                              </span>
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <Bookmark className="w-3 h-3" />
                                {listing.save_count || 0}
                              </span>
                            </div>
                          </div>
                          {isSelected && (
                            <Check className="w-4 h-4 text-primary shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}
              </ScrollArea>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
