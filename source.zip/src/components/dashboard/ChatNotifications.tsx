
import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { MessageCircle, Clock, Eye, User } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface ChatNotification {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  productTitle: string;
  productImage?: string;
  lastMessage: string;
  timestamp: Date;
  isRead: boolean;
  isOnline: boolean;
  adId?: string;
}

interface ChatNotificationsProps {
  onChatOpen: (sellerId: string, adId?: string) => void;
}

const ChatNotifications: React.FC<ChatNotificationsProps> = ({ onChatOpen }) => {
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [currentSellerProfileId, setCurrentSellerProfileId] = useState<string | null>(null);

  useEffect(() => {
    const getCurrentUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setCurrentUserId(user.id);
        
        // Get seller profile ID if user is a seller
        const { data: sellerProfile } = await supabase
          .from('seller_profiles')
          .select('id')
          .eq('user_id', user.id)
          .single();
        
        if (sellerProfile) {
          setCurrentSellerProfileId(sellerProfile.id);
        }
      }
    };
    getCurrentUser();
  }, []);

  // Fetch chat notifications for seller
  const { data: chatNotifications, isLoading } = useQuery({
    queryKey: ['chat-notifications', currentSellerProfileId],
    queryFn: async () => {
      if (!currentSellerProfileId) return [];
      
      // Get messages sent TO this seller
      const { data: messagesData, error: messagesError } = await supabase
        .from('messages')
        .select(`
          id,
          sender_id,
          content,
          created_at,
          is_read,
          ad_id
        `)
        .eq('recipient_id', currentSellerProfileId)
        .order('created_at', { ascending: false })
        .limit(50);

      if (messagesError) {
        console.error('Error fetching messages:', messagesError);
        throw messagesError;
      }

      if (!messagesData || messagesData.length === 0) return [];

      // Get unique sender IDs and ad IDs
      const senderIds = [...new Set(messagesData.map(msg => msg.sender_id))];
      const adIds = [...new Set(messagesData.map(msg => msg.ad_id).filter(Boolean))];

      // Batch fetch all sender profiles in ONE query
      const { data: sellerProfiles } = await supabase
        .from('seller_profiles')
        .select('user_id, business_name, business_logo_url')
        .in('user_id', senderIds);

      const senderProfiles = senderIds.map(senderId => {
        const profile = sellerProfiles?.find(p => p.user_id === senderId);
        return {
          id: senderId,
          name: profile?.business_name || 'User',
          avatar: profile?.business_logo_url || null,
        };
      });

      // Fetch ads data
      let adsData: any[] = [];
      if (adIds.length > 0) {
        const { data: ads, error: adsError } = await supabase
          .from('ads')
          .select('id, title, images')
          .in('id', adIds);

        if (!adsError && ads) {
          adsData = ads;
        }
      }

      // Transform data into notifications
      const notifications: ChatNotification[] = messagesData.map(msg => {
        const senderProfile = senderProfiles.find(profile => profile.id === msg.sender_id);
        const adData = adsData.find(ad => ad.id === msg.ad_id);

        return {
          id: msg.id,
          senderId: msg.sender_id,
          senderName: senderProfile?.name || 'Unknown User',
          senderAvatar: senderProfile?.avatar,
          productTitle: adData?.title || 'General Inquiry',
          productImage: adData?.images?.[0],
          lastMessage: msg.content,
          timestamp: new Date(msg.created_at),
          isRead: msg.is_read,
          isOnline: false, // Will be updated by real-time check
          adId: msg.ad_id,
        };
      });

      // Group by sender and ad, get latest message
      const grouped = notifications.reduce((acc, notification) => {
        const key = `${notification.senderId}-${notification.adId || 'no-ad'}`;
        if (!acc[key] || notification.timestamp > acc[key].timestamp) {
          acc[key] = notification;
        }
        return acc;
      }, {} as Record<string, ChatNotification>);

      return Object.values(grouped).slice(0, 10); // Show latest 10 conversations
    },
    enabled: !!currentSellerProfileId,
    staleTime: 1000 * 60 * 2, // Cache for 2 minutes instead of polling every 5s
  });

  const handleChatClick = (notification: ChatNotification) => {
    // Mark messages as read
    if (!notification.isRead) {
      supabase
        .from('messages')
        .update({ is_read: true })
        .eq('sender_id', notification.senderId)
        .eq('recipient_id', currentSellerProfileId)
        .then(() => {
          // Refresh the notifications after marking as read
          // The query will automatically refresh due to the refetch interval
        });
    }

    // Open chat - pass the sender's user ID and ad ID
    onChatOpen(notification.senderId, notification.adId);
  };

  const unreadCount = chatNotifications?.filter(n => !n.isRead).length || 0;

  if (!currentSellerProfileId) {
    return (
      <Card className="w-full">
        <CardContent className="p-6 text-center">
          <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50 text-gray-400" />
          <p className="text-gray-500">Create a seller profile to receive messages</p>
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded"></div>
                    <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold">Recent Messages</h3>
            {unreadCount > 0 && (
              <Badge variant="destructive" className="rounded-full">
                {unreadCount}
              </Badge>
            )}
          </div>
        </div>

        {!chatNotifications || chatNotifications.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No messages yet</p>
            <p className="text-sm">Customer messages will appear here</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {chatNotifications.map((notification) => (
              <div
                key={notification.id}
                className={`p-4 rounded-lg border cursor-pointer transition-all hover:shadow-md ${
                  notification.isRead ? 'bg-white' : 'bg-blue-50 border-blue-200'
                }`}
                onClick={() => handleChatClick(notification)}
              >
                <div className="flex items-start gap-3">
                  {/* Avatar with online status */}
                  <div className="relative">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={notification.senderAvatar} />
                      <AvatarFallback>
                        {notification.senderName.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div
                      className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white ${
                        notification.isOnline ? 'bg-green-500' : 'bg-gray-400'
                      }`}
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="font-medium text-gray-900 truncate text-sm">
                        {notification.senderName}
                      </p>
                      <span className="text-xs text-gray-500">
                        {formatDistanceToNow(notification.timestamp, { addSuffix: true })}
                      </span>
                    </div>

                    {/* Product context */}
                    <div className="flex items-center gap-2 mb-1">
                      {notification.productImage ? (
                        <img
                          src={notification.productImage}
                          alt={notification.productTitle}
                          className="w-4 h-4 rounded object-cover"
                        />
                      ) : (
                        <div className="w-4 h-4 bg-gray-200 rounded flex items-center justify-center">
                          <User className="w-2 h-2 text-gray-500" />
                        </div>
                      )}
                      <span className="text-xs text-gray-600 truncate">
                        {notification.productTitle}
                      </span>
                    </div>

                    <p className="text-sm text-gray-700 truncate">
                      {notification.lastMessage}
                    </p>
                  </div>

                  {!notification.isRead && (
                    <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0" />
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ChatNotifications;
