import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Heart, ChevronLeft, ChevronRight, X, ArrowUp, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { useIsMobile } from '@/hooks/use-mobile';
import { VisuallyHidden } from '@radix-ui/react-visually-hidden';

interface Comment {
  id: string;
  user_id: string;
  content: string;
  like_count: number;
  reply_count: number;
  created_at: string;
  parent_comment_id: string | null;
  user?: {
    name: string;
    avatar?: string;
  };
  replies?: Comment[];
  is_liked?: boolean;
}

interface CommentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contentType: 'ad' | 'post' | 'event' | 'announcement' | 'promotion';
  contentId: string;
  images?: string[];
  author?: {
    name: string;
    avatar?: string;
    is_verified?: boolean;
  };
  caption?: string;
  sellerId?: string;
  sellerUserId?: string;
  allowComments?: boolean;
}

export const CommentModal: React.FC<CommentModalProps> = ({
  open,
  onOpenChange,
  contentType,
  contentId,
  allowComments = true,
  images = [],
  author = { name: 'User' },
  caption = '',
  sellerId,
  sellerUserId
}) => {
  const { user } = useAuth();
  const isMobile = useIsMobile();
  // Lock modal type when it opens to prevent remount from keyboard resize
  const lockedMobileRef = useRef<boolean | undefined>(undefined);
  useEffect(() => {
    if (open && isMobile !== undefined) {
      lockedMobileRef.current = isMobile;
    }
    if (!open) {
      lockedMobileRef.current = undefined;
    }
  }, [open, isMobile]);
  const useMobileLayout = lockedMobileRef.current ?? isMobile;

  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [newComment, setNewComment] = useState('');
  const [replyingTo, setReplyingTo] = useState<{ id: string; name: string } | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds}s`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)}d`;
    return `${Math.floor(diffInSeconds / 604800)}w`;
  };

  // Fetch comments
  useEffect(() => {
    if (!open || !contentId) return;
    
    const fetchComments = async () => {
      setLoading(true);
      try {
        // Fetch all comments (parents + replies) in one query
        const { data, error } = await supabase
          .from('comments')
          .select('*')
          .eq('content_type', contentType)
          .eq('content_id', contentId)
          .order('created_at', { ascending: true });

        if (error) throw error;

        // Batch fetch all user profiles - check seller_profiles first, then auth metadata
        const userIds = [...new Set((data || []).map(c => c.user_id))];
        let usersMap: Record<string, { name: string; avatar?: string }> = {};
        
        if (userIds.length > 0) {
          // First get seller profiles
          const { data: sellers } = await supabase
            .from('seller_profiles')
            .select('user_id, business_name, business_logo_url')
            .in('user_id', userIds);
          
          (sellers || []).forEach(s => {
            usersMap[s.user_id] = { name: s.business_name || 'User', avatar: s.business_logo_url || undefined };
          });

          // For users without seller profiles, fetch from auth metadata via RPC
          const missingUserIds = userIds.filter(id => !usersMap[id]);
          if (missingUserIds.length > 0) {
            const { data: authProfiles } = await supabase.rpc('get_public_user_profiles', {
              p_user_ids: missingUserIds,
            });
            (authProfiles || []).forEach((p: any) => {
              usersMap[p.user_id] = { name: p.display_name || 'User', avatar: p.avatar_url || undefined };
            });
          }
        }

        // Build comment tree
        const allComments = (data || []).map(c => ({
          ...c,
          user: usersMap[c.user_id] || { name: 'User' },
          replies: [] as Comment[],
        }));

        const parentComments = allComments.filter(c => !c.parent_comment_id);
        const replies = allComments.filter(c => c.parent_comment_id);
        
        replies.forEach(reply => {
          const parent = parentComments.find(p => p.id === reply.parent_comment_id);
          if (parent) parent.replies.push(reply);
        });

        setComments(parentComments.reverse());
      } catch (error) {
        console.error('Error fetching comments:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchComments();
  }, [open, contentId, contentType]);

  const handleSubmitComment = async () => {
    if (!newComment.trim() || !user) {
      if (!user) toast.error('Please sign in to comment');
      return;
    }

    setSubmitting(true);
    try {
      const { data, error } = await supabase
        .from('comments')
        .insert({
          user_id: user.id,
          content_type: contentType,
          content_id: contentId,
          content: newComment.trim(),
          parent_comment_id: replyingTo?.id || null
        })
        .select()
        .single();

      if (error) throw error;

      // Fetch commenter's name - check seller profile first, then auth metadata
      const { data: userData } = await supabase
        .from('seller_profiles')
        .select('business_name, business_logo_url')
        .eq('user_id', user.id)
        .single();

      let commenterName = userData?.business_name;
      let commenterAvatar = userData?.business_logo_url;
      if (!commenterName) {
        // Try auth metadata (Google sign-in provides full_name)
        const { data: authProfile } = await supabase.rpc('get_public_user_profiles', {
          p_user_ids: [user.id],
        });
        commenterName = authProfile?.[0]?.display_name || user.email?.split('@')[0] || 'Someone';
        commenterAvatar = commenterAvatar || authProfile?.[0]?.avatar_url;
      }

      // Notify seller if they're not the commenter
      if (sellerUserId && sellerUserId !== user.id) {
        await supabase.from('notifications').insert({
          user_id: sellerUserId,
          title: '💬 New Comment',
          message: `${commenterName} commented: "${newComment.trim().substring(0, 50)}${newComment.length > 50 ? '...' : ''}"`,
          notification_type: 'comment',
          action_url: contentType === 'ad' ? `/ad/${contentId}` : contentType === 'event' ? `/event/${contentId}` : `/post/${contentId}`,
          metadata: {
            content_id: contentId,
            content_type: contentType,
            commenter_id: user.id,
            commenter_name: commenterName
          }
        });
      }

      const newCommentWithUser = {
        ...data,
        user: {
          name: commenterName,
          avatar: commenterAvatar
        },
        replies: []
      };

      if (replyingTo) {
        setComments(comments.map(c => 
          c.id === replyingTo.id 
            ? { ...c, replies: [...(c.replies || []), newCommentWithUser], reply_count: c.reply_count + 1 }
            : c
        ));
      } else {
        setComments([newCommentWithUser, ...comments]);
      }

      setNewComment('');
      setReplyingTo(null);
      toast.success('Comment posted');
    } catch (error) {
      console.error('Error posting comment:', error);
      toast.error('Failed to post comment');
    } finally {
      setSubmitting(false);
    }
  };

  const handleLikeComment = async (commentId: string) => {
    if (!user) {
      toast.error('Please sign in to like');
      return;
    }
  };

  // Render a single comment item - defined as a plain function to avoid re-mount
  const renderCommentItem = (comment: Comment, isReply = false) => (
    <div key={comment.id} className={cn("flex gap-3 py-3", isReply && "ml-10")}>
      <Avatar className="w-9 h-9 flex-shrink-0 ring-2 ring-border/50">
        <AvatarImage src={comment.user?.avatar} />
        <AvatarFallback className="bg-primary/10 text-primary text-xs font-medium">
          {comment.user?.name?.[0]?.toUpperCase() || 'U'}
        </AvatarFallback>
      </Avatar>
      
      <div className="flex-1 min-w-0">
        <div className="bg-muted/50 rounded-2xl px-4 py-2.5">
          <span className="text-sm font-semibold text-foreground">{comment.user?.name}</span>
          <p className="text-sm text-foreground/90 mt-0.5 whitespace-pre-wrap">{comment.content}</p>
        </div>
        
        <div className="flex items-center gap-4 mt-1.5 px-2">
          <span className="text-xs text-muted-foreground">{getTimeAgo(comment.created_at)}</span>
          {comment.like_count > 0 && (
            <button 
              onClick={() => handleLikeComment(comment.id)}
              className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
            >
              <Heart className="w-3 h-3" />
              {comment.like_count}
            </button>
          )}
          <button 
            onClick={() => setReplyingTo({ id: comment.id, name: comment.user?.name || 'User' })}
            className="text-xs text-muted-foreground font-medium hover:text-primary transition-colors"
          >
            Reply
          </button>
        </div>

        {comment.reply_count > 0 && comment.replies && comment.replies.length > 0 && (
          <div className="mt-2">
            {comment.replies.map(reply => renderCommentItem(reply, true))}
          </div>
        )}
      </div>
    </div>
  );

  const renderCommentSkeleton = () => (
    <div className="flex gap-3 py-3">
      <Skeleton className="w-9 h-9 rounded-full flex-shrink-0" />
      <div className="flex-1 space-y-2">
        <Skeleton className="h-16 w-full rounded-2xl" />
        <Skeleton className="h-3 w-24" />
      </div>
    </div>
  );

  const totalCommentCount = comments.reduce((acc, c) => acc + 1 + (c.reply_count || 0), 0);

  // Comment input - inlined to prevent re-mount and keyboard loss
  const commentInputSection = (
    <div className="p-4 border-t border-border bg-background/95 backdrop-blur-sm">
      {replyingTo && (
        <div className="flex items-center gap-2 mb-3 px-1">
          <span className="text-xs text-muted-foreground">
            Replying to <span className="text-primary font-medium">@{replyingTo.name}</span>
          </span>
          <button 
            onClick={() => setReplyingTo(null)} 
            className="hover:bg-muted rounded-full p-1 transition-colors"
          >
            <X className="w-3 h-3 text-muted-foreground" />
          </button>
        </div>
      )}
      <div className="flex items-center gap-3 bg-muted/50 rounded-full px-4 py-2 border border-border/50 focus-within:border-primary/50 focus-within:ring-2 focus-within:ring-primary/20 transition-all">
        <Avatar className="w-7 h-7 flex-shrink-0">
          <AvatarFallback className="bg-primary/10 text-primary text-xs">
            {user?.email?.[0]?.toUpperCase() || 'U'}
          </AvatarFallback>
        </Avatar>
        <input
          type="text"
          placeholder="Write a comment..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSubmitComment()}
          className="flex-1 bg-transparent text-sm placeholder:text-muted-foreground outline-none"
        />
        <button 
          onClick={handleSubmitComment}
          disabled={!newComment.trim() || submitting}
          className={cn(
            "p-2 rounded-full transition-all",
            newComment.trim() 
              ? "bg-primary text-primary-foreground hover:bg-primary/90" 
              : "bg-muted text-muted-foreground cursor-not-allowed"
          )}
        >
          {submitting ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <ArrowUp className="w-4 h-4" />
          )}
        </button>
      </div>
    </div>
  );

  // Comments section - rendered as JSX variable (not a component) to prevent re-mount
  const renderCommentsSection = (inDrawer = false) => (
    <div className={cn("flex flex-col h-full")}>
      {!allowComments ? (
        <div className="flex flex-col items-center justify-center p-8 text-center flex-1">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
            <X className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="font-semibold text-lg mb-2">Comments are turned off</h3>
          <p className="text-sm text-muted-foreground max-w-xs">The creator has disabled comments on this post.</p>
        </div>
      ) : (
        <>
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-border flex-shrink-0">
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10 ring-2 ring-primary/20">
                <AvatarImage src={author.avatar} />
                <AvatarFallback className="bg-primary/10 text-primary">
                  {author.name?.[0]?.toUpperCase() || 'U'}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-semibold text-sm">{author.name}</h3>
                <p className="text-xs text-muted-foreground">{totalCommentCount} comments</p>
              </div>
            </div>
            {!inDrawer && (
              <button 
                onClick={() => onOpenChange(false)}
                className="p-2 hover:bg-muted rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-muted-foreground" />
              </button>
            )}
          </div>

          {/* Caption */}
          {caption && (
            <div className="px-4 py-3 border-b border-border/50 bg-muted/30 flex-shrink-0">
              <p className="text-sm text-foreground/90 line-clamp-3">{caption}</p>
            </div>
          )}

          {/* Scrollable comments */}
          <div className="flex-1 overflow-y-auto min-h-0 px-4">
            {loading ? (
              <div className="space-y-2 py-2">
                {renderCommentSkeleton()}
                {renderCommentSkeleton()}
                {renderCommentSkeleton()}
              </div>
            ) : comments.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mb-4">
                  <span className="text-3xl">💬</span>
                </div>
                <p className="text-foreground font-medium">No comments yet</p>
                <p className="text-muted-foreground text-sm mt-1">Start the conversation</p>
              </div>
            ) : (
              <div className="divide-y divide-border/30">
                {comments.map(comment => renderCommentItem(comment))}
              </div>
            )}
          </div>

          {/* Comment input */}
          {commentInputSection}
        </>
      )}
    </div>
  );

  // Media section for desktop - rendered as JSX to avoid re-mount
  const mediaSection = (
    <div className="relative bg-black w-full md:w-[55%] flex-shrink-0 h-full overflow-hidden min-h-0">
      {images.length > 0 ? (
        <>
          <div className="h-full w-full flex items-center justify-center">
            <img 
              src={images[currentImageIndex]} 
              alt=""
              className="w-full h-full object-contain"
            />
          </div>
          
          {images.length > 1 && (
            <>
              {currentImageIndex > 0 && (
                <button 
                  onClick={() => setCurrentImageIndex(i => i - 1)}
                  className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-background/90 rounded-full flex items-center justify-center hover:bg-background transition-colors shadow-lg z-10"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
              )}
              {currentImageIndex < images.length - 1 && (
                <button 
                  onClick={() => setCurrentImageIndex(i => i + 1)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-background/90 rounded-full flex items-center justify-center hover:bg-background transition-colors shadow-lg z-10"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              )}
              
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
                {images.map((_, idx) => (
                  <button 
                    key={idx}
                    onClick={() => setCurrentImageIndex(idx)}
                    className={cn(
                      "w-2 h-2 rounded-full transition-all",
                      idx === currentImageIndex ? "bg-white scale-125" : "bg-white/50 hover:bg-white/70"
                    )}
                  />
                ))}
              </div>
            </>
          )}
        </>
      ) : (
        <div className="w-full h-full min-h-[300px] flex items-center justify-center bg-gradient-to-br from-primary/20 to-primary/5">
          <Avatar className="w-24 h-24">
            <AvatarImage src={author.avatar} />
            <AvatarFallback className="text-3xl bg-primary/20 text-primary">
              {author.name?.[0]?.toUpperCase() || 'U'}
            </AvatarFallback>
          </Avatar>
        </div>
      )}
    </div>
  );

  // Mobile: Use Drawer
  if (useMobileLayout) {
    return (
      <Drawer open={open} onOpenChange={onOpenChange}>
        <DrawerContent className="h-[85vh] max-h-[85vh]">
          <VisuallyHidden>
            <DrawerTitle>Comments</DrawerTitle>
          </VisuallyHidden>
          {renderCommentsSection(true)}
        </DrawerContent>
      </Drawer>
    );
  }

  // Desktop: Use Dialog
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl w-full h-[85vh] p-0 gap-0 overflow-hidden bg-background border border-border rounded-2xl">
        <VisuallyHidden>
          <DialogTitle>Comments</DialogTitle>
        </VisuallyHidden>
        <div className="flex h-full overflow-hidden">
          {/* Left: Media - independent scroll */}
          {mediaSection}
          
          {/* Right: Comments - independent scroll */}
          <div className="flex-1 flex flex-col min-w-0 min-h-0 h-full border-l border-border overflow-hidden">
            {renderCommentsSection(false)}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};