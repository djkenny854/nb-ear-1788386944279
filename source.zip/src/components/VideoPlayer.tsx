import React, { useRef, useEffect, useState } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';
import SmartVideo from '@/components/media/SmartVideo';
import { videoCdnUrl } from '@/utils/cdnUrl';
import { attachDecodeWatchdog } from '@/utils/videoDecodeGuard';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface VideoPlayerProps {
  src: string;
  poster?: string;
  className?: string;
  autoPlay?: boolean;
  muted?: boolean;
  loop?: boolean;
  controls?: boolean;
  scrollContainer?: HTMLElement | null;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ 
  src, 
  poster,
  className = '', 
  autoPlay = false,
  muted = true,
  loop = true,
  controls = true,
  scrollContainer = null
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(muted);
  const [showControls, setShowControls] = useState(false);
  const [isInView, setIsInView] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState('0:00');
  const [duration, setDuration] = useState('0:00');
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [isVideoReady, setIsVideoReady] = useState(false);
  const [decodeFailed, setDecodeFailed] = useState(false);

  // Some legacy uploads are HEVC/AV1 and decode to a black rectangle while the
  // progress bar keeps moving. Detect that and show the poster instead.
  useEffect(() => {
    return attachDecodeWatchdog(videoRef.current, () => setDecodeFailed(true));
  }, [src]);

  useEffect(() => { setDecodeFailed(false); }, [src]);

  // Intersection Observer for autoplay on scroll
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !autoPlay) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsInView(entry.isIntersecting);
        
        if (entry.isIntersecting && entry.intersectionRatio >= 0.5) {
          // Play when 50% visible
          video.play()
            .then(() => setIsPlaying(true))
            .catch(err => console.log('Autoplay prevented:', err));
        } else if (!entry.isIntersecting || entry.intersectionRatio < 0.3) {
          // Pause when less than 30% visible
          video.pause();
          setIsPlaying(false);
        }
      },
      { 
        threshold: [0.3, 0.5, 0.7],
        root: scrollContainer || null
      }
    );

    observer.observe(video);

    return () => observer.disconnect();
  }, [autoPlay, scrollContainer]);

  // Format time helper
  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Update progress bar and time
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const updateProgress = () => {
      const progress = (video.currentTime / video.duration) * 100;
      setProgress(isNaN(progress) ? 0 : progress);
      setCurrentTime(formatTime(video.currentTime));
    };

    const updateDuration = () => {
      setDuration(formatTime(video.duration));
    };

    video.addEventListener('timeupdate', updateProgress);
    video.addEventListener('loadedmetadata', updateDuration);
    video.addEventListener('durationchange', updateDuration);
    
    return () => {
      video.removeEventListener('timeupdate', updateProgress);
      video.removeEventListener('loadedmetadata', updateDuration);
      video.removeEventListener('durationchange', updateDuration);
    };
  }, []);

  const togglePlay = async () => {
    const video = videoRef.current;
    if (!video) return;

    try {
      if (isPlaying) {
        video.pause();
        setIsPlaying(false);
      } else {
        await video.play();
        setIsPlaying(true);
      }
    } catch (err) {
      console.error('Error toggling play:', err);
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;

    video.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleFullscreen = () => {
    const container = containerRef.current;
    if (!container) return;

    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      container.requestFullscreen();
    }
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const video = videoRef.current;
    if (!video) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    video.currentTime = pos * video.duration;
  };

  const handleSpeedChange = (speed: number) => {
    const video = videoRef.current;
    if (!video) return;
    video.playbackRate = speed;
    setPlaybackSpeed(speed);
  };

  const speedOptions = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

  // Sanitize video URL to fix double https:// issue and handle Supabase storage URLs
  const sanitizedSrc = React.useMemo(() => {
    if (!src) return '';
    let clean = videoCdnUrl(src) || src;
    
    // Keep removing duplicate https:// until there's only one
    while (clean.match(/^https:\/\/https:\/\//)) {
      clean = clean.replace(/^https:\/\/https:\/\//, 'https://');
    }
    
    // If it's a Supabase storage URL, ensure it's properly formatted
    if (clean.includes('.supabase.co/storage/v1/object/public/')) {
      // Already a public URL, use as is
      return clean;
    }
    
    return clean;
  }, [src]);

  return (
    <div 
      ref={containerRef}
      className={cn(
        "relative group overflow-hidden rounded-lg bg-black isolate",
        className
      )}
      onMouseEnter={() => setShowControls(true)}
      onMouseLeave={() => setShowControls(false)}
    >
      {/* Black placeholder with play icon until video loads */}
      {!isVideoReady && (
        <div className="absolute inset-0 bg-black flex items-center justify-center z-20">
          <div className="flex flex-col items-center gap-2">
            <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center">
              <Play className="w-8 h-8 text-white ml-1" fill="white" />
            </div>
            <div className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
          </div>
        </div>
      )}

      <SmartVideo
        ref={videoRef}
        src={sanitizedSrc}
        poster={poster}
        loop={loop}
        muted={isMuted}
        playsInline
        controlsList="nodownload nofullscreen noremoteplayback noplaybackrate"
        disablePictureInPicture
        onContextMenu={(e) => e.preventDefault()}
        className={cn("w-full h-full object-cover select-none bg-black", !isVideoReady && "opacity-0 absolute")}
        style={{ WebkitUserSelect: 'none', userSelect: 'none' }}
        onClick={togglePlay}
        onLoadedData={() => setIsVideoReady(true)}
        onReady={() => setIsVideoReady(true)}
        onError={() => setIsVideoReady(true)}
        data-protected="true"
      />

      {decodeFailed && poster && (
        <div className="absolute inset-0 z-30 bg-black">
          <img src={poster} alt="" className="absolute inset-0 w-full h-full object-cover" />
        </div>
      )}

      {/* Play/Pause Overlay */}
      <div
          className={cn(
            "absolute inset-0 flex items-center justify-center transition-opacity duration-200 pointer-events-none",
            showControls || !isPlaying ? "opacity-100" : "opacity-0"
          )}
        >
          {!isPlaying && (
            <div 
              className="w-16 h-16 rounded-full bg-black/60 backdrop-blur-sm flex items-center justify-center pointer-events-auto cursor-pointer hover:bg-black/70 transition-colors" 
              onClick={togglePlay}
            >
              <Play className="w-8 h-8 text-white ml-1" fill="white" />
            </div>
          )}
        </div>

      {/* Controls */}
      {controls && (
        <div 
          className={cn(
            "absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent px-3 py-2 transition-all duration-200",
            showControls ? "translate-y-0 opacity-100" : "translate-y-full opacity-0"
          )}
        >
          {/* Progress Bar */}
          <div 
            className="w-full h-1 bg-white/20 rounded-full cursor-pointer mb-2 group/progress hover:h-1.5 transition-all"
            onClick={handleProgressClick}
          >
            <div 
              className="h-full bg-[#1d9bf0] rounded-full relative transition-all"
              style={{ width: `${progress}%` }}
            >
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-[#1d9bf0] rounded-full shadow-lg opacity-0 group-hover/progress:opacity-100 transition-opacity" />
            </div>
          </div>

          {/* Control Buttons */}
          <div className="flex items-center justify-between text-white text-sm">
            <div className="flex items-center gap-1">
              <button
                onClick={togglePlay}
                className="w-8 h-8 flex items-center justify-center hover:bg-white/10 rounded-full transition-colors"
                aria-label={isPlaying ? 'Pause' : 'Play'}
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
              </button>

              <button
                onClick={toggleMute}
                className="w-8 h-8 flex items-center justify-center hover:bg-white/10 rounded-full transition-colors"
                aria-label={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>

              <span className="text-xs font-medium ml-1">
                {currentTime} / {duration}
              </span>
            </div>

            <div className="flex items-center gap-1">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    className="w-8 h-8 flex items-center justify-center hover:bg-white/10 rounded-full transition-colors"
                    aria-label="Settings"
                  >
                    <Settings className="w-4 h-4" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent 
                  align="end" 
                  className="bg-black/95 border-white/10 text-white backdrop-blur-md"
                >
                  <div className="px-2 py-1.5 text-xs font-semibold text-white/60">
                    Playback Speed
                  </div>
                  {speedOptions.map((speed) => (
                    <DropdownMenuItem
                      key={speed}
                      onClick={() => handleSpeedChange(speed)}
                      className={cn(
                        "cursor-pointer hover:bg-white/10 focus:bg-white/10",
                        playbackSpeed === speed && "bg-white/20 text-[#1d9bf0]"
                      )}
                    >
                      {speed === 1 ? 'Normal' : `${speed}x`}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              <button
                onClick={handleFullscreen}
                className="w-8 h-8 flex items-center justify-center hover:bg-white/10 rounded-full transition-colors"
                aria-label="Fullscreen"
              >
                <Maximize className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VideoPlayer;