import React, { useState, useEffect, useRef } from 'react';
import { Search, ArrowLeft, Menu, X, Edit, Share2, Briefcase, ShoppingBag, Tag, Settings, Bookmark, BarChart3, QrCode } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import XStyleSearchDropdown from '@/components/search/XStyleSearchDropdown';

interface SearchResult {
  id: string;
  title: string;
  type: 'product' | 'job' | 'service' | 'promotion';
  imageUrl?: string | null;
}

interface ProfileStickyHeaderProps {
  coverImage?: string | null;
  displayName: string;
  userProducts?: Array<{
    id: string;
    title: string;
    listing_type?: string | null;
    images?: string[] | null;
  }>;
  onBack: () => void;
  onOpenSidebar: () => void;
  onEditProduct?: (id: string) => void;
  onShareProduct?: (id: string) => void;
  onOpenQRCode?: () => void;
  onOpenSettings?: () => void;
}

const ProfileStickyHeader: React.FC<ProfileStickyHeaderProps> = ({
  coverImage,
  displayName,
  userProducts = [],
  onBack,
  onOpenSidebar,
  onEditProduct,
  onShareProduct,
  onOpenQRCode,
  onOpenSettings,
}) => {
  const navigate = useNavigate();
  const [isScrolled, setIsScrolled] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const searchButtonRef = useRef<HTMLButtonElement>(null);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Handle scroll to transform header - supports both ScrollArea viewport and window
  useEffect(() => {
    const onScroll = (scrollY: number) => {
      const threshold = 160;
      const progress = Math.min(scrollY / threshold, 1);
      setScrollProgress(progress);
      setIsScrolled(scrollY > 120);
    };

    // Try Radix ScrollArea viewport first
    const viewport = document.querySelector('[data-radix-scroll-area-viewport]') as HTMLElement;
    if (viewport) {
      const handler = () => onScroll(viewport.scrollTop);
      viewport.addEventListener('scroll', handler, { passive: true });
      return () => viewport.removeEventListener('scroll', handler);
    }

    // Try the main scrollable div in Profile page
    const scrollableDiv = document.querySelector('[data-scroll-container="profile"]') as HTMLElement;
    if (scrollableDiv && scrollableDiv.scrollHeight > scrollableDiv.clientHeight) {
      const handler = () => onScroll(scrollableDiv.scrollTop);
      scrollableDiv.addEventListener('scroll', handler, { passive: true });
      return () => scrollableDiv.removeEventListener('scroll', handler);
    }

    // Fallback to window
    const handler = () => onScroll(window.scrollY);
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);

  // Filter products based on search query (for local product search).
  // IMPORTANT: do NOT auto-open the results Dialog on every keystroke.
  // Opening a Radix Dialog focus-traps and steals focus from the
  // dropdown input, which made it impossible to type more than one
  // character. The modal now opens only when the user submits (Enter /
  // search button) via handleSubmitSearch below.
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      setShowSearchModal(false);
      return;
    }
    const query = searchQuery.toLowerCase();
    const filtered = userProducts
      .filter((p) => p.title.toLowerCase().includes(query))
      .map((p) => ({
        id: p.id,
        title: p.title,
        type: getListingType(p.listing_type),
        imageUrl: p.images?.[0] || null,
      }));
    setSearchResults(filtered);
  }, [searchQuery, userProducts]);

  // Called when the user actually submits the search (Enter / search btn).
  // This is the only place that opens the local results Dialog.
  const handleSubmitSearch = (q: string) => {
    const query = q.trim().toLowerCase();
    if (!query) return;
    const filtered = userProducts
      .filter((p) => p.title.toLowerCase().includes(query))
      .map((p) => ({
        id: p.id,
        title: p.title,
        type: getListingType(p.listing_type),
        imageUrl: p.images?.[0] || null,
      }));
    setSearchResults(filtered);
    setShowSearchModal(true);
    setIsSearchOpen(false);
  };

  const getListingType = (type?: string | null): 'product' | 'job' | 'service' | 'promotion' => {
    switch (type) {
      case 'jobs': return 'job';
      case 'services': return 'service';
      case 'promotions': return 'promotion';
      default: return 'product';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'job': return <Briefcase className="w-4 h-4" />;
      case 'service': return <Settings className="w-4 h-4" />;
      case 'promotion': return <Tag className="w-4 h-4" />;
      default: return <ShoppingBag className="w-4 h-4" />;
    }
  };

  const getTypeBadgeColor = (type: string) => {
    switch (type) {
      case 'job': return 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300';
      case 'service': return 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300';
      case 'promotion': return 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300';
      default: return 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300';
    }
  };

  const handleSearchClick = () => {
    setIsSearchOpen(true);
  };

  const handleCloseSearch = () => {
    setIsSearchOpen(false);
    setSearchQuery('');
    setShowSearchModal(false);
  };

  return (
    <>
      {/* Cover Image Section with initial buttons */}
      <div className="relative w-full h-[120px] sm:h-[160px] md:h-[200px] bg-gradient-to-br from-primary/20 to-primary/5">
        {coverImage ? (
          <img
            src={coverImage}
            alt="Cover"
            className="absolute inset-0 w-full h-full object-cover overflow-hidden"
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-primary/20 to-background" />
        )}
        
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />

        {/* Initial Top Bar (visible before scroll) - Only back and search on cover */}
        <div
          className={cn(
            "absolute top-0 left-0 right-0 z-[60] transition-opacity duration-300",
            isScrolled ? "opacity-0 pointer-events-none" : "opacity-100"
          )}
        >
          <div className="flex items-center justify-between px-3 py-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onBack}
              className="rounded-full h-9 w-9 bg-background/40 backdrop-blur-sm hover:bg-background/60"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            
            <div className="flex items-center gap-2">
              {/* Search Icon with X-style dropdown - ONLY icon on cover */}
              <div ref={searchContainerRef} className="relative">
                <motion.div
                  animate={{
                    scale: isSearchOpen ? 1.05 : 1,
                  }}
                  transition={{ duration: 0.2 }}
                >
                  <Button 
                    ref={searchButtonRef}
                    variant="ghost" 
                    size="icon" 
                    onClick={handleSearchClick}
                    className={cn(
                      "rounded-full h-9 w-9 bg-background/40 backdrop-blur-sm hover:bg-background/60 transition-all duration-300",
                      isSearchOpen && "bg-background/80 ring-2 ring-primary"
                    )}
                  >
                    <Search className="w-5 h-5" />
                  </Button>
                </motion.div>
                
                {/* X-style Search Dropdown */}
                <XStyleSearchDropdown
                  isOpen={isSearchOpen}
                  onClose={handleCloseSearch}
                  searchQuery={searchQuery}
                  onSearchChange={setSearchQuery}
                  anchorRef={searchContainerRef}
                  className="right-0 left-auto min-w-[320px]"
                  onSubmit={handleSubmitSearch}
                />
              </div>
              
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={onOpenSidebar}
                className="rounded-full h-9 w-9 bg-background/40 backdrop-blur-sm hover:bg-background/60"
              >
                <Menu className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Navigation Bar - X.com style dark header on scroll */}
      <div
        className={cn(
          "fixed top-0 left-0 right-0 z-[60] transition-all duration-300 ease-out lg:left-[280px] lg:right-[320px] xl:right-[340px]",
          isScrolled 
            ? "opacity-100 translate-y-0" 
            : "opacity-0 -translate-y-full pointer-events-none"
        )}
      >
        {/* Blurred cover image background */}
        {coverImage && (
          <div 
            className="absolute inset-0"
            style={{
              backgroundImage: `url(${coverImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              filter: 'blur(20px)',
              transform: 'scale(1.1)',
            }}
          />
        )}
        <div className="absolute inset-0 bg-background/70 backdrop-blur-sm" />
        
        {/* Navigation Content */}
        <div className="relative flex items-center justify-between px-3 py-2.5">
          <div className="flex items-center gap-3 min-w-0">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onBack}
              className="rounded-full h-8 w-8 flex-shrink-0 text-foreground hover:bg-accent/50"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            
            <div className="flex flex-col min-w-0">
              <span className="font-semibold text-foreground truncate">
                {displayName}
              </span>
              <span className="text-xs text-muted-foreground">
                {userProducts?.length || 0} posts
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-1 flex-shrink-0">
            {/* Search in sticky header */}
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleSearchClick}
              className="rounded-full h-8 w-8 text-foreground hover:bg-accent/50"
            >
              <Search className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Search Results Modal (for local products search) */}
      <Dialog open={showSearchModal && searchResults.length > 0} onOpenChange={(open) => {
        if (!open) {
          handleCloseSearch();
        }
      }}>
        <DialogContent className="sm:max-w-md p-0">
          <DialogHeader className="p-4 pb-2 border-b">
            <DialogTitle className="text-base">Your Products</DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[60vh]">
            <div className="p-2">
              {searchResults.map((result) => (
                <motion.div
                  key={result.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-3 p-3 rounded-xl hover:bg-accent/50 transition-colors cursor-pointer group"
                >
                  {/* Thumbnail */}
                  <div className="w-12 h-12 rounded-lg bg-muted overflow-hidden flex-shrink-0 flex items-center justify-center">
                    {result.imageUrl ? (
                      <img src={result.imageUrl} alt={result.title} className="w-full h-full object-cover" />
                    ) : (
                      getTypeIcon(result.type)
                    )}
                  </div>
                  
                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">{result.title}</p>
                    <Badge variant="secondary" className={cn("text-[10px] px-1.5 py-0 mt-1", getTypeBadgeColor(result.type))}>
                      {result.type}
                    </Badge>
                  </div>
                  
                  {/* Actions */}
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {onEditProduct && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 rounded-full"
                        onClick={(e) => {
                          e.stopPropagation();
                          onEditProduct(result.id);
                        }}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                    )}
                    {onShareProduct && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 rounded-full"
                        onClick={(e) => {
                          e.stopPropagation();
                          onShareProduct(result.id);
                        }}
                      >
                        <Share2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </motion.div>
              ))}
              
              {searchResults.length === 0 && searchQuery && (
                <div className="p-8 text-center text-muted-foreground">
                  <Search className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No results found for "{searchQuery}"</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ProfileStickyHeader;
