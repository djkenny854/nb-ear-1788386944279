import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Share2, X, UserPlus, UserCheck } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import UnifiedVerifiedBadge from '@/components/UnifiedVerifiedBadge';

interface ProfilePictureModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  imageUrl?: string | null;
  fallback: string;
  profileName: string;
  profileUrl?: string;
  sellerUserId?: string;
  isFollowing?: boolean;
  onToggleFollow?: () => void;
  followLoading?: boolean;
  isOwnProfile?: boolean;
  isVerified?: boolean;
  verificationBadgeColor?: string | null;
  businessCategory?: string;
}

const ProfilePictureModal: React.FC<ProfilePictureModalProps> = ({
  open,
  onOpenChange,
  imageUrl,
  fallback,
  profileName,
  profileUrl,
  isFollowing = false,
  onToggleFollow,
  followLoading = false,
  isOwnProfile = false,
  isVerified = false,
  verificationBadgeColor,
  businessCategory,
}) => {
  // Lock background body scroll completely when modal is open
  useEffect(() => {
    if (!open) return;
    const originalOverflow = document.body.style.overflow;
    const originalTouchAction = document.body.style.touchAction;
    document.body.style.overflow = 'hidden';
    document.body.style.touchAction = 'none';

    return () => {
      document.body.style.overflow = originalOverflow;
      document.body.style.touchAction = originalTouchAction;
    };
  }, [open]);

  const handleShareImage = async () => {
    try {
      const shareUrl = profileUrl || imageUrl || window.location.href;
      
      // Try sharing the image file if available and browser supports file sharing
      if (imageUrl && navigator.canShare) {
        try {
          const res = await fetch(imageUrl);
          const blob = await res.blob();
          const file = new File([blob], `${profileName.replace(/\s+/g, '_')}_profile.jpg`, { 
            type: blob.type || 'image/jpeg' 
          });
          if (navigator.canShare({ files: [file] })) {
            await navigator.share({
              title: `${profileName} on EarlyMarket`,
              text: `Check out ${profileName}'s profile photo on EarlyMarket`,
              files: [file],
            });
            return;
          }
        } catch {
          // Fall through to link share
        }
      }

      if (navigator.share) {
        await navigator.share({
          title: `${profileName} - Profile Photo`,
          text: `Check out ${profileName}'s profile on EarlyMarket`,
          url: shareUrl,
        });
      } else {
        await navigator.clipboard.writeText(imageUrl || shareUrl);
        toast.success('Image link copied to clipboard!');
      }
    } catch {
      // User cancelled share or clipboard fallback
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[300] h-[100vh] h-[100dvh] w-screen overflow-hidden overscroll-none touch-none flex flex-col justify-between items-center p-4 sm:p-6 md:p-8 bg-black/85 backdrop-blur-2xl select-none"
          onClick={() => onOpenChange(false)}
        >
          {/* Top Bar with Name / Category / Verified Badge + Close Button */}
          <motion.div
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="w-full max-w-2xl flex items-center justify-between z-10 shrink-0"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-white/10 shadow-lg">
              <span className="text-white font-medium text-sm sm:text-base truncate max-w-[180px] sm:max-w-xs">
                {profileName}
              </span>
              {isVerified && (
                <UnifiedVerifiedBadge 
                  isVerified={true} 
                  badgeColor={verificationBadgeColor} 
                  size="sm" 
                />
              )}
              {businessCategory && (
                <span className="hidden sm:inline text-xs text-white/70 border-l border-white/20 pl-2">
                  {businessCategory}
                </span>
              )}
            </div>

            <button
              onClick={() => onOpenChange(false)}
              className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 active:scale-95 text-white flex items-center justify-center backdrop-blur-md border border-white/10 shadow-lg transition-all cursor-pointer shrink-0"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </motion.div>

          {/* Center Circular Profile Image with bounded viewport sizing */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 320, damping: 26 }}
            className="relative flex items-center justify-center my-auto z-10 shrink-0 max-h-[55vh] max-w-[85vw]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Ambient glassmorphic glow behind the circular frame */}
            <div className="absolute -inset-4 bg-gradient-to-tr from-primary/30 via-white/10 to-primary/20 rounded-full blur-2xl opacity-60 pointer-events-none" />

            <div className="relative w-[min(70vw,260px)] h-[min(70vw,260px)] sm:w-80 sm:h-80 md:w-96 md:h-96 rounded-full ring-4 ring-white/30 shadow-[0_20px_70px_rgba(0,0,0,0.8)] overflow-hidden bg-neutral-900/80 backdrop-blur-md flex items-center justify-center shrink-0">
              {imageUrl ? (
                <img
                  src={imageUrl}
                  alt={profileName}
                  className="w-full h-full object-cover select-none pointer-events-none"
                  draggable={false}
                />
              ) : (
                <div className="w-full h-full bg-primary/30 flex items-center justify-center select-none">
                  <span className="text-6xl sm:text-8xl font-bold text-white tracking-wider">
                    {fallback}
                  </span>
                </div>
              )}
            </div>
          </motion.div>

          {/* Bottom Action Bar: Share Image + Button for Follow */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="w-full max-w-md bg-white/10 backdrop-blur-xl border border-white/15 rounded-2xl sm:rounded-full p-2.5 sm:p-3 shadow-2xl flex items-center justify-center gap-3 z-10 shrink-0"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Share Image Option */}
            <Button
              onClick={handleShareImage}
              variant="ghost"
              className="flex-1 rounded-full text-white bg-white/10 hover:bg-white/20 active:scale-95 border border-white/10 h-11 px-4 font-medium text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Share2 className="w-4 h-4 text-white" />
              <span>Share image</span>
            </Button>

            {/* Follow Button Option */}
            {!isOwnProfile && onToggleFollow ? (
              <Button
                onClick={onToggleFollow}
                disabled={followLoading}
                className={cn(
                  "flex-1 rounded-full h-11 px-4 font-semibold text-sm flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer",
                  isFollowing
                    ? "bg-white/20 text-white hover:bg-white/30 border border-white/20"
                    : "bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/30"
                )}
              >
                {isFollowing ? (
                  <>
                    <UserCheck className="w-4 h-4" />
                    <span>Following</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4" />
                    <span>Follow</span>
                  </>
                )}
              </Button>
            ) : isOwnProfile ? (
              <div className="flex-1 flex items-center justify-center text-xs text-white/75 font-medium px-3">
                Your Profile Picture
              </div>
            ) : null}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ProfilePictureModal;

