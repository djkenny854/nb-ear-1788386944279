import React, { useState, useRef, useCallback, useEffect } from 'react';
import ReactCrop, { Crop as CropType, PixelCrop, centerCrop, makeAspectCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { SearchableCategoryDropdown } from '@/components/common/SearchableCategoryDropdown';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient, useQuery } from '@tanstack/react-query';
import EMIIcon from '@/components/icons/EMIIcon';
import {
  Camera,
  Video,
  Upload,
  X,
  Loader2,
  Sparkles,
  Building,
  Phone,
  MapPin,
  Mail,
  Globe,
  MessageCircle,
  Image as ImageIcon,
  Check,
  User,
  Settings,
  Palette,
  Shield,
  ChevronRight,
  RotateCw,
  Eye,
  EyeOff,
  Lock,
  Users,
  Bell,
  Info,
  Facebook,
  Instagram,
  Twitter,
  Linkedin,
  Youtube,
  ExternalLink,
  Navigation,
  Crop as CropIcon,
  Search,
} from 'lucide-react';
import { ugandaDistricts } from '@/data/ugandaDistricts';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  sellerProfile: any;
  userId: string;
}

type SidebarSection = 'profile' | 'business' | 'contact' | 'location' | 'media' | 'privacy';

const EditProfileSkeleton = () => (
  <div className="flex flex-col h-full">
    <div className="p-4 border-b border-border/50">
      <Skeleton className="h-6 w-32" />
    </div>
    <div className="flex-1 p-6 space-y-6">
      {[1, 2, 3, 4].map((i) => (
        <div key={i} className="space-y-2">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-10 w-full rounded-lg" />
        </div>
      ))}
    </div>
  </div>
);

const UpgradeCardSkeleton = () => (
  <div className="p-3 rounded-xl border border-border/50 bg-secondary/30">
    <div className="space-y-2">
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-3 w-3/4" />
      <Skeleton className="h-8 w-full rounded-lg mt-2" />
    </div>
  </div>
);

const EditLimitBadge = ({ remaining }: { remaining: number }) => {
  if (remaining >= 1) return null;
  return <span className="text-xs px-2 py-0.5 rounded-full bg-destructive/10 text-destructive">Limit reached (wait 15 days)</span>;
};

const SettingsRow = ({
  label,
  description,
  children,
  aiAction,
  isLoadingAi,
  editLimit,
}: {
  label: string;
  description?: string;
  children: React.ReactNode;
  aiAction?: () => void;
  isLoadingAi?: boolean;
  editLimit?: { remaining: number; nextAvailable: string | null };
}) => (
  <div className="flex flex-col gap-3 py-4 border-b border-border/30 last:border-0">
    <div className="flex items-start justify-between gap-2">
      <div className="space-y-1">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-medium text-foreground text-sm">{label}</span>
          {aiAction && (
            <button
              type="button"
              onClick={aiAction}
              disabled={isLoadingAi}
              className="p-1 rounded-full hover:bg-primary/10 transition-colors"
            >
              {isLoadingAi ? <Loader2 className="w-4 h-4 animate-spin text-primary" /> : <EMIIcon className="w-4 h-4" />}
            </button>
          )}
          {editLimit && <EditLimitBadge remaining={editLimit.remaining} />}
        </div>
        {description && <p className="text-xs text-muted-foreground">{description}</p>}
      </div>
    </div>
    <div className="w-full">{children}</div>
  </div>
);

const SidebarItem = ({
  icon: Icon,
  label,
  active,
  onClick,
  disabled = false,
}: {
  icon: React.ElementType;
  label: string;
  active: boolean;
  onClick: () => void;
  disabled?: boolean;
}) => (
  <button
    type="button"
    onClick={disabled ? undefined : onClick}
    disabled={disabled}
    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
      disabled
        ? 'opacity-50 cursor-not-allowed text-muted-foreground'
        : active
          ? 'bg-secondary text-foreground'
          : 'text-muted-foreground hover:bg-secondary/50 hover:text-foreground'
    }`}
  >
    <Icon className="w-5 h-5" />
    <span>{label}</span>
    {disabled && <Lock className="w-3 h-3 ml-auto" />}
  </button>
);

function centerAspectCrop(mediaWidth: number, mediaHeight: number, aspect: number) {
  return centerCrop(makeAspectCrop({ unit: '%', width: 90 }, aspect, mediaWidth, mediaHeight), mediaWidth, mediaHeight);
}

const EditProfileModal: React.FC<EditProfileModalProps> = ({ isOpen, onClose, sellerProfile, userId }) => {
  const queryClient = useQueryClient();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [activeSection, setActiveSection] = useState<SidebarSection>('profile');

  const [formData, setFormData] = useState({
    business_name: '',
    business_email: '',
    business_phone: '',
    business_bio: '',
    business_category: '',
    district: '',
    sub_county: '',
    street_address: '',
    whatsapp_number: '',
    business_video_url: '',
    website_url: '',
    facebook_url: '',
    instagram_url: '',
    twitter_url: '',
    linkedin_url: '',
    youtube_url: '',
    tiktok_username: '',
    tiktok_video_url: '',
    return_policy: '',
    warranty_policy: '',
  });

  const [workingHours, setWorkingHours] = useState<Record<string, { open: string; close: string; closed: boolean }>>({});
  const [is24Hours, setIs24Hours] = useState(false);

  const [privacySettings, setPrivacySettings] = useState({
    profile_visibility: 'public',
    show_email: false,
    show_phone: true,
    show_location: true,
    allow_messages_from: 'everyone',
    show_online_status: true,
    show_activity_status: true,
    allow_tagging: true,
    show_listings_count: true,
    show_social_links: true,
  });

  const ensureUrlProtocol = (url: string): string => {
    if (!url || url.trim() === '') return '';
    const trimmed = url.trim();
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) return trimmed;
    return `https://${trimmed}`;
  };

  const handleSocialUrlBlur = (field: keyof typeof formData, value: string) => {
    if (value && value.trim() !== '') {
      setFormData((prev) => ({ ...prev, [field]: ensureUrlProtocol(value) }));
    }
  };

  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [coverImage, setCoverImage] = useState<string | null>(null);
  const [coverVideo, setCoverVideo] = useState<string | null>(null);
  const [showFollowerCount, setShowFollowerCount] = useState(true);

  const [showCropModal, setShowCropModal] = useState(false);
  const [cropImage, setCropImage] = useState<string>('');
  const [crop, setCrop] = useState<CropType>();
  const [completedCrop, setCompletedCrop] = useState<PixelCrop>();
  const [cropType, setCropType] = useState<'profile' | 'cover'>('profile');
  const [rotation, setRotation] = useState(0);
  const imgRef = useRef<HTMLImageElement>(null);

  const [isUploadingProfile, setIsUploadingProfile] = useState(false);
  const [isUploadingCover, setIsUploadingCover] = useState(false);
  const [isUploadingVideo, setIsUploadingVideo] = useState(false);

  const [aiSuggestions, setAiSuggestions] = useState<Record<string, string>>({});
  const [loadingAi, setLoadingAi] = useState<Record<string, boolean>>({});
  const [editLimits, setEditLimits] = useState<Record<string, { remaining: number; nextAvailable: string | null }>>({});

  const profileInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const selectedDistrict = ugandaDistricts.find((d) => d.name === formData.district);
  const availableSubCounties = selectedDistrict?.subCounties || [];

  const getMapEmbedUrl = () => {
    const location = [formData.street_address, formData.sub_county, formData.district, 'Uganda'].filter(Boolean).join(', ');
    if (!location || location === 'Uganda') return null;
    return `https://www.google.com/maps?q=${encodeURIComponent(location)}&output=embed`;
  };

  const { data: editLimitsData } = useQuery({
    queryKey: ['edit-limits', userId],
    queryFn: async () => {
      const fields = ['business_name', 'business_logo', 'business_bio'];
      const limits: Record<string, { remaining: number; nextAvailable: string | null }> = {};

      for (const field of fields) {
        const { data } = await supabase.rpc('get_remaining_edits', {
          p_user_id: userId,
          p_field_name: field,
        });
        if (data && data[0]) {
          limits[field] = { remaining: data[0].remaining, nextAvailable: data[0].next_available };
        } else {
          limits[field] = { remaining: 1, nextAvailable: null };
        }
      }
      return limits;
    },
    enabled: !!userId && isOpen,
  });

  const { data: existingPrivacySettings } = useQuery({
    queryKey: ['privacy-settings', userId],
    queryFn: async () => {
      const { data } = await supabase.from('user_privacy_settings').select('*').eq('user_id', userId).single();
      return data;
    },
    enabled: !!userId && isOpen,
  });

  useEffect(() => {
    if (editLimitsData) setEditLimits(editLimitsData);
  }, [editLimitsData]);

  useEffect(() => {
    if (existingPrivacySettings) {
      setPrivacySettings({
        profile_visibility: existingPrivacySettings.profile_visibility || 'public',
        show_email: existingPrivacySettings.show_email ?? false,
        show_phone: existingPrivacySettings.show_phone ?? true,
        show_location: existingPrivacySettings.show_location ?? true,
        allow_messages_from: existingPrivacySettings.allow_messages_from || 'everyone',
        show_online_status: existingPrivacySettings.show_online_status ?? true,
        show_activity_status: existingPrivacySettings.show_activity_status ?? true,
        allow_tagging: existingPrivacySettings.allow_tagging ?? true,
        show_listings_count: existingPrivacySettings.show_listings_count ?? true,
        show_social_links: (existingPrivacySettings as any).show_social_links ?? true,
      });
    }
  }, [existingPrivacySettings]);

  useEffect(() => {
    if (!isOpen) return;
    setIsLoading(true);
    const timer = setTimeout(() => {
      if (sellerProfile) {
        setFormData({
          business_name: sellerProfile.business_name || '',
          business_email: sellerProfile.business_email || '',
          business_phone: sellerProfile.business_phone || '',
          business_bio: sellerProfile.business_bio || '',
          business_category: sellerProfile.business_category || '',
          district: sellerProfile.district || '',
          sub_county: sellerProfile.sub_county || '',
          street_address: sellerProfile.street_address || '',
          whatsapp_number: sellerProfile.whatsapp_number || '',
          business_video_url: sellerProfile.business_video_url || '',
          website_url: sellerProfile.website_url || '',
          facebook_url: sellerProfile.facebook_url || '',
          instagram_url: sellerProfile.instagram_url || '',
          twitter_url: sellerProfile.twitter_url || '',
          linkedin_url: sellerProfile.linkedin_url || '',
          youtube_url: sellerProfile.youtube_url || '',
          tiktok_username: sellerProfile.tiktok_username || '',
          tiktok_video_url: sellerProfile.tiktok_video_url || '',
          return_policy: sellerProfile.return_policy || '',
          warranty_policy: sellerProfile.warranty_policy || '',
        });
        setProfileImage(sellerProfile.business_logo_url || null);
        setCoverImage(sellerProfile.cover_image_url || null);
        setCoverVideo(sellerProfile.business_video_url || null);
        setShowFollowerCount((sellerProfile as any).show_follower_count !== false);
        
        // Load working hours from database - handle both old flat format and new per-day format
        if (sellerProfile.working_hours) {
          const wh = sellerProfile.working_hours as any;
          if (wh.days && Array.isArray(wh.days)) {
            // Old flat format: convert to per-day
            const perDay: Record<string, { open: string; close: string; closed: boolean }> = {};
            for (const day of wh.days) {
              perDay[day] = { open: wh.openTime || '09:00', close: wh.closeTime || '18:00', closed: false };
            }
            setWorkingHours(perDay);
            setIs24Hours(wh.is24Hours || false);
          } else {
            // New per-day format
            const perDay: Record<string, { open: string; close: string; closed: boolean }> = {};
            for (const [day, val] of Object.entries(wh)) {
              if (day === 'is24Hours') {
                setIs24Hours(val as boolean);
              } else if (typeof val === 'object' && val !== null) {
                perDay[day] = val as { open: string; close: string; closed: boolean };
              }
            }
            setWorkingHours(perDay);
          }
        }
      }
      setIsLoading(false);
    }, 200);

    return () => clearTimeout(timer);
  }, [isOpen, sellerProfile]);

  const handleInputChange = (field: keyof typeof formData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handlePrivacyChange = (field: keyof typeof privacySettings, value: any) => {
    setPrivacySettings((prev) => ({ ...prev, [field]: value }));
  };

  const getAiSuggestion = async (field: string, currentValue: string) => {
    setLoadingAi((prev) => ({ ...prev, [field]: true }));
    try {
      const typeMap: Record<string, string> = {
        business_bio: 'description',
        business_name: 'title',
        business_category: 'tags',
      };

      const response = await supabase.functions.invoke('ai-assist', {
        body: {
          type: typeMap[field] || 'description',
          context: {
            title: formData.business_name || currentValue,
            category: formData.business_category || 'general',
            postType: 'business profile',
          },
        },
      });

      if (response.data?.result) {
        setAiSuggestions((prev) => ({ ...prev, [field]: response.data.result }));
        toast.success('AI suggestion ready! Click to apply.');
      } else if (response.data?.userMessage) {
        toast.error(response.data.userMessage);
      }
    } catch (error) {
      console.error('AI suggestion error:', error);
      toast.error('Failed to get AI suggestion');
    } finally {
      setLoadingAi((prev) => ({ ...prev, [field]: false }));
    }
  };

  const applyAiSuggestion = (field: keyof typeof formData) => {
    if (!aiSuggestions[field]) return;
    setFormData((prev) => ({ ...prev, [field]: aiSuggestions[field] }));
    setAiSuggestions((prev) => {
      const u = { ...prev };
      delete u[field];
      return u;
    });
    toast.success('Applied!');
  };

  const onImageLoad = useCallback(
    (e: React.SyntheticEvent<HTMLImageElement>) => {
      const { width, height } = e.currentTarget;
      setCrop(centerAspectCrop(width, height, cropType === 'profile' ? 1 : 3));
    },
    [cropType]
  );

  const handleProfileImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (editLimits.business_logo?.remaining === 0) {
      toast.error('You can only change your profile photo once every 15 days');
      e.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setCropImage(reader.result as string);
      setCropType('profile');
      setRotation(0);
      setShowCropModal(true);
    };
    reader.readAsDataURL(file);
  };

  const handleCoverImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setCropImage(reader.result as string);
      setCropType('cover');
      setRotation(0);
      setShowCropModal(true);
    };
    reader.readAsDataURL(file);
  };

  const handleRotate = () => setRotation((prev) => (prev + 90) % 360);

  const getCroppedImage = async (): Promise<Blob | null> => {
    if (!imgRef.current || !completedCrop) return null;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    const scaleX = imgRef.current.naturalWidth / imgRef.current.width;
    const scaleY = imgRef.current.naturalHeight / imgRef.current.height;

    const outputWidth = completedCrop.width * scaleX;
    const outputHeight = completedCrop.height * scaleY;

    canvas.width = outputWidth;
    canvas.height = outputHeight;

    ctx.drawImage(
      imgRef.current,
      completedCrop.x * scaleX,
      completedCrop.y * scaleY,
      outputWidth,
      outputHeight,
      0,
      0,
      outputWidth,
      outputHeight
    );

    return new Promise((resolve) => canvas.toBlob(resolve, 'image/webp', 0.9));
  };

  const handleCropComplete = async () => {
    const croppedBlob = await getCroppedImage();
    if (!croppedBlob) {
      toast.error('Failed to crop');
      return;
    }

    const isProfile = cropType === 'profile';
    isProfile ? setIsUploadingProfile(true) : setIsUploadingCover(true);

    try {
      const fileName = `${userId}/${cropType}-${Date.now()}.webp`;
      const { error } = await supabase.storage.from('business-assets').upload(fileName, croppedBlob, {
        cacheControl: '3600',
        upsert: true,
        contentType: 'image/webp',
      });
      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage.from('business-assets').getPublicUrl(fileName);

      if (isProfile) setProfileImage(publicUrl);
      else setCoverImage(publicUrl);

      toast.success(`${isProfile ? 'Profile' : 'Cover'} image ready — click Save to apply`);
      setShowCropModal(false);
    } catch (error: any) {
      console.error('Upload error:', error);
      toast.error('Upload failed: ' + (error?.message || 'Unknown error'));
    } finally {
      isProfile ? setIsUploadingProfile(false) : setIsUploadingCover(false);
    }
  };

  const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('video/')) {
      toast.error('Please select a video');
      return;
    }
    if (file.size > 50 * 1024 * 1024) {
      toast.error('Video must be < 50MB');
      return;
    }

    setIsUploadingVideo(true);
    try {
      // Compress in-browser (720p H.264 + AAC, faststart) then upload the
      // MP4 so cover videos stream instantly like every other clip.
      const { compressVideo } = await import('@/utils/videoCompression');
      const { video } = await compressVideo(file);
      const fileName = `${userId}/${Date.now()}.mp4`;
      const { error } = await supabase.storage
        .from('business-videos')
        .upload(fileName, video, { contentType: 'video/mp4', cacheControl: '31536000' });
      if (error) throw error;
      const { data: { publicUrl } } = supabase.storage.from('business-videos').getPublicUrl(fileName);
      setCoverVideo(publicUrl);
      setFormData((prev) => ({ ...prev, business_video_url: publicUrl }));
      toast.success('Video uploaded!');
    } catch (error) {
      toast.error('Video upload failed');
    } finally {
      setIsUploadingVideo(false);
    }
  };

  const handleSubmit = async () => {
    setIsSaving(true);
    try {
      const nameChanged = formData.business_name !== sellerProfile?.business_name;
      if (nameChanged && editLimits.business_name?.remaining === 0) {
        toast.error('You can only change your business name once every 15 days');
        setIsSaving(false);
        return;
      }

      const bioChanged = formData.business_bio !== sellerProfile?.business_bio;
      if (bioChanged && editLimits.business_bio?.remaining === 0) {
        toast.error('You can only change your bio once every 15 days');
        setIsSaving(false);
        return;
      }

      // Build diff-based update: only include changed fields
      const updateData: Record<string, any> = {};

      const urlFields = ['website_url', 'facebook_url', 'instagram_url', 'twitter_url', 'linkedin_url', 'youtube_url', 'tiktok_video_url'] as const;
      const plainFields = ['business_name', 'business_email', 'business_phone', 'business_bio', 'business_category', 'district', 'sub_county', 'street_address', 'whatsapp_number', 'business_video_url', 'tiktok_username', 'return_policy', 'warranty_policy'] as const;

      for (const field of plainFields) {
        if (formData[field] !== (sellerProfile?.[field] || '')) {
          updateData[field] = formData[field];
        }
      }
      for (const field of urlFields) {
        const formatted = ensureUrlProtocol(formData[field]);
        if (formatted !== (sellerProfile?.[field] || '')) {
          updateData[field] = formatted;
        }
      }

      // Check images
      if (profileImage !== sellerProfile?.business_logo_url) {
        updateData.business_logo_url = profileImage;
      }
      if (coverImage !== sellerProfile?.cover_image_url) {
        updateData.cover_image_url = coverImage;
      }

      // Working hours - save as per-day format with is24Hours flag
      const whData = { ...workingHours, is24Hours };
      const existingWh = sellerProfile?.working_hours;
      if (JSON.stringify(whData) !== JSON.stringify(existingWh)) {
        updateData.working_hours = whData;
      }

      if (showFollowerCount !== (sellerProfile?.show_follower_count !== false)) {
        updateData.show_follower_count = showFollowerCount;
      }

      // Only update if there are changes
      if (Object.keys(updateData).length > 0) {
        const { error } = await supabase
          .from('seller_profiles')
          .update(updateData as any)
          .eq('user_id', userId);
        if (error) throw error;
      }

      if (nameChanged) {
        await supabase.from('profile_edit_history').insert({
          user_id: userId,
          field_name: 'business_name',
          new_value: formData.business_name,
          old_value: sellerProfile?.business_name,
        });
      }

      if (bioChanged) {
        await supabase.from('profile_edit_history').insert({
          user_id: userId,
          field_name: 'business_bio',
          new_value: formData.business_bio,
          old_value: sellerProfile?.business_bio,
        });
      }

      // Record profile photo change ONLY after Save (prevents "consuming" edit on select/upload)
      const profileImageChanged = profileImage && profileImage !== sellerProfile?.business_logo_url;
      if (profileImageChanged) {
        await supabase.from('profile_edit_history').insert({
          user_id: userId,
          field_name: 'business_logo',
          new_value: profileImage,
          old_value: sellerProfile?.business_logo_url,
        });
      }

      const { error: privacyError } = await supabase.from('user_privacy_settings').upsert(
        {
          user_id: userId,
          ...privacySettings,
        },
        { onConflict: 'user_id' }
      );

      if (privacyError) console.error('Privacy settings error:', privacyError);

      toast.success('Profile updated!');
      queryClient.invalidateQueries({ queryKey: ['seller-profile', userId] });
      queryClient.invalidateQueries({ queryKey: ['edit-limits', userId] });
      queryClient.invalidateQueries({ queryKey: ['privacy-settings', userId] });
      onClose();
    } catch (error: any) {
      toast.error('Save failed: ' + (error?.message || 'Unknown error'));
    } finally {
      setIsSaving(false);
    }
  };

  // Seller account detection - ANY seller profile gets full access
  // seller_type values: individual, registered_business, ngo
  const isOrganization = sellerProfile?.seller_type === 'ngo';
  const isBusinessAccount = sellerProfile?.seller_type === 'registered_business';
  
  // All seller profiles (individual, registered_business, ngo) are business accounts
  const isBusinessSeller = !!sellerProfile;

  // Get user type label for UI
  const getUserTypeLabel = () => {
    if (isOrganization) return 'Organization';
    if (isBusinessAccount) return 'Business';
    if (sellerProfile) return 'Seller';
    return 'Personal';
  };

  const sidebarItems = [
    { id: 'profile' as const, icon: User, label: 'Profile', disabled: false },
    { id: 'business' as const, icon: Building, label: isOrganization ? 'Organization' : 'Business', disabled: !isBusinessSeller },
    { id: 'contact' as const, icon: Phone, label: 'Contact', disabled: false },
    { id: 'location' as const, icon: MapPin, label: 'Location', disabled: false },
    { id: 'media' as const, icon: ImageIcon, label: 'Media', disabled: false },
    { id: 'privacy' as const, icon: Shield, label: 'Privacy', disabled: false },
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'profile':
        return (
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-foreground">Profile Settings</h2>
            <p className="text-sm text-muted-foreground mb-6">Manage your profile photo and display name</p>

            <SettingsRow label="Profile Photo" description="Your business profile picture" editLimit={editLimits.business_logo}>
              <div className="flex items-center gap-4">
                <div className="relative w-20 h-20 rounded-full overflow-hidden bg-secondary border-2 border-border">
                  {profileImage ? (
                    <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <User className="w-8 h-8 text-muted-foreground" />
                    </div>
                  )}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => profileInputRef.current?.click()}
                  disabled={isUploadingProfile || editLimits.business_logo?.remaining === 0}
                >
                  {isUploadingProfile ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Camera className="w-4 h-4 mr-2" />}
                  Change
                </Button>
              </div>
            </SettingsRow>

            <SettingsRow
              label={isOrganization ? 'Organization Name' : isBusinessAccount ? 'Business Name' : 'Display Name'}
              description={
                isOrganization 
                  ? 'Your organization display name (1 change per 15 days)' 
                  : isBusinessAccount 
                    ? 'Your business display name (1 change per 15 days)' 
                    : 'Your personal display name (1 change per 15 days)'
              }
              editLimit={editLimits.business_name}
            >
              <Input
                value={formData.business_name}
                onChange={(e) => handleInputChange('business_name', e.target.value)}
                placeholder={isOrganization ? 'Organization name' : isBusinessAccount ? 'Business name' : 'Your name'}
                className="bg-secondary border-border/50"
                disabled={editLimits.business_name?.remaining === 0}
              />
            </SettingsRow>

            <div className="relative">
              <SettingsRow
                label="Bio"
                description={
                  isBusinessSeller 
                    ? `Tell ${isOrganization ? 'supporters' : 'customers'} about ${isOrganization ? 'your organization' : isBusinessAccount ? 'your business' : 'yourself'} (1 change per 15 days)` 
                    : 'Create a seller account to add a bio'
                }
                aiAction={isBusinessSeller ? () => getAiSuggestion('business_bio', formData.business_bio) : undefined}
                isLoadingAi={loadingAi.business_bio}
                editLimit={isBusinessSeller ? editLimits.business_bio : undefined}
              >
                <div className="space-y-2">
                  <Textarea
                    value={formData.business_bio}
                    onChange={(e) => handleInputChange('business_bio', e.target.value)}
                    placeholder={
                      isOrganization 
                        ? 'Write something about your organization...' 
                        : isBusinessAccount 
                          ? 'Write something about your business...' 
                          : 'Write something about yourself...'
                    }
                    rows={3}
                    className="bg-secondary border-border/50 resize-none"
                    disabled={!isBusinessSeller || editLimits.business_bio?.remaining === 0}
                  />
                  {aiSuggestions.business_bio && isBusinessSeller && (
                    <button
                      type="button"
                      onClick={() => applyAiSuggestion('business_bio')}
                      className="text-xs text-primary hover:underline flex items-center gap-1"
                    >
                      <Sparkles className="w-3 h-3" /> Apply AI suggestion
                    </button>
                  )}
                </div>
              </SettingsRow>
            </div>
          </div>
        );

      case 'business':
        if (!isBusinessSeller) {
          return (
            <div className="space-y-4">
              <h2 className="text-xl font-bold text-foreground">Business Information</h2>
              <div className="p-6 rounded-xl border border-border/50 bg-secondary/30 text-center">
                <Lock className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                <h3 className="font-semibold text-foreground mb-2">Create Seller Account</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Business settings are available for seller accounts.
                </p>
                <Button variant="default" size="sm" onClick={() => (window.location.href = '/create-business-account')}>
                  <Building className="w-4 h-4 mr-2" />
                  Create Business Profile
                </Button>
              </div>
            </div>
          );
        }
        return (
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-foreground">
              {isOrganization ? 'Organization Information' : 'Business Information'}
            </h2>
            <p className="text-sm text-muted-foreground mb-6">
              Details about your {isOrganization ? 'organization' : 'business'}
            </p>

            <SettingsRow
              label="Category"
              description={`Your ${isOrganization ? 'organization' : 'business'} category`}
            >
              <SearchableCategoryDropdown
                value={formData.business_category}
                onChange={(value) => handleInputChange('business_category', value)}
                placeholder="Search category..."
              />
            </SettingsRow>

            {/* Working Hours Section */}
            <SettingsRow
              label="Working Hours"
              description="Set your business operating hours per day"
            >
              <div className="space-y-4">
                {/* 24 Hours Toggle */}
                <div className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                  <span className="text-sm text-foreground">Open 24 Hours</span>
                  <Switch
                    checked={is24Hours}
                    onCheckedChange={setIs24Hours}
                  />
                </div>

                {/* Days Selection with per-day hours */}
                <div>
                  <label className="text-xs text-muted-foreground mb-2 block">Working Days</label>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((day) => {
                      const isSelected = !!workingHours[day] && !workingHours[day].closed;
                      return (
                        <button
                          key={day}
                          type="button"
                          onClick={() => {
                            setWorkingHours((prev) => {
                              const updated = { ...prev };
                              if (isSelected) {
                                delete updated[day];
                              } else {
                                updated[day] = { open: '09:00', close: '18:00', closed: false };
                              }
                              return updated;
                            });
                          }}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                            isSelected
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-secondary hover:bg-secondary/80 text-muted-foreground'
                          }`}
                        >
                          {day.slice(0, 3)}
                        </button>
                      );
                    })}
                  </div>

                  {/* Per-day time pickers */}
                  {!is24Hours && Object.entries(workingHours).filter(([key]) => key !== 'is24Hours').map(([day, hours]) => {
                    if (typeof hours !== 'object' || hours === null || hours.closed) return null;
                    return (
                      <div key={day} className="flex items-center gap-2 mb-2 p-2 rounded-lg bg-secondary/30">
                        <span className="text-xs font-medium w-12 text-foreground">{day.slice(0, 3)}</span>
                        <Select
                          value={hours.open}
                          onValueChange={(value) =>
                            setWorkingHours((prev) => ({ ...prev, [day]: { ...prev[day], open: value } }))
                          }
                        >
                          <SelectTrigger className="bg-secondary border-border/50 h-8 text-xs flex-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="max-h-60">
                            {Array.from({ length: 48 }, (_, i) => {
                              const hour = Math.floor(i / 2).toString().padStart(2, '0');
                              const min = i % 2 === 0 ? '00' : '30';
                              const val = `${hour}:${min}`;
                              return <SelectItem key={val} value={val}>{val}</SelectItem>;
                            })}
                          </SelectContent>
                        </Select>
                        <span className="text-xs text-muted-foreground">to</span>
                        <Select
                          value={hours.close}
                          onValueChange={(value) =>
                            setWorkingHours((prev) => ({ ...prev, [day]: { ...prev[day], close: value } }))
                          }
                        >
                          <SelectTrigger className="bg-secondary border-border/50 h-8 text-xs flex-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="max-h-60">
                            {Array.from({ length: 48 }, (_, i) => {
                              const hour = Math.floor(i / 2).toString().padStart(2, '0');
                              const min = i % 2 === 0 ? '00' : '30';
                              const val = `${hour}:${min}`;
                              return <SelectItem key={val} value={val}>{val}</SelectItem>;
                            })}
                          </SelectContent>
                        </Select>
                      </div>
                    );
                  })}
                </div>

                {/* Summary */}
                {Object.keys(workingHours).filter(k => k !== 'is24Hours').length > 0 && (
                  <div className="p-3 bg-primary/5 rounded-lg border border-primary/20">
                    <p className="text-xs text-primary">
                      {is24Hours
                        ? `Open 24 hours: ${Object.keys(workingHours).filter(k => k !== 'is24Hours').join(', ')}`
                        : Object.entries(workingHours)
                            .filter(([k, v]) => k !== 'is24Hours' && typeof v === 'object' && v !== null)
                            .map(([day, h]: [string, any]) => `${day.slice(0, 3)}: ${h.open}-${h.close}`)
                            .join(' · ')}
                    </p>
                  </div>
                )}
              </div>
            </SettingsRow>

            {/* Return Policy Section */}
            <SettingsRow
              label="Return Policy"
              description="Describe your return policy for customers"
            >
              <Textarea
                value={formData.return_policy}
                onChange={(e) => handleInputChange('return_policy', e.target.value)}
                placeholder="e.g., 7-day returns for defective items. Original packaging required. No returns on perishables."
                rows={3}
                className="bg-secondary border-border/50 resize-none"
              />
            </SettingsRow>

            {/* Warranty Policy Section */}
            <SettingsRow
              label="Warranty Policy"
              description="Describe warranty coverage for your products"
            >
              <Textarea
                value={formData.warranty_policy}
                onChange={(e) => handleInputChange('warranty_policy', e.target.value)}
                placeholder="e.g., 1-year manufacturer warranty. Covers defects in materials and workmanship."
                rows={3}
                className="bg-secondary border-border/50 resize-none"
              />
            </SettingsRow>
          </div>
        );

      case 'contact':
        return (
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-foreground">Contact & Social</h2>
            <p className="text-sm text-muted-foreground mb-6">How customers can reach you</p>

            <SettingsRow label="Email" description="Business email address">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="email"
                  value={formData.business_email}
                  onChange={(e) => handleInputChange('business_email', e.target.value)}
                  placeholder="business@example.com"
                  className="bg-secondary border-border/50 pl-10"
                />
              </div>
            </SettingsRow>

            <SettingsRow label="Phone" description="Business phone number">
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={formData.business_phone}
                  onChange={(e) => handleInputChange('business_phone', e.target.value)}
                  placeholder="+256 700 000 000"
                  className="bg-secondary border-border/50 pl-10"
                />
              </div>
            </SettingsRow>

            <SettingsRow label="WhatsApp" description="WhatsApp contact number">
              <div className="relative">
                <MessageCircle className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-green-500" />
                <Input
                  value={formData.whatsapp_number}
                  onChange={(e) => handleInputChange('whatsapp_number', e.target.value)}
                  placeholder="+256 700 000 000"
                  className="bg-secondary border-border/50 pl-10"
                />
              </div>
            </SettingsRow>

            <SettingsRow label="Website" description="Your website URL">
              <div className="relative">
                <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={formData.website_url}
                  onChange={(e) => handleInputChange('website_url', e.target.value)}
                  onBlur={(e) => handleSocialUrlBlur('website_url', e.target.value)}
                  placeholder="https://yourwebsite.com"
                  className="bg-secondary border-border/50 pl-10"
                />
              </div>
            </SettingsRow>

            <div className="border-t border-border/30 pt-4 mt-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-foreground">Social Media Links</h3>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Show on profile</span>
                  <Switch checked={privacySettings.show_social_links} onCheckedChange={(checked) => handlePrivacyChange('show_social_links', checked)} />
                </div>
              </div>

              <div className="space-y-4">
                <SettingsRow label="Facebook" description="Facebook profile link">
                  <div className="relative">
                    <Facebook className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-500" />
                    <Input
                      value={formData.facebook_url}
                      onChange={(e) => handleInputChange('facebook_url', e.target.value)}
                      onBlur={(e) => handleSocialUrlBlur('facebook_url', e.target.value)}
                      placeholder="facebook.com/yourpage"
                      className="bg-secondary border-border/50 pl-10"
                      disabled={!privacySettings.show_social_links}
                    />
                  </div>
                </SettingsRow>

                <SettingsRow label="Instagram" description="Instagram profile link">
                  <div className="relative">
                    <Instagram className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-pink-500" />
                    <Input
                      value={formData.instagram_url}
                      onChange={(e) => handleInputChange('instagram_url', e.target.value)}
                      onBlur={(e) => handleSocialUrlBlur('instagram_url', e.target.value)}
                      placeholder="instagram.com/yourhandle"
                      className="bg-secondary border-border/50 pl-10"
                      disabled={!privacySettings.show_social_links}
                    />
                  </div>
                </SettingsRow>

                <SettingsRow label="X" description="X (Twitter) profile link">
                  <div className="relative">
                    <Twitter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-sky-500" />
                    <Input
                      value={formData.twitter_url}
                      onChange={(e) => handleInputChange('twitter_url', e.target.value)}
                      onBlur={(e) => handleSocialUrlBlur('twitter_url', e.target.value)}
                      placeholder="x.com/yourhandle"
                      className="bg-secondary border-border/50 pl-10"
                      disabled={!privacySettings.show_social_links}
                    />
                  </div>
                </SettingsRow>

                <SettingsRow label="LinkedIn" description="LinkedIn profile link">
                  <div className="relative">
                    <Linkedin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-600" />
                    <Input
                      value={formData.linkedin_url}
                      onChange={(e) => handleInputChange('linkedin_url', e.target.value)}
                      onBlur={(e) => handleSocialUrlBlur('linkedin_url', e.target.value)}
                      placeholder="linkedin.com/in/yourprofile"
                      className="bg-secondary border-border/50 pl-10"
                      disabled={!privacySettings.show_social_links}
                    />
                  </div>
                </SettingsRow>

                <SettingsRow label="YouTube" description="YouTube channel link">
                  <div className="relative">
                    <Youtube className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-red-500" />
                    <Input
                      value={formData.youtube_url}
                      onChange={(e) => handleInputChange('youtube_url', e.target.value)}
                      onBlur={(e) => handleSocialUrlBlur('youtube_url', e.target.value)}
                      placeholder="youtube.com/@yourchannel"
                      className="bg-secondary border-border/50 pl-10"
                      disabled={!privacySettings.show_social_links}
                    />
                  </div>
                </SettingsRow>

                <SettingsRow label="TikTok Username" description="Your TikTok handle">
                  <Input
                    value={formData.tiktok_username}
                    onChange={(e) => handleInputChange('tiktok_username', e.target.value)}
                    placeholder="@yourusername"
                    className="bg-secondary border-border/50"
                    disabled={!privacySettings.show_social_links}
                  />
                </SettingsRow>

                <SettingsRow label="TikTok Video URL" description="A TikTok video link (optional)">
                  <Input
                    value={formData.tiktok_video_url}
                    onChange={(e) => handleInputChange('tiktok_video_url', e.target.value)}
                    onBlur={(e) => handleSocialUrlBlur('tiktok_video_url', e.target.value)}
                    placeholder="https://www.tiktok.com/@.../video/..."
                    className="bg-secondary border-border/50"
                    disabled={!privacySettings.show_social_links}
                  />
                </SettingsRow>
              </div>
            </div>
          </div>
        );

      case 'location': {
        const mapUrl = getMapEmbedUrl();
        return (
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-foreground">Location</h2>
            <p className="text-sm text-muted-foreground mb-6">Where your business is located</p>

            <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 border border-border/30 mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-full bg-primary/10">
                  {privacySettings.show_location ? <Eye className="w-4 h-4 text-primary" /> : <EyeOff className="w-4 h-4 text-muted-foreground" />}
                </div>
                <div>
                  <p className="text-sm font-medium">Show location on profile</p>
                  <p className="text-xs text-muted-foreground">Allow others to see your address on map</p>
                </div>
              </div>
              <Switch checked={privacySettings.show_location} onCheckedChange={(checked) => handlePrivacyChange('show_location', checked)} />
            </div>

            <SettingsRow label="District" description="Select your district">
              <Select
                value={formData.district}
                onValueChange={(value) => {
                  handleInputChange('district', value);
                  handleInputChange('sub_county', '');
                }}
              >
                <SelectTrigger className="bg-secondary border-border/50">
                  <SelectValue placeholder="Select district" />
                </SelectTrigger>
                <SelectContent className="max-h-60 z-[9999] bg-popover">
                  {ugandaDistricts.map((district) => (
                    <SelectItem key={district.id} value={district.name}>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3 h-3 text-muted-foreground" />
                        <span>{district.name}</span>
                        <span className="text-xs text-muted-foreground">({district.region})</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </SettingsRow>

            <SettingsRow label="Sub County" description="Select your sub-county">
              <Select value={formData.sub_county} onValueChange={(value) => handleInputChange('sub_county', value)} disabled={!formData.district}>
                <SelectTrigger className="bg-secondary border-border/50">
                  <SelectValue placeholder={formData.district ? 'Select sub-county' : 'Select district first'} />
                </SelectTrigger>
                <SelectContent className="max-h-60 z-[9999] bg-popover">
                  {availableSubCounties.map((subCounty) => (
                    <SelectItem key={subCounty} value={subCounty}>
                      {subCounty}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </SettingsRow>

            <SettingsRow label="Street Address" description="Full street address for precise location">
              <div className="relative">
                <Navigation className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={formData.street_address}
                  onChange={(e) => handleInputChange('street_address', e.target.value)}
                  placeholder="e.g., Plot 12, Kampala Road"
                  className="bg-secondary border-border/50 pl-10"
                />
              </div>
            </SettingsRow>

            <div className="pt-4 border-t border-border/30 mt-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-primary" />
                  Map Preview
                </h3>
                {mapUrl && (
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent([formData.street_address, formData.sub_county, formData.district, 'Uganda'].filter(Boolean).join(', '))}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-primary hover:underline flex items-center gap-1"
                  >
                    Open in Google Maps <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>

              <div className="relative rounded-lg overflow-hidden border border-border/50 bg-secondary">
                {mapUrl ? (
                  <iframe
                    src={mapUrl}
                    width="100%"
                    height="200"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    className="rounded-lg"
                  />
                ) : (
                  <div className="h-[200px] flex flex-col items-center justify-center text-muted-foreground">
                    <MapPin className="w-8 h-8 mb-2 opacity-50" />
                    <p className="text-sm">Select a location to see map preview</p>
                    <p className="text-xs mt-1">Choose district, sub-county or add street address</p>
                  </div>
                )}
              </div>

              {formData.district && (
                <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
                  <Info className="w-3 h-3" />
                  {[formData.street_address, formData.sub_county, formData.district, 'Uganda'].filter(Boolean).join(', ')}
                </p>
              )}
            </div>
          </div>
        );
      }

      case 'media':
        return (
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-foreground">Media</h2>
            <p className="text-sm text-muted-foreground mb-6">{isBusinessSeller ? 'Cover images and videos for your profile' : 'Profile images for your account'}</p>

            <SettingsRow label="Cover Image" description="Banner image for your profile page">
              <div className="space-y-3">
                <div className="relative h-28 rounded-lg overflow-hidden bg-secondary border border-border/50">
                  {coverImage ? (
                    <img src={coverImage} alt="Cover" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <ImageIcon className="w-8 h-8 text-muted-foreground/50" />
                    </div>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => coverInputRef.current?.click()} disabled={isUploadingCover}>
                    {isUploadingCover ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Upload className="w-4 h-4 mr-2" />}
                    Upload
                  </Button>
                  {coverImage && (
                    <Button variant="ghost" size="sm" onClick={() => setCoverImage(null)}>
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            </SettingsRow>

            <div className="relative">
              <SettingsRow 
                label="Cover Video" 
                description={
                  isBusinessSeller 
                    ? `Video to showcase ${isOrganization ? 'your organization' : isBusinessAccount ? 'your business' : 'yourself'} (max 50MB)` 
                    : 'Create a seller account to upload cover videos'
                }
              >
                <div className="space-y-3">
                  {coverVideo ? (
                    <div className="relative rounded-lg overflow-hidden bg-secondary">
                      <video src={coverVideo} controls className="w-full h-28 object-cover" />
                      <Button
                        size="icon"
                        variant="destructive"
                        className="absolute top-2 right-2 w-6 h-6"
                        onClick={() => {
                          setCoverVideo(null);
                          setFormData((prev) => ({ ...prev, business_video_url: '' }));
                        }}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  ) : (
                    <Button
                      variant="outline"
                      onClick={() => isBusinessSeller && videoInputRef.current?.click()}
                      disabled={isUploadingVideo || !isBusinessSeller}
                      className="w-full h-28 border-dashed"
                    >
                      {isUploadingVideo ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin mr-2" /> Uploading...
                        </>
                      ) : (
                        <>
                          <Video className="w-5 h-5 mr-2" /> Upload Video
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </SettingsRow>
            </div>
          </div>
        );

      case 'privacy':
        return (
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-foreground">Privacy & Security</h2>
            <p className="text-sm text-muted-foreground mb-6">Control who can see your information</p>

            <SettingsRow label="Profile Visibility" description="Who can see your profile">
              <Select value={privacySettings.profile_visibility} onValueChange={(value) => handlePrivacyChange('profile_visibility', value)}>
                <SelectTrigger className="bg-secondary border-border/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="public">
                    <div className="flex items-center gap-2">
                      <Globe className="w-4 h-4" />
                      <span>Public - Everyone</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="followers">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      <span>Followers Only</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="private">
                    <div className="flex items-center gap-2">
                      <Lock className="w-4 h-4" />
                      <span>Private</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </SettingsRow>

            <SettingsRow label="Who can message you" description="Control who can send you messages">
              <Select value={privacySettings.allow_messages_from} onValueChange={(value) => handlePrivacyChange('allow_messages_from', value)}>
                <SelectTrigger className="bg-secondary border-border/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="everyone">Everyone</SelectItem>
                  <SelectItem value="followers">Followers Only</SelectItem>
                  <SelectItem value="nobody">Nobody</SelectItem>
                </SelectContent>
              </Select>
            </SettingsRow>

            <div className="border-t border-border/30 pt-4 mt-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Show on Profile</h3>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">Email Address</span>
                  </div>
                  <Switch checked={privacySettings.show_email} onCheckedChange={(checked) => handlePrivacyChange('show_email', checked)} />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">Phone Number</span>
                  </div>
                  <Switch checked={privacySettings.show_phone} onCheckedChange={(checked) => handlePrivacyChange('show_phone', checked)} />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">Location</span>
                  </div>
                  <Switch checked={privacySettings.show_location} onCheckedChange={(checked) => handlePrivacyChange('show_location', checked)} />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Eye className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">Online Status</span>
                  </div>
                  <Switch checked={privacySettings.show_online_status} onCheckedChange={(checked) => handlePrivacyChange('show_online_status', checked)} />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Bell className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">Activity Status</span>
                  </div>
                  <Switch checked={privacySettings.show_activity_status} onCheckedChange={(checked) => handlePrivacyChange('show_activity_status', checked)} />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">Allow Tagging</span>
                  </div>
                  <Switch checked={privacySettings.allow_tagging} onCheckedChange={(checked) => handlePrivacyChange('allow_tagging', checked)} />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Settings className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">Show Listings Count</span>
                  </div>
                  <Switch checked={privacySettings.show_listings_count} onCheckedChange={(checked) => handlePrivacyChange('show_listings_count', checked)} />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <span className="text-sm">Show Followers & Following</span>
                      <p className="text-xs text-muted-foreground">Display follower and following counts on your business page</p>
                    </div>
                  </div>
                  <Switch checked={showFollowerCount} onCheckedChange={setShowFollowerCount} />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Globe className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">Show Social Links</span>
                  </div>
                  <Switch checked={privacySettings.show_social_links} onCheckedChange={(checked) => handlePrivacyChange('show_social_links', checked)} />
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent
          hideCloseButton
          className="w-[calc(100vw-32px)] max-w-[600px] md:max-w-[800px] lg:max-w-[900px] h-[85vh] sm:h-[80vh] p-0 bg-background border-border/50 gap-0 rounded-2xl mx-auto flex flex-col fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
        >
          {isLoading ? (
            <EditProfileSkeleton />
          ) : (
            <div className="flex flex-col md:flex-row h-full overflow-hidden">
              <div className="w-56 border-r border-border/50 bg-card/30 flex-shrink-0 hidden md:flex flex-col overflow-hidden">
                <div className="p-4 border-b border-border/50 flex-shrink-0">
                  <h3 className="font-bold text-base text-foreground">Edit Profile</h3>
                </div>
                <div className="flex-1 overflow-y-auto p-3">
                  <div className="space-y-1">
                    {sidebarItems.map((item) => (
                      <SidebarItem
                        key={item.id}
                        icon={item.icon}
                        label={item.label}
                        active={activeSection === item.id}
                        onClick={() => setActiveSection(item.id)}
                        disabled={item.disabled}
                      />
                    ))}
                  </div>

                  {!isBusinessSeller && (
                    <div className="mt-4 pt-4 border-t border-border/30">
                      <div className="p-3 rounded-xl border border-primary/20 bg-primary/5">
                        <div className="flex items-start gap-2 mb-2">
                          <Building className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                          <div>
                            <h4 className="text-sm font-semibold text-foreground leading-tight">Expand Your Reach</h4>
                            <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                              Upgrade for verified badges, analytics, job postings & more
                            </p>
                          </div>
                        </div>
                        <Button variant="default" size="sm" className="w-full mt-2 h-8 text-xs" onClick={() => (window.location.href = '/create-business-account')}>
                          <ChevronRight className="w-3 h-3 mr-1" />
                          Upgrade Now
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
                <div className="md:hidden border-b border-border/50 bg-card/50 flex-shrink-0">
                  <div className="flex items-center justify-between px-4 py-3">
                    <h3 className="font-bold text-base">Edit Profile</h3>
                    <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full h-8 w-8">
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="overflow-x-auto scrollbar-hide">
                    <div className="flex gap-1 px-3 pb-3 min-w-max">
                      {sidebarItems.map((item) => (
                        <Button
                          key={item.id}
                          variant={activeSection === item.id ? 'secondary' : 'ghost'}
                          size="sm"
                          onClick={() => setActiveSection(item.id)}
                          className="flex-shrink-0 gap-1.5 h-8 text-xs"
                        >
                          <item.icon className="w-3.5 h-3.5" />
                          {item.label}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto">
                  <div className="p-4 md:p-6 lg:p-8">{renderContent()}</div>
                </div>

                <div className="border-t border-border/50 p-3 md:p-4 bg-card/30 flex items-center justify-end gap-3 flex-shrink-0">
                  <Button variant="ghost" onClick={onClose} size="sm" className="hidden md:flex">
                    Cancel
                  </Button>
                  <Button onClick={handleSubmit} disabled={isSaving} size="sm" className="gap-2">
                    {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                    Save
                  </Button>
                </div>
              </div>

              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="absolute top-3 right-3 hidden md:flex rounded-full h-8 w-8"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <input ref={profileInputRef} type="file" accept="image/*" onChange={handleProfileImageSelect} className="hidden" />
      <input ref={coverInputRef} type="file" accept="image/*" onChange={handleCoverImageSelect} className="hidden" />
      <input ref={videoInputRef} type="file" accept="video/*" onChange={handleVideoUpload} className="hidden" />

      <Dialog open={showCropModal} onOpenChange={setShowCropModal}>
        <DialogContent className="w-[calc(100vw-32px)] max-w-lg p-0 bg-[#1a1a1a] border-0 overflow-hidden rounded-2xl fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <DialogHeader className="sr-only">
            <DialogTitle>{cropType === 'profile' ? 'Edit profile photo' : 'Edit cover image'}</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col h-[85vh] sm:h-auto">
            <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
              <Button variant="ghost" size="sm" onClick={() => setShowCropModal(false)} className="text-white/70 hover:text-white hover:bg-white/10">
                Cancel
              </Button>
              <h3 className="font-semibold text-white text-sm">{cropType === 'profile' ? 'Profile Photo' : 'Cover Image'}</h3>
              <div className="w-16" />
            </div>

            <div className="flex-1 flex items-center justify-center p-4 bg-[#0d0d0d] min-h-[300px]">
              {cropImage && (
                <div className="relative" style={{ transform: `rotate(${rotation}deg)`, transition: 'transform 0.3s ease' }}>
                  <ReactCrop
                    crop={crop}
                    onChange={(_, percentCrop) => setCrop(percentCrop)}
                    onComplete={(c) => setCompletedCrop(c)}
                    aspect={cropType === 'profile' ? 1 : 16 / 9}
                    circularCrop={cropType === 'profile'}
                    className="max-h-[50vh]"
                  >
                    <img ref={imgRef} src={cropImage} onLoad={onImageLoad} alt="Crop" className="max-h-[50vh] w-auto mx-auto rounded-lg" />
                  </ReactCrop>
                </div>
              )}
            </div>

            <div className="bg-[#262626] px-4 py-4 space-y-4">
              <div className="flex justify-center">
                <button type="button" onClick={handleRotate} className="flex flex-col items-center gap-1.5 p-3 rounded-xl hover:bg-white/10 transition-colors">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
                    <RotateCw className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-xs text-white/70">Rotate</span>
                </button>
              </div>

              <div className="flex items-center justify-center gap-2">
                <button type="button" className="px-4 py-2 rounded-full text-sm text-white/60 hover:bg-white/10 transition-colors">
                  <Sparkles className="w-4 h-4 inline mr-1.5" /> Suggestions
                </button>
                <button type="button" className="px-4 py-2 rounded-full text-sm text-white/60 hover:bg-white/10 transition-colors">
                  <Palette className="w-4 h-4 inline mr-1.5" /> Colour
                </button>
                <button type="button" className="px-4 py-2 rounded-full text-sm bg-white/20 text-white">
                  <CropIcon className="w-4 h-4 inline mr-1.5" /> Crop and rotate
                </button>
              </div>

              <div className="flex justify-center pt-2">
                <Button onClick={handleCropComplete} disabled={isUploadingProfile || isUploadingCover} className="px-8 rounded-full bg-primary hover:bg-primary/90">
                  {(isUploadingProfile || isUploadingCover) ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" /> Uploading...
                    </>
                  ) : (
                    'Next'
                  )}
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default EditProfileModal;
