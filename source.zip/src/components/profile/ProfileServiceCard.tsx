import React from 'react';
import { useNavigate } from 'react-router-dom';
import CatalogBullets from '@/components/service/CatalogBullets';
import { Pencil, Share2, Trash2, Zap, MapPin, Clock, Star, MoreHorizontal, CheckCircle, XCircle, Power, FolderPlus, Briefcase } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import { useCurrency } from '@/contexts/CurrencyContext';

interface ProfileServiceCardProps {
  id: string;
  title: string;
  description?: string | null;
  imageUrl: string | null;
  price?: number | null;
  location?: string;
  status?: string;
  category?: string;
  viewCount?: number;
  onEdit?: () => void;
  onShare?: () => void;
  onDelete?: () => void;
  onBoost?: () => void;
  onAddToCatalog?: () => void;
  onStatusChange?: (status: string) => void;
}

const ProfileServiceCard: React.FC<ProfileServiceCardProps> = ({
  id,
  title,
  description,
  imageUrl,
  price,
  location,
  status,
  category,
  viewCount = 0,
  onEdit,
  onShare,
  onDelete,
  onBoost,
  onAddToCatalog,
  onStatusChange,
}) => {
  const navigate = useNavigate();
  const { formatPriceCompact } = useCurrency();

  const stopProp = (e: React.MouseEvent) => e.stopPropagation();

  const statusStyles: Record<string, string> = {
    active: 'bg-green-500/10 text-green-600 border-green-500/20',
    inactive: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
    sold: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  };

  return (
    <div
      className="bg-card border border-border rounded-xl overflow-hidden cursor-pointer hover:shadow-md transition-shadow group"
      onClick={() => navigate(`/service/${id}`)}
    >
      <div className="flex gap-3 p-3">
        {/* Service image */}
        <div className="w-24 h-24 flex-shrink-0 rounded-lg overflow-hidden bg-muted">
          {imageUrl ? (
            <img src={imageUrl} alt={title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Star className="w-8 h-8 text-muted-foreground/50" />
            </div>
          )}
        </div>

        {/* Service details */}
        <div className="flex-1 min-w-0 space-y-1">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-semibold text-sm text-foreground line-clamp-1">{title}</h3>
            {status && (
              <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 flex-shrink-0", statusStyles[status])}>
                {status}
              </Badge>
            )}
          </div>

          {description && (
            <p className="text-xs text-muted-foreground line-clamp-2">{description}</p>
          )}

          <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
            {category && <span className="bg-muted px-1.5 py-0.5 rounded">{category}</span>}
            {location && (
              <span className="flex items-center gap-0.5">
                <MapPin className="w-2.5 h-2.5" />{location}
              </span>
            )}
            {viewCount > 0 && <span>{viewCount} views</span>}
          </div>

          {price != null && (
            <p className="text-sm font-bold text-primary">
              From {formatPriceCompact(price)}
            </p>
          )}

          {/* Catalog bullets */}
          <CatalogBullets adId={id} maxItems={2} compact />
        </div>
      </div>

      {/* Action bar */}
      <div className="flex items-center gap-1 px-3 pb-2.5 pt-0">
        <Button
          size="sm"
          variant="ghost"
          className="h-7 px-2 text-xs gap-1 text-primary"
          onClick={(e) => { stopProp(e); navigate(`/workspace/manage/${id}`); }}
        >
          <Briefcase className="w-3 h-3" />Manage workspace
        </Button>
        {onEdit && (
          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1" onClick={(e) => { stopProp(e); onEdit(); }}>
            <Pencil className="w-3 h-3" />Edit
          </Button>
        )}
        {onShare && (
          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1" onClick={(e) => { stopProp(e); onShare(); }}>
            <Share2 className="w-3 h-3" />Share
          </Button>
        )}
        {onAddToCatalog && (
          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1" onClick={(e) => { stopProp(e); onAddToCatalog(); }}>
            <FolderPlus className="w-3 h-3" />Catalog
          </Button>
        )}

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button size="icon" variant="ghost" className="h-7 w-7 ml-auto" onClick={stopProp}>
              <MoreHorizontal className="w-3.5 h-3.5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" onClick={stopProp}>
            {onStatusChange && (
              <>
                {status === 'active' && (
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onStatusChange('inactive'); }}>
                    <XCircle className="w-4 h-4 mr-2 text-yellow-500" />Deactivate
                  </DropdownMenuItem>
                )}
                {status === 'inactive' && (
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onStatusChange('active'); }}>
                    <Power className="w-4 h-4 mr-2 text-green-500" />Reactivate
                  </DropdownMenuItem>
                )}
              </>
            )}
            {onDelete && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDelete(); }} className="text-destructive focus:text-destructive">
                  <Trash2 className="w-4 h-4 mr-2" />Delete
                </DropdownMenuItem>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
};

export default ProfileServiceCard;
