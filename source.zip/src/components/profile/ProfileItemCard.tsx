import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Pencil, Share2, Trash2, Zap, Pin, PinOff, Users, MoreHorizontal, CheckCircle, XCircle, Power, Percent } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { usePromotionDiscount } from '@/hooks/usePromotionDiscount';
import { useCurrency } from '@/contexts/CurrencyContext';

interface ProfileItemCardProps {
  id: string;
  title: string;
  imageUrl: string | null;
  fallbackIcon: React.ReactNode;
  price?: number | null;
  originalPrice?: number | null;
  lastViewedAt?: string | null;
  viewCount?: number;
  isPinned?: boolean;
  canPin?: boolean;
  listingType?: string;
  applyMethod?: string;
  status?: string;
  hasDiscount?: boolean;
  discountPercent?: number;
  onEdit?: () => void;
  onShare?: () => void;
  onPin?: () => void;
  onUnpin?: () => void;
  onDelete?: () => void;
  onBoost?: () => void;
  onStatusChange?: (status: string) => void;
}

const ProfileItemCard: React.FC<ProfileItemCardProps> = ({
  id,
  title,
  imageUrl,
  fallbackIcon,
  price,
  originalPrice,
  isPinned = false,
  canPin = false,
  listingType,
  applyMethod,
  status,
  hasDiscount: propHasDiscount,
  discountPercent: propDiscountPercent,
  onEdit,
  onShare,
  onPin,
  onUnpin,
  onDelete,
  onBoost,
  onStatusChange,
}) => {
  const navigate = useNavigate();
  const { formatPriceCompact } = useCurrency();

  // Check for promotion-linked discounts (only for products)
  const isProduct = listingType === 'physical_products' || listingType === 'digital_products' || !listingType;
  const { data: promotionDiscount } = usePromotionDiscount(isProduct ? id : undefined);

  const hasActiveDiscount = propHasDiscount || promotionDiscount?.hasActivePromotion;
  const discountPercent = promotionDiscount?.hasActivePromotion
    ? promotionDiscount.discountPercentage
    : (propDiscountPercent || 0);

  const isJobWithEarlyMarket = listingType === 'jobs' && applyMethod === 'earlymarket';

  const stopProp = (e: React.MouseEvent) => e.stopPropagation();

  const handleClick = () => {
    const route = listingType === 'jobs' ? `/job/${id}`
      : listingType === 'services' ? `/service/${id}`
      : listingType === 'promotions' ? `/promotion/${id}`
      : `/ad/${id}`;
    navigate(route);
  };

  const handlePinToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    isPinned ? onUnpin?.() : onPin?.();
  };

  // Status badge styles
  const statusStyles: Record<string, string> = {
    active: 'bg-green-500/90 text-white',
    inactive: 'bg-yellow-500/90 text-white',
    sold: 'bg-blue-500/90 text-white',
    deleted: 'bg-red-500/90 text-white',
    under_review: 'bg-amber-500/90 text-white',
  };

  const statusLabels: Record<string, string> = {
    under_review: 'In Review',
  };

  return (
    <div
      className="relative aspect-[3/4] bg-muted overflow-hidden cursor-pointer group rounded-lg"
      onClick={handleClick}
    >
      {/* Full Image */}
      {imageUrl ? (
        <img
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center bg-muted">
          {fallbackIcon}
        </div>
      )}

      {/* Top-left badges */}
      <div className="absolute top-2 left-2 z-10 flex flex-col gap-1">
        {status && (
          <Badge className={cn("text-[10px] px-1.5 py-0.5", statusStyles[status] || 'bg-muted')}>
            {statusLabels[status] || status}
          </Badge>
        )}
        {hasActiveDiscount && discountPercent > 0 && (
          <Badge className="bg-destructive text-destructive-foreground text-[10px] px-1.5 py-0.5 flex items-center gap-0.5">
            <Percent className="w-2.5 h-2.5" />
            {discountPercent}% OFF
          </Badge>
        )}
        {isPinned && (
          <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center shadow-md">
            <Pin className="w-2.5 h-2.5 text-primary-foreground" />
          </div>
        )}
      </div>

      {/* Bottom gradient overlay with content */}
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent pt-16 pb-2.5 px-2.5">
        {/* Title */}
        <p className="text-white text-xs font-semibold line-clamp-1 mb-0.5">{title}</p>

        {/* Price */}
        {price != null && (
          <div className="flex items-center gap-1.5 mb-2">
            <span className="text-white text-[11px] font-bold">
              List: {formatPriceCompact(price)}
            </span>
            {originalPrice && originalPrice > price && (
              <span className="text-white/60 text-[9px] line-through">
                {formatPriceCompact(originalPrice)}
              </span>
            )}
          </div>
        )}

      {/* Action buttons row */}
        <div className="flex items-center gap-1">
          {onShare && (
            <Button
              size="icon"
              variant="ghost"
              className="h-7 w-7 bg-white/15 hover:bg-white/30 text-white rounded-full"
              onClick={(e) => { stopProp(e); onShare(); }}
              title="Share"
            >
              <Share2 className="w-3.5 h-3.5" />
            </Button>
          )}
          {onEdit && (
            <Button
              size="icon"
              variant="ghost"
              className="h-7 w-7 bg-white/15 hover:bg-white/30 text-white rounded-full"
              onClick={(e) => { stopProp(e); onEdit(); }}
              title="Edit"
            >
              <Pencil className="w-3.5 h-3.5" />
            </Button>
          )}
          {/* Pin/Unpin button (replaces delete) */}
          {canPin && (
            <Button
              size="icon"
              variant="ghost"
              className={cn(
                "h-7 w-7 rounded-full",
                isPinned ? "bg-primary/80 hover:bg-primary text-white" : "bg-white/15 hover:bg-white/30 text-white"
              )}
              onClick={handlePinToggle}
              title={isPinned ? "Unpin" : "Pin to Profile"}
            >
              {isPinned ? <PinOff className="w-3.5 h-3.5" /> : <Pin className="w-3.5 h-3.5" />}
            </Button>
          )}

          {/* More menu for additional options */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                size="icon"
                variant="ghost"
                className="h-7 w-7 bg-white/15 hover:bg-white/30 text-white rounded-full ml-auto"
                onClick={stopProp}
                onPointerDown={stopProp}
              >
                <MoreHorizontal className="w-3.5 h-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" onClick={stopProp} onPointerDown={stopProp}>
              {isJobWithEarlyMarket && (
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); navigate(`/job/${id}/applications`); }}>
                  <Users className="w-4 h-4 mr-2" />View Applications
                </DropdownMenuItem>
              )}
              {onStatusChange && (
                <>
                  {status === 'active' && (
                    <>
                      <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onStatusChange('sold'); }}>
                        <CheckCircle className="w-4 h-4 mr-2 text-blue-500" />Mark as Sold
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onStatusChange('inactive'); }}>
                        <XCircle className="w-4 h-4 mr-2 text-yellow-500" />Deactivate
                      </DropdownMenuItem>
                    </>
                  )}
                  {status === 'inactive' && (
                    <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onStatusChange('active'); }}>
                      <Power className="w-4 h-4 mr-2 text-green-500" />Reactivate
                    </DropdownMenuItem>
                  )}
                  {status === 'sold' && (
                    <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onStatusChange('active'); }}>
                      <Power className="w-4 h-4 mr-2 text-green-500" />Relist
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                </>
              )}
              {onDelete && (
                <DropdownMenuItem 
                  className="text-destructive focus:text-destructive"
                  onClick={(e) => { e.stopPropagation(); onDelete(); }}
                >
                  <Trash2 className="w-4 h-4 mr-2" />Delete
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
};

export default ProfileItemCard;
