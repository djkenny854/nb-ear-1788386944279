import React, { useMemo, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { Image as ImageIcon, Download, Trash2, Sparkles, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface MediaRow {
  id: string;
  url: string;
  storage_path: string | null;
  source: string;
  prompt: string | null;
  created_at: string;
  width: number | null;
  height: number | null;
}

type Filter = 'all' | 'ai' | 'promotion' | 'service';

const PAGE_SIZE = 24;

const downloadImage = async (url: string, name: string) => {
  try {
    const res = await fetch(url, { mode: 'cors' });
    const blob = await res.blob();
    const obj = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = obj;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(obj);
  } catch {
    // Fallback: open in new tab
    window.open(url, '_blank');
  }
};

const MyMediaTab: React.FC = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<Filter>('all');
  const [page, setPage] = useState(0);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const queryKey = ['user-generated-media', user?.id, filter];

  const { data, isLoading, isFetching } = useQuery({
    queryKey: [...queryKey, page],
    queryFn: async () => {
      if (!user) return { rows: [] as MediaRow[], hasMore: false };
      let q = supabase
        .from('user_generated_media')
        .select('id,url,storage_path,source,prompt,created_at,width,height')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .range(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE - 1);
      if (filter === 'promotion') q = q.eq('source', 'promotion');
      else if (filter === 'service') q = q.eq('source', 'service');
      else if (filter === 'ai') q = q.in('source', ['promotion', 'service', 'other']);
      const { data, error } = await q;
      if (error) throw error;
      return { rows: (data || []) as MediaRow[], hasMore: (data?.length || 0) === PAGE_SIZE };
    },
    enabled: !!user,
  });

  const allItems = useMemo(() => data?.rows || [], [data]);

  const handleDelete = async (row: MediaRow) => {
    if (!confirm('Delete this image? This cannot be undone.')) return;
    setDeletingId(row.id);
    try {
      if (row.storage_path) {
        await supabase.storage.from('product-images').remove([row.storage_path]).catch(() => {});
      }
      const { error } = await supabase.from('user_generated_media').delete().eq('id', row.id);
      if (error) throw error;
      toast.success('Image deleted');
      queryClient.invalidateQueries({ queryKey });
    } catch (e: any) {
      toast.error(e?.message || 'Failed to delete');
    } finally {
      setDeletingId(null);
    }
  };

  const filters: { id: Filter; label: string }[] = [
    { id: 'all', label: 'All' },
    { id: 'ai', label: 'EarlyMarket AI' },
    { id: 'promotion', label: 'Promotions' },
    { id: 'service', label: 'Services' },
  ];

  return (
    <div className="p-3 sm:p-4">
      <div className="flex items-center gap-2 mb-4 overflow-x-auto scrollbar-thin pb-1">
        {filters.map(f => (
          <button
            key={f.id}
            onClick={() => { setFilter(f.id); setPage(0); }}
            className={cn(
              'shrink-0 px-3 py-1.5 rounded-full text-xs font-medium border transition-colors',
              filter === f.id
                ? 'bg-primary text-primary-foreground border-primary'
                : 'bg-background text-muted-foreground border-border hover:bg-accent'
            )}
          >
            {f.id === 'ai' && <Sparkles className="w-3 h-3 inline mr-1" />}
            {f.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="aspect-square rounded-lg bg-muted animate-pulse" />
          ))}
        </div>
      ) : allItems.length === 0 ? (
        <div className="p-12 text-center border border-dashed border-border rounded-xl">
          <ImageIcon className="w-12 h-12 mx-auto text-muted-foreground mb-3 opacity-60" />
          <h3 className="font-semibold mb-1">No media yet</h3>
          <p className="text-sm text-muted-foreground">
            Images you generate with EarlyMarket AI will appear here.
          </p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
            {allItems.map(row => (
              <div key={row.id} className="group relative aspect-square rounded-lg overflow-hidden bg-muted border border-border">
                <img
                  src={row.url}
                  alt={row.prompt || 'Generated image'}
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute top-1.5 left-1.5">
                  <span className="px-1.5 py-0.5 rounded-full text-[10px] font-medium bg-black/60 text-white backdrop-blur-sm">
                    <Sparkles className="w-2.5 h-2.5 inline mr-0.5" />
                    {row.source === 'promotion' ? 'Promo' : row.source === 'service' ? 'Service' : 'AI'}
                  </span>
                </div>
                <div className="absolute inset-x-0 bottom-0 p-1.5 flex gap-1 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    size="sm"
                    variant="secondary"
                    className="flex-1 h-7 text-[11px] gap-1"
                    onClick={() => downloadImage(row.url, `earlymarket-${row.id}.png`)}
                  >
                    <Download className="w-3 h-3" /> Download
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    className="h-7 w-7 p-0"
                    disabled={deletingId === row.id}
                    onClick={() => handleDelete(row)}
                  >
                    {deletingId === row.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Trash2 className="w-3 h-3" />}
                  </Button>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-center gap-2 mt-6">
            {page > 0 && (
              <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(0, p - 1))}>
                ← Previous
              </Button>
            )}
            {data?.hasMore && (
              <Button variant="outline" size="sm" onClick={() => setPage(p => p + 1)} disabled={isFetching}>
                {isFetching ? <Loader2 className="w-3 h-3 animate-spin" /> : 'Load more →'}
              </Button>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default MyMediaTab;
