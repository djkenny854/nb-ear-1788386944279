import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Pencil, Share2, Trash2, Zap, MapPin, Briefcase, Users, Clock, MoreHorizontal, XCircle, Power } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

interface ProfileJobCardProps {
  id: string;
  title: string;
  imageUrl: string | null;
  location?: string;
  status?: string;
  category?: string;
  viewCount?: number;
  createdAt?: string;
  applyMethod?: string;
  onEdit?: () => void;
  onShare?: () => void;
  onDelete?: () => void;
  onBoost?: () => void;
  onStatusChange?: (status: string) => void;
}

const ProfileJobCard: React.FC<ProfileJobCardProps> = ({
  id,
  title,
  imageUrl,
  location,
  status,
  category,
  viewCount = 0,
  createdAt,
  applyMethod,
  onEdit,
  onShare,
  onDelete,
  onBoost,
  onStatusChange,
}) => {
  const navigate = useNavigate();
  const stopProp = (e: React.MouseEvent) => e.stopPropagation();

  const isEarlyMarket = applyMethod === 'earlymarket';
  const postedAgo = createdAt ? formatDistanceToNow(new Date(createdAt), { addSuffix: true }) : null;

  const statusStyles: Record<string, string> = {
    active: 'bg-green-500/10 text-green-600 border-green-500/20',
    inactive: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
    sold: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  };

  return (
    <div
      className="bg-card border border-border rounded-xl overflow-hidden cursor-pointer hover:shadow-md transition-shadow group"
      onClick={() => navigate(`/job/${id}`)}
    >
      <div className="flex gap-3 p-3">
        {/* Job image/logo */}
        <div className="w-14 h-14 flex-shrink-0 rounded-lg overflow-hidden bg-muted">
          {imageUrl ? (
            <img src={imageUrl} alt={title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Briefcase className="w-6 h-6 text-muted-foreground/50" />
            </div>
          )}
        </div>

        {/* Job details */}
        <div className="flex-1 min-w-0 space-y-1">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-semibold text-sm text-foreground line-clamp-1">{title}</h3>
            {status && (
              <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 flex-shrink-0", statusStyles[status])}>
                {status}
              </Badge>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2 text-[10px] text-muted-foreground">
            {category && <span className="bg-muted px-1.5 py-0.5 rounded">{category}</span>}
            {location && (
              <span className="flex items-center gap-0.5">
                <MapPin className="w-2.5 h-2.5" />{location}
              </span>
            )}
            {postedAgo && (
              <span className="flex items-center gap-0.5">
                <Clock className="w-2.5 h-2.5" />{postedAgo}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
            {viewCount > 0 && <span>{viewCount} views</span>}
          </div>
        </div>
      </div>

      {/* Action bar */}
      <div className="flex items-center gap-1 px-3 pb-2.5 pt-0">
        {onEdit && (
          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1" onClick={(e) => { stopProp(e); onEdit(); }}>
            <Pencil className="w-3 h-3" />Edit
          </Button>
        )}
        {onShare && (
          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1" onClick={(e) => { stopProp(e); onShare(); }}>
            <Share2 className="w-3 h-3" />Share
          </Button>
        )}
        {isEarlyMarket && (
          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1 text-emerald-600" onClick={(e) => { stopProp(e); navigate(`/job/${id}/applications`); }}>
            <Users className="w-3 h-3" />Applications
          </Button>
        )}


        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button size="icon" variant="ghost" className="h-7 w-7 ml-auto" onClick={stopProp}>
              <MoreHorizontal className="w-3.5 h-3.5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" onClick={stopProp}>
            {onStatusChange && (
              <>
                {status === 'active' && (
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onStatusChange('inactive'); }}>
                    <XCircle className="w-4 h-4 mr-2 text-yellow-500" />Deactivate
                  </DropdownMenuItem>
                )}
                {status === 'inactive' && (
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onStatusChange('active'); }}>
                    <Power className="w-4 h-4 mr-2 text-green-500" />Reactivate
                  </DropdownMenuItem>
                )}
              </>
            )}
            {onDelete && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDelete(); }} className="text-destructive focus:text-destructive">
                  <Trash2 className="w-4 h-4 mr-2" />Delete
                </DropdownMenuItem>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
};

export default ProfileJobCard;
