import React, { useEffect, useState } from 'react';
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';

interface NativeSplashScreenProps {
  onFinish: () => void;
}

const NativeSplashScreen: React.FC<NativeSplashScreenProps> = ({ onFinish }) => {
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setFadeOut(true), 2600);
    const finish = setTimeout(onFinish, 3000);
    return () => {
      clearTimeout(timer);
      clearTimeout(finish);
    };
  }, [onFinish]);

  return (
    <div
      className={`fixed inset-0 z-[100] bg-background flex items-center justify-center transition-opacity duration-400 ${
        fadeOut ? 'opacity-0' : 'opacity-100'
      }`}
    >
      <div className="relative w-28 h-28 flex items-center justify-center">
        {/* Google Material Design wavy spinner */}
        <svg
          className="absolute inset-0 w-full h-full splash-spinner-rotate"
          viewBox="0 0 100 100"
        >
          <circle
            cx="50"
            cy="50"
            r="44"
            fill="none"
            stroke="hsl(var(--primary))"
            strokeWidth="3"
            strokeLinecap="round"
            className="splash-spinner-dash"
          />
        </svg>

        {/* Logo centered inside */}
        <img
          src={earlymarketLogo}
          alt="EarlyMarket"
          className="w-14 h-14 object-contain relative z-10"
        />
      </div>

      {/* Google Material Design spinner keyframes */}
      <style>{`
        .splash-spinner-rotate {
          animation: splash-rotate 1.4s linear infinite;
        }
        .splash-spinner-dash {
          stroke-dasharray: 1 276;
          animation: splash-dash 1.4s ease-in-out infinite;
          transform-origin: center;
        }
        @keyframes splash-rotate {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes splash-dash {
          0% {
            stroke-dasharray: 1 276;
            stroke-dashoffset: 0;
          }
          50% {
            stroke-dasharray: 120 276;
            stroke-dashoffset: -40;
          }
          100% {
            stroke-dasharray: 1 276;
            stroke-dashoffset: -245;
          }
        }
      `}</style>
    </div>
  );
};

export default NativeSplashScreen;
