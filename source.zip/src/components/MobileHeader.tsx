import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/components/auth/AuthContext';
import NotificationBell from './notifications/NotificationBell';
import AnimatedSearchBar from './search/AnimatedSearchBar';
import logoUrl from '@/assets/earlymarket-logo-new.png';

const MobileHeader: React.FC = () => {
  const { user } = useAuth();
  const [searchExpanded, setSearchExpanded] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 lg:hidden">
        <div className="container flex h-14 items-center justify-between px-4">
          {/* Logo + wordmark */}
          <Link to="/" className="flex items-center gap-2" aria-label="EarlyMarket home">
            <img src={logoUrl} alt="EarlyMarket" className="h-9 w-auto object-contain" />
            <span
              className="text-foreground font-semibold tracking-tight text-[19px] leading-none"
            >
              EarlyMarket
            </span>
          </Link>

          {/* Right Side - Search and Notifications */}
          <div className="flex items-center space-x-2">
            {/* Search Icon that expands */}
            <AnimatedSearchBar 
              isExpanded={searchExpanded} 
              onExpandChange={setSearchExpanded} 
            />

            {/* Notifications - only show if user is logged in and search not expanded */}
            {user && !searchExpanded && (
              <NotificationBell onChatOpen={(sellerId) => console.log('Open chat with seller:', sellerId)} />
            )}
          </div>
        </div>
      </header>
      
      {/* Overlay when search is expanded */}
      {searchExpanded && (
        <div 
          className="fixed inset-0 bg-black/20 z-40 lg:hidden"
          onClick={() => setSearchExpanded(false)}
        />
      )}
    </>
  );
};

export default MobileHeader;
