
import React from 'react';
import { cn } from '@/lib/utils';

interface ProductSkeletonProps {
  count?: number;
  layout?: 'grid' | 'list' | 'carousel';
}

// Shimmer skeleton block matching HomeProductCard shape
const ShimmerBox = ({ className }: { className?: string }) => (
  <div className={cn("bg-muted/60 rounded skeleton-shimmer", className)} />
);

const ProductCardSkeleton = () => (
  <div className="bg-transparent rounded-xl overflow-hidden w-full flex flex-col animate-fade-in">
    {/* Image - aspect-square like HomeProductCard */}
    <ShimmerBox className="aspect-square w-full rounded-xl" />
    
    {/* Content */}
    <div className="pt-2.5 space-y-1.5 w-full">
      {/* Time + Location */}
      <div className="flex items-center justify-between">
        <ShimmerBox className="h-2.5 w-14 rounded" />
        <ShimmerBox className="h-2.5 w-16 rounded" />
      </div>
      
      {/* Title - 2 lines */}
      <ShimmerBox className="h-3.5 w-full rounded" />
      <ShimmerBox className="h-3.5 w-3/4 rounded" />
      
      {/* Price + bookmark */}
      <div className="flex items-center justify-between">
        <ShimmerBox className="h-4 w-20 rounded" />
        <ShimmerBox className="w-6 h-6 rounded-full" />
      </div>
      
      {/* Assurance text */}
      <ShimmerBox className="h-2.5 w-16 rounded" />
      
      {/* Seller */}
      <div className="flex items-center gap-1.5 pt-1">
        <ShimmerBox className="w-4 h-4 rounded-full" />
        <ShimmerBox className="h-2.5 w-20 rounded" />
      </div>
    </div>
  </div>
);

const ProductSkeleton: React.FC<ProductSkeletonProps> = ({ count = 8, layout = 'grid' }) => {
  const skeletons = Array.from({ length: count }, (_, i) => i);

  if (layout === 'carousel') {
    return (
      <div className="flex gap-3 overflow-hidden">
        {skeletons.slice(0, 5).map((index) => (
          <ProductCardSkeleton key={index} />
        ))}
      </div>
    );
  }

  if (layout === 'list') {
    return (
      <div className="space-y-3">
        {skeletons.map((index) => (
          <div key={index} className="flex gap-3 rounded-xl p-3 animate-fade-in">
            <ShimmerBox className="h-20 w-20 rounded-xl flex-shrink-0" />
            <div className="flex-1 space-y-2">
              <ShimmerBox className="h-4 w-3/4 rounded" />
              <ShimmerBox className="h-3 w-1/2 rounded" />
              <div className="flex justify-between items-center">
                <ShimmerBox className="h-4 w-20 rounded" />
                <ShimmerBox className="h-3 w-12 rounded" />
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-2.5 sm:gap-3.5 md:gap-4 lg:gap-4.5 w-full">
      {skeletons.map((index) => (
        <ProductCardSkeleton key={index} />
      ))}
    </div>
  );
};

export const CategorySkeleton: React.FC = () => (
  <div className="px-4 py-6">
    <ShimmerBox className="h-8 w-48 mb-4 rounded" />
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-4">
      {Array.from({ length: 8 }).map((_, index) => (
        <div key={index} className="p-4 text-center rounded-lg animate-fade-in">
          <ShimmerBox className="w-12 h-12 mx-auto mb-2 rounded-full" />
          <ShimmerBox className="h-3 w-16 mx-auto rounded" />
        </div>
      ))}
    </div>
  </div>
);

export const BannerSkeleton: React.FC = () => (
  <div className="relative h-96 bg-muted/30 rounded-2xl overflow-hidden skeleton-shimmer">
    <div className="absolute inset-0 flex items-center justify-center">
      <div className="text-center space-y-4">
        <ShimmerBox className="h-12 w-64 mx-auto rounded-lg" />
        <ShimmerBox className="h-6 w-96 mx-auto rounded-lg" />
        <ShimmerBox className="h-12 w-32 mx-auto rounded-full" />
      </div>
    </div>
  </div>
);

export default ProductSkeleton;
