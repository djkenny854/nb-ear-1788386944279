import React from 'react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { useNavigate } from 'react-router-dom';
import { getSellerProfileUrl } from '@/lib/sellerUrl';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';

interface SellerCardProps {
  seller: {
    id: string;
    business_name: string;
    business_logo_url: string | null;
    business_bio: string | null;
    business_category: string;
    is_verified: boolean;
    verification_badge_color?: BadgeColor;
    verification_score: number;
    district: string;
    sub_county: string;
    store_slug: string;
  };
}

const SellerCard: React.FC<SellerCardProps> = ({ seller }) => {
  const navigate = useNavigate();

  return (
    <div 
      className="flex flex-col items-center gap-3 min-w-[140px] cursor-pointer group"
      onClick={() => navigate(getSellerProfileUrl(seller))}
    >
      <div className="relative">
        <Avatar className="w-32 h-32 border-2 border-border transition-all duration-300 group-hover:border-primary group-hover:scale-105">
          <AvatarImage 
            src={seller.business_logo_url || ''} 
            alt={seller.business_name}
            className="object-cover"
          />
          <AvatarFallback className="bg-muted text-foreground font-semibold text-2xl">
            {seller.business_name.slice(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        {seller.is_verified && (
          <div className="absolute -bottom-1 -right-1">
            <UnifiedVerifiedBadge 
              isVerified={seller.is_verified} 
              badgeColor={seller.verification_badge_color}
              size="md" 
            />
          </div>
        )}
      </div>
      
      <div className="text-center">
        <h3 className="font-semibold text-sm truncate max-w-[140px] group-hover:text-primary transition-colors">
          {seller.business_name}
        </h3>
        <p className="text-xs text-muted-foreground">{seller.business_category}</p>
      </div>
    </div>
  );
};

export default SellerCard;
