import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Eye, EyeOff, Mail, Check } from 'lucide-react';
import XIcon from '@/assets/social-icons/x.svg';

const GoogleIcon = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5">
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
  </svg>
);

interface ProviderInfo {
  provider: string;
  label: string;
}

// Hoisted OUTSIDE the form so identity is stable across renders.
// Defining this inside PasswordChangeForm caused the input to remount on
// every keystroke, which closes the on-screen keyboard on Android.
const PasswordInput = React.memo(({
  id, label, value, onChange, show, onToggle, autoComplete, placeholder,
}: {
  id: string; label: string; value: string; onChange: (v: string) => void;
  show: boolean; onToggle: () => void; autoComplete: string; placeholder: string;
}) => (
  <div>
    <Label htmlFor={id} className="text-sm">{label}</Label>
    <div className="relative mt-1">
      <Input
        id={id}
        type={show ? 'text' : 'password'}
        autoComplete={autoComplete}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="pr-10"
      />
      <button
        type="button"
        onClick={onToggle}
        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
      >
        {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
      </button>
    </div>
  </div>
));
PasswordInput.displayName = 'PasswordInput';

const PasswordChangeForm = () => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [hasEmailIdentity, setHasEmailIdentity] = useState(false);
  const [linkedProviders, setLinkedProviders] = useState<ProviderInfo[]>([]);
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  useEffect(() => {
    const checkProviders = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const providers: ProviderInfo[] = [];
        const identities = user.identities || [];
        
        for (const identity of identities) {
          if (identity.provider === 'email') {
            providers.push({ provider: 'email', label: 'Email' });
          } else if (identity.provider === 'google') {
            providers.push({ provider: 'google', label: 'Google' });
          } else if (identity.provider === 'twitter' || identity.provider === 'x') {
            providers.push({ provider: 'twitter', label: 'X (Twitter)' });
          }
        }
        
        setLinkedProviders(providers);
        setHasEmailIdentity(identities.some(i => i.provider === 'email'));
      }
    };
    checkProviders();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (newPassword !== confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }

    if (newPassword.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }

    setIsUpdating(true);
    try {
      // If user already has an email identity, verify current password first.
      // OAuth-only users (Google/X) skip this step — they have no password to verify.
      if (hasEmailIdentity) {
        if (!currentPassword) {
          toast.error('Please enter your current password');
          setIsUpdating(false);
          return;
        }
        const { data: { user } } = await supabase.auth.getUser();
        if (user?.email) {
          const { error: signInError } = await supabase.auth.signInWithPassword({
            email: user.email,
            password: currentPassword,
          });
          if (signInError) {
            toast.error('Current password is incorrect');
            setIsUpdating(false);
            return;
          }
        }
      }

      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });
      if (error) throw error;

      // Refresh the session so the new email identity is reflected immediately.
      try { await supabase.auth.refreshSession(); } catch {}
      
      toast.success(hasEmailIdentity ? 'Password updated successfully' : 'Password created successfully');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      
      // Refresh provider status - they now have email identity
      if (!hasEmailIdentity) {
        setHasEmailIdentity(true);
        setLinkedProviders(prev => {
          if (!prev.some(p => p.provider === 'email')) {
            return [...prev, { provider: 'email', label: 'Email' }];
          }
          return prev;
        });
      }
    } catch (error: any) {
      toast.error(error?.message || 'Failed to update password');
    } finally {
      setIsUpdating(false);
    }
  };

  const ProviderIcon = ({ provider }: { provider: string }) => {
    if (provider === 'google') return <GoogleIcon />;
    if (provider === 'twitter') return <img src={XIcon} alt="X" className="w-4 h-4 dark:invert" />;
    return <Mail className="w-4 h-4 text-muted-foreground" />;
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 py-2">
      {/* All linked providers */}
      <div className="space-y-2">
        <p className="text-xs text-muted-foreground font-medium">Linked accounts</p>
        <div className="flex flex-wrap gap-2">
          {linkedProviders.map((p) => (
            <div key={p.provider} className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-muted/50 border border-border/50">
              <ProviderIcon provider={p.provider} />
              <span className="text-xs font-medium">{p.label}</span>
              <Check className="w-3 h-3 text-green-500" />
            </div>
          ))}
        </div>
        {!hasEmailIdentity && (
          <p className="text-xs text-muted-foreground">
            Set a password to also sign in with email
          </p>
        )}
      </div>

      {hasEmailIdentity && (
        <PasswordInput
          id="currentPassword"
          label="Current Password"
          value={currentPassword}
          onChange={setCurrentPassword}
          show={showCurrent}
          onToggle={() => setShowCurrent(!showCurrent)}
          autoComplete="current-password"
          placeholder="Enter current password"
        />
      )}

      <PasswordInput
        id="newPassword"
        label={hasEmailIdentity ? "New Password" : "Create Password"}
        value={newPassword}
        onChange={setNewPassword}
        show={showNew}
        onToggle={() => setShowNew(!showNew)}
        autoComplete="new-password"
        placeholder={hasEmailIdentity ? "Enter new password" : "Create a password"}
      />

      <PasswordInput
        id="confirmPassword"
        label="Confirm Password"
        value={confirmPassword}
        onChange={setConfirmPassword}
        show={showConfirm}
        onToggle={() => setShowConfirm(!showConfirm)}
        autoComplete="new-password"
        placeholder="Confirm password"
      />

      <Button 
        type="submit" 
        disabled={isUpdating || (hasEmailIdentity && !currentPassword) || !newPassword}
        size="sm"
      >
        {isUpdating ? 'Updating...' : hasEmailIdentity ? 'Change Password' : 'Set Password'}
      </Button>
    </form>
  );
};

export default PasswordChangeForm;
