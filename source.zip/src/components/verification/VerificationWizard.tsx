import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  ShieldCheck, 
  Building2, 
  Star, 
  CheckCircle2,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';

// Import step components
import NewIdentityVerificationStep from './steps/NewIdentityVerificationStep';
import BusinessVerificationStep from './steps/BusinessVerificationStep';
import QualityVerificationStep from './steps/QualityVerificationStep';
import ReviewSubmitStep from './steps/ReviewSubmitStep';

interface VerificationWizardProps {
  onComplete?: () => void;
}

const VerificationWizard: React.FC<VerificationWizardProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [formData, setFormData] = useState<any>({});
  const [stepValidation, setStepValidation] = useState<Record<number, boolean>>({});
  const { theme } = useTheme();
  const { toast } = useToast();

  const steps = [
    {
      id: 0,
      title: 'Identity Verification',
      icon: ShieldCheck,
      description: 'Verify your identity with government-issued documents',
      component: NewIdentityVerificationStep,
      required: true
    },
    {
      id: 1,
      title: 'Business Verification',
      icon: Building2,
      description: 'Provide business documents and information',
      component: BusinessVerificationStep,
      required: false
    },
    {
      id: 2,
      title: 'Quality Standards',
      icon: Star,
      description: 'Meet platform quality requirements',
      component: QualityVerificationStep,
      required: false
    },
    {
      id: 3,
      title: 'Review & Submit',
      icon: CheckCircle2,
      description: 'Review your information and submit',
      component: ReviewSubmitStep,
      required: true
    }
  ];

  const CurrentStepComponent = steps[currentStep].component;
  const progress = ((currentStep + 1) / steps.length) * 100;

  const handleStepValidation = useCallback((stepId: number, isValid: boolean) => {
    setStepValidation(prev => ({ ...prev, [stepId]: isValid }));
  }, []);

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      // Check if step 0 is complete before allowing to proceed
      if (currentStep === 0 && !stepValidation[0]) {
        toast({
          title: "Complete Required Fields",
          description: "Please complete all required fields and verify your documents before proceeding.",
          variant: "destructive",
        });
        return;
      }
      
      setCompletedSteps(prev => [...new Set([...prev, currentStep])]);
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleStepClick = (stepId: number) => {
    // Only allow navigation to completed steps or current step
    // For step 0, always allow. For other steps, require previous step to be completed OR be the current step
    if (stepId === 0) {
      setCurrentStep(stepId);
    } else if (completedSteps.includes(stepId - 1) || stepId <= currentStep) {
      setCurrentStep(stepId);
    }
  };

  const handleFormDataChange = (data: any) => {
    setFormData(data);
    if (data.idType && data.fullName && data.idNumber && 
        data.frontImage && data.selfieImage) {
      handleStepValidation(0, true);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="max-w-7xl mx-auto px-4 py-6 sm:py-8">
        {/* Header */}
        <div className="mb-6 sm:mb-8 flex items-center gap-4">
          <img 
            src={earlymarketLogo} 
            alt="EarlyMarket" 
            className="h-12 w-auto drop-shadow-sm"
          />
          <div className="flex-1">
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-1 bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              Get Verified
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground">
              Complete the verification process to unlock premium features and build trust
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-12 gap-6 lg:gap-8">
          {/* Steps Sidebar */}
          <div className="lg:col-span-4 xl:col-span-3">
            <div className="sticky top-6 max-h-[calc(100vh-3rem)] overflow-hidden flex flex-col">
              <Card className="p-4 sm:p-6 bg-card/95 backdrop-blur-sm border-border/50 shadow-lg flex flex-col max-h-full">
              <div className="mb-6 p-4 bg-gradient-to-br from-primary/10 to-primary/5 rounded-xl border border-primary/20">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold">Progress</span>
                  <span className="text-sm font-bold text-primary">{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>

              <ScrollArea className="flex-1 pr-2">
                <div className="hidden sm:block space-y-3">
                {steps.map((step, index) => {
                  const isCompleted = completedSteps.includes(step.id);
                  const isCurrent = currentStep === step.id;
                  const isAccessible = (index === 0) || completedSteps.includes(index - 1) || index <= currentStep;

                  return (
                    <button
                      key={step.id}
                      onClick={() => handleStepClick(step.id)}
                      disabled={!isAccessible}
                      className={cn(
                        'w-full text-left p-4 rounded-xl transition-all duration-300 relative',
                        isCurrent && 'bg-gradient-to-r from-primary to-primary/90 text-primary-foreground shadow-lg scale-105 border-2 border-primary',
                        !isCurrent && isCompleted && 'bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950/30 dark:to-green-900/20 hover:scale-102 border-2 border-green-200 dark:border-green-800',
                        !isCurrent && !isCompleted && isAccessible && 'bg-muted/30 hover:bg-muted/50 hover:scale-102 border-2 border-transparent',
                        !isAccessible && 'opacity-50 cursor-not-allowed'
                      )}
                    >
                      {isCurrent && (
                        <motion.div
                          className="absolute inset-0 bg-gradient-to-r from-primary/20 to-transparent rounded-xl"
                          initial={{ x: '-100%' }}
                          animate={{ x: '100%' }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                        />
                      )}
                      <div className="flex items-center gap-3 relative z-10">
                        <div className={cn(
                          'p-2.5 rounded-lg shadow-md',
                          isCurrent && 'bg-primary-foreground/20',
                          isCompleted && !isCurrent && 'bg-green-500 text-white',
                          !isCurrent && !isCompleted && 'bg-muted'
                        )}>
                          {isCompleted ? (
                            <CheckCircle2 className="w-5 h-5" />
                          ) : (
                            <step.icon className="w-5 h-5" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-sm truncate">
                            {step.title}
                            {step.required && <span className="text-red-500 ml-1">*</span>}
                          </div>
                          <div className={cn(
                            'text-xs mt-0.5 truncate',
                            isCurrent ? 'text-primary-foreground/80' : 'text-muted-foreground'
                          )}>
                            {step.description}
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
                </div>
              </ScrollArea>

              {/* Mobile step indicators */}
              <div className="sm:hidden flex gap-2">
                {steps.map((step, index) => (
                  <div
                    key={step.id}
                    className={cn(
                      'flex-1 h-2 rounded-full transition-all',
                      currentStep === index && 'bg-primary',
                      currentStep > index && 'bg-green-500',
                      currentStep < index && 'bg-muted'
                    )}
                  />
                ))}
              </div>
              </Card>
            </div>

            {/* Benefits Card - Desktop only */}
            <Card className="hidden xl:block mt-6 p-6 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20 max-h-96 overflow-y-auto">
              <h3 className="font-bold mb-4 flex items-center gap-2">
                <Star className="w-5 h-5 text-primary" />
                Verification Benefits
              </h3>
              <ul className="space-y-3 text-sm">
                {[
                  'Verified badge on profile',
                  'Priority in search results',
                  'Access to premium features',
                  'Enhanced buyer trust',
                  'Advanced analytics'
                ].map((benefit, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-8 xl:col-span-9">
            <Card className="p-4 sm:p-6 md:p-8 bg-card/95 backdrop-blur-sm border-border/50 shadow-xl">
              {/* Step Title - Mobile */}
              <div className="sm:hidden mb-6">
                <h2 className="text-xl font-bold flex items-center gap-2 bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                  {React.createElement(steps[currentStep].icon, { className: "w-6 h-6 text-primary" })}
                  {steps[currentStep].title}
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  {steps[currentStep].description}
                </p>
              </div>

              {/* Step Content with Animation */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentStep}
                  initial={{ opacity: 0, y: 20, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -20, scale: 0.98 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                >
                  <CurrentStepComponent 
                    onNext={handleNext}
                    onBack={handleBack}
                    formData={formData}
                    onFormDataChange={handleFormDataChange}
                    {...(currentStep === 0 && { onValidationChange: (isValid: boolean) => handleStepValidation(currentStep, isValid) })}
                    {...(currentStep === 3 && { onComplete })}
                  />
                </motion.div>
              </AnimatePresence>

              {/* Navigation Buttons */}
              <div className="flex items-center justify-between mt-8 pt-6 border-t border-border/50">
                <Button
                  variant="outline"
                  onClick={handleBack}
                  disabled={currentStep === 0}
                  className="gap-2 hover:scale-105 transition-transform"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span className="hidden sm:inline">Back</span>
                </Button>

                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span className="hidden sm:inline">Step</span>
                  <span className="font-semibold text-primary">{currentStep + 1}</span>
                  <span>/</span>
                  <span>{steps.length}</span>
                </div>

                {currentStep < steps.length - 1 && (
                  <Button 
                    onClick={handleNext} 
                    disabled={currentStep === 0 && !stepValidation[0]}
                    className="gap-2 bg-gradient-to-r from-primary to-primary/90 hover:scale-105 transition-transform shadow-lg"
                  >
                    <span className="hidden sm:inline">Continue</span>
                    <span className="sm:hidden">Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                )}
                
                {currentStep === steps.length - 1 && (
                  <div />
                )}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VerificationWizard;
