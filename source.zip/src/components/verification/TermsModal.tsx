import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

interface TermsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const TermsModal = ({ open, onOpenChange }: TermsModalProps) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>Verification Terms & Conditions</DialogTitle>
          <DialogDescription>
            Please read and understand our verification terms before proceeding
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="h-[60vh] pr-4">
          <div className="space-y-4 text-sm">
            <section>
              <h3 className="font-semibold text-base mb-2">1. Identity Verification</h3>
              <p className="text-muted-foreground">
                By submitting documents for verification, you confirm that all information provided is accurate 
                and authentic. You understand that submitting false or fraudulent documents may result in 
                permanent account suspension and potential legal action.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">2. Data Processing</h3>
              <p className="text-muted-foreground">
                We will process your personal information, including identity documents and photos, solely 
                for the purpose of verification. Your data will be stored securely and in compliance with 
                applicable data protection laws.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">3. Document Requirements</h3>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-2">
                <li>All documents must be valid and not expired</li>
                <li>Images must be clear, legible, and show all corners of the document</li>
                <li>Selfie photos must clearly show your face without obstruction</li>
                <li>Documents must match the personal information provided</li>
              </ul>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">4. Verification Process</h3>
              <p className="text-muted-foreground">
                Our verification team will review your submission within 2-3 business days. We may request 
                additional information if needed. Verification is not guaranteed and may be denied if 
                requirements are not met.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">5. Verification Status</h3>
              <p className="text-muted-foreground">
                Verified status may be revoked if you violate platform policies or if we detect fraudulent 
                activity. You agree to maintain accurate information and notify us of any changes to your 
                verified details.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">6. Account Age Requirement</h3>
              <p className="text-muted-foreground">
                Your account must be at least 30 days old to be eligible for verification. This helps us 
                ensure account authenticity and platform trust.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">7. Quality Standards</h3>
              <p className="text-muted-foreground">
                You must maintain platform quality standards including positive reviews, completed 
                transactions, and professional conduct. Failure to maintain these standards may result 
                in verification removal.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">8. Privacy & Security</h3>
              <p className="text-muted-foreground">
                We use AI-powered verification to validate document authenticity. Your documents are 
                encrypted and stored securely. We will never share your personal information with third 
                parties without your consent, except as required by law.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">9. Rejection & Appeals</h3>
              <p className="text-muted-foreground">
                If your verification is rejected, we will provide a reason. You may resubmit after 
                addressing the issues. Repeated rejections may result in temporary restrictions on 
                resubmission.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">10. Agreement</h3>
              <p className="text-muted-foreground">
                By checking "I agree" and submitting your verification application, you acknowledge that 
                you have read, understood, and agree to these terms and conditions.
              </p>
            </section>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};
