import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Upload, 
  CheckCircle2, 
  Building2,
  FileText,
  AlertCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface BusinessVerificationStepProps {
  onNext?: () => void;
  onBack?: () => void;
  formData?: any;
  onFormDataChange?: (data: any) => void;
}

const BusinessVerificationStep: React.FC<BusinessVerificationStepProps> = ({ onNext }) => {
  const [registrationUploaded, setRegistrationUploaded] = useState(false);
  const [taxUploaded, setTaxUploaded] = useState(false);
  const [addressProofUploaded, setAddressProofUploaded] = useState(false);

  return (
    <div className="space-y-6">
      <div className="hidden sm:block">
        <h2 className="text-2xl font-bold mb-2">Business Verification</h2>
        <p className="text-muted-foreground">
          Provide business documentation to verify your business credentials
        </p>
      </div>

      {/* Skip Option for Individual Sellers */}
      <div className="bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30 border border-blue-200 dark:border-blue-800 rounded-xl p-5">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="flex gap-3">
            <div className="p-2 bg-blue-500 rounded-lg text-white">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <p className="font-semibold text-blue-900 dark:text-blue-100">Individual Seller?</p>
              <p className="text-sm text-blue-700 dark:text-blue-300">
                If you don't have a registered business, you can skip this step. Business documents are <strong>optional</strong> for individual sellers.
              </p>
            </div>
          </div>
          <button
            onClick={onNext}
            className="shrink-0 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors"
          >
            Skip This Step →
          </button>
        </div>
      </div>

      <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
        <div className="flex gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-amber-900 dark:text-amber-100">
            <p className="font-medium mb-1">For Registered Businesses:</p>
            <p>Providing business documents speeds up your verification and unlocks additional trust badges.</p>
          </div>
        </div>
      </div>

      {/* Business Information */}
      <div className="space-y-4">
        <h3 className="font-semibold text-lg flex items-center gap-2">
          <Building2 className="w-5 h-5 text-primary" />
          Business Information
        </h3>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="business-name">Business/Trade Name</Label>
            <Input 
              id="business-name" 
              placeholder="Your Business Name" 
              className="mt-2" 
            />
          </div>
          <div>
            <Label htmlFor="business-type">Business Type</Label>
            <Input 
              id="business-type" 
              placeholder="e.g., Sole Proprietorship, LLC" 
              className="mt-2" 
            />
          </div>
        </div>

        <div>
          <Label htmlFor="business-description">Business Description</Label>
          <Textarea
            id="business-description"
            placeholder="Brief description of what your business does..."
            className="mt-2 min-h-[100px]"
          />
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="business-phone">Business Phone</Label>
            <Input 
              id="business-phone" 
              type="tel"
              placeholder="+256 XXX XXX XXX" 
              className="mt-2" 
            />
          </div>
          <div>
            <Label htmlFor="business-email">Business Email</Label>
            <Input 
              id="business-email" 
              type="email"
              placeholder="business@example.com" 
              className="mt-2" 
            />
          </div>
        </div>

        <div>
          <Label htmlFor="business-address">Business Address</Label>
          <Textarea
            id="business-address"
            placeholder="Full business address including street, city, district..."
            className="mt-2"
          />
        </div>
      </div>

      {/* Business Documents */}
      <div className="space-y-4">
        <h3 className="font-semibold text-lg flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          Business Documents (Optional)
        </h3>

        {/* Business Registration */}
        <div>
          <Label className="text-sm font-medium mb-2 block">
            Business Registration Certificate
          </Label>
          <div className={cn(
            'border-2 border-dashed rounded-lg p-6 text-center transition-all',
            registrationUploaded 
              ? 'border-green-500 bg-green-50' 
              : 'border-muted-foreground/25 hover:border-primary/50 cursor-pointer'
          )}>
            <input
              type="file"
              id="registration-upload"
              className="hidden"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={(e) => e.target.files?.[0] && setRegistrationUploaded(true)}
            />
            <label htmlFor="registration-upload" className="cursor-pointer">
              {registrationUploaded ? (
                <div className="text-green-600">
                  <CheckCircle2 className="w-10 h-10 mx-auto mb-2" />
                  <p className="font-medium">Certificate uploaded</p>
                  <p className="text-xs mt-1">Click to change</p>
                </div>
              ) : (
                <div>
                  <Upload className="w-10 h-10 mx-auto mb-2 text-muted-foreground" />
                  <p className="font-medium text-foreground text-sm">Upload registration certificate</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    PDF, JPG, or PNG (Max 5MB)
                  </p>
                </div>
              )}
            </label>
          </div>
        </div>

        {/* Tax Registration */}
        <div>
          <Label className="text-sm font-medium mb-2 block">
            Tax Registration Number (TIN)
          </Label>
          <div className="grid sm:grid-cols-2 gap-4">
            <Input 
              placeholder="Enter TIN number" 
            />
            <div className={cn(
              'border-2 border-dashed rounded-lg p-4 text-center transition-all',
              taxUploaded 
                ? 'border-green-500 bg-green-50' 
                : 'border-muted-foreground/25 hover:border-primary/50 cursor-pointer'
            )}>
              <input
                type="file"
                id="tax-upload"
                className="hidden"
                accept=".pdf,.jpg,.jpeg,.png"
                onChange={(e) => e.target.files?.[0] && setTaxUploaded(true)}
              />
              <label htmlFor="tax-upload" className="cursor-pointer">
                {taxUploaded ? (
                  <div className="text-green-600 flex items-center justify-center gap-2">
                    <CheckCircle2 className="w-5 h-5" />
                    <span className="text-sm font-medium">Uploaded</span>
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-2 text-muted-foreground">
                    <Upload className="w-5 h-5" />
                    <span className="text-sm">Upload TIN Certificate</span>
                  </div>
                )}
              </label>
            </div>
          </div>
        </div>

        {/* Business Address Proof */}
        <div>
          <Label className="text-sm font-medium mb-2 block">
            Proof of Business Address
          </Label>
          <p className="text-xs text-muted-foreground mb-2">
            Utility bill, lease agreement, or bank statement showing business address
          </p>
          <div className={cn(
            'border-2 border-dashed rounded-lg p-6 text-center transition-all',
            addressProofUploaded 
              ? 'border-green-500 bg-green-50' 
              : 'border-muted-foreground/25 hover:border-primary/50 cursor-pointer'
          )}>
            <input
              type="file"
              id="address-proof-upload"
              className="hidden"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={(e) => e.target.files?.[0] && setAddressProofUploaded(true)}
            />
            <label htmlFor="address-proof-upload" className="cursor-pointer">
              {addressProofUploaded ? (
                <div className="text-green-600">
                  <CheckCircle2 className="w-10 h-10 mx-auto mb-2" />
                  <p className="font-medium">Address proof uploaded</p>
                  <p className="text-xs mt-1">Click to change</p>
                </div>
              ) : (
                <div>
                  <Upload className="w-10 h-10 mx-auto mb-2 text-muted-foreground" />
                  <p className="font-medium text-foreground text-sm">Upload address proof</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    PDF, JPG, or PNG (Max 5MB)
                  </p>
                </div>
              )}
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BusinessVerificationStep;
