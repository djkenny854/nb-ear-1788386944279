import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { 
  Star, 
  Users, 
  Calendar, 
  User, 
  Video, 
  CheckCircle2, 
  Clock,
  TrendingUp
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface QualityVerificationStepProps {
  onNext?: () => void;
  onBack?: () => void;
  formData?: any;
  onFormDataChange?: (data: any) => void;
}

const QualityVerificationStep: React.FC<QualityVerificationStepProps> = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const { data: verificationData, refetch } = useQuery({
    queryKey: ['verification-progress', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      // Get seller profile first
      const { data: sellerProfile } = await supabase
        .from('seller_profiles')
        .select('id, created_at')
        .eq('user_id', user.id)
        .maybeSingle();
      
      if (!sellerProfile) return null;
      
      // Calculate account age
      const accountAge = Math.floor(
        (new Date().getTime() - new Date(sellerProfile.created_at).getTime()) / (1000 * 60 * 60 * 24)
      );
      
      // Get verification data
      const { data, error } = await supabase
        .from('verification_criteria')
        .select('*')
        .eq('user_id', user.id)
        .eq('seller_profile_id', sellerProfile.id)
        .maybeSingle();
      
      if (error && error.code !== 'PGRST116') throw error;
      
      // If no data exists, calculate it
      if (!data) {
        const { data: calcResult } = await supabase
          .rpc('calculate_verification_score', { user_uuid: user.id });
        
        // Fetch again after calculation
        const { data: newData } = await supabase
          .from('verification_criteria')
          .select('*')
          .eq('user_id', user.id)
          .eq('seller_profile_id', sellerProfile.id)
          .maybeSingle();
        
        return newData;
      }
      
      return data;
    },
    enabled: !!user?.id
  });

  const criteria = verificationData || {
    reviews_count: 0,
    avg_rating: 0,
    transactions_count: 0,
    account_age_days: 0,
    profile_complete: false,
    has_video: false,
    verification_score: 0
  };

  const qualityItems = [
    {
      icon: Star,
      title: 'Customer Reviews',
      requirement: '10+ reviews with 4.5+ rating',
      current: `${criteria.reviews_count} reviews (${criteria.avg_rating.toFixed(1)} avg)`,
      completed: criteria.reviews_count >= 10 && criteria.avg_rating >= 4.5,
      points: 25,
      progress: Math.min((criteria.reviews_count / 10) * 100, 100)
    },
    {
      icon: Users,
      title: 'Successful Transactions',
      requirement: '15+ completed transactions',
      current: `${criteria.transactions_count} transactions`,
      completed: criteria.transactions_count >= 15,
      points: 25,
      progress: Math.min((criteria.transactions_count / 15) * 100, 100)
    },
    {
      icon: Calendar,
      title: 'Account Age',
      requirement: '30+ days active',
      current: `${criteria.account_age_days} days`,
      completed: criteria.account_age_days >= 30,
      points: 15,
      progress: Math.min((criteria.account_age_days / 30) * 100, 100)
    },
    {
      icon: User,
      title: 'Profile Completeness',
      requirement: '100% profile completion',
      current: 'Profile status',
      completed: criteria.profile_complete,
      points: 15,
      progress: criteria.profile_complete ? 100 : 60
    },
    {
      icon: Video,
      title: 'Product Videos',
      requirement: 'At least one product with video',
      current: criteria.has_video ? 'Video added' : 'No video',
      completed: criteria.has_video,
      points: 10,
      progress: criteria.has_video ? 100 : 0
    }
  ];

  const totalPoints = qualityItems.reduce((sum, item) => sum + item.points, 0);
  const earnedPoints = qualityItems
    .filter(item => item.completed)
    .reduce((sum, item) => sum + item.points, 0);
  const overallProgress = (earnedPoints / totalPoints) * 100;

  return (
    <div className="space-y-6">
      <div className="hidden sm:block">
        <h2 className="text-2xl font-bold mb-2">Quality Standards</h2>
        <p className="text-muted-foreground">
          Meet our platform quality requirements to earn verification
        </p>
      </div>

      {/* Overall Progress */}
      <Card className="p-6 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-full bg-primary/20">
              <TrendingUp className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h3 className="font-bold text-lg">Quality Score</h3>
              <p className="text-sm text-muted-foreground">
                {earnedPoints} / {totalPoints} points earned
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-primary">
              {Math.round(overallProgress)}%
            </div>
            <p className="text-xs text-muted-foreground">Complete</p>
          </div>
        </div>
        <Progress value={overallProgress} className="h-3" />
      </Card>

      {/* Quality Items */}
      <div className="space-y-4">
        {qualityItems.map((item, index) => (
          <Card 
            key={index}
            className={cn(
              'p-5 transition-all',
              item.completed && 'border-2 border-green-500 bg-green-50/50'
            )}
          >
            <div className="flex items-start gap-4">
              <div className={cn(
                'p-3 rounded-full flex-shrink-0',
                item.completed 
                  ? 'bg-green-500 text-white' 
                  : 'bg-muted text-muted-foreground'
              )}>
                <item.icon className="w-5 h-5" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4 mb-2">
                  <div className="flex-1">
                    <h4 className="font-semibold mb-1">{item.title}</h4>
                    <p className="text-sm text-muted-foreground mb-1">
                      {item.requirement}
                    </p>
                    <p className="text-sm font-medium text-primary">
                      Current: {item.current}
                    </p>
                  </div>
                  <Badge 
                    variant={item.completed ? "default" : "outline"}
                    className="flex-shrink-0"
                  >
                    {item.completed ? (
                      <span className="flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        +{item.points} pts
                      </span>
                    ) : (
                      <span>+{item.points} pts</span>
                    )}
                  </Badge>
                </div>

                <div className="space-y-2">
                  <Progress value={item.progress} className="h-2" />
                  
                  {item.completed ? (
                    <div className="flex items-center gap-2 text-green-600 text-sm font-medium">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Requirement met</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-orange-600 text-sm">
                      <Clock className="w-4 h-4" />
                      <span>Keep building your reputation</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Tips Card */}
      <Card className="p-6 bg-blue-50 border-blue-200">
        <h3 className="font-bold mb-3 text-blue-900">Tips to Improve Your Quality Score:</h3>
        <ul className="space-y-2 text-sm text-blue-800">
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <span>Provide excellent customer service to earn positive reviews</span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <span>Complete your profile with accurate business information</span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <span>Add product videos to showcase your items better</span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <span>Respond quickly to customer inquiries</span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <span>Maintain consistent activity on the platform</span>
          </li>
        </ul>
      </Card>
    </div>
  );
};

export default QualityVerificationStep;
