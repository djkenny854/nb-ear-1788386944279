import React from 'react';
import { motion } from 'framer-motion';
import { Loader2, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';

interface ImageVerificationStatusProps {
  status: 'idle' | 'verifying' | 'valid' | 'invalid';
  message?: string;
}

const ImageVerificationStatus: React.FC<ImageVerificationStatusProps> = ({ status, message }) => {
  if (status === 'idle') return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="mt-2"
    >
      {status === 'verifying' && (
        <div className="flex items-center gap-2 text-blue-600">
          <Loader2 className="w-4 h-4 animate-spin" />
          <span className="text-sm font-medium">
            AI is verifying your document...
          </span>
        </div>
      )}

      {status === 'valid' && (
        <div className="flex items-center gap-2 text-green-600">
          <CheckCircle2 className="w-4 h-4" />
          <span className="text-sm font-medium">
            Document verified successfully!
          </span>
        </div>
      )}

      {status === 'invalid' && (
        <div className="flex items-start gap-2 text-red-600">
          <XCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <div className="text-sm font-medium">Document verification failed</div>
            {message && (
              <div className="text-xs text-red-500 mt-1">{message}</div>
            )}
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default ImageVerificationStatus;
