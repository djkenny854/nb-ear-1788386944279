import React from 'react';
import { motion } from 'framer-motion';
import { Loader2 } from 'lucide-react';

const AIVerificationLoader: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center p-4 space-y-2">
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
      >
        <Loader2 className="w-8 h-8 text-primary" />
      </motion.div>
      <p className="text-sm text-muted-foreground">Verifying...</p>
    </div>
  );
};

export default AIVerificationLoader;
