import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Clock, XCircle, AlertCircle } from "lucide-react";

interface VerificationStatusCardProps {
  status: "not_verified" | "pending" | "verified" | "rejected";
  rejectionReason?: string | null;
  reviewedAt?: string | null;
}

export const VerificationStatusCard = ({
  status,
  rejectionReason,
  reviewedAt,
}: VerificationStatusCardProps) => {
  const statusConfig = {
    not_verified: {
      icon: AlertCircle,
      label: "Not Verified",
      description: "Your account is not yet verified. Complete the form below to start verification.",
      badgeVariant: "secondary" as const,
      iconColor: "text-muted-foreground",
      bgColor: "bg-muted/50",
    },
    pending: {
      icon: Clock,
      label: "Pending Review",
      description: "Your verification request is under review. We'll notify you once it's processed.",
      badgeVariant: "default" as const,
      iconColor: "text-yellow-600",
      bgColor: "bg-yellow-50 border-yellow-200",
    },
    verified: {
      icon: CheckCircle2,
      label: "Verified",
      description: "Your account is verified! You have full access to all features.",
      badgeVariant: "default" as const,
      iconColor: "text-green-600",
      bgColor: "bg-green-50 border-green-200",
    },
    rejected: {
      icon: XCircle,
      label: "Rejected",
      description: rejectionReason || "Your verification was rejected. Please review and resubmit.",
      badgeVariant: "destructive" as const,
      iconColor: "text-destructive",
      bgColor: "bg-destructive/5 border-destructive/20",
    },
  };

  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <Card className={`p-6 border-2 ${config.bgColor}`}>
      <div className="flex items-start gap-4">
        <div className={`p-3 rounded-full bg-background`}>
          <Icon className={`w-6 h-6 ${config.iconColor}`} />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h3 className="text-lg font-semibold">{config.label}</h3>
            <Badge variant={config.badgeVariant}>{status.replace("_", " ")}</Badge>
          </div>
          <p className="text-sm text-muted-foreground mb-2">{config.description}</p>
          {reviewedAt && (
            <p className="text-xs text-muted-foreground">
              Reviewed on {new Date(reviewedAt).toLocaleDateString()}
            </p>
          )}
        </div>
      </div>
    </Card>
  );
};
