import React, { useEffect, useRef, useState, useCallback } from 'react';
import { cn } from '@/lib/utils';
import { Play } from 'lucide-react';
import MaterialSpinner from '@/components/ui/MaterialSpinner';
import SmartVideo from '@/components/media/SmartVideo';
import { videoCdnUrl, imageCdnUrl } from '@/utils/cdnUrl';
import { getIsDataSaverActive } from '@/contexts/AppSettingsContext';

export type MediaContext = 'feed' | 'detail' | 'thumbnail' | 'fullscreen';

interface ContextConfig {
  min: number; // narrowest (tallest portrait) allowed ratio
  max: number; // widest (landscape) allowed ratio
  maxHeight?: number; // absolute pixel ceiling
  fixed?: number; // forced ratio (overrides everything)
}

const CONTEXT_CONFIG: Record<MediaContext, ContextConfig> = {
  // X-style feed: nothing taller than 4:5, nothing wider than 16:9
  feed: { min: 4 / 5, max: 16 / 9, maxHeight: 512 },
  // detail: allow tall portraits and ultra-wide
  detail: { min: 1 / 2, max: 21 / 9, maxHeight: 640 },
  // square crop
  thumbnail: { min: 1, max: 1, fixed: 1 },
  // natural ratio, no clamp
  fullscreen: { min: 0, max: Infinity },
};

/**
 * Clamp a raw aspect ratio (width/height) into the allowed range for a context.
 */
export function getClampedRatio(ratio: number, context: MediaContext): number {
  const cfg = CONTEXT_CONFIG[context];
  if (cfg.fixed) return cfg.fixed;
  if (!ratio || !isFinite(ratio) || ratio <= 0) return context === 'feed' ? 1 : 16 / 9;
  return Math.min(Math.max(ratio, cfg.min), cfg.max);
}

export interface AdaptiveMediaProps {
  url: string;
  type: 'image' | 'video';
  originalWidth?: number | null;
  originalHeight?: number | null;
  context: MediaContext;
  poster?: string;
  alt?: string;
  className?: string;
  onClick?: (e: React.MouseEvent) => void;
  /** disable IntersectionObserver autoplay in feed (e.g. inside carousels) */
  disableAutoplay?: boolean;
  /**
   * Fill the parent element completely (absolute inset-0, object-cover) instead
   * of imposing an intrinsic aspect ratio. Used for grid cells where the parent
   * already defines the cell size — prevents empty gaps at the bottom.
   */
  fill?: boolean;
}

const DEFAULT_IMAGE_RATIO = 1;
const DEFAULT_VIDEO_RATIO = 16 / 9;

const AdaptiveMedia: React.FC<AdaptiveMediaProps> = ({
  url,
  type,
  originalWidth,
  originalHeight,
  context,
  poster,
  alt = '',
  className,
  onClick,
  disableAutoplay = false,
  fill = false,
}) => {
  const hasStoredDims = !!(originalWidth && originalHeight);
  const initialRatio = hasStoredDims
    ? originalWidth! / originalHeight!
    : type === 'video'
    ? DEFAULT_VIDEO_RATIO
    : DEFAULT_IMAGE_RATIO;

  const [rawRatio, setRawRatio] = useState<number>(initialRatio);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);
  const [useOriginalImage, setUseOriginalImage] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const cfg = CONTEXT_CONFIG[context];
  const clampedRatio = getClampedRatio(rawRatio, context);
  const objectFit = context === 'fullscreen' ? 'contain' : 'cover';

  // Request an appropriately-sized image variant from Supabase's image CDN so
  // feed/thumbnail contexts download far less data. Fullscreen keeps original.
  const imageWidth =
    context === 'thumbnail'
      ? 240
      : context === 'feed'
      ? 700
      : context === 'detail'
      ? 1080
      : undefined; // fullscreen -> original

  useEffect(() => {
    setLoaded(false);
    setError(false);
    setUseOriginalImage(false);
    setRawRatio(initialRatio);
  }, [url, poster, type, initialRatio]);

  // IntersectionObserver autoplay for feed videos
  useEffect(() => {
    if (type !== 'video' || context !== 'feed' || disableAutoplay) return;
    const el = containerRef.current;
    const video = videoRef.current;
    if (!el || !video) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.6) {
            video.play().then(() => setIsPlaying(true)).catch(() => {});
          } else {
            video.pause();
            setIsPlaying(false);
          }
        });
      },
      { threshold: [0, 0.6, 1] }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [type, context, disableAutoplay, url]);

  const onImgLoad = useCallback((e: React.SyntheticEvent<HTMLImageElement>) => {
    setLoaded(true);
    if (!hasStoredDims) {
      const img = e.currentTarget;
      if (img.naturalWidth && img.naturalHeight) {
        setRawRatio(img.naturalWidth / img.naturalHeight);
      }
    }
  }, [hasStoredDims]);

  const onVideoMeta = useCallback((e: React.SyntheticEvent<HTMLVideoElement>) => {
    setLoaded(true);
    if (!hasStoredDims) {
      const v = e.currentTarget;
      if (v.videoWidth && v.videoHeight) {
        setRawRatio(v.videoWidth / v.videoHeight);
      }
    }
  }, [hasStoredDims]);

  const containerStyle: React.CSSProperties = fill
    ? { width: '100%', height: '100%' }
    : {
        width: '100%',
        aspectRatio: String(clampedRatio),
        ...(cfg.maxHeight ? { maxHeight: cfg.maxHeight } : {}),
      };

  const mediaStyle: React.CSSProperties = {
    width: '100%',
    height: '100%',
    objectFit,
  };

  if (error) {
    return (
      <div
        className={cn('flex items-center justify-center bg-muted text-muted-foreground text-xs', className)}
        style={containerStyle}
      >
        Media unavailable
      </div>
    );
  }

  const isDataSaver = getIsDataSaverActive();

  // thumbnail or data saver in feed/cards: never load a <video>, only the poster image
  const renderAsPoster = type === 'video' && (context === 'thumbnail' || isDataSaver);
  const quality = isDataSaver ? 62 : 72;
  const originalImageSource = renderAsPoster ? poster || url : url;
  const resolvedImageSource = useOriginalImage
    ? originalImageSource
    : imageCdnUrl(originalImageSource, imageWidth ? { width: imageWidth, quality } : {});

  return (
    <div
      ref={containerRef}
      onClick={onClick}
      className={cn(
        'relative overflow-hidden',
        fill && 'absolute inset-0 w-full h-full',
        context === 'fullscreen' ? 'bg-black' : 'bg-muted',
        className
      )}
      style={containerStyle}
    >
      {!loaded && (
        <div className="absolute inset-0 flex items-center justify-center">
          <MaterialSpinner size={22} />
        </div>
      )}

      {type === 'image' || renderAsPoster ? (
        <>
          <img
            src={resolvedImageSource}
            alt={alt}
            loading={context === 'fullscreen' ? 'eager' : 'lazy'}
            decoding="async"
            draggable={false}
            onContextMenu={(e) => e.preventDefault()}
            onLoad={onImgLoad}
            onError={() => {
              if (!useOriginalImage && resolvedImageSource !== originalImageSource) {
                setLoaded(false);
                setUseOriginalImage(true);
                return;
              }
              setError(true);
            }}
            className={cn('transition-opacity duration-200 select-none', loaded ? 'opacity-100' : 'opacity-0')}
            style={mediaStyle}
          />
          {type === 'video' && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none bg-black/20">
              <div className="w-12 h-12 rounded-full bg-black/60 backdrop-blur-sm flex items-center justify-center shadow border border-white/20">
                <Play className="w-6 h-6 text-white fill-white ml-0.5" />
              </div>
            </div>
          )}
        </>
      ) : (
        <>
          <SmartVideo
            ref={videoRef}
            src={videoCdnUrl(url)}
            poster={imageCdnUrl(poster, imageWidth ? { width: imageWidth, quality: 72 } : {})}
            muted={context === 'feed'}
            loop={context === 'feed'}
            controls={context === 'fullscreen' || context === 'detail'}
            autoPlayInView={context === 'feed' && !disableAutoplay}
            onLoadedMetadata={onVideoMeta}
            onError={() => setError(true)}
            style={mediaStyle}
          />
          {context === 'feed' && !isPlaying && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-14 h-14 rounded-full bg-black/50 flex items-center justify-center">
                <Play className="w-7 h-7 text-white fill-white ml-0.5" />
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default AdaptiveMedia;