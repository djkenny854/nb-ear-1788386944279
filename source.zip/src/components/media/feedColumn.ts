/**
 * X-style fluid feed column width system.
 * - Mobile (< 640px): full width
 * - Tablet (640-1024px): full width, capped at 600px, centered
 * - Desktop (> 1024px): fixed 598px, centered
 */
export const FEED_COLUMN_CLASS = 'w-full sm:max-w-[600px] lg:w-[598px] lg:max-w-[598px] mx-auto';