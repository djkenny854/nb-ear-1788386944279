import React, { useEffect, useMemo, useRef, useState, forwardRef, useImperativeHandle } from 'react';
import { Play } from 'lucide-react';
import { cn } from '@/lib/utils';
import { videoCdnUrl } from '@/utils/cdnUrl';
import { attachDecodeWatchdog } from '@/utils/videoDecodeGuard';
import { FALLBACK_THUMBNAIL } from '@/utils/fallbackImage';
import { getIsDataSaverActive } from '@/contexts/AppSettingsContext';

export interface SmartVideoProps
  extends Omit<
    React.VideoHTMLAttributes<HTMLVideoElement>,
    'src' | 'poster' | 'preload' | 'onCanPlay'
  > {
  src: string | null | undefined;
  poster?: string | null;
  /** Optional secondary fallback (e.g. low-res blur thumbnail). */
  blurThumbnail?: string | null;
  /** Wrap the <video> in a black container so there is never a white flash. */
  wrapped?: boolean;
  /** Tailwind classes on the <video> element (or the wrapper when wrapped). */
  className?: string;
  /** Auto play / pause based on viewport visibility (muted, loop). */
  autoPlayInView?: boolean;
  /** Optional scroll container for IntersectionObserver. */
  scrollRoot?: Element | null;
  /** Visibility ratio at which we upgrade preload + start playback. */
  inViewThreshold?: number;
  /** Called once the element can paint a frame. */
  onReady?: () => void;
  /** Explicit override to disable data saver blocking for this instance */
  forceAttach?: boolean;
}

/**
 * SmartVideo — the single low-level player every video surface in the app
 * delegates to.
 *
 * Lazy loading: The <video> element is rendered immediately but carries NO
 * `src` until the container intersects the viewport (threshold 0.25). This
 * stops bulk metadata fetches when a feed with many video cards mounts.
 *
 * Data Saver: When Data Saver is active, videos will NOT attach `src` or
 * autoplay upon scrolling into view. A poster thumbnail with a Play button
 * is shown instead, and the video stream is only fetched on-demand when tapped.
 *
 * Poster fallback: When no poster is provided, the wrapper paints a solid
 * black background with a centered play icon, so the user always sees a
 * thumbnail-like state before the first frame is ready.
 */
const SmartVideo = forwardRef<HTMLVideoElement, SmartVideoProps>(function SmartVideo(
  {
    src,
    poster,
    blurThumbnail,
    wrapped = false,
    className,
    autoPlayInView = false,
    scrollRoot = null,
    inViewThreshold = 0.6,
    onReady,
    muted,
    loop,
    controls,
    playsInline = true,
    onLoadedData,
    onError,
    forceAttach = false,
    ...rest
  },
  ref,
) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDataSaver = !forceAttach && getIsDataSaverActive();

  const [ready, setReady] = useState(false);
  const [decodeFailed, setDecodeFailed] = useState(false);
  // Lazy: only attach src once the player has been in view at least once.
  // When native controls are shown (detail/fullscreen), attach eagerly so the
  // browser's built-in play button can start playback on the very first tap.
  const eager = Boolean(controls) || Boolean((rest as { autoPlay?: boolean }).autoPlay) || forceAttach;
  const [attached, setAttached] = useState<boolean>(eager);

  useImperativeHandle(ref, () => {
    const video = videoRef.current;
    if (!video) return video as unknown as HTMLVideoElement;
    return new Proxy(video, {
      get(target, prop, receiver) {
        if (prop === 'play') {
          return async () => {
            if (!attached) {
              setAttached(true);
              await new Promise((resolve) => setTimeout(resolve, 30));
            }
            return target.play();
          };
        }
        // NOTE: pass `target` (not the proxy) as the receiver so native
        // getters like `readyState`/`currentTime` don't throw "Illegal invocation".
        const val = Reflect.get(target, prop, target);
        return typeof val === 'function' ? val.bind(target) : val;
      },
    }) as HTMLVideoElement;
  });

  useEffect(() => {
    if (eager) setAttached(true);
  }, [eager]);

  const resolvedSrc = useMemo(() => {
    if (!src) return '';
    let s = videoCdnUrl(src) || src;
    while (s.match(/^https:\/\/https:\/\//)) {
      s = s.replace(/^https:\/\/https:\/\//, 'https://');
    }
    return s;
  }, [src]);

  // Every player always has a poster: real thumbnail -> blur thumbnail ->
  // shared black placeholder. A video element must never fall back to the
  // browser's default (grey) media UI.
  const resolvedPoster = poster || blurThumbnail || FALLBACK_THUMBNAIL;

  // Single IntersectionObserver drives both lazy-attach AND autoplay.
  useEffect(() => {
    const target = containerRef.current || videoRef.current;
    if (!target) return;
    if (!resolvedSrc) return;

    const v = videoRef.current;

    const io = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (!entry) return;

        // In Data Saver mode, scrolling into view NEVER attaches the video or starts autoplay.
        if (isDataSaver && !attached) {
          return;
        }

        const visible = entry.isIntersecting;
        const fullyVisible = entry.isIntersecting && entry.intersectionRatio >= inViewThreshold;

        if (visible && !attached) {
          setAttached(true);
        }

        if (!v || !autoPlayInView || isDataSaver) return;

        if (fullyVisible) {
          v.preload = 'auto';
          const tryPlay = () => {
            v.play().catch(() => {
              v.muted = true;
              v.play().catch(() => {});
            });
          };
          tryPlay();
          v.addEventListener('loadeddata', tryPlay, { once: true });
          v.addEventListener('canplay', tryPlay, { once: true });
        } else if (!entry.isIntersecting || entry.intersectionRatio < 0.1) {
          try { v.pause(); } catch {}
        }
      },
      {
        threshold: [0, 0.1, 0.25, inViewThreshold, 1],
        root: scrollRoot ?? null,
        rootMargin: '250px 0px',
      },
    );

    io.observe(target);
    return () => io.disconnect();
  }, [autoPlayInView, inViewThreshold, scrollRoot, resolvedSrc, attached, isDataSaver]);

  useEffect(() => {
    setDecodeFailed(false);
    return attachDecodeWatchdog(videoRef.current, () => setDecodeFailed(true));
  }, [resolvedSrc, attached]);

  // Non-faststart MP4s handling
  useEffect(() => {
    if (!attached || !resolvedSrc || isDataSaver) return;
    const v = videoRef.current;
    if (!v) return;
    const timer = window.setTimeout(() => {
      if (v.readyState >= 1) return;
      try {
        v.preload = 'auto';
        v.load();
        if (autoPlayInView && !isDataSaver) {
          v.play().catch(() => {
            v.muted = true;
            v.play().catch(() => {});
          });
        }
      } catch { /* noop */ }
    }, 2500);
    return () => window.clearTimeout(timer);
  }, [attached, resolvedSrc, autoPlayInView, isDataSaver]);

  const handleCanPlay = () => {
    setReady(true);
    onReady?.();
  };

  // Reset readiness whenever the source changes
  useEffect(() => {
    setReady(false);
  }, [resolvedSrc]);

  // Safety net for video reveal
  useEffect(() => {
    if (!attached || ready) return;
    const v = videoRef.current;
    if (!v) return;
    const reveal = () => {
      if (v.readyState >= 2 || v.currentTime > 0) setReady(true);
    };
    reveal();
    v.addEventListener('playing', reveal);
    v.addEventListener('timeupdate', reveal);
    v.addEventListener('loadedmetadata', reveal);
    const id = window.setInterval(reveal, 400);
    return () => {
      window.clearInterval(id);
      v.removeEventListener('playing', reveal);
      v.removeEventListener('timeupdate', reveal);
      v.removeEventListener('loadedmetadata', reveal);
    };
  }, [attached, ready, resolvedSrc]);

  // Handle on-demand user tap to play in Data Saver mode
  const handleDataSaverPlay = (e: React.MouseEvent) => {
    if (!attached) {
      setAttached(true);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.play().catch(() => {});
        }
      }, 50);
    }
  };

  // Black + play-icon fallback when no poster image is available or in data saver
  const showPlaceholder = !ready;
  const hasPosterImage = Boolean(resolvedPoster);

  const videoEl = (
    <video
      ref={videoRef}
      // Only attach src once visible and attached. Zero network activity when detached.
      src={attached && resolvedSrc ? resolvedSrc : undefined}
      poster={resolvedPoster}
      preload={attached ? 'metadata' : 'none'}
      playsInline={playsInline}
      {...({ 'webkit-playsinline': 'true', 'x5-playsinline': 'true' } as Record<string, string>)}
      muted={muted}
      loop={loop}
      controls={controls}
      onCanPlay={handleCanPlay}
      onPlaying={handleCanPlay}
      onLoadedData={(e) => {
        handleCanPlay();
        onLoadedData?.(e);
      }}
      onError={(e) => {
        setDecodeFailed(true);
        onError?.(e);
      }}
      className={cn(
        'transition-opacity duration-300',
        ready && !decodeFailed ? 'opacity-100' : 'opacity-0',
        wrapped ? 'w-full h-full' : className,
      )}
      {...rest}
    />
  );

  return (
    <div
      ref={containerRef}
      onClick={isDataSaver && !attached ? handleDataSaverPlay : undefined}
      className={cn(
        'relative overflow-hidden bg-black',
        wrapped ? className : 'w-full h-full',
        isDataSaver && !attached && 'cursor-pointer'
      )}
      style={
        hasPosterImage
          ? {
              backgroundImage: `url(${resolvedPoster})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }
          : undefined
      }
    >
      {videoEl}

      {/* When data saver is active and user hasn't started playing, show interactive play button */}
      {isDataSaver && !attached && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/30 transition-opacity hover:bg-black/40">
          <div className="w-14 h-14 rounded-full bg-black/60 backdrop-blur-sm flex items-center justify-center shadow-lg border border-white/20">
            <Play className="w-7 h-7 text-white fill-white ml-0.5" />
          </div>
        </div>
      )}

      {/* Generic fallback play icon when no poster is available */}
      {showPlaceholder && !hasPosterImage && !isDataSaver && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="w-14 h-14 rounded-full bg-white/15 backdrop-blur-sm flex items-center justify-center">
            <Play className="w-7 h-7 text-white fill-white ml-0.5" />
          </div>
        </div>
      )}
    </div>
  );
});

export default SmartVideo;

