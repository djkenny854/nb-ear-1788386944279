import React, { useState, useRef } from 'react';
import { Upload, Video, X, Loader2, AlertCircle, Lock } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { Progress } from '@/components/ui/progress';
import VideoPlayer from '@/components/VideoPlayer';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { MAX_VIDEO_UPLOAD_MB, uploadVideoWithThumbnailToB2 } from '@/utils/uploadVideoToB2';

interface VideoUploadProps {
  onVideoUploaded: (videoUrl: string) => void;
  currentVideoUrl?: string;
  isVerified?: boolean;
  maxSizeMB?: number;
}

const VideoUpload: React.FC<VideoUploadProps> = ({ 
  onVideoUploaded, 
  currentVideoUrl,
  isVerified = true,
  maxSizeMB = MAX_VIDEO_UPLOAD_MB 
}) => {
  const navigate = useNavigate();
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [videoPreview, setVideoPreview] = useState<string | null>(currentVideoUrl || null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [uploadEnabled, setUploadEnabled] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Check if video uploads are enabled
  React.useEffect(() => {
    const checkVideoEnabled = async () => {
      const { data, error } = await supabase
        .from('settings')
        .select('setting_value')
        .eq('setting_key', 'video_uploads_enabled')
        .single();

      if (!error && data) {
        setUploadEnabled(data.setting_value === true);
      }
    };

    checkVideoEnabled();
  }, []);

  // Show verification requirement
  if (!isVerified) {
    return (
      <Card className="p-6 border-2 border-dashed border-muted">
        <div className="flex flex-col items-center justify-center text-center space-y-4 py-8">
          <div className="p-3 bg-muted rounded-full">
            <Lock className="w-6 h-6 text-muted-foreground" />
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">Verification Required</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Video uploads are available for verified sellers only
            </p>
            <Button onClick={() => navigate('/verify')} variant="default">
              Verify Now
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  // Show disabled state
  if (!uploadEnabled) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Video uploads are currently disabled. Please try again later.
        </AlertDescription>
      </Alert>
    );
  }

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type - Accept MP4, MOV, and WebM (most compatible formats)
    if (!file.type.startsWith('video/')) {
      toast({
        title: 'Invalid file',
        description: 'Please choose a video file.',
        variant: 'destructive',
      });
      return;
    }

    // Validate file size
    const fileSizeMB = file.size / (1024 * 1024);
    if (fileSizeMB > maxSizeMB) {
      toast({
        title: 'File too large',
        description: `Video must be under ${maxSizeMB}MB (current: ${fileSizeMB.toFixed(1)}MB)`,
        variant: 'destructive',
      });
      return;
    }

    setVideoFile(file);
    
    // Create preview
    const previewUrl = URL.createObjectURL(file);
    setVideoPreview(previewUrl);

    // Start upload
    await uploadVideoToB2(file);
  };

  const uploadVideoToB2 = async (file: File) => {
    setUploading(true);
    setUploadProgress(0);

    try {
      const { videoUrl: finalUrl } = await uploadVideoWithThumbnailToB2(file, {
        onProgress: setUploadProgress,
      });
      setUploadProgress(100);

      onVideoUploaded(finalUrl);
      toast({
        title: 'Video uploaded successfully!',
        description: 'Your video will be displayed in your listing',
      });
    } catch (error: any) {
      console.error('Video upload error:', error);
      toast({
        title: 'Upload failed',
        description: error.message || 'Failed to upload video. Check console for details.',
        variant: 'destructive',
      });
      setVideoPreview(null);
      setVideoFile(null);
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const handleRemoveVideo = () => {
    setVideoPreview(null);
    setVideoFile(null);
    onVideoUploaded('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Video className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold">Product Video</h3>
            <Badge variant="secondary" className="text-xs">
              Optional
            </Badge>
          </div>
          {videoPreview && !uploading && (
            <button
              onClick={handleRemoveVideo}
              className="text-sm text-destructive hover:text-destructive/80 flex items-center gap-1"
            >
              <X className="w-4 h-4" />
              Remove
            </button>
          )}
        </div>

        {uploading && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Uploading video...</span>
              <span className="font-medium">{uploadProgress}%</span>
            </div>
            <Progress value={uploadProgress} className="h-2" />
          </div>
        )}

        {videoPreview && !uploading ? (
          <VideoPlayer
            src={videoPreview}
            className="aspect-video w-full"
            autoPlay={false}
            muted={true}
            loop={true}
            controls={true}
          />
        ) : !uploading ? (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-muted rounded-lg p-8 text-center cursor-pointer hover:border-primary hover:bg-accent/50 transition-all group"
          >
            <div className="flex flex-col items-center gap-3">
              <div className="p-3 bg-primary/10 rounded-full group-hover:bg-primary/20 transition-colors">
                <Upload className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-medium mb-1">Click to upload video</p>
                <p className="text-sm text-muted-foreground">
                  MP4, MOV, or WebM up to {maxSizeMB}MB (MP4 recommended)
                </p>
              </div>
            </div>
          </div>
        ) : null}

        <input
          ref={fileInputRef}
          type="file"
          accept="video/*"
          onChange={handleFileSelect}
          className="hidden"
          disabled={uploading}
        />

        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-xs">
            Videos are stored securely and automatically embedded in your listing. Ensure your video showcases your product clearly.
          </AlertDescription>
        </Alert>
      </div>
    </Card>
  );
};

export default VideoUpload;