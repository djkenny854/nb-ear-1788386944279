
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface StepCardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  subtitle?: string;
  icon?: React.ReactNode;
}

export const StepCard: React.FC<StepCardProps> = ({ 
  children, 
  className, 
  title, 
  subtitle, 
  icon 
}) => {
  return (
    <Card className={cn(
      "bg-white border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300",
      "rounded-2xl overflow-hidden",
      "animate-in slide-in-from-bottom-4 duration-500",
      className
    )}>
      {(title || subtitle || icon) && (
        <CardHeader className="pb-4 bg-gradient-to-r from-blue-50 to-purple-50 border-b border-gray-100">
          <CardTitle className="flex items-center gap-3">
            {icon && (
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white shadow-lg">
                {icon}
              </div>
            )}
            <div>
              {title && <h2 className="text-xl font-bold text-gray-900">{title}</h2>}
              {subtitle && <p className="text-sm text-gray-600 font-normal mt-1">{subtitle}</p>}
            </div>
          </CardTitle>
        </CardHeader>
      )}
      <CardContent className="p-6 md:p-8">
        {children}
      </CardContent>
    </Card>
  );
};
