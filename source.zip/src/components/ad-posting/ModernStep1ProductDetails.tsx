
import React from 'react';
import { StepCard } from './StepCard';
import { FloatingLabelInput } from './FloatingLabelInput';
import { FloatingLabelTextarea } from './FloatingLabelTextarea';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Sparkles, DollarSign, Package, Star } from 'lucide-react';

interface ProductFormData {
  title: string;
  description: string;
  price: string;
  currency: string;
  category: string;
  subcategory: string;
  condition: string;
  brand: string;
  model: string;
  color: string;
  size: string;
  weight: string;
  dimensions: string;
  features: string;
  warranty: string;
  yearManufactured: string;
  isPriceNegotiable: boolean;
  isBoostEnabled: boolean;
}

interface ModernStep1ProductDetailsProps {
  formData: ProductFormData;
  onFormChange: (field: keyof ProductFormData, value: string | boolean) => void;
  categories: any[];
  subcategories: any[];
}

export const ModernStep1ProductDetails: React.FC<ModernStep1ProductDetailsProps> = ({
  formData,
  onFormChange,
  categories,
  subcategories
}) => {
  return (
    <StepCard 
      title="Product Details" 
      subtitle="Tell us about your item"
      icon={<Package className="w-5 h-5" />}
    >
      <div className="space-y-6">
        {/* Basic Information */}
        <div className="space-y-4">
          <FloatingLabelInput
            label="Product Title"
            value={formData.title}
            onChange={(value) => onFormChange('title', value)}
            placeholder="Enter a descriptive title"
            required
          />
          
          <FloatingLabelTextarea
            label="Description"
            value={formData.description}
            onChange={(value) => onFormChange('description', value)}
            placeholder="Describe your item in detail"
            rows={4}
            required
          />
          <p className="text-xs text-gray-500 -mt-2 px-1">
            Press Enter for a new line. Start a line with <code>-</code> to add a bullet.
          </p>
        </div>

        {/* Pricing Section */}
        <Card className="backdrop-blur-sm bg-white/50 border-white/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-4">
              <DollarSign className="w-4 h-4 text-green-600" />
              <h3 className="font-semibold text-gray-900">Pricing</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="md:col-span-2">
                <FloatingLabelInput
                  label="Price"
                  value={formData.price}
                  onChange={(value) => onFormChange('price', value)}
                  type="number"
                  placeholder="0.00"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">Currency</Label>
                <Select value={formData.currency || undefined} onValueChange={(value) => onFormChange('currency', value)}>
                  <SelectTrigger className="bg-white/70 backdrop-blur-sm border-white/30">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="UGX">UGX</SelectItem>
                    <SelectItem value="USD">USD</SelectItem>
                    <SelectItem value="EUR">EUR</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Switch
                  checked={formData.isPriceNegotiable}
                  onCheckedChange={(checked) => onFormChange('isPriceNegotiable', checked)}
                />
                <Label className="text-sm text-gray-600">Price is negotiable</Label>
              </div>
              {formData.isPriceNegotiable && (
                <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                  Negotiable
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Category Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-700">Category *</Label>
            <Select value={formData.category || undefined} onValueChange={(value) => onFormChange('category', value)}>
              <SelectTrigger className="bg-white/70 backdrop-blur-sm border-white/30">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {categories.filter(category => category.id && category.id.toString().trim() !== '').map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-700">Subcategory</Label>
            <Select 
              value={formData.subcategory || undefined} 
              onValueChange={(value) => onFormChange('subcategory', value)}
              disabled={!formData.category}
            >
              <SelectTrigger className="bg-white/70 backdrop-blur-sm border-white/30">
                <SelectValue placeholder="Select subcategory" />
              </SelectTrigger>
              <SelectContent>
                {subcategories.filter(subcategory => subcategory.id && subcategory.id.toString().trim() !== '').map((subcategory) => (
                  <SelectItem key={subcategory.id} value={subcategory.id}>
                    {subcategory.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Condition */}
        <div className="space-y-2">
          <Label className="text-sm font-medium text-gray-700">Condition *</Label>
          <Select value={formData.condition || undefined} onValueChange={(value) => onFormChange('condition', value)}>
            <SelectTrigger className="bg-white/70 backdrop-blur-sm border-white/30">
              <SelectValue placeholder="Select condition" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="new">New</SelectItem>
              <SelectItem value="like-new">Like New</SelectItem>
              <SelectItem value="good">Good</SelectItem>
              <SelectItem value="fair">Fair</SelectItem>
              <SelectItem value="poor">Poor</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Product Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FloatingLabelInput
            label="Brand"
            value={formData.brand}
            onChange={(value) => onFormChange('brand', value)}
            placeholder="e.g., Apple, Samsung"
          />
          
          <FloatingLabelInput
            label="Model"
            value={formData.model}
            onChange={(value) => onFormChange('model', value)}
            placeholder="e.g., iPhone 13, Galaxy S21"
          />
          
          <FloatingLabelInput
            label="Color"
            value={formData.color}
            onChange={(value) => onFormChange('color', value)}
            placeholder="e.g., Black, White, Red"
          />
          
          <FloatingLabelInput
            label="Size"
            value={formData.size}
            onChange={(value) => onFormChange('size', value)}
            placeholder="e.g., Large, 64GB, 15 inch"
          />
          
          <FloatingLabelInput
            label="Weight"
            value={formData.weight}
            onChange={(value) => onFormChange('weight', value)}
            placeholder="e.g., 1.5kg, 200g"
          />
          
          <FloatingLabelInput
            label="Dimensions"
            value={formData.dimensions}
            onChange={(value) => onFormChange('dimensions', value)}
            placeholder="e.g., 30x20x10 cm"
          />
          
          <FloatingLabelInput
            label="Year Manufactured"
            value={formData.yearManufactured}
            onChange={(value) => onFormChange('yearManufactured', value)}
            type="number"
            placeholder="2023"
          />
          
          <FloatingLabelInput
            label="Warranty"
            value={formData.warranty}
            onChange={(value) => onFormChange('warranty', value)}
            placeholder="e.g., 1 year, 6 months"
          />
        </div>

        {/* Features */}
        <FloatingLabelTextarea
          label="Features"
          value={formData.features}
          onChange={(value) => onFormChange('features', value)}
          placeholder="List key features and specifications"
          rows={3}
        />

        {/* Boost Feature */}
        <Card className="backdrop-blur-sm bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Sparkles className="w-5 h-5 text-amber-600" />
                <div>
                  <h3 className="font-semibold text-gray-900">Boost Your Ad</h3>
                  <p className="text-sm text-gray-600">Get more visibility for your listing</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={formData.isBoostEnabled}
                  onCheckedChange={(checked) => onFormChange('isBoostEnabled', checked)}
                />
                {formData.isBoostEnabled && (
                  <Badge className="bg-amber-100 text-amber-700">
                    <Star className="w-3 h-3 mr-1" />
                    Boosted
                  </Badge>
                )}
              </div>
            </div>
            {formData.isBoostEnabled && (
              <div className="mt-3 p-3 bg-amber-100 rounded-lg">
                <p className="text-sm text-amber-800">
                  💡 Your ad will appear at the top of search results for 7 days. Payment will be required before publishing.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </StepCard>
  );
};
