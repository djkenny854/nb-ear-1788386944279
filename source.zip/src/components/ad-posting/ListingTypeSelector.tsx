
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Package, Users, Briefcase, Download, Tag } from 'lucide-react';
import { ListingType } from '@/types/listing';
import { cn } from '@/lib/utils';

interface ListingTypeSelectorProps {
  selectedType: string;
  onTypeChange: (type: string) => void;
}

const iconMap = {
  Package,
  Users,
  Briefcase,
  Download,
  Tag
};

export const ListingTypeSelector: React.FC<ListingTypeSelectorProps> = ({
  selectedType,
  onTypeChange
}) => {
  const { data: listingTypes, isLoading } = useQuery({
    queryKey: ['listing-types'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('listing_types')
        .select('*')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      return data as ListingType[];
    }
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-4">
              <div className="h-12 w-12 bg-gray-200 rounded-lg mb-3 mx-auto"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-3 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">What are you posting?</h3>
        <p className="text-gray-600 text-sm">Choose the type of listing you want to create</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {listingTypes?.map((type) => {
          const IconComponent = iconMap[type.icon as keyof typeof iconMap] || Package;
          const isSelected = selectedType === type.name;
          
          return (
            <Card
              key={type.id}
              className={cn(
                "cursor-pointer transition-all duration-200 hover:shadow-md border-2",
                isSelected
                  ? "border-blue-500 bg-blue-50 shadow-md"
                  : "border-gray-200 hover:border-gray-300"
              )}
              onClick={() => onTypeChange(type.name)}
            >
              <CardContent className="p-4 text-center">
                <div className={cn(
                  "w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3",
                  isSelected ? "bg-blue-100 text-blue-600" : "bg-gray-100 text-gray-600"
                )}>
                  <IconComponent className="w-6 h-6" />
                </div>
                <h4 className="font-medium text-gray-900 mb-1 text-sm">
                  {type.display_name}
                </h4>
                <p className="text-xs text-gray-500 leading-tight">
                  {type.description}
                </p>
                {isSelected && (
                  <Badge className="mt-2 bg-blue-500 text-white">
                    Selected
                  </Badge>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};
