import React from "react";

/**
 * Soft, brand-tinted illustrations for the media wizard empty states.
 * Pure SVG, inherits primary color via currentColor where possible.
 */

export const StackedFramesIllustration: React.FC<{ className?: string }> = ({
  className = "",
}) => (
  <svg
    viewBox="0 0 240 180"
    className={className}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    {/* soft leaf accent */}
    <path
      d="M120 38c34 0 56 28 56 70 0 18-8 32-22 38H86c-14-6-22-20-22-38 0-42 22-70 56-70z"
      className="fill-primary/5"
    />
    {/* back frame (image) */}
    <g transform="rotate(-8 100 95)">
      <rect x="58" y="48" width="86" height="106" rx="14" className="fill-primary/15 stroke-primary/30" strokeWidth="1.5" />
      <rect x="68" y="58" width="66" height="68" rx="8" className="fill-card" />
      <path d="M72 116l16-20 14 16 10-10 18 20H72z" className="fill-primary/40" />
      <circle cx="118" cy="78" r="6" className="fill-primary/40" />
    </g>
    {/* front frame (video) */}
    <g transform="rotate(8 150 95)">
      <rect x="106" y="48" width="86" height="106" rx="14" className="fill-primary/25 stroke-primary/40" strokeWidth="1.5" />
      <rect x="116" y="58" width="66" height="68" rx="8" className="fill-card" />
      <path d="M138 78l22 14-22 14V78z" className="fill-primary/60" />
    </g>
  </svg>
);

export const PlayCardIllustration: React.FC<{ className?: string }> = ({
  className = "",
}) => (
  <svg
    viewBox="0 0 240 180"
    className={className}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    <ellipse cx="120" cy="158" rx="80" ry="8" className="fill-primary/10" />
    <rect x="60" y="32" width="120" height="110" rx="18" className="fill-primary/15 stroke-primary/30" strokeWidth="1.5" />
    <rect x="72" y="44" width="96" height="72" rx="10" className="fill-card" />
    <circle cx="120" cy="80" r="22" className="fill-primary/70" />
    <path d="M114 70l16 10-16 10V70z" className="fill-card" />
    <rect x="80" y="124" width="56" height="6" rx="3" className="fill-primary/30" />
    <rect x="80" y="134" width="36" height="4" rx="2" className="fill-primary/20" />
  </svg>
);