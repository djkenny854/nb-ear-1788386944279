import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Loader2, Sparkles } from "lucide-react";
import { formatBytes, type CompressionProgress } from "@/utils/videoCompression";

interface Props {
  open: boolean;
  progress: CompressionProgress | null;
  originalSize?: number;
}

const STAGE_LABELS: Record<CompressionProgress["stage"], string> = {
  loading: "Preparing compressor…",
  compressing: "Compressing video…",
  shrinking: "Optimizing size…",
  thumbnail: "Generating thumbnail…",
  done: "Finalizing…",
};

const VideoCompressionDialog: React.FC<Props> = ({ open, progress, originalSize }) => {
  const overall = progress?.overall ?? 0;
  const label = progress ? STAGE_LABELS[progress.stage] : "Starting…";

  return (
    <Dialog open={open}>
      <DialogContent
        className="sm:max-w-md [&>button]:hidden"
        onPointerDownOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => e.preventDefault()}
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Optimizing your video
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="flex items-center gap-3">
            <Loader2 className="w-5 h-5 animate-spin text-primary" />
            <div className="text-sm">{label}</div>
          </div>
          <Progress value={overall} className="h-2" />
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{overall}%</span>
            {originalSize ? <span>Original: {formatBytes(originalSize)}</span> : null}
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            We're shrinking your video to upload faster while keeping audio and quality. This
            happens on your device — your video never leaves until you publish.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default VideoCompressionDialog;