import React from 'react';
import FloatingBorderInput from '@/components/publish/FloatingBorderInput';
import { cn } from '@/lib/utils';

interface FloatingLabelInputProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: 'text' | 'number' | 'email';
  placeholder?: string;
  required?: boolean;
  className?: string;
}

export const FloatingLabelInput: React.FC<FloatingLabelInputProps> = ({
  label,
  value,
  onChange,
  type = 'text',
  required = false,
  className,
}) => {
  return (
    <FloatingBorderInput
      label={label}
      value={value ?? ''}
      onChange={onChange}
      type={type}
      required={required}
      className={cn(className)}
    />
  );
};
