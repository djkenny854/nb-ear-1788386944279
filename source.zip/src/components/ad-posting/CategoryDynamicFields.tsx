import { useState, useEffect } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Smartphone, Car, Home, Shirt, Wrench, Laptop, Sofa, Baby, Dumbbell, Briefcase } from 'lucide-react';
import BrandSelector from '@/components/ui/BrandSelector';

// Category field configurations
export const CATEGORY_FIELDS: Record<string, CategoryFieldConfig[]> = {
  // Electronics
  'electronics': [
    { name: 'brand', label: 'Brand', type: 'brand', required: true, placeholder: 'Select brand', brandCategory: 'Electronics' },
    { name: 'model', label: 'Model', type: 'text', required: true, placeholder: 'e.g., iPhone 15 Pro' },
    { name: 'storage', label: 'Storage Capacity', type: 'select', options: ['16GB', '32GB', '64GB', '128GB', '256GB', '512GB', '1TB', '2TB', 'N/A'] },
    { name: 'ram', label: 'RAM', type: 'select', options: ['1GB', '2GB', '4GB', '6GB', '8GB', '12GB', '16GB', '32GB', '64GB', 'N/A'] },
    { name: 'screen_size', label: 'Screen Size', type: 'text', placeholder: 'e.g., 6.1 inches' },
    { name: 'battery_health', label: 'Battery Health (%)', type: 'number', placeholder: '100' },
    { name: 'color', label: 'Color', type: 'text', placeholder: 'e.g., Space Black' },
    { name: 'warranty_status', label: 'Warranty Status', type: 'select', options: ['Under Warranty', 'Warranty Expired', 'No Warranty'] },
    { name: 'includes_accessories', label: 'Includes Original Accessories', type: 'boolean' },
    { name: 'has_original_box', label: 'Has Original Box', type: 'boolean' },
  ],

  // Vehicles
  'vehicles': [
    { name: 'make', label: 'Make', type: 'brand', required: true, placeholder: 'Select make', brandCategory: 'Vehicles' },
    { name: 'model', label: 'Model', type: 'text', required: true, placeholder: 'e.g., Camry, Civic, X5' },
    { name: 'year_manufactured', label: 'Year of Manufacture', type: 'number', required: true, placeholder: '2020' },
    { name: 'mileage', label: 'Mileage (km)', type: 'number', required: true, placeholder: '50000' },
    { name: 'fuel_type', label: 'Fuel Type', type: 'select', required: true, options: ['Petrol', 'Diesel', 'Electric', 'Hybrid', 'LPG'] },
    { name: 'transmission', label: 'Transmission', type: 'select', required: true, options: ['Automatic', 'Manual', 'CVT', 'Semi-Automatic'] },
    { name: 'engine_size', label: 'Engine Size', type: 'text', placeholder: 'e.g., 2.0L, 1500cc' },
    { name: 'body_type', label: 'Body Type', type: 'select', options: ['Sedan', 'SUV', 'Hatchback', 'Pickup', 'Van', 'Coupe', 'Wagon', 'Convertible'] },
    { name: 'drive_type', label: 'Drive Type', type: 'select', options: ['FWD', 'RWD', 'AWD', '4WD'] },
    { name: 'color', label: 'Exterior Color', type: 'text', placeholder: 'e.g., White Pearl' },
    { name: 'interior_color', label: 'Interior Color', type: 'text', placeholder: 'e.g., Black Leather' },
    { name: 'registration_status', label: 'Registration Status', type: 'select', options: ['Registered', 'Unregistered', 'Expired'] },
    { name: 'vehicle_location', label: 'Vehicle Location', type: 'text', placeholder: 'e.g., Kampala, Kololo' },
    { name: 'vin_number', label: 'VIN/Chassis Number (Optional)', type: 'text', placeholder: 'Last 4 digits' },
    { name: 'service_history', label: 'Service History Available', type: 'boolean' },
    { name: 'accident_free', label: 'Accident Free', type: 'boolean' },
  ],

  // Real Estate
  'real-estate': [
    { name: 'property_type', label: 'Property Type', type: 'select', required: true, options: ['House', 'Land', 'Commercial', 'Shop', 'Office', 'Warehouse'] },
    { name: 'listing_purpose', label: 'Purpose', type: 'select', required: true, options: ['For Sale'] },
    { name: 'bedrooms', label: 'Bedrooms', type: 'select', options: ['Studio', '1', '2', '3', '4', '5', '6+', 'N/A'] },
    { name: 'bathrooms', label: 'Bathrooms', type: 'select', options: ['1', '2', '3', '4', '5+', 'N/A'] },
    { name: 'property_size', label: 'Size', type: 'text', placeholder: 'e.g., 1500 sqft or 50 decimals' },
    { name: 'size_unit', label: 'Size Unit', type: 'select', options: ['Square Feet', 'Square Meters', 'Decimals', 'Acres', 'Hectares'] },
    { name: 'furnished', label: 'Furnished', type: 'select', options: ['Fully Furnished', 'Semi Furnished', 'Unfurnished'] },
    { name: 'water_available', label: 'Water Available', type: 'boolean' },
    { name: 'electricity_available', label: 'Electricity Available', type: 'boolean' },
    { name: 'parking', label: 'Parking', type: 'select', options: ['None', '1 Car', '2 Cars', '3+ Cars', 'Garage'] },
    { name: 'ownership_type', label: 'Ownership Type', type: 'select', options: ['Freehold', 'Leasehold', 'Mailo'] },
    { name: 'documents_ready', label: 'Title/Documents Ready', type: 'boolean' },
    { name: 'compound_size', label: 'Compound/Plot Size', type: 'text', placeholder: 'e.g., 50x100ft' },
    { name: 'year_built', label: 'Year Built', type: 'number', placeholder: '2020' },
  ],

  // Fashion & Clothing
  'fashion': [
    { name: 'gender', label: 'Gender', type: 'select', required: true, options: ['Men', 'Women', 'Unisex', 'Boys', 'Girls'] },
    { name: 'size', label: 'Size', type: 'select', required: true, options: ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', 'Custom', 'One Size'] },
    { name: 'numeric_size', label: 'Numeric Size (if applicable)', type: 'text', placeholder: 'e.g., 32, 42, 10' },
    { name: 'color', label: 'Color', type: 'text', required: true, placeholder: 'e.g., Navy Blue' },
    { name: 'material', label: 'Material', type: 'text', placeholder: 'e.g., Cotton, Polyester, Leather' },
    { name: 'brand', label: 'Brand', type: 'brand', placeholder: 'Select brand', brandCategory: 'Fashion' },
    { name: 'age_group', label: 'Age Group', type: 'select', options: ['Baby (0-2)', 'Kids (3-12)', 'Teens (13-17)', 'Adults', 'All Ages'] },
    { name: 'style_type', label: 'Style Type', type: 'select', options: ['Casual', 'Formal', 'Sports', 'Traditional', 'Streetwear', 'Vintage'] },
    { name: 'pattern', label: 'Pattern', type: 'select', options: ['Solid', 'Striped', 'Plaid', 'Floral', 'Printed', 'Other'] },
    { name: 'care_instructions', label: 'Care Instructions', type: 'text', placeholder: 'e.g., Machine Washable' },
  ],

  // Home & Furniture
  'furniture': [
    { name: 'furniture_type', label: 'Furniture Type', type: 'select', required: true, options: ['Sofa', 'Bed', 'Table', 'Chair', 'Cabinet', 'Wardrobe', 'Desk', 'Shelf', 'Other'] },
    { name: 'material', label: 'Material', type: 'select', options: ['Wood', 'Metal', 'Plastic', 'Glass', 'Fabric', 'Leather', 'Composite'] },
    { name: 'color', label: 'Color', type: 'text', placeholder: 'e.g., Brown Oak' },
    { name: 'dimensions', label: 'Dimensions (L x W x H)', type: 'text', placeholder: 'e.g., 200cm x 90cm x 45cm' },
    { name: 'seating_capacity', label: 'Seating Capacity (if applicable)', type: 'select', options: ['1', '2', '3', '4', '5', '6+', 'N/A'] },
    { name: 'assembly_required', label: 'Assembly Required', type: 'boolean' },
    { name: 'weight_capacity', label: 'Weight Capacity', type: 'text', placeholder: 'e.g., 150kg' },
  ],

  // Sports & Fitness
  'sports': [
    { name: 'sport_type', label: 'Sport/Activity', type: 'text', required: true, placeholder: 'e.g., Football, Gym, Running' },
    { name: 'brand', label: 'Brand', type: 'brand', placeholder: 'Select brand', brandCategory: 'Fashion' },
    { name: 'size', label: 'Size', type: 'text', placeholder: 'e.g., Size 5, Large' },
    { name: 'gender', label: 'Gender', type: 'select', options: ['Men', 'Women', 'Unisex', 'Kids'] },
    { name: 'weight', label: 'Weight', type: 'text', placeholder: 'e.g., 5kg' },
    { name: 'includes_accessories', label: 'Includes Accessories', type: 'boolean' },
  ],

  // Baby & Kids
  'baby-kids': [
    { name: 'age_range', label: 'Age Range', type: 'select', required: true, options: ['0-6 months', '6-12 months', '1-2 years', '2-4 years', '4-6 years', '6-10 years', '10+ years'] },
    { name: 'gender', label: 'Gender', type: 'select', options: ['Boys', 'Girls', 'Unisex'] },
    { name: 'brand', label: 'Brand', type: 'brand', placeholder: 'Select brand', brandCategory: 'Electronics' },
    { name: 'safety_certified', label: 'Safety Certified', type: 'boolean' },
    { name: 'material', label: 'Material', type: 'text', placeholder: 'e.g., BPA-Free Plastic' },
  ],

  // Food & Beverages (perishable / prepared food)
  'food': [
    { name: 'preparation', label: 'Preparation', type: 'select', required: true, options: ['Made-to-order', 'Ready now', 'Pre-order'] },
    { name: 'serving_size', label: 'Serving Size', type: 'text', placeholder: 'e.g., 1 person, family pack' },
    { name: 'cuisine_type', label: 'Cuisine / Style', type: 'text', placeholder: 'e.g., Ugandan, Indian, Continental' },
    { name: 'dietary_tags', label: 'Dietary', type: 'select', options: ['None', 'Vegetarian', 'Vegan', 'Halal', 'Gluten-free'] },
    { name: 'spice_level', label: 'Spice Level', type: 'select', options: ['Mild', 'Medium', 'Hot', 'Extra Hot', 'N/A'] },
    { name: 'packaging', label: 'Packaging', type: 'select', options: ['Dine-in', 'Takeaway', 'Both'] },
    { name: 'delivery_available', label: 'Delivery available', type: 'boolean' },
    { name: 'delivery_radius_km', label: 'Delivery Radius (km)', type: 'number', placeholder: 'e.g., 5' },
    { name: 'lead_time_minutes', label: 'Prep / Lead Time (minutes)', type: 'number', placeholder: 'e.g., 30' },
    { name: 'available_from', label: 'Available From', type: 'text', placeholder: 'e.g., 11:00' },
    { name: 'available_to', label: 'Available To', type: 'text', placeholder: 'e.g., 22:00' },
  ],
};

// Service categories mapping
export const SERVICE_CATEGORIES = [
  { value: 'accommodation', label: 'Accommodation & Rentals' },
  { value: 'repair', label: 'Repair & Maintenance' },
  { value: 'design', label: 'Design & Creative' },
  { value: 'cleaning', label: 'Cleaning & Housekeeping' },
  { value: 'transport', label: 'Transport & Delivery' },
  { value: 'it', label: 'IT & Technology' },
  { value: 'education', label: 'Education & Tutoring' },
  { value: 'beauty', label: 'Beauty & Personal Care' },
  { value: 'health', label: 'Health & Wellness' },
  { value: 'events', label: 'Events & Entertainment' },
  { value: 'legal', label: 'Legal & Finance' },
  { value: 'construction', label: 'Construction & Building' },
  { value: 'agriculture', label: 'Agriculture & Farming' },
  { value: 'security', label: 'Security Services' },
  { value: 'photography', label: 'Photography & Video' },
  { value: 'writing', label: 'Writing & Translation' },
  { value: 'marketing', label: 'Marketing & Advertising' },
  { value: 'consulting', label: 'Consulting & Business' },
  { value: 'other', label: 'Other Services' },
];

export interface CategoryFieldConfig {
  name: string;
  label: string;
  type: 'text' | 'number' | 'select' | 'boolean' | 'textarea' | 'brand';
  required?: boolean;
  placeholder?: string;
  options?: string[];
  brandCategory?: string;
}

interface CategoryDynamicFieldsProps {
  categoryName: string;
  values: Record<string, any>;
  onChange: (name: string, value: any) => void;
}

// Normalize category name to match our keys
const normalizeCategoryName = (name: string): string => {
  const normalized = name.toLowerCase().trim();
  
  // Map various category names to our field config keys
  const categoryMap: Record<string, string> = {
    'electronics': 'electronics',
    'phones & tablets': 'electronics',
    'phones': 'electronics',
    'computers': 'electronics',
    'laptops': 'electronics',
    'tvs': 'electronics',
    'audio': 'electronics',
    
    'vehicles': 'vehicles',
    'cars': 'vehicles',
    'motorcycles': 'vehicles',
    'bikes': 'vehicles',
    'trucks': 'vehicles',
    
    'real estate': 'real-estate',
    'property': 'real-estate',
    'houses': 'real-estate',
    'land': 'real-estate',
    'apartments': 'real-estate',
    
    'fashion': 'fashion',
    'clothing': 'fashion',
    'fashion & clothing': 'fashion',
    'shoes': 'fashion',
    'accessories': 'fashion',
    
    'furniture': 'furniture',
    'home & furniture': 'furniture',
    'home': 'furniture',
    
    'sports': 'sports',
    'sports & fitness': 'sports',
    'fitness': 'sports',
    'gym': 'sports',
    
    'baby & kids': 'baby-kids',
    'baby': 'baby-kids',
    'kids': 'baby-kids',
    'toys': 'baby-kids',

    // Food & Beverages (and food-related subcategories)
    'food & beverages': 'food',
    'food and beverages': 'food',
    'food': 'food',
    'restaurant meals': 'food',
    'street food (rolex, chapati, etc.)': 'food',
    'street food': 'food',
    'local cuisine': 'food',
    'bakery & pastries': 'food',
    'bakery and pastries': 'food',
    'beverages & juices': 'food',
    'beverages and juices': 'food',
    'catering services': 'food',
    'home-cooked meals': 'food',
    'home cooked meals': 'food',
  };
  
  return categoryMap[normalized] || '';
};

// Categories where the standard "Condition" field does not apply
export const PERISHABLE_CATEGORY_KEYS = new Set(['food']);

const PERISHABLE_NAME_KEYWORDS = [
  'food', 'beverage', 'restaurant', 'meal', 'cuisine',
  'bakery', 'pastr', 'juice', 'catering', 'home-cooked',
  'street food', 'rolex', 'chapati', 'eatery'
];

/**
 * Returns true when the given category/subcategory name should hide the
 * standard "Condition" selector and use food-specific fields instead.
 */
export function isPerishableCategory(name: string | null | undefined): boolean {
  if (!name) return false;
  const key = normalizeCategoryName(name);
  if (PERISHABLE_CATEGORY_KEYS.has(key)) return true;
  const lower = name.toLowerCase();
  return PERISHABLE_NAME_KEYWORDS.some(k => lower.includes(k));
}

// Get icon for category
const getCategoryIcon = (categoryKey: string) => {
  const icons: Record<string, any> = {
    'electronics': Smartphone,
    'vehicles': Car,
    'real-estate': Home,
    'fashion': Shirt,
    'furniture': Sofa,
    'sports': Dumbbell,
    'baby-kids': Baby,
    'services': Wrench,
    'computers': Laptop,
    'jobs': Briefcase,
  };
  return icons[categoryKey] || null;
};

// Conditional sub-fields for real estate based on property_type
const REAL_ESTATE_SUB_FIELDS: Record<string, CategoryFieldConfig[]> = {
  'House': [
    { name: 'amenities', label: 'Amenities', type: 'select', options: ['WiFi', 'CCTV/Security', 'Water Heater', 'Air Conditioning', 'Generator/Backup Power', 'Compound/Yard', 'Balcony', 'Gate/Fence'] },
    { name: 'pets_allowed', label: 'Pets Allowed', type: 'boolean' },
    { name: 'security_type', label: 'Security Type', type: 'select', options: ['24hr Guard', 'Gated Community', 'CCTV Only', 'None'] },
    { name: 'nearby_facilities', label: 'Nearby Facilities', type: 'text', placeholder: 'e.g., Hospital 2km, Market 500m' },
    { name: 'deposit_required', label: 'Deposit Required', type: 'text', placeholder: 'e.g., 2 months rent' },
    { name: 'available_from', label: 'Available From', type: 'text', placeholder: 'e.g., Immediately, March 2026' },
  ],
  // Apartment removed - now under accommodation services
  'Land': [
    { name: 'land_use', label: 'Land Use', type: 'select', required: true, options: ['Residential', 'Commercial', 'Agricultural', 'Industrial', 'Mixed Use'] },
    { name: 'road_access', label: 'Road Access', type: 'select', options: ['Tarmac Road', 'Murram Road', 'Footpath Only', 'No Direct Access'] },
    { name: 'topography', label: 'Topography', type: 'select', options: ['Flat', 'Gentle Slope', 'Hilly', 'Waterfront'] },
    { name: 'proximity_to_town', label: 'Proximity to Town', type: 'text', placeholder: 'e.g., 5km from Kampala CBD' },
    { name: 'has_title', label: 'Has Land Title', type: 'boolean' },
    { name: 'title_type', label: 'Title Type', type: 'select', options: ['Freehold', 'Leasehold', 'Mailo', 'Customary'] },
    { name: 'survey_done', label: 'Survey/Map Available', type: 'boolean' },
  ],
};

export default function CategoryDynamicFields({ categoryName, values, onChange }: CategoryDynamicFieldsProps) {
  const categoryKey = normalizeCategoryName(categoryName);
  const baseFields = CATEGORY_FIELDS[categoryKey] || [];
  
  // Get conditional sub-fields for real estate
  const propertyType = values['property_type'] || '';
  const subFields = categoryKey === 'real-estate' ? (REAL_ESTATE_SUB_FIELDS[propertyType] || []) : [];
  const fields = [...baseFields, ...subFields];
  
  // Hide title_type if has_title is not checked (for Land)
  const visibleFields = fields.filter(f => {
    if (f.name === 'title_type' && !values['has_title']) return false;
    return true;
  });
  
  if (visibleFields.length === 0) {
    return null;
  }
  
  const Icon = getCategoryIcon(categoryKey);
  
  return (
    <div className="space-y-6 border border-border rounded-xl p-5 bg-muted/20">
      <div className="flex items-center gap-3 mb-4">
        {Icon && (
          <div className="p-2 bg-primary/10 rounded-lg">
            <Icon className="w-5 h-5 text-primary" />
          </div>
        )}
        <div>
          <h4 className="text-lg font-semibold capitalize">{categoryName} Details</h4>
          <p className="text-sm text-muted-foreground">
            Provide specific details to help buyers find your listing
          </p>
        </div>
      </div>

      {subFields.length > 0 && (
        <p className="text-xs text-primary font-medium">
          ✨ Additional {propertyType} fields shown below
        </p>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {visibleFields.map((field) => (
          <div key={field.name} className={field.type === 'textarea' ? 'md:col-span-2' : ''}>
            <Label htmlFor={field.name} className="text-sm font-medium flex items-center gap-1">
              {field.label}
              {field.required && <span className="text-destructive">*</span>}
            </Label>
            
            {field.type === 'text' && (
              <Input
                id={field.name}
                value={values[field.name] || ''}
                onChange={(e) => onChange(field.name, e.target.value)}
                placeholder={field.placeholder}
                className="h-11 mt-1.5"
              />
            )}

            {field.type === 'brand' && (
              <BrandSelector
                value={values[field.name] || ''}
                onChange={(value) => onChange(field.name, value)}
                category={field.brandCategory}
                placeholder={field.placeholder}
                className="w-full h-11 mt-1.5"
              />
            )}
            
            {field.type === 'number' && (
              <Input
                id={field.name}
                type="number"
                value={values[field.name] || ''}
                onChange={(e) => onChange(field.name, e.target.value)}
                placeholder={field.placeholder}
                className="h-11 mt-1.5"
              />
            )}
            
            {field.type === 'select' && field.options && (
              <Select 
                value={values[field.name] || ''} 
                onValueChange={(v) => onChange(field.name, v)}
              >
                <SelectTrigger className="h-11 mt-1.5">
                  <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
                </SelectTrigger>
                <SelectContent className="bg-popover z-[200]">
                  {field.options.map((option) => (
                    <SelectItem key={option} value={option}>{option}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            
            {field.type === 'boolean' && (
              <div className="flex items-center gap-3 mt-2 p-3 bg-muted/30 rounded-lg">
                <Switch
                  id={field.name}
                  checked={values[field.name] || false}
                  onCheckedChange={(v) => onChange(field.name, v)}
                />
                <span className="text-sm text-muted-foreground">
                  {values[field.name] ? 'Yes' : 'No'}
                </span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// Inventory/Stock component for sellers with multiple items
export function InventoryField({ 
  value, 
  onChange 
}: { 
  value: number | null; 
  onChange: (value: number | null) => void;
}) {
  const [hasMultiple, setHasMultiple] = useState(value !== null && value > 1);
  
  return (
    <div className="flex items-center justify-between p-5 bg-muted/30 border border-border rounded-xl">
      <div>
        <Label htmlFor="inventory" className="text-base font-medium">Multiple Items in Stock?</Label>
        <p className="text-sm text-muted-foreground mt-1">
          Do you have more than one of this item for sale?
        </p>
      </div>
      <div className="flex items-center gap-4">
        <Switch
          id="has-inventory"
          checked={hasMultiple}
          onCheckedChange={(checked) => {
            setHasMultiple(checked);
            if (!checked) {
              onChange(1);
            }
          }}
        />
        {hasMultiple && (
          <Input
            type="number"
            min={1}
            value={value || ''}
            onChange={(e) => onChange(parseInt(e.target.value) || null)}
            placeholder="Qty"
            className="w-24 h-10"
          />
        )}
      </div>
    </div>
  );
}

// Stock badge component for product cards
export function StockBadge({ count }: { count: number | null }) {
  if (!count || count <= 1) return null;
  
  return (
    <Badge variant="secondary" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
      {count} in stock
    </Badge>
  );
}
