
import React from 'react';
import { Check, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StepIndicatorProps {
  currentStep: number;
  totalSteps: number;
  steps: string[];
}

export const StepIndicator: React.FC<StepIndicatorProps> = ({ 
  currentStep, 
  totalSteps, 
  steps 
}) => {
  const progressPercentage = (currentStep / totalSteps) * 100;

  return (
    <div className="w-full">
      {/* Progress Bar */}
      <div className="relative h-2 bg-gray-200 rounded-full mb-6">
        <div 
          className="absolute top-0 left-0 h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full transition-all duration-500 ease-out"
          style={{ width: `${progressPercentage}%` }}
        />
      </div>

      {/* Desktop Steps */}
      <div className="hidden md:flex items-center justify-between">
        {steps.map((step, index) => {
          const stepNumber = index + 1;
          const isActive = stepNumber === currentStep;
          const isCompleted = stepNumber < currentStep;
          const isUpcoming = stepNumber > currentStep;
          
          return (
            <React.Fragment key={index}>
              <div className="flex items-center">
                <div className={cn(
                  "flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all duration-300",
                  isCompleted 
                    ? "bg-green-500 border-green-500 text-white scale-105" 
                    : isActive 
                      ? "bg-gradient-to-r from-blue-500 to-purple-500 border-transparent text-white scale-110 shadow-lg" 
                      : "bg-white border-gray-300 text-gray-400"
                )}>
                  {isCompleted ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    <span className="text-sm font-semibold">{stepNumber}</span>
                  )}
                </div>
                <div className="ml-3">
                  <p className={cn(
                    "text-sm font-medium transition-colors duration-200",
                    isActive 
                      ? "text-gray-900" 
                      : isCompleted 
                        ? "text-green-600" 
                        : "text-gray-500"
                  )}>
                    {step}
                  </p>
                  {isActive && (
                    <p className="text-xs text-gray-500 mt-1">Current step</p>
                  )}
                </div>
              </div>
              {index < totalSteps - 1 && (
                <div className={cn(
                  "flex-1 h-0.5 mx-4 transition-colors duration-300",
                  isCompleted ? "bg-green-500" : "bg-gray-200"
                )} />
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Mobile Steps */}
      <div className="md:hidden">
        <div className="flex items-center justify-center space-x-2 mb-4">
          {steps.map((_, index) => {
            const stepNumber = index + 1;
            const isActive = stepNumber === currentStep;
            const isCompleted = stepNumber < currentStep;
            
            return (
              <div
                key={index}
                className={cn(
                  "w-3 h-3 rounded-full transition-all duration-300",
                  isCompleted 
                    ? "bg-green-500 scale-110" 
                    : isActive 
                      ? "bg-gradient-to-r from-blue-500 to-purple-500 scale-125" 
                      : "bg-gray-300"
                )}
              />
            );
          })}
        </div>
        <div className="text-center">
          <h2 className="text-lg font-semibold text-gray-900 mb-1">
            {steps[currentStep - 1]}
          </h2>
          <p className="text-sm text-gray-500">
            Step {currentStep} of {totalSteps}
          </p>
        </div>
      </div>
    </div>
  );
};
