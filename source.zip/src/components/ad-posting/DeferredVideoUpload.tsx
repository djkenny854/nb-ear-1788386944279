import React, { useState, useRef } from 'react';
import { Upload, Video, X, Lock, AlertCircle, Scissors, Replace, Clock, FileVideo } from 'lucide-react';
import VideoTrimmerDialog from './VideoTrimmerDialog';
import VideoCompressionDialog from './VideoCompressionDialog';
import { compressVideo, type CompressionProgress, formatBytes } from '@/utils/videoCompression';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/hooks/use-toast';
import { PlayCardIllustration } from './MediaIllustrations';
import { MAX_VIDEO_UPLOAD_MB } from '@/utils/uploadVideoToB2';

interface DeferredVideoUploadProps {
  onVideoSelected: (
    file: File | null,
    previewUrl: string | null,
    thumbnail?: File | null
  ) => void;
  currentPreviewUrl?: string | null;
  isVerified?: boolean;
  maxSizeMB?: number;
}

/**
 * Video upload component that defers actual upload until publish time.
 * Only handles file selection and preview - actual upload happens in the wizard's handleSubmit.
 */
const MAX_DURATION_SECONDS = 600; // 10 minutes

const DeferredVideoUpload: React.FC<DeferredVideoUploadProps> = ({ 
  onVideoSelected, 
  currentPreviewUrl,
  isVerified = true,
  maxSizeMB = MAX_VIDEO_UPLOAD_MB 
}) => {
  const navigate = useNavigate();
  const [videoPreview, setVideoPreview] = useState<string | null>(currentPreviewUrl || null);
  const [uploadEnabled, setUploadEnabled] = useState(true);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [showTrimmer, setShowTrimmer] = useState(false);
  const [compressing, setCompressing] = useState(false);
  const [compressionProgress, setCompressionProgress] = useState<CompressionProgress | null>(null);
  const [originalSize, setOriginalSize] = useState<number>(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Check if video uploads are enabled
  React.useEffect(() => {
    const checkVideoEnabled = async () => {
      const { data, error } = await supabase
        .from('settings')
        .select('setting_value')
        .eq('setting_key', 'video_uploads_enabled')
        .single();

      if (!error && data) {
        setUploadEnabled(data.setting_value === true);
      }
    };

    checkVideoEnabled();
  }, []);

  // Show verification requirement
  if (!isVerified) {
    return (
      <div className="rounded-3xl bg-muted/40 border border-border p-10 text-center space-y-4">
        <div className="mx-auto p-3 bg-muted rounded-full w-fit">
          <Lock className="w-6 h-6 text-muted-foreground" />
        </div>
        <div>
          <h3 className="font-semibold text-lg mb-1">Verification required</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Featured videos are available to verified sellers.
          </p>
          <Button onClick={() => navigate('/verify')} variant="default" className="rounded-full">
            Verify now
          </Button>
        </div>
      </div>
    );
  }

  // Show disabled state
  if (!uploadEnabled) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Video uploads are currently disabled. Please try again later.
        </AlertDescription>
      </Alert>
    );
  }

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    // Any video container is accepted — it is transcoded to baseline MP4
    // (H.264 + AAC, yuv420p, faststart) in the browser before upload.
    if (!file.type.startsWith('video/')) {
      toast({
        title: 'Unsupported file',
        description: 'Please choose a video file.',
        variant: 'destructive',
      });
      return;
    }

    // Validate file size
    const fileSizeMB = file.size / (1024 * 1024);
    if (fileSizeMB > maxSizeMB) {
      toast({
        title: 'Video too large',
        description: `Max ${maxSizeMB} MB. Yours is ${fileSizeMB.toFixed(1)} MB. Try trimming or compressing.`,
        variant: 'destructive',
      });
      return;
    }

    // Create preview
    let previewUrl = URL.createObjectURL(file);

    // Validate duration (≤ 10 minutes)
    try {
      const duration = await getVideoDuration(previewUrl);
      if (duration > MAX_DURATION_SECONDS) {
        URL.revokeObjectURL(previewUrl);
        toast({
          title: 'Video too long',
          description: `Featured videos must be 10 minutes or less. Yours is ${formatDuration(duration)}. Use the Edit tool to trim it after uploading a shorter version.`,
          variant: 'destructive',
        });
        return;
      }
    } catch {
      // If we can't read duration, fall through and let the user upload anyway
    }

    // Compress before storing
    setOriginalSize(file.size);
    setCompressing(true);
    setCompressionProgress({ stage: 'loading', percent: 0, overall: 0 });
    try {
      const result = await compressVideo(file, (p) => setCompressionProgress(p));
      URL.revokeObjectURL(previewUrl);
      previewUrl = URL.createObjectURL(result.video);
      setVideoPreview(previewUrl);
      setSelectedFile(result.video);
      onVideoSelected(result.video, previewUrl, result.thumbnail);
      if (result.compressedSize < result.originalSize) {
        toast({
          title: 'Video optimized',
          description: `${formatBytes(result.originalSize)} → ${formatBytes(result.compressedSize)}`,
        });
      }
    } catch (err) {
      console.error(err);
      setVideoPreview(previewUrl);
      setSelectedFile(file);
      onVideoSelected(file, previewUrl);
    } finally {
      setCompressing(false);
      setCompressionProgress(null);
    }
  };

  const handleTrimComplete = (trimmedFile: File, previewUrl: string) => {
    if (videoPreview && videoPreview.startsWith('blob:')) {
      URL.revokeObjectURL(videoPreview);
    }
    setVideoPreview(previewUrl);
    setSelectedFile(trimmedFile);
    onVideoSelected(trimmedFile, previewUrl);
  };

  const handleRemoveVideo = () => {
    if (videoPreview && videoPreview.startsWith('blob:')) {
      URL.revokeObjectURL(videoPreview);
    }
    setVideoPreview(null);
    onVideoSelected(null, null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-primary/10">
            <Video className="w-4 h-4 text-primary" />
          </div>
          <h3 className="text-base font-semibold">Featured Video</h3>
          <Badge variant="secondary" className="text-[10px] rounded-full px-2">Optional</Badge>
        </div>
        {videoPreview && (
          <div className="flex items-center gap-1">
            {selectedFile && (
              <Button
                type="button"
                onClick={() => setShowTrimmer(true)}
                variant="ghost"
                size="sm"
                className="h-8 px-2 text-xs gap-1"
              >
                <Scissors className="w-3.5 h-3.5" /> Edit
              </Button>
            )}
            <Button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              variant="ghost"
              size="sm"
              className="h-8 px-2 text-xs gap-1"
            >
              <Replace className="w-3.5 h-3.5" /> Replace
            </Button>
            <Button
              type="button"
              onClick={handleRemoveVideo}
              variant="ghost"
              size="sm"
              className="h-8 px-2 text-xs gap-1 text-destructive hover:text-destructive"
            >
              <X className="w-3.5 h-3.5" /> Remove
            </Button>
          </div>
        )}
      </div>

      {/* Description */}
      <p className="text-sm text-muted-foreground">
        This is the hero video shown on your product page and in the social feed.
        If you upload a featured video, photos become optional — buyers see the
        video first.
      </p>

      {videoPreview ? (
        // Preview — respects native aspect ratio (no forced 16:9 squish)
        <div className="rounded-3xl bg-muted/30 border border-border p-3">
          <div className="rounded-2xl overflow-hidden bg-black flex items-center justify-center max-h-[480px]">
            <video
              src={videoPreview}
              className="max-h-[480px] w-auto max-w-full"
              controls
              muted
              controlsList="nodownload noremoteplayback"
              disablePictureInPicture
            />
          </div>
          <p className="text-[11px] text-muted-foreground text-center mt-2">
            Ready — your video will be uploaded when you publish.
          </p>
        </div>
      ) : (
        // Empty state — matches the reference mockup style
        <div
          onClick={() => fileInputRef.current?.click()}
          className="rounded-3xl bg-muted/40 border border-border hover:border-primary/40 hover:bg-muted/60 transition-all p-8 text-center cursor-pointer group"
        >
          <div className="max-w-xs mx-auto">
            <PlayCardIllustration className="w-40 h-32 mx-auto mb-2 text-primary" />
            <h4 className="text-lg font-semibold text-foreground">No featured video yet</h4>
            <p className="text-sm text-muted-foreground mt-1 mb-5">
              Show your product in motion. A 15–60 second clip works best.
            </p>
            <Button
              type="button"
              size="lg"
              className="rounded-full px-6 gap-2 shadow-sm group-hover:shadow-md transition-shadow"
            >
              <Upload className="w-4 h-4" />
              Upload video
            </Button>
          </div>
        </div>
      )}

      {/* Limits row */}
      <div className="flex flex-wrap items-center justify-center gap-1.5 text-[11px]">
        <Chip icon={<FileVideo className="w-3 h-3" />}>MP4 · MOV · WebM</Chip>
        <Chip>Up to {maxSizeMB} MB</Chip>
        <Chip icon={<Clock className="w-3 h-3" />}>Up to 10 minutes</Chip>
        <Chip>9:16 or 16:9 recommended</Chip>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="video/*"
        onChange={handleFileSelect}
        className="hidden"
      />

      {/* Video Trimmer Dialog */}
      {selectedFile && videoPreview && (
        <VideoTrimmerDialog
          open={showTrimmer}
          onClose={() => setShowTrimmer(false)}
          videoFile={selectedFile}
          videoUrl={videoPreview}
          onTrimComplete={handleTrimComplete}
        />
      )}

      <VideoCompressionDialog
        open={compressing}
        progress={compressionProgress}
        originalSize={originalSize}
      />
    </div>
  );
};

const Chip: React.FC<{ children: React.ReactNode; icon?: React.ReactNode }> = ({ children, icon }) => (
  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-muted text-muted-foreground border border-border">
    {icon}
    {children}
  </span>
);

function getVideoDuration(url: string): Promise<number> {
  return new Promise((resolve, reject) => {
    const v = document.createElement('video');
    v.preload = 'metadata';
    v.onloadedmetadata = () => resolve(v.duration);
    v.onerror = () => reject(new Error('Could not read video metadata'));
    v.src = url;
  });
}

function formatDuration(seconds: number) {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}m ${s.toString().padStart(2, '0')}s`;
}

export default DeferredVideoUpload;
