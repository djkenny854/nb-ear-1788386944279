
import React from 'react';
import { FloatingLabelInput } from './FloatingLabelInput';
import { FloatingLabelTextarea } from './FloatingLabelTextarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { FieldMapping } from '@/types/listing';

interface FormFieldConfigProps {
  field: FieldMapping;
  value: any;
  onChange: (value: any) => void;
}

export const FormFieldConfig: React.FC<FormFieldConfigProps> = ({
  field,
  value,
  onChange
}) => {
  const renderField = () => {
    switch (field.field_type) {
      case 'text':
        return (
          <FloatingLabelInput
            label={field.field_name.replace('_', ' ')}
            value={value || ''}
            onChange={onChange}
            required={field.is_required}
          />
        );

      case 'number':
        return (
          <FloatingLabelInput
            label={field.field_name.replace('_', ' ')}
            value={value || ''}
            onChange={onChange}
            type="number"
            required={field.is_required}
          />
        );

      case 'textarea':
        return (
          <FloatingLabelTextarea
            label={field.field_name.replace('_', ' ')}
            value={value || ''}
            onChange={onChange}
            required={field.is_required}
            rows={4}
          />
        );

      case 'select':
        const selectOptions = getSelectOptions(field.field_name);
        return (
          <div className="space-y-2">
            <Label>
              {field.field_name.replace('_', ' ')}
              {field.is_required && <span className="text-red-500 ml-1">*</span>}
            </Label>
            <Select value={value || undefined} onValueChange={onChange}>
              <SelectTrigger>
                <SelectValue placeholder={`Select ${field.field_name.replace('_', ' ')}`} />
              </SelectTrigger>
              <SelectContent>
                {selectOptions.filter(option => option.value && option.value.trim() !== '').map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        );

      case 'boolean':
        return (
          <div className="flex items-center space-x-2">
            <Checkbox
              id={field.field_name}
              checked={value || false}
              onCheckedChange={onChange}
            />
            <Label htmlFor={field.field_name}>
              {field.field_name.replace('_', ' ')}
            </Label>
          </div>
        );

      case 'date':
        return (
          <div className="space-y-2">
            <Label>
              {field.field_name.replace('_', ' ')}
              {field.is_required && <span className="text-red-500 ml-1">*</span>}
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {value ? format(new Date(value), 'PPP') : 'Pick a date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={value ? new Date(value) : undefined}
                  onSelect={(date) => onChange(date?.toISOString())}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
        );

      default:
        return null;
    }
  };

  return <div className="space-y-2">{renderField()}</div>;
};

// Helper function to get select options based on field name
const getSelectOptions = (fieldName: string) => {
  const optionsMap: Record<string, { value: string; label: string }[]> = {
    condition: [
      { value: 'new', label: 'New' },
      { value: 'like_new', label: 'Like New' },
      { value: 'good', label: 'Good' },
      { value: 'fair', label: 'Fair' },
      { value: 'poor', label: 'Poor' }
    ],
    job_type: [
      { value: 'full_time', label: 'Full Time' },
      { value: 'part_time', label: 'Part Time' },
      { value: 'contract', label: 'Contract' },
      { value: 'internship', label: 'Internship' }
    ],
    work_location: [
      { value: 'remote', label: 'Remote' },
      { value: 'on_site', label: 'On Site' },
      { value: 'hybrid', label: 'Hybrid' }
    ],
    file_type: [
      { value: 'ebook', label: 'E-book' },
      { value: 'software', label: 'Software' },
      { value: 'course', label: 'Online Course' },
      { value: 'template', label: 'Template' },
      { value: 'music', label: 'Music' },
      { value: 'video', label: 'Video' }
    ],
    license_type: [
      { value: 'personal', label: 'Personal Use' },
      { value: 'commercial', label: 'Commercial Use' },
      { value: 'extended', label: 'Extended License' }
    ],
    offer_type: [
      { value: 'discount', label: 'Discount' },
      { value: 'free_trial', label: 'Free Trial' },
      { value: 'bundle', label: 'Bundle Deal' },
      { value: 'cashback', label: 'Cashback' }
    ],
    shipping_options: [
      { value: 'pickup_only', label: 'Pickup Only' },
      { value: 'delivery_available', label: 'Delivery Available' },
      { value: 'shipping_available', label: 'Shipping Available' }
    ]
  };

  return optionsMap[fieldName] || [];
};
