import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Globe, Shield, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import mastercardLogo from '@/assets/mastercard.svg';
import mtnLogo from '@/assets/mtn.svg';
import airtelLogo from '@/assets/airtel.svg';

interface PaymentMethodsDisplayProps {
  mobileMoneyEnabled: boolean;
  stripeEnabled: boolean;
  variant?: 'compact' | 'full';
  onViewAll?: () => void;
}

export const PaymentMethodsDisplay = ({
  mobileMoneyEnabled,
  stripeEnabled,
  variant = 'full',
  onViewAll,
}: PaymentMethodsDisplayProps) => {
  const paymentMethods = [
    { 
      id: '1', 
      type: 'mobile_money' as const, 
      name: 'MTN Mobile Money', 
      brand: 'MTN', 
      description: 'Pay with MTN MoMo',
      status: mobileMoneyEnabled ? 'active' : 'disabled',
      isDefault: true,
    },
    { 
      id: '2', 
      type: 'mobile_money' as const, 
      name: 'Airtel Money', 
      brand: 'Airtel', 
      description: 'Pay with Airtel Money',
      status: mobileMoneyEnabled ? 'active' : 'disabled',
      isDefault: false,
    },
    { 
      id: '3', 
      type: 'card' as const, 
      name: 'Visa/Mastercard', 
      brand: 'Stripe', 
      description: 'International card payments',
      status: stripeEnabled ? 'active' : 'disabled',
      isDefault: false,
    },
  ];

  if (variant === 'compact') {
    return (
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Payment Methods</CardTitle>
            {onViewAll && (
              <Button variant="ghost" size="sm" onClick={onViewAll} className="gap-1">
                View All <ChevronRight className="w-4 h-4" />
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {paymentMethods.map((method) => (
            <div key={method.id} className={cn(
              "flex items-center gap-3 p-3 rounded-lg border transition-all",
              method.status === 'disabled' ? "opacity-60 bg-muted/50" : "bg-card hover:shadow-sm"
            )}>
              <div className="w-12 h-8 flex items-center justify-center bg-background rounded border">
                {method.brand === 'MTN' && <img src={mtnLogo} alt="MTN" className="w-10 h-6 object-contain" />}
                {method.brand === 'Airtel' && <img src={airtelLogo} alt="Airtel" className="w-10 h-6 object-contain" />}
                {method.brand === 'Stripe' && <Globe className="w-5 h-5 text-[#635bff]" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">{method.name}</p>
                <p className="text-xs text-muted-foreground">{method.description}</p>
              </div>
              <Badge 
                variant="outline" 
                className={cn(
                  "text-[10px]",
                  method.status === 'active' 
                    ? "border-green-500/50 text-green-600 bg-green-500/10" 
                    : "border-amber-500/50 text-amber-600 bg-amber-500/10"
                )}
              >
                {method.status === 'active' ? 'Active' : 'Coming Soon'}
              </Badge>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Mobile Money */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Mobile Money</CardTitle>
          <CardDescription>Pay with MTN or Airtel Mobile Money</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {paymentMethods.filter(m => m.type === 'mobile_money').map((method) => (
            <div key={method.id} className={cn(
              "flex items-center gap-4 p-4 rounded-xl border-2 transition-all",
              method.status === 'disabled' 
                ? "opacity-60 bg-muted/30 border-dashed" 
                : "bg-card hover:border-primary/50 hover:shadow-md",
              method.isDefault && method.status === 'active' && "border-primary"
            )}>
              <div className="w-14 h-10 flex items-center justify-center bg-background rounded-lg border">
                {method.brand === 'MTN' && <img src={mtnLogo} alt="MTN" className="w-12 h-7 object-contain" />}
                {method.brand === 'Airtel' && <img src={airtelLogo} alt="Airtel" className="w-12 h-7 object-contain" />}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h4 className="font-medium">{method.name}</h4>
                  {method.isDefault && method.status === 'active' && (
                    <Badge className="bg-primary/10 text-primary text-[10px]">Default</Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">{method.description}</p>
              </div>
              <Badge 
                variant="outline" 
                className={cn(
                  method.status === 'active' 
                    ? "border-green-500/50 text-green-600 bg-green-500/10" 
                    : "border-amber-500/50 text-amber-600 bg-amber-500/10"
                )}
              >
                {method.status === 'active' ? 'Available' : 'Coming Soon'}
              </Badge>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* International Cards */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Globe className="w-5 h-5 text-[#635bff]" />
            International Cards (Stripe)
          </CardTitle>
          <CardDescription>Pay with Visa, Mastercard, or other cards worldwide</CardDescription>
        </CardHeader>
        <CardContent>
          {paymentMethods.filter(m => m.type === 'card').map((method) => (
            <div key={method.id} className={cn(
              "flex items-center gap-4 p-4 rounded-xl border-2 transition-all",
              method.status === 'disabled' 
                ? "opacity-60 bg-muted/30 border-dashed" 
                : "bg-card hover:border-primary/50 hover:shadow-md"
            )}>
              <div className="w-14 h-10 flex items-center justify-center bg-background rounded-lg border">
                <img src={mastercardLogo} alt="Card" className="w-10 h-6 object-contain" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium">Visa / Mastercard</h4>
                <p className="text-sm text-muted-foreground">International card payments</p>
              </div>
              <Badge 
                variant="outline" 
                className={cn(
                  method.status === 'active' 
                    ? "border-green-500/50 text-green-600 bg-green-500/10" 
                    : "border-amber-500/50 text-amber-600 bg-amber-500/10"
                )}
              >
                {method.status === 'active' ? 'Available' : 'Coming Soon'}
              </Badge>
            </div>
          ))}

          {!stripeEnabled && (
            <div className="mt-4 p-4 rounded-lg bg-muted/50 border border-dashed">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm font-medium">Secure Card Payments Coming Soon</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    We're setting up secure payment processing with Stripe. Card payments will be available in 2-3 months.
                  </p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
