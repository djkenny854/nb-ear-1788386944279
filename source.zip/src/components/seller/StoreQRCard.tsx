import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Skeleton } from '@/components/ui/skeleton';
import { Copy, Check, Shield, BadgeCheck, ExternalLink, MapPin, Store, Award, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { getFullSellerProfileUrl, getSellerProfileUrl } from '@/lib/sellerUrl';
import StyledQRCode from '@/components/StyledQRCode';

interface StoreQRCardProps {
  storeName: string;
  storeSlug?: string | null;
  sellerId?: string;
  logoUrl?: string | null;
  district?: string | null;
  sellerType?: string | null;
  isVerified?: boolean | null;
}

const StoreQRCard: React.FC<StoreQRCardProps> = ({ 
  storeName, storeSlug, sellerId, logoUrl, district, sellerType, isVerified 
}) => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  const storeUrl = getFullSellerProfileUrl({
    id: sellerId,
    store_slug: storeSlug,
    business_name: storeName
  });

  const internalProfilePath = getSellerProfileUrl({
    id: sellerId,
    store_slug: storeSlug,
    business_name: storeName,
  });

  const qrUrl = `${storeUrl}?action=follow`;

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 600);
    return () => clearTimeout(timer);
  }, []);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(storeUrl);
      setCopied(true);
      toast.success('Link copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('Failed to copy');
    }
  };

  const getSellerTypeLabel = () => {
    switch (sellerType) {
      case 'registered_business': return 'Registered Business';
      case 'ngo': return 'Organization / NGO';
      case 'individual': return 'Individual Seller';
      default: return 'Business Account';
    }
  };

  if (isLoading) {
    return (
      <div className="w-full max-w-2xl mx-auto">
        <div className="bg-card border border-border rounded-3xl p-6 shadow-sm">
          <div className="flex flex-col sm:flex-row gap-6">
            <Skeleton className="w-[200px] h-[200px] rounded-2xl mx-auto sm:mx-0 flex-shrink-0" />
            <div className="flex-1 space-y-4">
              <Skeleton className="h-6 w-40" />
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-4 w-28" />
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-12 w-full rounded-xl" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-2xl mx-auto animate-in fade-in-50 zoom-in-95 duration-500">
      <div className="bg-card border border-border rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow">
        <div className="flex flex-col sm:flex-row gap-6">
          {/* Left: QR Code */}
          <div className="flex flex-col items-center gap-3 flex-shrink-0">
            <StyledQRCode
              value={qrUrl}
              size={180}
              showDownload={false}
            />
            <p className="text-[11px] text-muted-foreground text-center">
              Scan with any camera app
            </p>
          </div>

          {/* Right: Business Info */}
          <div className="flex-1 flex flex-col justify-between min-w-0">
            {/* Business Name & Verification */}
            <div className="space-y-3">
              <div className="flex items-start gap-2">
                {logoUrl ? (
                  <img 
                    src={logoUrl} 
                    alt={storeName} 
                    className="w-10 h-10 rounded-full object-cover border border-border flex-shrink-0" 
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Store className="w-5 h-5 text-primary" />
                  </div>
                )}
                <div className="min-w-0">
                  <h3 className="font-bold text-foreground text-lg truncate">{storeName}</h3>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    {isVerified ? (
                      <span className="flex items-center gap-1 text-xs text-primary font-medium">
                        <BadgeCheck className="w-3.5 h-3.5" />
                        Verified
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Shield className="w-3.5 h-3.5" />
                        Not verified
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Info rows */}
              <div className="space-y-2 pt-1">
                {/* Account Type */}
                <div className="flex items-center gap-2 text-sm">
                  <Award className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span className="text-muted-foreground">Type:</span>
                  <span className="font-medium text-foreground">{getSellerTypeLabel()}</span>
                </div>

                {/* Location */}
                {district && (
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                    <span className="text-muted-foreground">Location:</span>
                    <span className="font-medium text-foreground">{district}, Uganda</span>
                  </div>
                )}

                {/* Status */}
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 rounded-full bg-green-500 flex-shrink-0" />
                  <span className="text-muted-foreground">Status:</span>
                  <span className="font-medium text-green-600 dark:text-green-400">Active</span>
                </div>
              </div>
            </div>

            {/* Copy link button */}
            <button
              onClick={handleCopy}
              className="mt-4 w-full flex items-center justify-between gap-3 bg-muted/50 hover:bg-muted border border-border rounded-xl px-4 py-3 transition-all group"
            >
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <ExternalLink className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                <span className="text-sm text-muted-foreground truncate">
                  {storeUrl.replace('https://', '').replace('http://', '')}
                </span>
              </div>
              <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg transition-all ${
                copied ? 'bg-green-500 text-white' : 'bg-primary text-primary-foreground group-hover:scale-105'
              }`}>
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </div>
            </button>

            {/* Trust footer */}
            <p className="text-center text-[11px] text-muted-foreground/70 mt-3">
              This QR code links to your verified EarlyMarket business profile
            </p>
          </div>
        </div>

        {/* Go to profile — prominent, especially on small devices */}
        <button
          onClick={() => navigate('/profile')}
          className="mt-5 w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-xl px-4 py-3 font-medium transition-all hover:bg-primary/90 active:scale-[0.99]"
        >
          Go to your profile
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

export default StoreQRCard;
