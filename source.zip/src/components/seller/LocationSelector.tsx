
import React, { useEffect, useState } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { useDistricts, getSubCountiesFor } from '@/hooks/useDistricts';

interface LocationSelectorProps {
  district: string;
  subCounty: string;
  parish: string;
  village: string;
  onLocationChange: (field: string, value: string) => void;
  required?: boolean;
}

const LocationSelector: React.FC<LocationSelectorProps> = ({
  district,
  subCounty,
  parish,
  village,
  onLocationChange,
  required = false
}) => {
  const { districts } = useDistricts();
  const [subCounties, setSubCounties] = useState<string[]>([]);

  useEffect(() => {
    setSubCounties(district ? getSubCountiesFor(districts, district) : []);
  }, [district, districts]);

  const handleChange = (field: string, value: string) => {
    onLocationChange(field, value);
    
    // Reset dependent fields when parent changes
    if (field === 'district') {
      onLocationChange('subCounty', '');
      onLocationChange('parish', '');
      onLocationChange('village', '');
    } else if (field === 'subCounty') {
      onLocationChange('parish', '');
      onLocationChange('village', '');
    } else if (field === 'parish') {
      onLocationChange('village', '');
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <Label htmlFor="district">District {required && '*'}</Label>
        <Select value={district || undefined} onValueChange={(value) => handleChange('district', value)}>
          <SelectTrigger>
            <SelectValue placeholder="Select district" />
          </SelectTrigger>
          <SelectContent className="max-h-60 overflow-y-auto bg-white border shadow-lg">
            {districts.filter(dist => dist.name && dist.name.trim() !== '').map((dist) => (
              <SelectItem key={dist.id} value={dist.name}>
                {dist.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Label htmlFor="subCounty">Sub County {required && '*'}</Label>
        <Select 
          value={subCounty || undefined} 
          onValueChange={(value) => handleChange('subCounty', value)}
          disabled={!district}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select sub county" />
          </SelectTrigger>
          <SelectContent className="max-h-60 overflow-y-auto bg-white border shadow-lg">
            {subCounties.filter(sub => sub && sub.trim() !== '').map((sub) => (
              <SelectItem key={sub} value={sub}>
                {sub}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Label htmlFor="parish">Parish (Optional)</Label>
        <Input
          value={parish}
          onChange={(e) => handleChange('parish', e.target.value)}
          placeholder="Enter parish (optional)"
          disabled={!subCounty}
          className="w-full"
        />
      </div>
      
      <div>
        <Label htmlFor="village">Village (Optional)</Label>
        <Input
          value={village}
          onChange={(e) => handleChange('village', e.target.value)}
          placeholder="Enter village (optional)"
          disabled={!parish}
          className="w-full"
        />
      </div>
    </div>
  );
};

export default LocationSelector;
