import React, { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, Search } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CategoryBubbleSelectProps {
  options: string[];
  selected: string[];
  onChange: (next: string[]) => void;
  max?: number;
  /** How many suggestions to show before the user searches. */
  suggestionCount?: number;
}

/**
 * Multi-select category picker rendered as rounded, tickable chips.
 * Shows a handful of suggestions by default and filters the full list as
 * the user types. Enforces a maximum number of selections.
 */
const CategoryBubbleSelect: React.FC<CategoryBubbleSelectProps> = ({
  options,
  selected,
  onChange,
  max = 5,
  suggestionCount = 10,
}) => {
  const [query, setQuery] = useState('');

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) {
      // Always show selected first, then fill up to suggestionCount.
      const rest = options.filter(o => !selected.includes(o));
      return [...selected, ...rest].slice(0, Math.max(suggestionCount, selected.length));
    }
    return options.filter(o => o.toLowerCase().includes(q)).slice(0, 24);
  }, [query, options, selected, suggestionCount]);

  const atMax = selected.length >= max;

  const toggle = (cat: string) => {
    if (selected.includes(cat)) {
      onChange(selected.filter(c => c !== cat));
    } else if (!atMax) {
      onChange([...selected, cat]);
    }
  };

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <input
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Search to see more categories…"
          className="w-full h-12 rounded-xl border-[1.5px] border-border bg-background pl-10 pr-4 text-base outline-none transition-colors focus:border-primary hover:border-foreground/40"
        />
      </div>

      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">
          Pick the categories your business belongs to
        </span>
        <span className={cn('font-medium', atMax ? 'text-primary' : 'text-muted-foreground')}>
          {selected.length}/{max}
        </span>
      </div>

      <div className="flex flex-wrap gap-2.5">
        <AnimatePresence initial={false}>
          {visible.map(cat => {
            const isSelected = selected.includes(cat);
            const disabled = !isSelected && atMax;
            return (
              <motion.button
                key={cat}
                type="button"
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.15 }}
                whileTap={{ scale: 0.94 }}
                onClick={() => toggle(cat)}
                disabled={disabled}
                className={cn(
                  'group inline-flex items-center gap-2 rounded-full border-[1.5px] px-4 py-2 text-sm transition-colors',
                  isSelected
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border text-foreground/80 hover:border-primary/50',
                  disabled && 'opacity-40 cursor-not-allowed hover:border-border',
                )}
              >
                <span
                  className={cn(
                    'flex h-4 w-4 items-center justify-center rounded-full border transition-all',
                    isSelected ? 'border-primary bg-primary text-primary-foreground' : 'border-muted-foreground/40',
                  )}
                >
                  <AnimatePresence>
                    {isSelected && (
                      <motion.span
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        exit={{ scale: 0 }}
                        transition={{ duration: 0.12 }}
                      >
                        <Check className="h-3 w-3" strokeWidth={3} />
                      </motion.span>
                    )}
                  </AnimatePresence>
                </span>
                {cat}
              </motion.button>
            );
          })}
        </AnimatePresence>
        {visible.length === 0 && (
          <p className="text-sm text-muted-foreground py-2">No categories match “{query}”.</p>
        )}
      </div>
    </div>
  );
};

export default CategoryBubbleSelect;