import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '@/components/auth/AuthContext';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { PhoneInputWithFlag } from '@/components/ui/PhoneInputWithFlag';
import { toast } from 'sonner';
import {
  ArrowLeft,
  ArrowRight,
  Camera,
  Upload,
  Package,
  Briefcase,
  Store,
  Clock,
  Check,
  CheckCircle2,
  ImageIcon,
} from 'lucide-react';
import { cn } from '@/lib/utils';

import FloatingBorderInput from '@/components/publish/FloatingBorderInput';
import SearchableLocationSelector from './SearchableLocationSelector';
import LogoCropModal from './LogoCropModal';
import CategoryBubbleSelect from './CategoryBubbleSelect';
import BusinessLocationMap, { parseLatLngFromMapsUrl } from './BusinessLocationMap';
import OnboardingAssurancePanel from './OnboardingAssurancePanel';
import MaterialSpinner from '@/components/ui/MaterialSpinner';
import { getFullSellerProfileUrl } from '@/lib/sellerUrl';

interface EnhancedSellerOnboardingProps {
  initialSellerType?: 'individual' | 'registered_business' | 'ngo';
}

interface WorkingHours {
  [key: string]: { open: string; close: string; closed: boolean };
}

interface SellerFormData {
  business_name: string;
  seller_type: 'individual' | 'registered_business' | 'ngo';
  registration_number: string;
  business_categories: string[];
  business_type: 'products' | 'services' | 'both';
  country: string;
  district: string;
  sub_county: string;
  street_address: string;
  map_url: string;
  business_phone: string;
  whatsapp_number: string;
  business_email: string;
  business_bio: string;
  payment_methods: string[];
  delivery_options: string[];
  delivery_areas: string[];
  working_hours: WorkingHours;
  terms_accepted: boolean;
  marketing_emails: boolean;
}

const defaultWorkingHours: WorkingHours = {
  monday: { open: '09:00', close: '17:00', closed: false },
  tuesday: { open: '09:00', close: '17:00', closed: false },
  wednesday: { open: '09:00', close: '17:00', closed: false },
  thursday: { open: '09:00', close: '17:00', closed: false },
  friday: { open: '09:00', close: '17:00', closed: false },
  saturday: { open: '09:00', close: '13:00', closed: false },
  sunday: { open: '', close: '', closed: true },
};

// Broad list of business categories — covers products, services, trades,
// creative work, and professional services. The bubble selector shows the
// first ~10 as suggestions and lets users search the full list.
const BUSINESS_CATEGORIES = [
  // Top suggestions (retail/e-commerce)
  'Retail & General Merchandise', 'Fashion & Clothing', 'Electronics & Gadgets',
  'Food & Beverages', 'Grocery & Supermarket', 'Health & Beauty Products',
  'Furniture & Interior Design', 'Building & Hardware Materials', 'Automotive & Vehicles',
  'Agriculture & Farming',
  // Product categories
  'Real Estate & Property', 'Wholesale & Distribution', 'Books & Stationery',
  'Toys & Baby Products', 'Jewelry & Accessories', 'Sports & Fitness Equipment',
  'Musical Instruments', 'Art & Crafts Supplies', 'Pet Supplies', 'Home Appliances',
  'Kitchenware & Cookware', 'Garden & Outdoor', 'Office Equipment', 'Cosmetics & Perfume',
  'Fabric & Textiles', 'Shoes & Footwear', 'Bags & Luggage', 'Watches & Timepieces',
  'Solar & Renewable Energy Products', 'Medical Equipment & Supplies',
  // Service providers — trades & home
  'Plumbing Services', 'Electrical Services', 'Carpentry & Woodwork', 'Welding & Metalwork',
  'Painting & Decorating', 'Masonry & Bricklaying', 'Roofing Services', 'Tiling & Flooring',
  'Home Repair & Maintenance', 'Cleaning Services', 'Laundry & Dry Cleaning',
  'Pest Control', 'Landscaping & Gardening', 'Interior Design Services',
  'Moving & Relocation Services', 'Security Services',
  // Automotive services
  'Auto Repair & Mechanic', 'Car Wash & Detailing', 'Tyre & Puncture Services',
  'Auto Electrical Services', 'Panel Beating & Spray Painting', 'Boda Boda & Ride Services',
  'Car Hire & Rentals', 'Driving School',
  // Beauty & personal care
  'Hair Salon & Barbershop', 'Nail Salon', 'Spa & Massage', 'Makeup Artist',
  'Tattoo & Piercing', 'Fitness Trainer', 'Yoga & Wellness',
  // Health & wellness
  'Medical Clinic', 'Dental Services', 'Optical Services', 'Pharmacy',
  'Herbal & Traditional Medicine', 'Veterinary Services', 'Physiotherapy',
  'Counselling & Mental Health', 'Nutrition & Dietician',
  // Food services
  'Restaurant & Cafe', 'Catering Services', 'Bakery & Confectionery',
  'Food Delivery', 'Bar & Nightlife', 'Butchery',
  // Education
  'Teaching & Tutoring Services', 'Language Classes', 'Music Lessons',
  'Driving Lessons', 'Vocational Training', 'Daycare & Early Education',
  // Professional & business services
  'Legal Services', 'Accounting & Bookkeeping', 'Tax Consulting', 'Financial Advisory',
  'Insurance Services', 'Notary Services', 'Business Consulting', 'HR & Recruitment',
  'Marketing & Advertising', 'Public Relations', 'Translation Services',
  'Data Entry & Virtual Assistant', 'Market Research',
  // IT & digital
  'IT & Software Services', 'Web Development', 'Mobile App Development',
  'Graphic Design', 'UI/UX Design', 'Digital Marketing', 'SEO Services',
  'Social Media Management', 'Video Editing', 'Animation & Motion Graphics',
  'Computer Repair', 'Networking & Cabling', 'Cybersecurity Services', 'AI & Data Services',
  // Creative & events
  'Photography & Videography', 'Event Planning & Decoration', 'DJ & Entertainment',
  'MC & Event Hosting', 'Live Band & Musicians', 'Rental (Chairs, Tents, Sound)',
  'Wedding Planning', 'Corporate Events', 'Printing & Branding', 'Signage & Billboards',
  // Logistics & transport
  'Transportation & Logistics', 'Courier & Delivery', 'Freight & Cargo',
  'Warehousing & Storage', 'Truck & Van Hire',
  // Construction & industrial
  'Construction Services', 'Architecture & Surveying', 'Engineering Services',
  'Interior Fit-out', 'Property Management', 'Real Estate Agency',
  // Agriculture & environment
  'Poultry & Livestock', 'Fisheries & Aquaculture', 'Agro-processing',
  'Agricultural Inputs', 'Farm Consulting', 'Waste Management & Recycling',
  // Tourism & hospitality
  'Hotel & Guest House', 'Tours & Travel Agency', 'Safari Operator',
  'Airbnb & Short-term Rentals',
  // Fallback
  'Other',
];

const PAYMENT_METHODS = ['Mobile Money', 'Bank Transfer', 'Cash on Delivery', 'Credit/Debit Card', 'Pay on Service Completion'];
const DELIVERY_OPTIONS = ['Pick-up Only', 'Door Delivery', 'Both Pick-up & Delivery'];
const SERVICE_OPTIONS = ['On-site Service', 'Remote/Online Service', 'Both On-site & Remote'];
const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

const STEP_TITLES = ['About your business', 'Location & contact', 'Profile & branding', 'How you operate', 'Review & finish'];

const EnhancedSellerOnboarding: React.FC<EnhancedSellerOnboardingProps> = ({ initialSellerType = 'individual' }) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [step, setStep] = useState(0);
  const [direction, setDirection] = useState(1);

  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState('');
  const [coverPreview, setCoverPreview] = useState('');
  const [showLogoCropModal, setShowLogoCropModal] = useState(false);
  const [showCoverCropModal, setShowCoverCropModal] = useState(false);
  const [tempLogoFile, setTempLogoFile] = useState<File | null>(null);
  const [tempCoverFile, setTempCoverFile] = useState<File | null>(null);

  const [generatedStoreSlug, setGeneratedStoreSlug] = useState('');
  const [checking, setChecking] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState<SellerFormData>({
    business_name: '',
    seller_type: initialSellerType,
    registration_number: '',
    business_categories: [],
    business_type: 'products',
    country: 'Uganda',
    district: '',
    sub_county: '',
    street_address: '',
    map_url: '',
    business_phone: '',
    whatsapp_number: '',
    business_email: user?.email || '',
    business_bio: '',
    payment_methods: [],
    delivery_options: [],
    delivery_areas: [],
    working_hours: defaultWorkingHours,
    terms_accepted: false,
    marketing_emails: true,
  });

  const set = <K extends keyof SellerFormData>(field: K, value: SellerFormData[K]) =>
    setFormData(prev => ({ ...prev, [field]: value }));

  const mapQuery = useMemo(
    () => [formData.sub_county, formData.district, formData.country].filter(Boolean).join(', '),
    [formData.sub_county, formData.district, formData.country],
  );

  // Generate slug when reaching the review step.
  useEffect(() => {
    if (step === 4 && formData.business_name) {
      runSlugCheck();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  const runSlugCheck = async () => {
    setChecking(true);
    const started = Date.now();
    let slug = '';
    try {
      const base = formData.business_name.toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
      const { data: existing } = await supabase
        .from('seller_profiles').select('store_slug').eq('store_slug', base).maybeSingle();
      if (!existing) {
        slug = base;
      } else {
        const { data: slugData } = await supabase.rpc('generate_store_slug', { business_name: formData.business_name });
        slug = slugData || `${base}-${Date.now().toString(36)}`;
      }
    } catch {
      slug = formData.business_name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    }
    // Hold the "please wait" state for a minimum of 3s for a premium feel.
    const elapsed = Date.now() - started;
    setTimeout(() => {
      setGeneratedStoreSlug(slug);
      setChecking(false);
    }, Math.max(0, 3000 - elapsed));
  };

  const handleFileUpload = (file: File, type: 'logo' | 'cover') => {
    if (type === 'logo') { setTempLogoFile(file); setShowLogoCropModal(true); }
    else { setTempCoverFile(file); setShowCoverCropModal(true); }
  };

  const handleLogoCropSave = (blob: Blob) => {
    const f = new File([blob], 'business-logo.jpg', { type: 'image/jpeg' });
    setLogoFile(f);
    const r = new FileReader(); r.onload = e => setLogoPreview(e.target?.result as string); r.readAsDataURL(f);
    setShowLogoCropModal(false); setTempLogoFile(null);
  };

  const handleCoverCropSave = (blob: Blob) => {
    const f = new File([blob], 'cover-image.jpg', { type: 'image/jpeg' });
    setCoverFile(f);
    const r = new FileReader(); r.onload = e => setCoverPreview(e.target?.result as string); r.readAsDataURL(f);
    setShowCoverCropModal(false); setTempCoverFile(null);
  };

  const uploadFile = async (file: File, folder: string): Promise<string> => {
    const ext = file.name.split('.').pop();
    const name = `${user?.id}/${folder}/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from('business-assets').upload(name, file);
    if (error) throw error;
    const { data: { publicUrl } } = supabase.storage.from('business-assets').getPublicUrl(name);
    return publicUrl;
  };

  const createSellerProfile = useMutation({
    mutationFn: async (data: SellerFormData) => {
      const { data: existingProfile } = await supabase
        .from('seller_profiles').select('id, store_slug')
        .eq('user_id', user?.id).order('created_at', { ascending: false }).limit(1).maybeSingle();

      let finalStoreSlug = existingProfile?.store_slug || generatedStoreSlug;
      if (!finalStoreSlug?.trim()) {
        try {
          const { data: slugData } = await supabase.rpc('generate_store_slug', { business_name: data.business_name });
          if (slugData) finalStoreSlug = slugData;
        } catch { /* ignore */ }
        if (!finalStoreSlug?.trim()) {
          const base = data.business_name.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
          finalStoreSlug = `${base}-${Date.now().toString(36)}`;
        }
      }

      let logoUrl = '';
      let coverUrl = '';
      if (logoFile) logoUrl = await uploadFile(logoFile, 'logos');
      if (coverFile) coverUrl = await uploadFile(coverFile, 'covers');

      const coords = parseLatLngFromMapsUrl(data.map_url);
      const mapLocation = data.map_url?.trim() || mapQuery;

      const profileData = {
        user_id: user?.id,
        business_name: data.business_name,
        seller_type: data.seller_type,
        account_tier: data.seller_type === 'ngo' ? 'organization' : 'business',
        registration_number: data.registration_number || null,
        business_category: data.business_categories[0] || '',
        business_categories: data.business_categories,
        business_type: data.business_type,
        country: data.country || 'Uganda',
        district: data.district,
        sub_county: data.sub_county || data.district,
        street_address: data.street_address || '',
        map_location: mapLocation || null,
        latitude: coords?.lat ?? null,
        longitude: coords?.lng ?? null,
        business_phone: data.business_phone,
        whatsapp_number: data.whatsapp_number || null,
        business_email: data.business_email || user?.email || '',
        business_logo_url: logoUrl || null,
        cover_image_url: coverUrl || null,
        business_bio: data.business_bio || null,
        payment_methods: data.payment_methods,
        delivery_options: data.delivery_options,
        delivery_areas: data.delivery_areas,
        working_hours: data.working_hours,
        terms_accepted: data.terms_accepted,
        terms_accepted_at: data.terms_accepted ? new Date().toISOString() : null,
        store_slug: finalStoreSlug,
        is_active: true,
      };

      let profile;
      if (existingProfile) {
        const { data: updated, error } = await supabase.from('seller_profiles').update(profileData).eq('id', existingProfile.id).select().single();
        if (error) throw error;
        profile = updated;
      } else {
        const { data: created, error } = await supabase.from('seller_profiles').insert([profileData]).select().single();
        if (error) throw error;
        profile = created;
      }

      try {
        await supabase.from('user_app_settings').upsert(
          { user_id: user?.id, marketing_emails: data.marketing_emails }, { onConflict: 'user_id' });
      } catch { /* non-fatal */ }

      setGeneratedStoreSlug(finalStoreSlug);
      return profile;
    },
    onSuccess: () => {
      setIsSubmitting(false);
      toast.success('🎉 Your store is now live!');
      queryClient.invalidateQueries({ queryKey: ['seller-profile'] });
      navigate('/create-business-account');
    },
    onError: (error: Error & { code?: string; message?: string }) => {
      let msg = 'Failed to create store. Please try again.';
      if (error.message?.includes('duplicate')) msg = 'A store with this name already exists.';
      else if (error.message?.includes('store_slug')) msg = 'This store URL is already taken. Try a different name.';
      toast.error(msg);
      setIsSubmitting(false);
    },
  });

  const stepValid = useMemo(() => {
    switch (step) {
      case 0: return formData.business_name.trim().length >= 2 && formData.business_categories.length > 0 && !!formData.business_type;
      case 1: return !!formData.district && !!formData.sub_county && !!formData.business_phone && !!formData.business_email;
      case 2: return !!logoFile; // bio optional, cover optional
      case 3:
        if (formData.business_type === 'products' || formData.business_type === 'both')
          return formData.payment_methods.length > 0 && formData.delivery_options.length > 0;
        return formData.payment_methods.length > 0;
      case 4: return formData.terms_accepted && !checking;
      default: return false;
    }
  }, [step, formData, logoFile, checking]);

  const goNext = () => { setDirection(1); setStep(s => Math.min(s + 1, STEP_TITLES.length - 1)); };
  const goBack = () => {
    if (step === 0) { navigate(-1); return; }
    setDirection(-1); setStep(s => s - 1);
  };

  const handleSubmit = () => {
    if (!formData.terms_accepted) { toast.error('Please accept the Terms & Conditions to continue.'); return; }
    if (isSubmitting) return;
    setIsSubmitting(true);
    createSellerProfile.mutate(formData);
  };

  const offerOptions = [
    { key: 'products', label: 'Products', icon: Package },
    { key: 'services', label: 'Services', icon: Briefcase },
    { key: 'both', label: 'Both', icon: Store },
  ] as const;

  return (
    <div className="h-[100dvh] bg-background flex flex-col overflow-hidden">
      {/* Top bar */}
      <div className="border-b border-border/60 shrink-0">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <span className="text-sm font-medium text-foreground">Create your business account</span>
          <span className="text-xs text-muted-foreground">Step {step + 1} of {STEP_TITLES.length}</span>
        </div>
        {/* progress */}
        <div className="h-0.5 w-full bg-muted">
          <motion.div
            className="h-full bg-primary"
            initial={false}
            animate={{ width: `${((step + 1) / STEP_TITLES.length) * 100}%` }}
            transition={{ duration: 0.35 }}
          />
        </div>
      </div>

      <div className="flex-1 min-h-0 grid lg:grid-cols-[minmax(0,3fr)_minmax(0,1.4fr)]">
        {/* Left: form */}
        <div className="relative flex flex-col min-h-0">
          <button
            onClick={goBack}
            aria-label="Back"
            className="hidden lg:flex absolute left-6 top-8 h-10 w-10 items-center justify-center rounded-full border border-border bg-background text-muted-foreground hover:text-foreground hover:border-primary/50 transition-colors z-10"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>

          <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden">
            <div className="max-w-2xl mx-auto w-full min-w-0 px-4 sm:px-6 lg:pl-24 lg:pr-10 py-6 lg:py-10">
              <AnimatePresence mode="wait" custom={direction}>
                <motion.div
                  key={step}
                  custom={direction}
                  initial={{ opacity: 0, x: direction * 40 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: direction * -40 }}
                  transition={{ duration: 0.28, ease: 'easeOut' }}
                >
                  <h2 className="text-2xl lg:text-3xl font-normal tracking-tight mb-1">{STEP_TITLES[step]}</h2>

                  {/* STEP 0 — About */}
                  {step === 0 && (
                    <div className="space-y-5 mt-5">
                      <p className="text-sm text-muted-foreground">Let’s start with the essentials. You can refine everything later.</p>
                      <FloatingBorderInput label="Business name" value={formData.business_name} onChange={v => set('business_name', v)} required autoFocus />

                      <div className="space-y-2">
                        <p className="text-sm font-medium">What do you offer? <span className="text-destructive">*</span></p>
                        <div className="grid grid-cols-3 gap-3">
                          {offerOptions.map(({ key, label, icon: Icon }) => (
                            <button
                              key={key}
                              type="button"
                              onClick={() => set('business_type', key)}
                              className={cn(
                                'flex flex-col items-center gap-2 rounded-xl border-[1.5px] py-4 transition-all',
                                formData.business_type === key ? 'border-primary bg-primary/5 text-primary' : 'border-border hover:border-primary/50',
                              )}
                            >
                              <Icon className="h-6 w-6" strokeWidth={1.6} />
                              <span className="text-sm font-medium">{label}</span>
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="text-sm font-medium">Your categories <span className="text-destructive">*</span></p>
                        <CategoryBubbleSelect
                          options={BUSINESS_CATEGORIES}
                          selected={formData.business_categories}
                          onChange={v => set('business_categories', v)}
                          max={5}
                        />
                      </div>

                      {/* Registration number hidden per product decision. */}
                    </div>
                  )}

                  {/* STEP 1 — Location & contact */}
                  {step === 1 && (
                    <div className="space-y-5 mt-5">
                      <p className="text-sm text-muted-foreground">Help nearby customers find and reach you.</p>
                      <SearchableLocationSelector
                        onLocationSelect={(loc) => { set('district', loc.district); set('sub_county', loc.subcounty || ''); }}
                        initialLocation={{ district: formData.district, subcounty: formData.sub_county }}
                        required
                      />

                      <FloatingBorderInput label="Street or landmark (optional)" value={formData.street_address} onChange={v => set('street_address', v)} />

                      <BusinessLocationMap query={mapQuery} pastedUrl={formData.map_url} onPastedUrlChange={v => set('map_url', v)} />

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm font-medium mb-1.5">Business phone <span className="text-destructive">*</span></p>
                          <PhoneInputWithFlag value={formData.business_phone} onChange={v => set('business_phone', v)} placeholder="700 000 000" required />
                        </div>
                        <div>
                          <p className="text-sm font-medium mb-1.5">WhatsApp (optional)</p>
                          <PhoneInputWithFlag value={formData.whatsapp_number} onChange={v => set('whatsapp_number', v)} placeholder="700 000 000" />
                        </div>
                      </div>

                      <FloatingBorderInput label="Business email" type="email" value={formData.business_email} onChange={v => set('business_email', v)} required />
                    </div>
                  )}

                  {/* STEP 2 — Branding */}
                  {step === 2 && (
                    <div className="space-y-6 mt-5">
                      <p className="text-sm text-muted-foreground">A clean logo and cover make your store instantly trustworthy.</p>

                      <div className="flex items-center gap-4">
                        <Avatar className="w-20 h-20 border border-border">
                          <AvatarImage src={logoPreview} />
                          <AvatarFallback><Camera className="w-7 h-7 text-muted-foreground" /></AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="text-sm font-medium mb-1">Logo <span className="text-destructive">*</span></p>
                          <input id="logo_file" type="file" accept="image/*" className="hidden"
                            onChange={e => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'logo')} />
                          <Button type="button" variant="outline" size="sm" onClick={() => document.getElementById('logo_file')?.click()}>
                            <Upload className="w-4 h-4 mr-2" />{logoFile ? 'Change logo' : 'Upload logo'}
                          </Button>
                          <p className="text-xs text-muted-foreground mt-1.5">Square image, cropped to a circle.</p>
                        </div>
                      </div>

                      <div>
                        <p className="text-sm font-medium mb-2">Cover image <span className="text-xs text-muted-foreground">(recommended)</span></p>
                        {coverPreview ? (
                          <div className="w-full rounded-xl overflow-hidden border border-border mb-2" style={{ aspectRatio: '3 / 1' }}>
                            <img src={coverPreview} alt="Cover preview" className="w-full h-full object-cover" />
                          </div>
                        ) : (
                          <div className="w-full rounded-xl border-[1.5px] border-dashed border-border flex items-center justify-center text-muted-foreground mb-2" style={{ aspectRatio: '3 / 1' }}>
                            <ImageIcon className="w-6 h-6" />
                          </div>
                        )}
                        <input id="cover_file" type="file" accept="image/*" className="hidden"
                          onChange={e => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'cover')} />
                        <Button type="button" variant="outline" size="sm" onClick={() => document.getElementById('cover_file')?.click()}>
                          <Upload className="w-4 h-4 mr-2" />{coverFile ? 'Change cover' : 'Upload cover'}
                        </Button>
                      </div>

                      <div>
                        <p className="text-sm font-medium mb-2">Business bio <span className="text-xs text-muted-foreground">(optional — add later)</span></p>
                        <textarea
                          value={formData.business_bio}
                          onChange={e => set('business_bio', e.target.value)}
                          rows={4}
                          placeholder={formData.business_type === 'services'
                            ? 'Tell customers about your services and what makes you unique…'
                            : 'Tell customers what you sell and what makes you unique…'}
                          className="w-full rounded-xl border-[1.5px] border-border bg-background px-4 py-3 text-base outline-none transition-colors focus:border-primary hover:border-foreground/40 resize-none"
                        />
                      </div>
                    </div>
                  )}

                  {/* STEP 3 — Operations */}
                  {step === 3 && (
                    <div className="space-y-6 mt-5">
                      <p className="text-sm text-muted-foreground">Set how customers pay, receive, and reach you.</p>

                      <div>
                        <p className="text-sm font-medium mb-3">Payment methods <span className="text-destructive">*</span></p>
                        <div className="flex flex-wrap gap-2.5">
                          {PAYMENT_METHODS.map(m => {
                            const sel = formData.payment_methods.includes(m);
                            return (
                              <button key={m} type="button"
                                onClick={() => set('payment_methods', sel ? formData.payment_methods.filter(x => x !== m) : [...formData.payment_methods, m])}
                                className={cn('inline-flex items-center gap-2 rounded-full border-[1.5px] px-4 py-2 text-sm transition-colors',
                                  sel ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-primary/50')}>
                                {sel && <Check className="h-3.5 w-3.5" strokeWidth={3} />}{m}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {(formData.business_type === 'products' || formData.business_type === 'both') && (
                        <div>
                          <p className="text-sm font-medium mb-3">Delivery options <span className="text-destructive">*</span></p>
                          <div className="flex flex-wrap gap-2.5">
                            {DELIVERY_OPTIONS.map(o => {
                              const sel = formData.delivery_options.includes(o);
                              return (
                                <button key={o} type="button"
                                  onClick={() => set('delivery_options', sel ? formData.delivery_options.filter(x => x !== o) : [...formData.delivery_options, o])}
                                  className={cn('inline-flex items-center gap-2 rounded-full border-[1.5px] px-4 py-2 text-sm transition-colors',
                                    sel ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-primary/50')}>
                                  {sel && <Check className="h-3.5 w-3.5" strokeWidth={3} />}{o}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {formData.business_type === 'services' && (
                        <div>
                          <p className="text-sm font-medium mb-3">Service delivery</p>
                          <div className="flex flex-wrap gap-2.5">
                            {SERVICE_OPTIONS.map(o => {
                              const sel = formData.delivery_options.includes(o);
                              return (
                                <button key={o} type="button"
                                  onClick={() => set('delivery_options', sel ? formData.delivery_options.filter(x => x !== o) : [...formData.delivery_options, o])}
                                  className={cn('inline-flex items-center gap-2 rounded-full border-[1.5px] px-4 py-2 text-sm transition-colors',
                                    sel ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-primary/50')}>
                                  {sel && <Check className="h-3.5 w-3.5" strokeWidth={3} />}{o}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      <div>
                        <p className="text-sm font-medium mb-3 flex items-center gap-2"><Clock className="h-4 w-4" /> Working hours</p>
                        <div className="space-y-2 rounded-xl border border-border p-3">
                          {DAYS.map(day => {
                            const wh = formData.working_hours[day];
                            return (
                              <div key={day} className="flex flex-wrap items-center gap-x-3 gap-y-2 min-w-0">
                                <span className="w-12 shrink-0 capitalize text-sm">{day.slice(0, 3)}</span>
                                <Switch checked={!wh?.closed}
                                  onCheckedChange={c => setFormData(p => ({ ...p, working_hours: { ...p.working_hours, [day]: { ...p.working_hours[day], closed: !c } } }))} />
                                {wh?.closed ? (
                                  <span className="text-xs text-muted-foreground">Closed</span>
                                ) : (
                                  <div className="flex flex-wrap items-center gap-2 text-sm min-w-0">
                                    <input type="time" value={wh?.open || '09:00'}
                                      onChange={e => setFormData(p => ({ ...p, working_hours: { ...p.working_hours, [day]: { ...p.working_hours[day], open: e.target.value } } }))}
                                      className="rounded-md border border-border bg-background px-2 py-1 text-xs" />
                                    <span className="text-muted-foreground text-xs">to</span>
                                    <input type="time" value={wh?.close || '17:00'}
                                      onChange={e => setFormData(p => ({ ...p, working_hours: { ...p.working_hours, [day]: { ...p.working_hours[day], close: e.target.value } } }))}
                                      className="rounded-md border border-border bg-background px-2 py-1 text-xs" />
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* STEP 4 — Review & finish */}
                  {step === 4 && (
                    <div className="space-y-5 mt-5">
                      <p className="text-sm text-muted-foreground">Almost there — review your details and claim your store link.</p>

                      <div className="rounded-2xl border border-border p-4 space-y-2 text-sm">
                        <div className="flex justify-between gap-3"><span className="text-muted-foreground">Business</span><span className="font-medium text-right">{formData.business_name}</span></div>
                        <div className="flex justify-between gap-3"><span className="text-muted-foreground">Offers</span><span className="font-medium text-right capitalize">{formData.business_type === 'both' ? 'Products & Services' : formData.business_type}</span></div>
                        <div className="flex justify-between gap-3"><span className="text-muted-foreground">Categories</span><span className="font-medium text-right">{formData.business_categories.join(', ')}</span></div>
                        <div className="flex justify-between gap-3"><span className="text-muted-foreground">Location</span><span className="font-medium text-right">{[formData.sub_county, formData.district].filter(Boolean).join(', ')}</span></div>
                        <div className="flex justify-between gap-3"><span className="text-muted-foreground">Phone</span><span className="font-medium text-right">{formData.business_phone}</span></div>
                      </div>

                      {/* Store link — generating experience */}
                      <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4">
                        <p className="text-sm font-medium text-primary mb-3 flex items-center gap-2"><Store className="h-4 w-4" /> Your store link</p>
                        {checking ? (
                          <div className="space-y-3">
                            <div className="flex items-center gap-3">
                              <MaterialSpinner size={22} />
                              <span className="text-sm text-muted-foreground">Please wait while we check availability…</span>
                            </div>
                            <div className="h-4 rounded-md algo-skel-line w-3/4" />
                            <div className="h-4 rounded-md algo-skel-line w-1/2" />
                          </div>
                        ) : (
                          <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-2">
                            <StoreLinkReveal
                              url={getFullSellerProfileUrl({ store_slug: generatedStoreSlug, business_name: formData.business_name })}
                            />
                            <p className="text-xs text-green-600 dark:text-green-400 flex items-center gap-1">
                              <CheckCircle2 className="h-3.5 w-3.5" /> This link is available!
                            </p>
                          </motion.div>
                        )}
                      </div>

                      <label className="flex items-start gap-3 rounded-xl border border-border p-4 cursor-pointer">
                        <Checkbox checked={formData.terms_accepted} onCheckedChange={c => set('terms_accepted', c as boolean)} className="mt-0.5" />
                        <span className="text-sm text-foreground/80">
                          I agree to the{' '}
                          <a href="/terms" target="_blank" rel="noreferrer" className="text-primary hover:underline">EarlyMarket Seller Terms &amp; Conditions</a>.
                        </span>
                      </label>

                      <label className="flex items-start gap-3 cursor-pointer">
                        <Checkbox checked={formData.marketing_emails} onCheckedChange={c => set('marketing_emails', c as boolean)} className="mt-0.5" />
                        <span className="text-sm text-muted-foreground">Send me tips, offers and product updates. Unsubscribe anytime.</span>
                      </label>
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>

            </div>
          </div>

          {/* Navigation — pinned to the bottom, never scrolls away */}
          <div className="shrink-0 border-t border-border/60 bg-background">
            <div className="max-w-2xl mx-auto w-full px-4 sm:px-6 lg:pl-24 lg:pr-10 py-3 pb-[calc(env(safe-area-inset-bottom,0px)+0.75rem)]">
              <div className="flex items-center justify-between gap-3">
                <Button variant="ghost" onClick={goBack} className="text-muted-foreground">
                  <ArrowLeft className="w-4 h-4 mr-2" /> Back
                </Button>
                {step < STEP_TITLES.length - 1 ? (
                  <Button onClick={goNext} disabled={!stepValid} className="min-w-[120px]">
                    Next <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                ) : (
                  <Button onClick={handleSubmit} disabled={!stepValid || isSubmitting || createSellerProfile.isPending} className="min-w-[160px]">
                    {(isSubmitting || createSellerProfile.isPending) ? (
                      <><MaterialSpinner size={18} className="mr-2" /> Setting up…</>
                    ) : 'Create business account'}
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right: assurance panel */}
        <div className="hidden lg:block border-l border-border/60">
          <OnboardingAssurancePanel step={step} />
        </div>
      </div>

      <LogoCropModal
        isOpen={showLogoCropModal}
        onClose={() => { setShowLogoCropModal(false); setTempLogoFile(null); }}
        imageFile={tempLogoFile}
        onSave={handleLogoCropSave}
        aspectRatio="square"
        title="Crop your logo"
      />
      <LogoCropModal
        isOpen={showCoverCropModal}
        onClose={() => { setShowCoverCropModal(false); setTempCoverFile(null); }}
        imageFile={tempCoverFile}
        onSave={handleCoverCropSave}
        aspectRatio="cover"
        title="Crop your cover image"
      />
    </div>
  );
};

function StoreLinkReveal({ url }: { url: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(url); setCopied(true); toast.success('Link copied!'); setTimeout(() => setCopied(false), 2000); }
    catch { toast.error('Failed to copy'); }
  };
  return (
    <button onClick={copy} type="button"
      className="w-full flex items-center justify-between gap-3 rounded-xl bg-background border border-border px-3 py-2.5 text-left transition-colors hover:border-primary/50">
      <span className="text-sm font-mono text-primary truncate">{url.replace(/^https?:\/\//, '')}</span>
      <span className={cn('flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-xs', copied ? 'bg-green-500 text-white' : 'bg-primary text-primary-foreground')}>
        {copied ? <Check className="h-3.5 w-3.5" /> : 'Copy'}
      </span>
    </button>
  );
}

export default EnhancedSellerOnboarding;