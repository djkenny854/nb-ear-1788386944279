import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useIsMobile } from '@/hooks/use-mobile';
import { Users, Search, Ban, UserMinus } from 'lucide-react';
import { toast } from 'sonner';
import { useBlockedUsers } from '@/hooks/useBlockedUsers';

interface Follower {
  id: string;
  follower_id: string;
  created_at: string;
  seller_profile: {
    id: string;
    business_name: string | null;
    business_logo_url: string | null;
    store_slug: string | null;
  } | null;
}

interface FollowersModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerId: string;
  sellerUserId: string;
  businessName: string;
  isOwnProfile?: boolean;
}

const FollowerItem = ({ 
  follower, 
  currentUserId,
  isOwnProfile,
  onBlock,
  onRemoveFollower
}: { 
  follower: Follower; 
  currentUserId?: string;
  isOwnProfile: boolean;
  onBlock: (userId: string, name: string) => void;
  onRemoveFollower: (followerId: string) => void;
}) => {
  const navigate = useNavigate();
  const [isFollowing, setIsFollowing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const checkFollowStatus = async () => {
      if (!currentUserId || !follower.follower_id) return;
      const { data } = await supabase
        .from('follows')
        .select('id')
        .eq('follower_id', currentUserId)
        .eq('following_id', follower.follower_id)
        .maybeSingle();
      setIsFollowing(!!data);
    };
    checkFollowStatus();
  }, [currentUserId, follower.follower_id]);

  const handleFollowBack = async () => {
    if (!currentUserId) {
      toast.error('Please sign in to follow');
      return;
    }
    if (currentUserId === follower.follower_id) return;

    setIsLoading(true);
    try {
      if (isFollowing) {
        await supabase
          .from('follows')
          .delete()
          .eq('follower_id', currentUserId)
          .eq('following_id', follower.follower_id);
        setIsFollowing(false);
        toast.success('Unfollowed');
      } else {
        await supabase
          .from('follows')
          .insert({ follower_id: currentUserId, following_id: follower.follower_id });
        setIsFollowing(true);
        toast.success('Following');
      }
    } catch (error) {
      console.error('Error following back:', error);
      toast.error('Failed to update follow status');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRemoveFollower = async () => {
    if (!currentUserId) return;
    setIsLoading(true);
    try {
      await supabase
        .from('follows')
        .delete()
        .eq('follower_id', follower.follower_id)
        .eq('following_id', currentUserId);
      onRemoveFollower(follower.follower_id);
      toast.success('Removed follower');
    } catch (error) {
      console.error('Error removing follower:', error);
      toast.error('Failed to remove follower');
    } finally {
      setIsLoading(false);
    }
  };

  const displayName = follower.seller_profile?.business_name || 'User';
  const avatarUrl = follower.seller_profile?.business_logo_url;
  const profileSlug = follower.seller_profile?.store_slug || follower.seller_profile?.id;
  const isSelf = currentUserId === follower.follower_id;

  const handleClick = () => {
    if (follower.seller_profile) {
      navigate(`/business/${profileSlug}`);
    }
  };

  return (
    <div className="flex items-center justify-between py-3 px-1">
      <div 
        className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
        onClick={handleClick}
      >
        <Avatar className="h-10 w-10">
          <AvatarImage src={avatarUrl || ''} />
          <AvatarFallback className="bg-primary/10 text-primary">
            {displayName.charAt(0).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate">{displayName}</p>
          <p className="text-xs text-muted-foreground">
            Followed {new Date(follower.created_at).toLocaleDateString()}
          </p>
        </div>
      </div>
      
      <div className="flex items-center gap-1.5">
        {!isSelf && follower.seller_profile && (
          <Button
            variant={isFollowing ? 'secondary' : 'default'}
            size="sm"
            onClick={handleFollowBack}
            disabled={isLoading}
            className="rounded-full text-xs"
          >
            {isFollowing ? 'Following' : 'Follow'}
          </Button>
        )}
        {isOwnProfile && !isSelf && (
          <>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground hover:text-destructive"
              onClick={handleRemoveFollower}
              disabled={isLoading}
              title="Remove follower"
            >
              <UserMinus className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground hover:text-destructive"
              onClick={() => onBlock(follower.follower_id, displayName)}
              title="Block user"
            >
              <Ban className="w-4 h-4" />
            </Button>
          </>
        )}
      </div>
    </div>
  );
};

const FollowersModal: React.FC<FollowersModalProps> = ({
  open,
  onOpenChange,
  sellerId,
  sellerUserId,
  businessName,
  isOwnProfile = false
}) => {
  const { user } = useAuth();
  const isMobile = useIsMobile();
  const { blockUser } = useBlockedUsers();
  const [followers, setFollowers] = useState<Follower[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchFollowers = async () => {
      if (!open || !sellerUserId) return;
      
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('follows')
          .select('id, follower_id, created_at')
          .eq('following_id', sellerUserId)
          .order('created_at', { ascending: false });

        if (error) throw error;

        const followersWithProfiles = await Promise.all(
          (data || []).map(async (follow) => {
            const { data: sellerProfile } = await supabase
              .from('seller_profiles')
              .select('id, business_name, business_logo_url, store_slug')
              .eq('user_id', follow.follower_id)
              .maybeSingle();

            return { ...follow, seller_profile: sellerProfile };
          })
        );

        setFollowers(followersWithProfiles);
      } catch (error) {
        console.error('Error fetching followers:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchFollowers();
  }, [open, sellerUserId]);

  const handleBlock = async (userId: string, name: string) => {
    const success = await blockUser(userId, name);
    if (success) {
      setFollowers(prev => prev.filter(f => f.follower_id !== userId));
    }
  };

  const handleRemoveFollower = (followerId: string) => {
    setFollowers(prev => prev.filter(f => f.follower_id !== followerId));
  };

  const filteredFollowers = followers.filter(f => {
    if (!searchQuery) return true;
    return f.seller_profile?.business_name?.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const content = (
    <>
      {/* Search Bar */}
      <div className="px-1 mb-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search followers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 rounded-full bg-muted/50 border-border"
          />
        </div>
      </div>

      <ScrollArea className="max-h-[55vh] pr-2">
        {isLoading ? (
          <div className="space-y-3 p-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-24" />
                </div>
                <Skeleton className="h-8 w-20 rounded-full" />
              </div>
            ))}
          </div>
        ) : filteredFollowers.length === 0 ? (
          <div className="text-center py-8">
            <Users className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">
              {searchQuery ? 'No followers match your search' : 'No followers yet'}
            </p>
            {!searchQuery && (
              <p className="text-xs text-muted-foreground mt-1">
                Be the first to follow {businessName}!
              </p>
            )}
          </div>
        ) : (
          <div className="divide-y divide-border">
            {filteredFollowers.map((follower) => (
              <FollowerItem
                key={follower.id}
                follower={follower}
                currentUserId={user?.id}
                isOwnProfile={isOwnProfile}
                onBlock={handleBlock}
                onRemoveFollower={handleRemoveFollower}
              />
            ))}
          </div>
        )}
      </ScrollArea>
    </>
  );

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={onOpenChange}>
        <DrawerContent className="max-h-[85vh]">
          <DrawerHeader>
            <DrawerTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Followers ({followers.length})
            </DrawerTitle>
          </DrawerHeader>
          <div className="px-4 pb-6">{content}</div>
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Followers ({followers.length})
          </DialogTitle>
        </DialogHeader>
        {content}
      </DialogContent>
    </Dialog>
  );
};

export default FollowersModal;
