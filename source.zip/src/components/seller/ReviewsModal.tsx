import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useIsMobile } from '@/hooks/use-mobile';
import { Star, Search, MessageSquare } from 'lucide-react';

interface Review {
  id: string;
  reviewer_id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  reviewer_profile: {
    business_name: string | null;
    business_logo_url: string | null;
    store_slug: string | null;
  } | null;
}

interface ReviewsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userId: string;
  businessName: string;
}

const ReviewItem = ({ review }: { review: Review }) => {
  const navigate = useNavigate();
  const displayName = review.reviewer_profile?.business_name || 'EarlyMarket user';
  const avatarUrl = review.reviewer_profile?.business_logo_url;
  const profileSlug = review.reviewer_profile?.store_slug;

  const handleClick = () => {
    if (profileSlug) {
      navigate(`/business/${profileSlug}`);
    }
  };

  return (
    <div className="py-3 px-1">
      <div className="flex items-start gap-3">
        <Avatar 
          className="h-10 w-10 cursor-pointer" 
          onClick={handleClick}
        >
          <AvatarImage src={avatarUrl || ''} />
          <AvatarFallback className="bg-primary/10 text-primary font-medium">
            {displayName.charAt(0).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <p 
              className="text-sm font-semibold truncate cursor-pointer hover:underline"
              onClick={handleClick}
            >
              {displayName}
            </p>
            <span className="text-xs text-muted-foreground">
              {new Date(review.created_at).toLocaleDateString()}
            </span>
          </div>
          <div className="flex items-center gap-0.5 mt-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`w-3.5 h-3.5 ${
                  i < review.rating
                    ? 'fill-yellow-400 text-yellow-400'
                    : 'text-muted-foreground/30'
                }`}
              />
            ))}
          </div>
          {review.comment && (
            <p className="text-sm text-muted-foreground mt-1.5 leading-relaxed">
              {review.comment}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

const ReviewsModal: React.FC<ReviewsModalProps> = ({
  open,
  onOpenChange,
  userId,
  businessName
}) => {
  const isMobile = useIsMobile();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchReviews = async () => {
      if (!open || !userId) return;

      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('reviews')
          .select('id, reviewer_id, rating, comment, created_at')
          .eq('reviewed_user_id', userId)
          .order('created_at', { ascending: false });

        if (error) throw error;

        const reviewsWithProfiles = await Promise.all(
          (data || []).map(async (review) => {
            const { data: profile } = await supabase
              .from('seller_profiles')
              .select('business_name, business_logo_url, store_slug')
              .eq('user_id', review.reviewer_id)
              .maybeSingle();

            if (profile?.business_name) {
              return { ...review, reviewer_profile: profile };
            }

            // Fall back to public auth profile for non-seller reviewers
            const { data: publicProfiles } = await supabase.rpc('get_public_user_profiles', {
              p_user_ids: [review.reviewer_id],
            });
            const pub = publicProfiles?.[0];
            return {
              ...review,
              reviewer_profile: {
                business_name: pub?.display_name ?? null,
                business_logo_url: pub?.avatar_url ?? null,
                store_slug: profile?.store_slug ?? null,
              },
            };
          })
        );

        setReviews(reviewsWithProfiles);
      } catch (error) {
        console.error('Error fetching reviews:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchReviews();
  }, [open, userId]);

  const filteredReviews = reviews.filter((r) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      r.reviewer_profile?.business_name?.toLowerCase().includes(q) ||
      r.comment?.toLowerCase().includes(q)
    );
  });

  const averageRating = reviews.length > 0
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : '0';

  const content = (
    <>
      {/* Search Bar */}
      <div className="px-1 mb-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search reviews..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 rounded-full bg-muted/50 border-border"
          />
        </div>
      </div>

      {/* Rating Summary */}
      {!isLoading && reviews.length > 0 && (
        <div className="flex items-center gap-3 px-1 mb-3 py-2 rounded-lg bg-muted/30">
          <div className="text-2xl font-bold text-foreground">{averageRating}</div>
          <div>
            <div className="flex items-center gap-0.5">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`w-4 h-4 ${
                    i < Math.round(Number(averageRating))
                      ? 'fill-yellow-400 text-yellow-400'
                      : 'text-muted-foreground/30'
                  }`}
                />
              ))}
            </div>
            <p className="text-xs text-muted-foreground">{reviews.length} reviews</p>
          </div>
        </div>
      )}

      <ScrollArea className="max-h-[50vh] pr-2">
        {isLoading ? (
          <div className="space-y-3 p-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex items-start gap-3">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-20" />
                  <Skeleton className="h-3 w-full" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredReviews.length === 0 ? (
          <div className="text-center py-8">
            <MessageSquare className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">
              {searchQuery ? 'No reviews match your search' : 'No reviews yet'}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {!searchQuery && `Be the first to review ${businessName}!`}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {filteredReviews.map((review) => (
              <ReviewItem key={review.id} review={review} />
            ))}
          </div>
        )}
      </ScrollArea>
    </>
  );

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={onOpenChange}>
        <DrawerContent className="max-h-[85vh]">
          <DrawerHeader>
            <DrawerTitle className="flex items-center gap-2">
              <Star className="w-5 h-5" />
              Reviews ({reviews.length})
            </DrawerTitle>
          </DrawerHeader>
          <div className="px-4 pb-6">{content}</div>
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Star className="w-5 h-5" />
            Reviews ({reviews.length})
          </DialogTitle>
        </DialogHeader>
        {content}
      </DialogContent>
    </Dialog>
  );
};

export default ReviewsModal;
