import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useIsMobile } from '@/hooks/use-mobile';
import { UserPlus, Search } from 'lucide-react';
import { toast } from 'sonner';

interface Following {
  id: string;
  following_id: string;
  created_at: string;
  seller_profile: {
    id: string;
    business_name: string | null;
    business_logo_url: string | null;
    store_slug: string | null;
    is_verified: boolean | null;
  } | null;
}

interface FollowingModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userId: string;
  businessName: string;
  isOwnProfile: boolean;
}

const FollowingItem = ({ 
  following, 
  currentUserId,
  isOwnProfile,
  onUnfollow
}: { 
  following: Following; 
  currentUserId?: string;
  isOwnProfile: boolean;
  onUnfollow: (followingId: string) => void;
}) => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const handleUnfollow = async () => {
    if (!currentUserId) return;
    
    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('follows')
        .delete()
        .eq('follower_id', currentUserId)
        .eq('following_id', following.following_id);
      
      if (error) throw error;
      
      onUnfollow(following.following_id);
      toast.success('Unfollowed successfully');
    } catch (error) {
      console.error('Error unfollowing:', error);
      toast.error('Failed to unfollow');
    } finally {
      setIsLoading(false);
    }
  };

  const displayName = following.seller_profile?.business_name || 'User';
  const avatarUrl = following.seller_profile?.business_logo_url;
  const profileSlug = following.seller_profile?.store_slug || following.seller_profile?.id;
  const handle = following.seller_profile?.store_slug || 
    following.seller_profile?.business_name?.toLowerCase().replace(/\s+/g, '') || 
    following.following_id.slice(0, 8);

  const handleClick = () => {
    if (following.seller_profile) {
      navigate(`/business/${profileSlug}`);
    }
  };

  return (
    <div className="flex items-center justify-between py-3 px-1">
      <div 
        className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
        onClick={handleClick}
      >
        <Avatar className="h-11 w-11 border border-border">
          <AvatarImage src={avatarUrl || ''} />
          <AvatarFallback className="bg-primary/10 text-primary font-medium">
            {displayName.charAt(0).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <p className="text-sm font-semibold truncate">{displayName}</p>
            {following.seller_profile?.is_verified && (
              <svg className="w-4 h-4 text-primary" viewBox="0 0 24 24" fill="currentColor">
                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
              </svg>
            )}
          </div>
          <p className="text-xs text-muted-foreground">@{handle}</p>
        </div>
      </div>
      
      {isOwnProfile && (
        <Button
          variant="secondary"
          size="sm"
          onClick={handleUnfollow}
          disabled={isLoading}
          className="rounded-full text-xs"
        >
          {isLoading ? 'Unfollowing...' : 'Following'}
        </Button>
      )}
    </div>
  );
};

const FollowingModal: React.FC<FollowingModalProps> = ({
  open,
  onOpenChange,
  userId,
  businessName,
  isOwnProfile
}) => {
  const { user } = useAuth();
  const isMobile = useIsMobile();
  const [followingList, setFollowingList] = useState<Following[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchFollowing = async () => {
      if (!open || !userId) return;
      
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('follows')
          .select('id, following_id, created_at')
          .eq('follower_id', userId)
          .order('created_at', { ascending: false });

        if (error) throw error;

        const followingWithProfiles = await Promise.all(
          (data || []).map(async (follow) => {
            const { data: sellerProfile } = await supabase
              .from('seller_profiles')
              .select('id, business_name, business_logo_url, store_slug, is_verified')
              .eq('user_id', follow.following_id)
              .maybeSingle();

            return { ...follow, seller_profile: sellerProfile };
          })
        );

        setFollowingList(followingWithProfiles);
      } catch (error) {
        console.error('Error fetching following:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchFollowing();
  }, [open, userId]);

  const handleUnfollow = (followingId: string) => {
    setFollowingList(prev => prev.filter(f => f.following_id !== followingId));
  };

  const filteredFollowing = followingList.filter(f => {
    if (!searchQuery) return true;
    return f.seller_profile?.business_name?.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const content = (
    <>
      {/* Search Bar */}
      <div className="px-1 mb-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search following..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 rounded-full bg-muted/50 border-border"
          />
        </div>
      </div>

      <ScrollArea className="max-h-[55vh] pr-2">
        {isLoading ? (
          <div className="space-y-3 p-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3">
                <Skeleton className="h-11 w-11 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-24" />
                </div>
                <Skeleton className="h-8 w-20 rounded-full" />
              </div>
            ))}
          </div>
        ) : filteredFollowing.length === 0 ? (
          <div className="text-center py-8">
            <UserPlus className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">
              {searchQuery ? 'No results match your search' : 'Not following anyone yet'}
            </p>
            {!searchQuery && (
              <p className="text-xs text-muted-foreground mt-1">
                {isOwnProfile ? 'Find interesting sellers to follow!' : `${businessName} hasn't followed anyone yet`}
              </p>
            )}
          </div>
        ) : (
          <div className="divide-y divide-border">
            {filteredFollowing.map((following) => (
              <FollowingItem
                key={following.id}
                following={following}
                currentUserId={user?.id}
                isOwnProfile={isOwnProfile}
                onUnfollow={handleUnfollow}
              />
            ))}
          </div>
        )}
      </ScrollArea>
    </>
  );

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={onOpenChange}>
        <DrawerContent className="max-h-[85vh]">
          <DrawerHeader>
            <DrawerTitle className="flex items-center gap-2">
              <UserPlus className="w-5 h-5" />
              Following ({followingList.length})
            </DrawerTitle>
          </DrawerHeader>
          <div className="px-4 pb-6">{content}</div>
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="w-5 h-5" />
            Following ({followingList.length})
          </DialogTitle>
        </DialogHeader>
        {content}
      </DialogContent>
    </Dialog>
  );
};

export default FollowingModal;
