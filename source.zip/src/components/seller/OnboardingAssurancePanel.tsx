import React, { useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, Sparkles, Rocket, MessageCircle } from 'lucide-react';
import EarlyMarketAIIcon from '@/components/icons/EarlyMarketAIIcon';

interface OnboardingAssurancePanelProps {
  /** Zero-indexed current step, used to pick step-specific assurance copy. */
  step: number;
}

/**
 * Step-specific, premium-but-calm assurance messages shown on the right
 * panel of the business creation flow. Rotates through a glass card so the
 * copy feels alive without overwhelming the user.
 */
const STEP_ASSURANCES: string[][] = [
  // Step 0 — About
  [
    "You're in the right place — this takes just a few minutes.",
    'Pick up to 5 categories so the right customers find you.',
    'You can rename or re-categorise your business anytime.',
  ],
  // Step 1 — Location & contact
  [
    'Nearby customers discover businesses with a clear location faster.',
    'Drop your exact spot with a Google Maps link — optional but powerful.',
    'Your contact details are only shown to genuine customers.',
  ],
  // Step 2 — Branding
  [
    'A crisp logo builds instant trust with new customers.',
    'Add a cover image to make your store look established.',
    'No time for a bio? Add it later — it stays optional.',
  ],
  // Step 3 — Operations
  [
    'Clear payment options mean fewer abandoned orders.',
    'Set working hours so customers know when to reach you.',
    'Everything here can be fine-tuned later from settings.',
  ],
  // Step 4 — Review & finish
  [
    'Almost done — your store link is being prepared.',
    'Share your unique link anywhere to start getting customers.',
    'Verified-looking stores win more repeat business.',
  ],
];

function RotatingAssurance({ messages }: { messages: string[] }) {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    setIdx(0);
    const t = setInterval(() => setIdx(i => (i + 1) % messages.length), 3800);
    return () => clearInterval(t);
  }, [messages]);
  return (
    <div className="relative w-full max-w-sm h-20">
      <AnimatePresence mode="wait">
        <motion.div
          key={idx}
          initial={{ opacity: 0, y: 10, filter: 'blur(6px)' }}
          animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
          exit={{ opacity: 0, y: -10, filter: 'blur(6px)' }}
          transition={{ duration: 0.5 }}
          className="absolute inset-0 flex items-center justify-center"
        >
          <div className="rounded-2xl border border-white/20 bg-white/10 backdrop-blur-xl px-5 py-4 shadow-[0_8px_30px_rgba(0,0,0,0.06)]">
            <p className="text-sm text-foreground/85 text-center leading-snug">{messages[idx]}</p>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

const OnboardingAssurancePanel: React.FC<OnboardingAssurancePanelProps> = ({ step }) => {
  const messages = useMemo(
    () => STEP_ASSURANCES[Math.min(step, STEP_ASSURANCES.length - 1)],
    [step],
  );

  return (
    <div className="relative h-full w-full bg-gradient-to-br from-primary/5 via-background to-primary/10 overflow-hidden">
      <div className="absolute -top-16 -left-16 h-72 w-72 rounded-full bg-primary/10 blur-3xl" />
      <div className="absolute bottom-0 right-0 h-80 w-80 rounded-full bg-primary/10 blur-3xl" />

      <div className="relative z-10 flex flex-col items-center justify-center h-full px-8 py-8 text-center">
        <EarlyMarketAIIcon className="h-10 w-10 mb-5" />

        <RotatingAssurance messages={messages} />

        {/* Free-standing trust icons — not boxed in cards */}
        <div className="mt-8 flex items-center gap-8 text-primary/80">
          <div className="flex flex-col items-center gap-1.5">
            <ShieldCheck className="h-6 w-6" strokeWidth={1.6} />
            <span className="text-[11px] text-muted-foreground">Trusted</span>
          </div>
          <div className="flex flex-col items-center gap-1.5">
            <Sparkles className="h-6 w-6" strokeWidth={1.6} />
            <span className="text-[11px] text-muted-foreground">AI-assisted</span>
          </div>
          <div className="flex flex-col items-center gap-1.5">
            <Rocket className="h-6 w-6" strokeWidth={1.6} />
            <span className="text-[11px] text-muted-foreground">Fast setup</span>
          </div>
        </div>

        <div className="mt-8 w-full max-w-sm rounded-2xl bg-card/70 backdrop-blur-md border border-border/60 px-5 py-4 shadow-sm">
          <p className="text-primary text-sm font-medium text-left flex items-center gap-2">
            <MessageCircle className="h-4 w-4" /> EarlyMarket AI
          </p>
          <p className="mt-1 text-xs text-muted-foreground text-left">
            We help you set up a store customers trust — clean branding, the right categories,
            and a location people can find.
          </p>
        </div>
      </div>
    </div>
  );
};

export default OnboardingAssurancePanel;