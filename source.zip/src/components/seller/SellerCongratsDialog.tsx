import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Copy, Check, ExternalLink, Share2, Sparkles } from 'lucide-react';
import StyledQRCode from '@/components/StyledQRCode';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { getFullSellerProfileUrl, getSellerProfileUrl } from '@/lib/sellerUrl';
import { motion } from 'framer-motion';
import confetti from 'canvas-confetti';

interface SellerCongratsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  storeName: string;
  storeSlug: string;
  logoUrl?: string | null;
}

const SellerCongratsDialog: React.FC<SellerCongratsDialogProps> = ({
  isOpen,
  onClose,
  storeName,
  storeSlug,
  logoUrl
}) => {
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);

  const storeUrl = getFullSellerProfileUrl({ store_slug: storeSlug, business_name: storeName });
  const storePathUrl = getSellerProfileUrl({ store_slug: storeSlug, business_name: storeName });

  // Trigger confetti when dialog opens
  useEffect(() => {
    if (isOpen) {
      const duration = 3000;
      const end = Date.now() + duration;
      const colors = ['#FF6B35', '#004E89', '#F77F00', '#22c55e'];

      const frame = () => {
        confetti({
          particleCount: 3,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: colors
        });
        confetti({
          particleCount: 3,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: colors
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      };
      frame();
    }
  }, [isOpen]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(storeUrl);
      setCopied(true);
      toast.success('Link copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('Failed to copy');
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${storeName} on EarlyMarket`,
          text: `Check out ${storeName} on EarlyMarket!`,
          url: storeUrl
        });
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          handleCopy();
        }
      }
    } else {
      handleCopy();
    }
  };

  const handleOpenStore = () => {
    onClose();
    navigate(storePathUrl);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent 
        className="sm:max-w-md p-0 overflow-hidden bg-gradient-to-br from-background via-background to-primary/5 border-primary/20"
        hideCloseButton
      >
        {/* Animated header */}
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-primary/10 to-transparent" />
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-primary/10 rounded-full blur-2xl" />
          
          <div className="relative pt-8 pb-6 px-6 text-center">
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 200, damping: 15 }}
              className="mx-auto w-16 h-16 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center mb-4 shadow-lg shadow-primary/30"
            >
              <Sparkles className="w-8 h-8 text-primary-foreground" />
            </motion.div>
            
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-2xl font-bold text-foreground mb-2"
            >
              Congratulations! 🎉
            </motion.h2>
            
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-muted-foreground"
            >
              Your store <span className="font-semibold text-foreground">{storeName}</span> is now live!
            </motion.p>
          </div>
        </div>

        {/* QR Code Section */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
          className="px-6 pb-4"
        >
          <StyledQRCode
            value={`${storeUrl}?action=follow`}
            size={160}
            showDownload={false}
          />
          <p className="text-center text-xs text-muted-foreground mt-3">
            Scan to visit your store
          </p>
        </motion.div>

        {/* Link Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="px-6 pb-4"
        >
          <button
            onClick={handleCopy}
            className="w-full flex items-center justify-between gap-3 bg-muted/50 hover:bg-muted border border-border rounded-xl px-4 py-3 transition-all group"
          >
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <ExternalLink className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <span className="text-sm text-muted-foreground truncate">
                {storeUrl.replace('https://', '').replace('http://', '')}
              </span>
            </div>
            <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg transition-all ${
              copied ? 'bg-green-500 text-white' : 'bg-primary text-primary-foreground group-hover:scale-105'
            }`}>
              {copied ? (
                <Check className="w-4 h-4" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </div>
          </button>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="px-6 pb-6 space-y-3"
        >
          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="outline"
              onClick={handleShare}
              className="flex items-center gap-2"
            >
              <Share2 className="w-4 h-4" />
              Share
            </Button>
            <Button
              onClick={handleOpenStore}
              className="flex items-center gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <ExternalLink className="w-4 h-4" />
              Open Store
            </Button>
          </div>
          
          <Button
            variant="ghost"
            onClick={onClose}
            className="w-full text-muted-foreground hover:text-foreground"
          >
            Continue to Dashboard
          </Button>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
};

export default SellerCongratsDialog;
