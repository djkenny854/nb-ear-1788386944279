import React from 'react';
import { Check, User, Building2, Landmark, Sparkles, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useFeatureToggle } from '@/hooks/useFeatureToggle';
import { toast } from 'sonner';

interface AccountType {
  id: 'regular' | 'business' | 'organization';
  name: string;
  subtitle: string;
  price: string;
  originalPrice?: string;
  priceNote: string;
  savingsNote?: string;
  highlight?: string;
  highlightColor?: string;
  borderColor?: string;
  features: { text: string; isNew?: boolean }[];
  icon: React.ReactNode;
  buttonText: string;
  buttonVariant: 'default' | 'outline';
  recommended?: boolean;
  footerNote?: string;
}

interface AccountTypeSelectorProps {
  onSelect: (type: 'regular' | 'business' | 'organization') => void;
}

const accountTypes: AccountType[] = [
  {
    id: 'regular',
    name: 'Regular User',
    subtitle: 'For casual sellers',
    price: 'Free',
    priceNote: 'forever',
    highlight: 'Free Forever',
    highlightColor: 'text-green-600',
    borderColor: 'border-l-green-500',
    features: [
      { text: 'Post up to 5 listings' },
      { text: 'Basic profile page' },
      { text: 'Direct messaging' },
      { text: 'Listings expire after 30 days' },
      { text: 'Products only (no jobs/services)' }
    ],
    icon: <User className="w-5 h-5" />,
    buttonText: 'Continue Free',
    buttonVariant: 'outline',
    footerNote: 'No account setup needed'
  },
  {
    id: 'business',
    name: 'Business Account',
    subtitle: 'For serious sellers',
    price: 'Free',
    priceNote: 'to create',
    highlight: 'Recommended',
    highlightColor: 'text-primary',
    borderColor: 'border-l-primary',
    features: [
      { text: 'Unlimited product listings', isNew: true },
      { text: 'Custom store page with URL' },
      { text: 'Post products, jobs & services' },
      { text: 'Analytics dashboard' },
      { text: 'Priority support' },
      { text: 'Verification badge eligible', isNew: true }
    ],
    icon: <Building2 className="w-5 h-5" />,
    buttonText: 'Create Business',
    buttonVariant: 'default',
    recommended: true,
    footerNote: 'Quick 5-minute setup'
  },
  {
    id: 'organization',
    name: 'Organization',
    subtitle: 'NGOs, Government & Institutions',
    price: 'Free',
    priceNote: 'to register',
    highlight: 'Verified Badge',
    highlightColor: 'text-orange-600',
    borderColor: 'border-l-orange-500',
    features: [
      { text: 'Everything in Business', isNew: true },
      { text: 'Instant orange verification badge', isNew: true },
      { text: 'Official organization profile' },
      { text: 'Multiple team members' },
      { text: 'Event hosting capabilities' },
      { text: 'Job posting privileges', isNew: true }
    ],
    icon: <Landmark className="w-5 h-5" />,
    buttonText: 'Register Organization',
    buttonVariant: 'outline',
    footerNote: 'Full document verification required'
  }
];

const AccountTypeSelector: React.FC<AccountTypeSelectorProps> = ({ onSelect }) => {
  const { isEnabled: organizationEnabled, isLoading } = useFeatureToggle('organization_onboarding_enabled');

  const handleSelect = (type: 'regular' | 'business' | 'organization') => {
    if (type === 'organization' && !organizationEnabled) {
      toast.error('Organization registration is temporarily unavailable. Please try again later or choose a Business account.');
      return;
    }
    onSelect(type);
  };

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            <Sparkles className="w-4 h-4" />
            Choose Your Account Type
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
            Start Selling on EarlyMarket
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Select the account type that best fits your needs. All options are completely free to get started.
          </p>
        </div>

        {/* Cards Grid - Google Style */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {accountTypes.map((type) => {
            const isOrgDisabled = type.id === 'organization' && !organizationEnabled && !isLoading;
            
            return (
              <div
                key={type.id}
                className={cn(
                  "relative bg-card rounded-xl border border-border transition-all duration-300 overflow-hidden",
                  type.borderColor && `border-l-4 ${type.borderColor}`,
                  type.recommended && "ring-2 ring-primary shadow-lg",
                  isOrgDisabled ? "opacity-60 cursor-not-allowed" : "hover:shadow-lg"
                )}
              >
                {/* Disabled overlay for organization */}
                {isOrgDisabled && (
                  <div className="absolute inset-0 bg-background/50 z-10 flex items-center justify-center">
                    <div className="bg-card border border-border rounded-lg p-4 mx-4 text-center shadow-lg">
                      <AlertCircle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                      <p className="text-sm font-medium text-foreground">Temporarily Unavailable</p>
                      <p className="text-xs text-muted-foreground mt-1">Organization registration is currently closed</p>
                    </div>
                  </div>
                )}

                {/* Highlight Badge */}
                {type.highlight && (
                  <div className="px-6 pt-4">
                    <span className={cn(
                      "text-xs font-semibold uppercase tracking-wider",
                      type.highlightColor,
                      isOrgDisabled && "text-muted-foreground"
                    )}>
                      {isOrgDisabled ? 'Coming Soon' : type.highlight}
                    </span>
                  </div>
                )}

                <div className="p-6 pt-2">
                  {/* Name */}
                  <h3 className="font-medium text-lg text-foreground mb-1">{type.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{type.subtitle}</p>

                  {/* Price */}
                  <div className="mb-4">
                    <div className="flex items-baseline gap-1">
                      {type.originalPrice && (
                        <span className="text-lg text-muted-foreground line-through">{type.originalPrice}</span>
                      )}
                      <span className="text-3xl font-bold text-foreground">{type.price}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{type.priceNote}</p>
                    {type.savingsNote && (
                      <p className="text-sm text-green-600 font-medium">{type.savingsNote}</p>
                    )}
                  </div>

                  {/* CTA Button */}
                  <Button
                    onClick={() => handleSelect(type.id)}
                    variant={type.buttonVariant}
                    disabled={isOrgDisabled}
                    className={cn(
                      "w-full mb-4",
                      type.recommended && "bg-primary hover:bg-primary/90",
                      isOrgDisabled && "opacity-50 cursor-not-allowed"
                    )}
                  >
                    {isOrgDisabled ? 'Temporarily Off' : type.buttonText}
                  </Button>

                  {/* Footer Note */}
                  {type.footerNote && (
                    <p className="text-xs text-center text-muted-foreground mb-4">{type.footerNote}</p>
                  )}

                {/* Divider */}
                <div className="border-t border-border pt-4 mt-2" />

                {/* Features Section */}
                {type.id !== 'regular' && (
                  <div className="flex items-center gap-2 mb-3">
                    <Sparkles className="w-4 h-4 text-primary" />
                    <span className="text-sm font-medium text-foreground">
                      {type.id === 'organization' ? 'Everything in Business, plus:' : 'Get access to powerful features'}
                    </span>
                  </div>
                )}

                {/* Features List */}
                <ul className="space-y-2.5">
                  {type.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2.5 text-sm">
                      <Check className={cn(
                        "w-4 h-4 mt-0.5 flex-shrink-0",
                        feature.isNew ? "text-primary" : "text-muted-foreground"
                      )} />
                      <span className={cn(
                        feature.isNew ? "text-primary font-medium" : "text-foreground/80"
                      )}>
                        {feature.text}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
              </div>
            );
          })}
        </div>

        {/* Footer Note */}
        <div className="text-center mt-10">
          <p className="text-sm text-muted-foreground">
            You can upgrade or change your account type anytime. All plans include basic seller features.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AccountTypeSelector;
