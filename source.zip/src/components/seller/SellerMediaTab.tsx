import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Play, Share2, Image as ImageIcon, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { videoCdnUrl } from '@/utils/cdnUrl';
import { toast } from 'sonner';
import { ImageDownloadButton } from '@/components/ImageDownloadButton';
import SmartVideo from '@/components/media/SmartVideo';

interface SellerMediaTabProps {
  sellerId: string;
}

type MediaItem = {
  kind: 'image' | 'video';
  url: string;
  permalink: string;
  createdAt: string;
  title: string;
};

// VisuallyHidden inline (avoids extra Radix dep) — used to satisfy a11y
// requirement of DialogTitle while keeping the lightbox chrome minimal.
const SrOnly: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <span className="absolute w-px h-px p-0 -m-px overflow-hidden whitespace-nowrap border-0" style={{ clip: 'rect(0 0 0 0)' }}>
    {children}
  </span>
);

// Thumbnail that only reveals once the image has fully loaded.
const LazyThumb: React.FC<{ src: string; alt: string }> = ({ src, alt }) => {
  const [loaded, setLoaded] = useState(false);
  return (
    <>
      {!loaded && <Skeleton className="absolute inset-0" />}
      <img
        src={src}
        alt={alt}
        loading="lazy"
        decoding="async"
        onLoad={() => setLoaded(true)}
        className={`w-full h-full object-cover transition-opacity duration-300 group-hover:scale-105 ${
          loaded ? 'opacity-100' : 'opacity-0'
        }`}
      />
    </>
  );
};

const SellerMediaTab: React.FC<SellerMediaTabProps> = ({ sellerId }) => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['seller-media', sellerId],
    queryFn: async () => {
      const [adsRes, postsRes, eventsRes] = await Promise.all([
        supabase
          .from('ads')
          .select('id, title, images, b2_video_url, listing_type, created_at')
          .eq('seller_id', sellerId)
          .eq('status', 'active'),
        supabase
          .from('posts')
          .select('id, title, images, video_url, created_at')
          .eq('seller_id', sellerId)
          .eq('is_active', true),
        supabase
          .from('events')
          .select('id, title, images, b2_video_url, video_url, created_at')
          .eq('seller_id', sellerId),
      ]);

      const items: MediaItem[] = [];

      const adsRoute = (lt: string | null) => {
        switch (lt) {
          case 'services': return '/service/';
          case 'promotions': return '/promotion/';
          case 'jobs': return '/job/';
          default: return '/ad/';
        }
      };

      (adsRes.data || []).forEach((ad: any) => {
        const link = `${adsRoute(ad.listing_type)}${ad.id}`;
        (ad.images || []).forEach((img: string) => {
          if (img) items.push({ kind: 'image', url: img, permalink: link, createdAt: ad.created_at, title: ad.title });
        });
        if (ad.b2_video_url) {
          items.push({ kind: 'video', url: videoCdnUrl(ad.b2_video_url), permalink: link, createdAt: ad.created_at, title: ad.title });
        }
      });

      (postsRes.data || []).forEach((p: any) => {
        const link = `/ad/${p.id}`;
        (p.images || []).forEach((img: string) => {
          if (img) items.push({ kind: 'image', url: img, permalink: link, createdAt: p.created_at, title: p.title || 'Post' });
        });
        const v = p.video_url;
        if (v) items.push({ kind: 'video', url: videoCdnUrl(v), permalink: link, createdAt: p.created_at, title: p.title || 'Post' });
      });

      (eventsRes.data || []).forEach((e: any) => {
        const link = `/event/${e.id}`;
        (e.images || []).forEach((img: string) => {
          if (img) items.push({ kind: 'image', url: img, permalink: link, createdAt: e.created_at, title: e.title });
        });
        const v = e.b2_video_url || e.video_url;
        if (v) items.push({ kind: 'video', url: videoCdnUrl(v), permalink: link, createdAt: e.created_at, title: e.title });
      });

      items.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
      return items;
    },
    enabled: !!sellerId,
  });

  const items = useMemo(() => data || [], [data]);
  const active = activeIndex !== null ? items[activeIndex] : null;
  const total = items.length;

  const close = useCallback(() => setActiveIndex(null), []);
  const prev = useCallback(() => {
    setActiveIndex((i) => (i === null ? null : (i - 1 + total) % total));
  }, [total]);
  const next = useCallback(() => {
    setActiveIndex((i) => (i === null ? null : (i + 1) % total));
  }, [total]);

  // Keyboard navigation while lightbox is open
  useEffect(() => {
    if (activeIndex === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') prev();
      else if (e.key === 'ArrowRight') next();
      else if (e.key === 'Escape') close();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [activeIndex, prev, next, close]);

  if (isLoading) {
    return (
      <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 gap-1.5 p-2">
        {Array.from({ length: 12 }).map((_, i) => (
          <Skeleton key={i} className="aspect-square rounded-md" />
        ))}
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center text-muted-foreground">
        <ImageIcon className="w-10 h-10 mb-3 opacity-40" />
        <p className="text-sm">No media yet.</p>
      </div>
    );
  }

  const handleShare = async (item: MediaItem) => {
    const url = `${window.location.origin}${item.permalink}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: item.title, url });
      } else {
        await navigator.clipboard.writeText(url);
        toast.success('Link copied');
      }
    } catch {
      /* user cancelled */
    }
  };

  return (
    <>
      <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 gap-1.5 p-2">
        {items.map((item, idx) => (
          <button
            key={`${item.url}-${idx}`}
            onClick={() => setActiveIndex(idx)}
            className="relative aspect-square overflow-hidden rounded-md bg-muted group"
          >
            {item.kind === 'image' ? (
              <LazyThumb src={item.url} alt={item.title} />
            ) : (
              <>
                <SmartVideo
                  src={item.url}
                  muted
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                  <div className="w-10 h-10 rounded-full bg-black/60 flex items-center justify-center">
                    <Play className="w-5 h-5 text-white fill-white" />
                  </div>
                </div>
                <span className="absolute bottom-1.5 left-1.5 text-[10px] font-medium bg-black/60 text-white px-1.5 py-0.5 rounded">
                  Video
                </span>
              </>
            )}
          </button>
        ))}
      </div>

      <Dialog open={activeIndex !== null} onOpenChange={(o) => !o && close()}>
        <DialogContent
          className="max-w-4xl w-[95vw] h-[90vh] p-0 overflow-hidden bg-black border-0 flex flex-col"
        >
          <DialogTitle asChild>
            <SrOnly>{active?.title || 'Media preview'}</SrOnly>
          </DialogTitle>

          {active && (
            <>
              {/* Close */}
              <button
                onClick={close}
                className="absolute top-2 right-2 z-20 w-9 h-9 rounded-full bg-black/60 hover:bg-black/80 flex items-center justify-center text-white"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Prev / Next */}
              {total > 1 && (
                <>
                  <button
                    onClick={prev}
                    aria-label="Previous"
                    className="absolute left-2 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/60 hover:bg-black/80 flex items-center justify-center text-white"
                  >
                    <ChevronLeft className="w-6 h-6" />
                  </button>
                  <button
                    onClick={next}
                    aria-label="Next"
                    className="absolute right-2 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/60 hover:bg-black/80 flex items-center justify-center text-white"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </button>
                </>
              )}

              {/* Media */}
              <div className="flex-1 min-h-0 flex items-center justify-center bg-black">
                {active.kind === 'image' ? (
                  <img
                    key={active.url}
                    src={active.url}
                    alt={active.title}
                    onContextMenu={(e) => e.preventDefault()}
                    className="max-w-full max-h-full w-auto h-auto object-contain"
                    draggable={false}
                  />
                ) : (
                  <SmartVideo
                    key={active.url}
                    src={active.url}
                    controls
                    autoPlay
                    controlsList="nodownload noremoteplayback noplaybackrate"
                    disablePictureInPicture
                    onContextMenu={(e) => e.preventDefault()}
                    className="max-w-full max-h-full w-auto h-auto"
                  />
                )}
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between gap-2 p-3 bg-background shrink-0">
                <div className="min-w-0 flex items-center gap-2">
                  <p className="text-sm font-medium truncate">{active.title}</p>
                  {total > 1 && (
                    <span className="text-xs text-muted-foreground shrink-0">
                      {(activeIndex ?? 0) + 1} / {total}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {active.kind === 'image' && (
                    <ImageDownloadButton
                      imageUrl={active.url}
                      fileName={`${(active.title || 'image').replace(/[^a-z0-9-_]+/gi, '_')}.jpg`}
                    />
                  )}
                  <Button size="sm" variant="outline" onClick={() => handleShare(active)}>
                    <Share2 className="w-4 h-4 mr-1.5" /> Share
                  </Button>
                  <Button size="sm" onClick={() => { close(); window.location.href = active.permalink; }}>
                    Open
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default SellerMediaTab;
