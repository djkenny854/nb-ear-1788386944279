
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  FileText,
  Calendar,
  User
} from 'lucide-react';

const SellerApplicationStatus = () => {
  const { user } = useAuth();

  const { data: sellerProfile, isLoading } = useQuery({
    queryKey: ['seller-profile', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sellers')
        .select('*')
        .eq('user_id', user?.id)
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
    enabled: !!user
  });

  if (isLoading) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-5/6"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!sellerProfile) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle>No Seller Application Found</CardTitle>
          <CardDescription>
            You haven't submitted a seller application yet.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <Button onClick={() => window.location.href = '/create-business-account'}>
            Create Business Profile
          </Button>
        </CardContent>
      </Card>
    );
  }

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'draft':
        return {
          icon: FileText,
          color: 'bg-gray-100 text-gray-800',
          title: 'Draft Application',
          description: 'Your application is saved but not yet submitted.'
        };
      case 'pending':
        return {
          icon: Clock,
          color: 'bg-yellow-100 text-yellow-800',
          title: 'Under Review',
          description: 'Your application is being reviewed by our team.'
        };
      case 'approved':
        return {
          icon: CheckCircle,
          color: 'bg-green-100 text-green-800',
          title: 'Approved',
          description: 'Congratulations! Your seller account has been approved.'
        };
      case 'rejected':
        return {
          icon: XCircle,
          color: 'bg-red-100 text-red-800',
          title: 'Rejected',
          description: 'Your application was not approved. Please review the feedback.'
        };
      default:
        return {
          icon: AlertCircle,
          color: 'bg-gray-100 text-gray-800',
          title: 'Unknown Status',
          description: 'Application status is unclear.'
        };
    }
  };

  const statusConfig = getStatusConfig(sellerProfile.application_status);
  const StatusIcon = statusConfig.icon;

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center">
          <StatusIcon className="w-8 h-8" />
        </div>
        <CardTitle className="text-2xl">{statusConfig.title}</CardTitle>
        <CardDescription>{statusConfig.description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex justify-center">
          <Badge className={statusConfig.color}>
            {sellerProfile.application_status.charAt(0).toUpperCase() + sellerProfile.application_status.slice(1)}
          </Badge>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <User className="w-4 h-4" />
              <span>Business Name:</span>
            </div>
            <p className="font-medium">{sellerProfile.business_name}</p>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Calendar className="w-4 h-4" />
              <span>Applied:</span>
            </div>
            <p className="font-medium">
              {sellerProfile.applied_at 
                ? new Date(sellerProfile.applied_at).toLocaleDateString()
                : 'Not submitted'
              }
            </p>
          </div>
        </div>
        
        {sellerProfile.application_status === 'approved' && (
          <div className="text-center space-y-4">
            <p className="text-green-600 font-medium">
              Approved on: {new Date(sellerProfile.approved_at).toLocaleDateString()}
            </p>
            <Button onClick={() => window.location.href = '/dashboard'}>
              Go to Seller Dashboard
            </Button>
          </div>
        )}
        
        {sellerProfile.application_status === 'draft' && (
          <div className="text-center">
            <Button onClick={() => window.location.href = '/create-business-account'}>
              Complete Application
            </Button>
          </div>
        )}
        
        {sellerProfile.application_status === 'pending' && (
          <div className="text-center">
            <p className="text-gray-600 mb-4">
              We typically review applications within 24-48 hours. You'll be notified via email once your application is processed.
            </p>
            <Button variant="outline" onClick={() => window.location.href = '/profile'}>
              Back to Profile
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default SellerApplicationStatus;
