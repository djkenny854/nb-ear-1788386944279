import React, { useEffect, useState, useMemo } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from '@/components/ui/drawer';
import { MapPin, Search, ChevronDown, Check } from 'lucide-react';
import { ugandaDistricts } from '@/data/ugandaDistricts';
import { cn } from '@/lib/utils';

interface LocationData {
  district: string;
  subcounty?: string;
  parish?: string;
  village?: string;
}

interface SearchableLocationSelectorProps {
  onLocationSelect: (location: LocationData) => void;
  initialLocation?: LocationData;
  className?: string;
  district?: string;
  subCounty?: string;
  parish?: string;
  village?: string;
  onLocationChange?: (field: string, value: string) => void;
  required?: boolean;
}

/** A drawer-based searchable picker used for both district and sub-county. */
function DrawerPicker({
  label,
  placeholder,
  value,
  options,
  onSelect,
  required,
}: {
  label: string;
  placeholder: string;
  value: string;
  options: string[];
  onSelect: (v: string) => void;
  required?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return options;
    return options.filter((o) => o.toLowerCase().includes(q));
  }, [search, options]);

  return (
    <div className="space-y-2">
      <Label>
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <Drawer open={open} onOpenChange={setOpen}>
        <DrawerTrigger asChild>
          <button
            type="button"
            className={cn(
              'w-full flex items-center justify-between h-11 rounded-xl border-[1.5px] border-border bg-background px-4 text-left text-base transition-colors hover:border-foreground/40',
              !value && 'text-muted-foreground',
            )}
          >
            <span className="truncate">{value || placeholder}</span>
            <ChevronDown className="h-4 w-4 text-muted-foreground flex-shrink-0 ml-2" />
          </button>
        </DrawerTrigger>
        <DrawerContent className="max-h-[85vh]">
          <DrawerHeader>
            <DrawerTitle>{label}</DrawerTitle>
          </DrawerHeader>
          <div className="px-4 pb-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                autoFocus
                placeholder={`Search ${label.toLowerCase()}…`}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 h-11"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto px-2 pb-6">
            {filtered.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                No matches for “{search}”.
              </p>
            ) : (
              <ul className="space-y-0.5">
                {filtered.map((o) => {
                  const active = o === value;
                  return (
                    <li key={o}>
                      <button
                        type="button"
                        onClick={() => {
                          onSelect(o);
                          setSearch('');
                          setOpen(false);
                        }}
                        className={cn(
                          'w-full flex items-center justify-between px-4 py-3 rounded-lg text-left text-[15px] transition-colors',
                          active
                            ? 'bg-primary/10 text-primary font-medium'
                            : 'hover:bg-accent/50',
                        )}
                      >
                        <span>{o}</span>
                        {active && <Check className="h-4 w-4" />}
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </DrawerContent>
      </Drawer>
    </div>
  );
}

const SearchableLocationSelector: React.FC<SearchableLocationSelectorProps> = ({
  onLocationSelect,
  initialLocation,
  className = '',
  district: propDistrict,
  subCounty: propSubCounty,
  parish: propParish,
  village: propVillage,
  onLocationChange,
  required = false,
}) => {
  const [selectedDistrict, setSelectedDistrict] = useState(
    initialLocation?.district || propDistrict || '',
  );
  const [selectedSubcounty, setSelectedSubcounty] = useState(
    initialLocation?.subcounty || propSubCounty || '',
  );
  const [selectedParish, setSelectedParish] = useState(
    initialLocation?.parish || propParish || '',
  );
  const [selectedVillage, setSelectedVillage] = useState(
    initialLocation?.village || propVillage || '',
  );

  const districts = ugandaDistricts.map((d) => d.name);
  const subcounties = selectedDistrict
    ? ugandaDistricts.find((d) => d.name === selectedDistrict)?.subCounties || []
    : [];

  useEffect(() => {
    if (selectedDistrict) {
      onLocationSelect({
        district: selectedDistrict,
        ...(selectedSubcounty && { subcounty: selectedSubcounty }),
        ...(selectedParish && { parish: selectedParish }),
        ...(selectedVillage && { village: selectedVillage }),
      });
    }
  }, [selectedDistrict, selectedSubcounty, selectedParish, selectedVillage, onLocationSelect]);

  const setDistrict = (value: string) => {
    setSelectedDistrict(value);
    setSelectedSubcounty('');
    setSelectedParish('');
    setSelectedVillage('');
    onLocationChange?.('district', value);
    onLocationChange?.('subCounty', '');
    onLocationChange?.('parish', '');
    onLocationChange?.('village', '');
  };

  const setSubcounty = (value: string) => {
    setSelectedSubcounty(value);
    setSelectedParish('');
    setSelectedVillage('');
    onLocationChange?.('subCounty', value);
    onLocationChange?.('parish', '');
    onLocationChange?.('village', '');
  };

  return (
    <div className={`space-y-4 ${className}`}>
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <MapPin className="w-4 h-4" />
        <span>Select your location</span>
      </div>

      <DrawerPicker
        label="District"
        placeholder="Select district"
        value={selectedDistrict}
        options={districts}
        onSelect={setDistrict}
        required={required}
      />

      {selectedDistrict && (
        <DrawerPicker
          label="Sub-county"
          placeholder="Select sub-county"
          value={selectedSubcounty}
          options={subcounties}
          onSelect={setSubcounty}
          required={required}
        />
      )}

      {selectedDistrict && (
        <div className="space-y-2">
          <Label htmlFor="parish">
            Parish <span className="text-xs text-muted-foreground">(optional)</span>
          </Label>
          <Input
            id="parish"
            placeholder="Enter parish"
            value={selectedParish}
            onChange={(e) => {
              setSelectedParish(e.target.value);
              onLocationChange?.('parish', e.target.value);
            }}
          />
        </div>
      )}

      {selectedDistrict && (
        <div className="space-y-2">
          <Label htmlFor="village">
            Village <span className="text-xs text-muted-foreground">(optional)</span>
          </Label>
          <Input
            id="village"
            placeholder="Enter village"
            value={selectedVillage}
            onChange={(e) => {
              setSelectedVillage(e.target.value);
              onLocationChange?.('village', e.target.value);
            }}
          />
        </div>
      )}
    </div>
  );
};

export default SearchableLocationSelector;
