import React, { useState } from 'react';
import { useAuth } from '@/components/auth/AuthContext';
import { useNavigate } from 'react-router-dom';
import { useMutation } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import {
  Building2,
  User,
  MapPin,
  FileText,
  Mail,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Camera,
  Upload,
  Shield,
  AlertCircle
} from 'lucide-react';
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';
import SearchableLocationSelector from './SearchableLocationSelector';

interface OrganizationFormData {
  // Organization Identity
  organization_name: string;
  organization_type: string;
  registration_number: string;
  tin_number: string;
  incorporation_date: string;
  
  // Contact Person
  contact_person_name: string;
  contact_person_title: string;
  contact_person_email: string;
  contact_person_phone: string;
  
  // Organization Address
  physical_address: string;
  district: string;
  postal_address: string;
  website_url: string;
  
  // Documents
  registration_certificate_url: string;
  tax_certificate_url: string;
  authorization_letter_url: string;
  org_logo_url: string;
}

const organizationTypes = [
  { value: 'government', label: 'Government Agency' },
  { value: 'ngo', label: 'Non-Governmental Organization (NGO)' },
  { value: 'institution', label: 'Educational Institution' },
  { value: 'embassy', label: 'Embassy / Diplomatic Mission' },
  { value: 'religious', label: 'Religious Organization' },
  { value: 'other', label: 'Other Organization' }
];

const OrganizationRegistrationWizard: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { theme } = useTheme();
  
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [emailVerificationSent, setEmailVerificationSent] = useState(false);
  
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState('');
  const [certificateFile, setCertificateFile] = useState<File | null>(null);
  const [taxCertFile, setTaxCertFile] = useState<File | null>(null);
  const [authLetterFile, setAuthLetterFile] = useState<File | null>(null);

  const [formData, setFormData] = useState<OrganizationFormData>({
    organization_name: '',
    organization_type: '',
    registration_number: '',
    tin_number: '',
    incorporation_date: '',
    contact_person_name: '',
    contact_person_title: '',
    contact_person_email: user?.email || '',
    contact_person_phone: '',
    physical_address: '',
    district: '',
    postal_address: '',
    website_url: '',
    registration_certificate_url: '',
    tax_certificate_url: '',
    authorization_letter_url: '',
    org_logo_url: ''
  });

  const steps = [
    {
      id: 0,
      title: 'Organization Details',
      icon: Building2,
      description: 'Basic information about your organization'
    },
    {
      id: 1,
      title: 'Contact Person',
      icon: User,
      description: 'Authorized representative details'
    },
    {
      id: 2,
      title: 'Location',
      icon: MapPin,
      description: 'Physical address and contact information'
    },
    {
      id: 3,
      title: 'Documents',
      icon: FileText,
      description: 'Upload required verification documents'
    },
    {
      id: 4,
      title: 'Email Verification',
      icon: Mail,
      description: 'Verify your official email address'
    },
    {
      id: 5,
      title: 'Review & Submit',
      icon: CheckCircle2,
      description: 'Review and submit your application'
    }
  ];

  const progress = ((currentStep + 1) / steps.length) * 100;

  const handleInputChange = (field: keyof OrganizationFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleLocationSelect = (location: { district: string }) => {
    setFormData(prev => ({ ...prev, district: location.district }));
  };

  const handleFileUpload = async (file: File, type: 'logo' | 'certificate' | 'tax' | 'letter') => {
    if (type === 'logo') {
      setLogoFile(file);
      const reader = new FileReader();
      reader.onload = (e) => setLogoPreview(e.target?.result as string);
      reader.readAsDataURL(file);
    } else if (type === 'certificate') {
      setCertificateFile(file);
    } else if (type === 'tax') {
      setTaxCertFile(file);
    } else if (type === 'letter') {
      setAuthLetterFile(file);
    }
  };

  const uploadFile = async (file: File, folder: string): Promise<string> => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${user?.id}/${folder}/${Date.now()}.${fileExt}`;
    
    const { error: uploadError } = await supabase.storage
      .from('business-assets')
      .upload(fileName, file);
    
    if (uploadError) throw uploadError;
    
    const { data: { publicUrl } } = supabase.storage
      .from('business-assets')
      .getPublicUrl(fileName);
    
    return publicUrl;
  };

  const sendVerificationEmail = async () => {
    // In a real implementation, this would call an edge function to send verification email
    toast.success('Verification email sent! Please check your inbox.');
    setEmailVerificationSent(true);
  };

  const createOrganization = useMutation({
    mutationFn: async () => {
      let logoUrl = '';
      let certificateUrl = '';
      let taxUrl = '';
      let letterUrl = '';

      if (logoFile) logoUrl = await uploadFile(logoFile, 'org-logos');
      if (certificateFile) certificateUrl = await uploadFile(certificateFile, 'org-certificates');
      if (taxCertFile) taxUrl = await uploadFile(taxCertFile, 'org-tax');
      if (authLetterFile) letterUrl = await uploadFile(authLetterFile, 'org-letters');

      // Create organization registration
      const { data: orgData, error: orgError } = await supabase
        .from('organization_registrations')
        .insert([{
          user_id: user?.id,
          organization_name: formData.organization_name,
          organization_type: formData.organization_type,
          registration_number: formData.registration_number,
          tin_number: formData.tin_number || null,
          incorporation_date: formData.incorporation_date || null,
          contact_person_name: formData.contact_person_name,
          contact_person_title: formData.contact_person_title,
          contact_person_email: formData.contact_person_email,
          contact_person_phone: formData.contact_person_phone,
          physical_address: formData.physical_address,
          district: formData.district,
          postal_address: formData.postal_address || null,
          website_url: formData.website_url || null,
          registration_certificate_url: certificateUrl,
          tax_certificate_url: taxUrl || null,
          authorization_letter_url: letterUrl,
          org_logo_url: logoUrl || null,
          email_verified: emailVerificationSent,
          verification_status: 'verified', // Instant verification for organizations
          verified_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (orgError) throw orgError;

      // Generate store slug
      const { data: slugData, error: slugError } = await supabase
        .rpc('generate_store_slug', { business_name: formData.organization_name });

      if (slugError) throw slugError;

      // Create seller profile with orange badge
      const { data: sellerProfile, error: sellerError } = await supabase
        .from('seller_profiles')
        .insert([{
          user_id: user?.id,
          business_name: formData.organization_name,
          seller_type: 'ngo',
          registration_number: formData.registration_number,
          business_category: 'Organization',
          country: 'Uganda',
          district: formData.district,
          sub_county: '',
          street_address: formData.physical_address,
          business_phone: formData.contact_person_phone,
          business_email: formData.contact_person_email,
          business_logo_url: logoUrl,
          business_bio: `Official ${formData.organization_type} organization`,
          store_slug: slugData,
          is_verified: true,
          verification_badge: 'verified',
          verification_badge_color: 'orange',
          organization_registration_id: orgData.id
        }])
        .select()
        .single();

      if (sellerError) throw sellerError;

      return { organization: orgData, seller: sellerProfile };
    },
    onSuccess: (data) => {
      toast.success('🎉 Organization registered successfully!');
      
      // Trigger confetti
      import('canvas-confetti').then((confetti) => {
        confetti.default({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#f97316', '#ea580c', '#c2410c'] // Orange colors
        });
      });

      setTimeout(() => navigate(`/business/${data.seller.store_slug}`), 1500);
    },
    onError: (error) => {
      toast.error('Failed to register organization. Please try again.');
      console.error('Error:', error);
    }
  });

  const isStepValid = () => {
    switch (currentStep) {
      case 0:
        return formData.organization_name && formData.organization_type && formData.registration_number;
      case 1:
        return formData.contact_person_name && formData.contact_person_title && 
               formData.contact_person_email && formData.contact_person_phone;
      case 2:
        return formData.physical_address && formData.district;
      case 3:
        return certificateFile && authLetterFile;
      case 4:
        return emailVerificationSent;
      case 5:
        return true;
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCompletedSteps(prev => [...new Set([...prev, currentStep])]);
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-6">
            <div>
              <Label>Organization Name *</Label>
              <Input
                value={formData.organization_name}
                onChange={(e) => handleInputChange('organization_name', e.target.value)}
                placeholder="Official organization name"
              />
            </div>
            <div>
              <Label>Organization Type *</Label>
              <Select value={formData.organization_type} onValueChange={(v) => handleInputChange('organization_type', v)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select organization type" />
                </SelectTrigger>
                <SelectContent>
                  {organizationTypes.map(type => (
                    <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Registration Number *</Label>
              <Input
                value={formData.registration_number}
                onChange={(e) => handleInputChange('registration_number', e.target.value)}
                placeholder="Official registration number"
              />
            </div>
            <div>
              <Label>TIN Number (Optional)</Label>
              <Input
                value={formData.tin_number}
                onChange={(e) => handleInputChange('tin_number', e.target.value)}
                placeholder="Tax Identification Number"
              />
            </div>
            <div>
              <Label>Incorporation Date (Optional)</Label>
              <Input
                type="date"
                value={formData.incorporation_date}
                onChange={(e) => handleInputChange('incorporation_date', e.target.value)}
              />
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            <div className="p-4 bg-orange-50 dark:bg-orange-950/30 rounded-lg border border-orange-200 dark:border-orange-800">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-orange-600 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-orange-800 dark:text-orange-300">Authorization Required</p>
                  <p className="text-xs text-orange-600 dark:text-orange-400">
                    This person must be authorized to represent the organization. An authorization letter will be required.
                  </p>
                </div>
              </div>
            </div>
            <div>
              <Label>Full Name *</Label>
              <Input
                value={formData.contact_person_name}
                onChange={(e) => handleInputChange('contact_person_name', e.target.value)}
                placeholder="Contact person's full name"
              />
            </div>
            <div>
              <Label>Title / Position *</Label>
              <Input
                value={formData.contact_person_title}
                onChange={(e) => handleInputChange('contact_person_title', e.target.value)}
                placeholder="e.g., Executive Director, Manager"
              />
            </div>
            <div>
              <Label>Official Email *</Label>
              <Input
                type="email"
                value={formData.contact_person_email}
                onChange={(e) => handleInputChange('contact_person_email', e.target.value)}
                placeholder="official@organization.org"
              />
            </div>
            <div>
              <Label>Phone Number *</Label>
              <Input
                value={formData.contact_person_phone}
                onChange={(e) => handleInputChange('contact_person_phone', e.target.value)}
                placeholder="+256 700 000 000"
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <SearchableLocationSelector
              onLocationSelect={handleLocationSelect}
              initialLocation={{ district: formData.district }}
              required
            />
            <div>
              <Label>Physical Address *</Label>
              <Textarea
                value={formData.physical_address}
                onChange={(e) => handleInputChange('physical_address', e.target.value)}
                placeholder="Full physical address including building name, street"
                rows={3}
              />
            </div>
            <div>
              <Label>Postal Address (Optional)</Label>
              <Input
                value={formData.postal_address}
                onChange={(e) => handleInputChange('postal_address', e.target.value)}
                placeholder="P.O. Box 1234, Kampala"
              />
            </div>
            <div>
              <Label>Website (Optional)</Label>
              <Input
                value={formData.website_url}
                onChange={(e) => handleInputChange('website_url', e.target.value)}
                placeholder="https://www.organization.org"
              />
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="p-4 bg-muted rounded-lg">
              <h4 className="font-medium mb-2">Required Documents</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Registration Certificate (PDF/Image)</li>
                <li>• Authorization Letter (PDF/Image)</li>
                <li>• Tax Certificate (Optional)</li>
                <li>• Organization Logo (Optional)</li>
              </ul>
            </div>

            <div>
              <Label>Organization Logo</Label>
              <div className="flex items-center gap-4 mt-2">
                <Avatar className="w-20 h-20">
                  <AvatarImage src={logoPreview} />
                  <AvatarFallback><Camera className="w-8 h-8 text-muted-foreground" /></AvatarFallback>
                </Avatar>
                <Input
                  type="file"
                  accept="image/*"
                  onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'logo')}
                />
              </div>
            </div>

            <div>
              <Label>Registration Certificate *</Label>
              <div className="mt-2 border-2 border-dashed border-border rounded-lg p-4 text-center">
                <Upload className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                <Input
                  type="file"
                  accept=".pdf,image/*"
                  onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'certificate')}
                  className="max-w-xs mx-auto"
                />
                {certificateFile && (
                  <p className="text-sm text-green-600 mt-2">✓ {certificateFile.name}</p>
                )}
              </div>
            </div>

            <div>
              <Label>Authorization Letter *</Label>
              <p className="text-xs text-muted-foreground mb-2">
                Letter authorizing the contact person to represent the organization
              </p>
              <div className="mt-2 border-2 border-dashed border-border rounded-lg p-4 text-center">
                <Upload className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                <Input
                  type="file"
                  accept=".pdf,image/*"
                  onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'letter')}
                  className="max-w-xs mx-auto"
                />
                {authLetterFile && (
                  <p className="text-sm text-green-600 mt-2">✓ {authLetterFile.name}</p>
                )}
              </div>
            </div>

            <div>
              <Label>Tax Certificate (Optional)</Label>
              <div className="mt-2 border-2 border-dashed border-border rounded-lg p-4 text-center">
                <Input
                  type="file"
                  accept=".pdf,image/*"
                  onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'tax')}
                  className="max-w-xs mx-auto"
                />
                {taxCertFile && (
                  <p className="text-sm text-green-600 mt-2">✓ {taxCertFile.name}</p>
                )}
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6 text-center py-8">
            <div className="w-20 h-20 bg-orange-100 dark:bg-orange-900/30 rounded-full flex items-center justify-center mx-auto">
              <Mail className="w-10 h-10 text-orange-600" />
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">Verify Your Email</h3>
              <p className="text-muted-foreground mb-4">
                We'll send a verification link to <strong>{formData.contact_person_email}</strong>
              </p>
            </div>
            
            {!emailVerificationSent ? (
              <Button onClick={sendVerificationEmail} className="bg-orange-600 hover:bg-orange-700">
                Send Verification Email
              </Button>
            ) : (
              <div className="space-y-4">
                <div className="p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-800">
                  <CheckCircle2 className="w-6 h-6 text-green-600 mx-auto mb-2" />
                  <p className="text-sm text-green-700 dark:text-green-300">
                    Verification email sent! Check your inbox.
                  </p>
                </div>
                <Button variant="outline" onClick={sendVerificationEmail}>
                  Resend Email
                </Button>
              </div>
            )}
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <div className="p-4 bg-orange-50 dark:bg-orange-950/30 rounded-lg border border-orange-200 dark:border-orange-800">
              <div className="flex items-center gap-3 mb-3">
                <Shield className="w-6 h-6 text-orange-600" />
                <h4 className="font-semibold text-orange-800 dark:text-orange-300">
                  Instant Verification
                </h4>
              </div>
              <p className="text-sm text-orange-700 dark:text-orange-400">
                As a registered organization, you'll receive instant verification with an orange badge upon submission.
              </p>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium">Review Your Information</h4>
              
              <div className="grid gap-4">
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-xs text-muted-foreground">Organization</p>
                  <p className="font-medium">{formData.organization_name}</p>
                  <p className="text-sm text-muted-foreground">{formData.organization_type}</p>
                </div>
                
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-xs text-muted-foreground">Contact Person</p>
                  <p className="font-medium">{formData.contact_person_name}</p>
                  <p className="text-sm text-muted-foreground">{formData.contact_person_title}</p>
                </div>
                
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-xs text-muted-foreground">Location</p>
                  <p className="font-medium">{formData.district}</p>
                  <p className="text-sm text-muted-foreground">{formData.physical_address}</p>
                </div>
                
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-xs text-muted-foreground">Documents</p>
                  <div className="text-sm space-y-1">
                    {certificateFile && <p className="text-green-600">✓ Registration Certificate</p>}
                    {authLetterFile && <p className="text-green-600">✓ Authorization Letter</p>}
                    {taxCertFile && <p className="text-green-600">✓ Tax Certificate</p>}
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-orange-500/5">
      <div className="max-w-7xl mx-auto px-4 py-6 sm:py-8">
        {/* Header */}
        <div className="mb-6 sm:mb-8 flex items-center gap-4">
          <img 
            src={earlymarketLogo} 
            alt="EarlyMarket" 
            className="h-10 w-auto cursor-pointer"
            onClick={() => navigate('/')}
          />
          <div className="flex-1">
            <h1 className="text-2xl sm:text-3xl font-bold mb-1 bg-gradient-to-r from-orange-600 to-orange-500 bg-clip-text text-transparent">
              Register Organization
            </h1>
            <p className="text-sm text-muted-foreground">
              Complete verification to get your official orange badge
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-12 gap-6 lg:gap-8">
          {/* Steps Sidebar */}
          <div className="lg:col-span-4 xl:col-span-3">
            <Card className="p-4 sm:p-6 bg-card/95 backdrop-blur-sm border-border/50 shadow-lg sticky top-6">
              <div className="mb-6 p-4 bg-gradient-to-br from-orange-500/10 to-orange-500/5 rounded-xl border border-orange-500/20">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold">Progress</span>
                  <span className="text-sm font-bold text-orange-600">{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>

              <ScrollArea className="max-h-[400px]">
                <div className="space-y-2">
                  {steps.map((step, index) => {
                    const isCompleted = completedSteps.includes(step.id);
                    const isCurrent = currentStep === step.id;

                    return (
                      <button
                        key={step.id}
                        onClick={() => index <= currentStep && setCurrentStep(index)}
                        disabled={index > currentStep}
                        className={cn(
                          'w-full text-left p-3 rounded-lg transition-all duration-200',
                          isCurrent && 'bg-gradient-to-r from-orange-500 to-orange-600 text-white',
                          !isCurrent && isCompleted && 'bg-green-50 dark:bg-green-950/30',
                          !isCurrent && !isCompleted && 'bg-muted/30',
                          index > currentStep && 'opacity-50 cursor-not-allowed'
                        )}
                      >
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            'p-2 rounded-lg',
                            isCurrent && 'bg-white/20',
                            isCompleted && !isCurrent && 'bg-green-500 text-white',
                            !isCurrent && !isCompleted && 'bg-muted'
                          )}>
                            {isCompleted && !isCurrent ? (
                              <CheckCircle2 className="w-4 h-4" />
                            ) : (
                              <step.icon className="w-4 h-4" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{step.title}</p>
                            <p className={cn(
                              'text-xs truncate',
                              isCurrent ? 'text-white/70' : 'text-muted-foreground'
                            )}>
                              {step.description}
                            </p>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </ScrollArea>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-8 xl:col-span-9">
            <Card className="p-4 sm:p-6 md:p-8 bg-card/95 backdrop-blur-sm border-border/50 shadow-xl">
              {/* Step Title */}
              <div className="mb-6">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  {React.createElement(steps[currentStep].icon, { className: "w-6 h-6 text-orange-600" })}
                  {steps[currentStep].title}
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  {steps[currentStep].description}
                </p>
              </div>

              {/* Step Content */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentStep}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.2 }}
                >
                  {renderStepContent()}
                </motion.div>
              </AnimatePresence>

              {/* Navigation */}
              <div className="flex items-center justify-between mt-8 pt-6 border-t border-border/50">
                <Button
                  variant="outline"
                  onClick={handleBack}
                  disabled={currentStep === 0}
                  className="gap-2"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Back
                </Button>

                <div className="text-sm text-muted-foreground">
                  Step <span className="font-semibold text-orange-600">{currentStep + 1}</span> / {steps.length}
                </div>

                {currentStep < steps.length - 1 ? (
                  <Button
                    onClick={handleNext}
                    disabled={!isStepValid()}
                    className="gap-2 bg-orange-600 hover:bg-orange-700"
                  >
                    Continue
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                ) : (
                  <Button
                    onClick={() => createOrganization.mutate()}
                    disabled={createOrganization.isPending}
                    className="gap-2 bg-orange-600 hover:bg-orange-700"
                  >
                    {createOrganization.isPending ? 'Submitting...' : 'Submit Registration'}
                    <CheckCircle2 className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrganizationRegistrationWizard;
