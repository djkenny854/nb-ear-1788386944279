import React, { useState } from 'react';
import { useAuth } from '@/components/auth/AuthContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { 
  Upload, 
  Building, 
  Phone, 
  Mail, 
  Globe, 
  MapPin, 
  FileText,
  Check,
  AlertCircle,
  Camera,
  Users,
  Store
} from 'lucide-react';
import SearchableLocationSelector from './SearchableLocationSelector';

interface SellerFormData {
  business_name: string;
  business_description: string;
  business_type: string;
  business_address: string;
  business_phone: string;
  business_email: string;
  business_website: string;
  tax_id: string;
  registration_number: string;
  district: string;
  sub_county: string;
  parish: string;
  village: string;
  terms_accepted: boolean;
}

const SellerUpgradeForm = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState<SellerFormData>({
    business_name: '',
    business_description: '',
    business_type: '',
    business_address: '',
    business_phone: '',
    business_email: user?.email || '',
    business_website: '',
    tax_id: '',
    registration_number: '',
    district: '',
    sub_county: '',
    parish: '',
    village: '',
    terms_accepted: false
  });
  
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string>('');
  const [currentStep, setCurrentStep] = useState(1);
  
  // Fetch seller terms
  const { data: terms } = useQuery({
    queryKey: ['seller-terms'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('seller_terms')
        .select('*')
        .eq('is_active', true)
        .single();
      
      if (error) throw error;
      return data;
    }
  });
  
  // Check if user already has a seller profile
  const { data: existingSeller } = useQuery({
    queryKey: ['existing-seller', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sellers')
        .select('*')
        .eq('user_id', user?.id)
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
    enabled: !!user
  });

  const handleLocationSelect = (location: any) => {
    setFormData(prev => ({
      ...prev,
      district: location.district || '',
      sub_county: location.subcounty || '',
      parish: location.parish || '',
      village: location.village || ''
    }));
  };
  
  const handleInputChange = (field: keyof SellerFormData, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleLocationChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setLogoFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setLogoPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const uploadLogo = async (file: File): Promise<string> => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${user?.id}-${Date.now()}.${fileExt}`;
    
    const { error: uploadError } = await supabase.storage
      .from('seller-logos')
      .upload(fileName, file);
    
    if (uploadError) throw uploadError;
    
    const { data: { publicUrl } } = supabase.storage
      .from('seller-logos')
      .getPublicUrl(fileName);
    
    return publicUrl;
  };
  
  const createSellerMutation = useMutation({
    mutationFn: async (data: SellerFormData) => {
      let logoUrl = '';
      
      if (logoFile) {
        logoUrl = await uploadLogo(logoFile);
      }
      
      const sellerData = {
        user_id: user?.id,
        business_logo_url: logoUrl,
        terms_accepted_at: new Date().toISOString(),
        applied_at: new Date().toISOString(),
        application_status: 'pending',
        ...data
      };
      
      const { data: seller, error } = await supabase
        .from('sellers')
        .insert([sellerData])
        .select()
        .single();
      
      if (error) throw error;
      return seller;
    },
    onSuccess: () => {
      toast.success('Seller application submitted successfully! We will review your application within 24-48 hours.');
      queryClient.invalidateQueries({ queryKey: ['existing-seller'] });
    },
    onError: (error) => {
      toast.error('Failed to submit application. Please try again.');
      console.error('Error creating seller:', error);
    }
  });
  
  const updateSellerMutation = useMutation({
    mutationFn: async (data: SellerFormData) => {
      let logoUrl = existingSeller?.business_logo_url;
      
      if (logoFile) {
        logoUrl = await uploadLogo(logoFile);
      }
      
      const updateData = {
        business_logo_url: logoUrl,
        terms_accepted_at: new Date().toISOString(),
        applied_at: new Date().toISOString(),
        application_status: 'pending',
        ...data
      };
      
      const { data: seller, error } = await supabase
        .from('sellers')
        .update(updateData)
        .eq('user_id', user?.id)
        .select()
        .single();
      
      if (error) throw error;
      return seller;
    },
    onSuccess: () => {
      toast.success('Seller application updated successfully!');
      queryClient.invalidateQueries({ queryKey: ['existing-seller'] });
    },
    onError: (error) => {
      toast.error('Failed to update application. Please try again.');
      console.error('Error updating seller:', error);
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.terms_accepted) {
      toast.error('Please accept the terms and conditions to continue');
      return;
    }
    
    if (existingSeller) {
      updateSellerMutation.mutate(formData);
    } else {
      createSellerMutation.mutate(formData);
    }
  };
  
  const isFormValid = () => {
    const requiredFields = [
      'business_name', 'business_description', 'business_type', 
      'business_address', 'business_phone', 'business_email',
      'district'
    ];
    
    return requiredFields.every(field => formData[field as keyof SellerFormData]) && 
           formData.terms_accepted;
  };
  
  if (existingSeller?.application_status === 'approved') {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-green-600" />
          </div>
          <CardTitle className="text-2xl text-green-800">You're Already a Seller!</CardTitle>
          <CardDescription>
            Your seller account has been approved and is active.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <Button onClick={() => window.location.href = '/dashboard'}>
            Go to Seller Dashboard
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  if (existingSeller?.application_status === 'pending') {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-8 h-8 text-yellow-600" />
          </div>
          <CardTitle className="text-2xl text-yellow-800">Application Under Review</CardTitle>
          <CardDescription>
            Your seller application is being reviewed. We'll notify you once it's processed.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <p className="text-gray-600 mb-4">
            Applied on: {new Date(existingSeller.applied_at).toLocaleDateString()}
          </p>
          <Button variant="outline" onClick={() => window.location.href = '/profile'}>
            Back to Profile
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Create Business Profile</h1>
        <p className="text-gray-600">Join thousands of successful businesses on EarlyMarket</p>
      </div>
      
      {/* Progress Steps */}
      <div className="flex items-center justify-center mb-8">
        <div className="flex items-center space-x-4">
          {[1, 2, 3].map((step) => (
            <div key={step} className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                currentStep >= step ? 'bg-primary text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                {step}
              </div>
              {step < 3 && (
                <div className={`w-16 h-1 mx-2 ${
                  currentStep > step ? 'bg-primary' : 'bg-gray-200'
                }`} />
              )}
            </div>
          ))}
        </div>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Step 1: Business Information */}
        {currentStep === 1 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="w-5 h-5" />
                Business Information
              </CardTitle>
              <CardDescription>
                Tell us about your business and what you sell
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Business Logo */}
              <div className="flex items-center gap-6">
                <div className="flex-shrink-0">
                  <Avatar className="w-24 h-24">
                    <AvatarImage src={logoPreview} />
                    <AvatarFallback>
                      <Camera className="w-8 h-8 text-gray-400" />
                    </AvatarFallback>
                  </Avatar>
                </div>
                <div className="flex-1">
                  <Label htmlFor="logo-upload" className="block text-sm font-medium mb-2">
                    Business Logo
                  </Label>
                  <Input
                    id="logo-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="cursor-pointer"
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Upload a clear logo for your business (PNG, JPG, max 5MB)
                  </p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="business_name">Business Name *</Label>
                  <Input
                    id="business_name"
                    value={formData.business_name}
                    onChange={(e) => handleInputChange('business_name', e.target.value)}
                    placeholder="Enter your business name"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="business_type">Business Type *</Label>
                  <Select value={formData.business_type} onValueChange={(value) => handleInputChange('business_type', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select business type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="retail">Retail</SelectItem>
                      <SelectItem value="wholesale">Wholesale</SelectItem>
                      <SelectItem value="manufacturer">Manufacturer</SelectItem>
                      <SelectItem value="service">Service Provider</SelectItem>
                      <SelectItem value="agriculture">Agriculture</SelectItem>
                      <SelectItem value="technology">Technology</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="business_description">Business Description *</Label>
                <Textarea
                  id="business_description"
                  value={formData.business_description}
                  onChange={(e) => handleInputChange('business_description', e.target.value)}
                  placeholder="Describe your business, products, and services..."
                  rows={4}
                  required
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="tax_id">Tax ID (Optional)</Label>
                  <Input
                    id="tax_id"
                    value={formData.tax_id}
                    onChange={(e) => handleInputChange('tax_id', e.target.value)}
                    placeholder="Enter your tax ID"
                  />
                </div>
                
                <div>
                  <Label htmlFor="registration_number">Registration Number (Optional)</Label>
                  <Input
                    id="registration_number"
                    value={formData.registration_number}
                    onChange={(e) => handleInputChange('registration_number', e.target.value)}
                    placeholder="Enter business registration number"
                  />
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button type="button" onClick={() => setCurrentStep(2)}>
                  Next: Contact Information
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Step 2: Contact Information */}
        {currentStep === 2 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="w-5 h-5" />
                Contact Information
              </CardTitle>
              <CardDescription>
                How can customers reach you?
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="business_phone">Business Phone *</Label>
                  <Input
                    id="business_phone"
                    value={formData.business_phone}
                    onChange={(e) => handleInputChange('business_phone', e.target.value)}
                    placeholder="+256 700 000 000"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="business_email">Business Email *</Label>
                  <Input
                    id="business_email"
                    type="email"
                    value={formData.business_email}
                    onChange={(e) => handleInputChange('business_email', e.target.value)}
                    placeholder="business@example.com"
                    required
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="business_website">Business Website (Optional)</Label>
                <Input
                  id="business_website"
                  value={formData.business_website}
                  onChange={(e) => handleInputChange('business_website', e.target.value)}
                  placeholder="https://www.yourwebsite.com"
                />
              </div>
              
              <div>
                <Label htmlFor="business_address">Business Address *</Label>
                <Textarea
                  id="business_address"
                  value={formData.business_address}
                  onChange={(e) => handleInputChange('business_address', e.target.value)}
                  placeholder="Enter your complete business address"
                  rows={3}
                  required
                />
              </div>
              
              {/* Location Selection */}
              <div>
                <Label className="text-base font-medium mb-4 block">Business Location *</Label>
                <SearchableLocationSelector
                  onLocationSelect={handleLocationSelect}
                  district={formData.district}
                  subCounty={formData.sub_county}
                  parish={formData.parish}
                  village={formData.village}
                  onLocationChange={handleLocationChange}
                  required={true}
                />
              </div>
              
              <div className="flex justify-between">
                <Button type="button" variant="outline" onClick={() => setCurrentStep(1)}>
                  Back
                </Button>
                <Button type="button" onClick={() => setCurrentStep(3)}>
                  Next: Terms & Conditions
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Step 3: Terms and Conditions */}
        {currentStep === 3 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Terms and Conditions
              </CardTitle>
              <CardDescription>
                Please read and accept our seller terms and conditions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {terms && (
                <div className="border rounded-lg p-4">
                  <h3 className="font-semibold text-lg mb-4">{terms.title}</h3>
                  <ScrollArea className="h-96 w-full">
                    <div className="text-sm text-gray-700 whitespace-pre-line">
                      {terms.content}
                    </div>
                  </ScrollArea>
                </div>
              )}
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="terms_accepted"
                  checked={formData.terms_accepted}
                  onCheckedChange={(checked) => handleInputChange('terms_accepted', checked as boolean)}
                />
                <Label htmlFor="terms_accepted" className="text-sm">
                  I have read and accept the terms and conditions
                </Label>
              </div>
              
              <div className="flex justify-between">
                <Button type="button" variant="outline" onClick={() => setCurrentStep(2)}>
                  Back
                </Button>
                <Button 
                  type="submit" 
                  disabled={!isFormValid() || createSellerMutation.isPending || updateSellerMutation.isPending}
                  className="bg-primary text-white hover:bg-primary/90"
                >
                  {createSellerMutation.isPending || updateSellerMutation.isPending ? 'Submitting...' : 'Submit Application'}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </form>
    </div>
  );
};

export default SellerUpgradeForm;
