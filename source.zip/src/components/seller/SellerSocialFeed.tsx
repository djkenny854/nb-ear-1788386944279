import React, { useState, useMemo, useEffect } from 'react';
import { getAppBaseUrl } from '@/utils/getAppUrl';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal, Briefcase, Tag, Package, Calendar, FileText, Image as ImageIcon, Search, X } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import verifiedBadge from '@/assets/verified-badge.png';
import { motion, AnimatePresence } from 'framer-motion';
import { useIsMobile } from '@/hooks/use-mobile';
import HomeProductCard from '@/components/cards/HomeProductCard';
import SellerMediaTab from '@/components/seller/SellerMediaTab';
import InterestedButton from '@/components/common/InterestedButton';
import { useBookmarks } from '@/hooks/useBookmarks';
import ShareModal from '@/components/ShareModal';
import { CommentModal } from '@/components/CommentModal';

interface SellerSocialFeedProps {
  sellerId: string;
  seller: any;
  searchQuery?: string;
  onSearchChange?: (query: string) => void;
}

type FeedFilter = 'products' | 'services' | 'jobs' | 'promotions' | 'posts' | 'events' | 'media';

const SellerSocialFeed: React.FC<SellerSocialFeedProps> = ({ sellerId, seller, searchQuery: externalSearchQuery, onSearchChange }) => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  // Default tab: products. Will be auto-corrected to the first non-empty tab
  // once content loads (so service-only businesses don't open on empty Products).
  const [filter, setFilter] = useState<FeedFilter>('products');
  const [filterAutoPicked, setFilterAutoPicked] = useState(false);
  const [localSearchQuery, setLocalSearchQuery] = useState('');
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const [commentModalOpen, setCommentModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [shareItem, setShareItem] = useState<any>(null);
  const { isBookmarked, toggleBookmark } = useBookmarks();

  // Use external search query if provided, otherwise use local
  const externalQuery = externalSearchQuery !== undefined ? externalSearchQuery : localSearchQuery;
  const handleSearchChange = onSearchChange || setLocalSearchQuery;
  // Debounce the actual filtering query so typing doesn't lag the input on
  // big stores with hundreds of items.
  const [searchQuery, setSearchQuery] = useState(externalQuery);
  useEffect(() => {
    const t = setTimeout(() => setSearchQuery(externalQuery), 250);
    return () => clearTimeout(t);
  }, [externalQuery]);

  // Fetch all content types
  const { data: ads = [], isLoading: adsLoading } = useQuery({
    queryKey: ['seller-feed-ads', sellerId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('ads')
        .select('*')
        .eq('seller_id', sellerId)
        .eq('status', 'active')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: !!sellerId
  });

  const { data: posts = [], isLoading: postsLoading } = useQuery({
    queryKey: ['seller-feed-posts', sellerId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .eq('seller_id', sellerId)
        .eq('is_active', true)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: !!sellerId
  });

  const { data: events = [], isLoading: eventsLoading } = useQuery({
    queryKey: ['seller-feed-events', sellerId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .eq('seller_id', sellerId)
        .eq('is_active', true)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: !!sellerId
  });

  // Combine and sort all content
  const allFeedItems = React.useMemo(() => {
    const items: any[] = [];

    // Add ads
    ads.forEach(ad => {
      const isService = ad.listing_type === 'services';
      items.push({
        id: ad.id,
        type: ad.listing_type === 'jobs' ? 'job' : 
              ad.listing_type === 'promotions' ? 'promotion' :
              isService ? 'service' : 'product',
        title: ad.title,
        description: ad.description,
        images: ad.images || [],
        price: isService ? null : ad.price,
        currency: ad.currency || 'UGX',
        location: ad.location,
        created_at: ad.created_at,
        view_count: ad.view_count || 0,
        listing_type: ad.listing_type,
        category: ad.category,
      });
    });

    // Add posts
    posts.forEach(post => {
      items.push({
        id: post.id,
        type: 'post',
        title: post.title,
        description: post.content,
        images: post.images || [],
        created_at: post.created_at,
        view_count: post.view_count || 0,
        like_count: post.like_count || 0,
        comment_count: post.comment_count || 0,
      });
    });

    // Add events
    events.forEach(event => {
      items.push({
        id: event.id,
        type: 'event',
        title: event.title,
        description: event.description,
        images: event.images || [],
        created_at: event.created_at,
        event_date: event.event_date,
        location: event.location,
        view_count: event.view_count || 0,
        is_free: event.is_free,
        ticket_price: event.ticket_price,
      });
    });

    // Sort by created_at
    items.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    return items;
  }, [ads, posts, events]);

  // Filter items by type and search query
  const filteredItems = useMemo(() => {
    let items = allFeedItems;
    
    // Apply type filter - no 'all' option anymore
    if (filter === 'products') items = items.filter(item => item.type === 'product');
    else if (filter === 'services') items = items.filter(item => item.type === 'service');
    else if (filter === 'jobs') items = items.filter(item => item.type === 'job');
    else if (filter === 'promotions') items = items.filter(item => item.type === 'promotion');
    else if (filter === 'posts') items = items.filter(item => item.type === 'post');
    else if (filter === 'events') items = items.filter(item => item.type === 'event');
    
    // Apply search filter
    if (searchQuery && searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      items = items.filter(item => 
        item.title?.toLowerCase().includes(query) ||
        item.description?.toLowerCase().includes(query) ||
        item.category?.toLowerCase().includes(query) ||
        item.location?.toLowerCase().includes(query)
      );
    }
    
    return items;
  }, [allFeedItems, filter, searchQuery]);

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds}s`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)}d`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const handleItemClick = (item: any) => {
    if (item.type === 'service') {
      navigate(`/service/${item.id}`);
    } else if (item.type === 'post') {
      navigate(`/post/${item.id}`);
    } else if (item.type === 'event') {
      navigate(`/event/${item.id}`);
    } else if (item.type === 'promotion') {
      navigate(`/promotion/${item.id}`);
    } else {
      // product, job, default
      navigate(`/ad/${item.id}`);
    }
  };

  const getContentType = (type: string): 'ad' | 'post' | 'event' | 'service' => {
    if (type === 'post') return 'post';
    if (type === 'event') return 'event';
    return 'ad';
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'job': return <Briefcase className="w-3 h-3" />;
      case 'promotion': return <Tag className="w-3 h-3" />;
      case 'event': return <Calendar className="w-3 h-3" />;
      case 'post': return <FileText className="w-3 h-3" />;
      default: return <Package className="w-3 h-3" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'job': return 'bg-green-500/10 text-green-600 dark:text-green-400';
      case 'promotion': return 'bg-orange-500/10 text-orange-600 dark:text-orange-400';
      case 'event': return 'bg-pink-500/10 text-pink-600 dark:text-pink-400';
      case 'post': return 'bg-blue-500/10 text-blue-600 dark:text-blue-400';
      default: return 'bg-primary/10 text-primary';
    }
  };

  const isLoading = adsLoading || postsLoading || eventsLoading;

  const filters = ([
    { id: 'products' as FeedFilter, label: 'Products', count: allFeedItems.filter(i => i.type === 'product').length },
    { id: 'services' as FeedFilter, label: 'Services', count: allFeedItems.filter(i => i.type === 'service').length },
    { id: 'jobs' as FeedFilter, label: 'Jobs', count: allFeedItems.filter(i => i.type === 'job').length },
    { id: 'promotions' as FeedFilter, label: 'Promos', count: allFeedItems.filter(i => i.type === 'promotion').length },
    { id: 'posts' as FeedFilter, label: 'Posts', count: allFeedItems.filter(i => i.type === 'post').length },
    { id: 'events' as FeedFilter, label: 'Events', count: allFeedItems.filter(i => i.type === 'event').length },
    { id: 'media' as FeedFilter, label: 'Media', count: 0 },
  ] as const).filter(f => f.id === 'products' || f.id === 'media' || f.count > 0);

  // Smart default-tab: once content has loaded, if the user is still on the
  // initial "products" tab and that tab is empty, jump to the first tab that
  // has content (services, jobs, events, promotions, posts).
  useEffect(() => {
    if (isLoading || filterAutoPicked) return;
    const productCount = allFeedItems.filter(i => i.type === 'product').length;
    if (filter === 'products' && productCount === 0) {
      const order: FeedFilter[] = ['services', 'jobs', 'events', 'promotions', 'posts'];
      for (const id of order) {
        const t = id === 'jobs' ? 'job'
                : id === 'services' ? 'service'
                : id === 'promotions' ? 'promotion'
                : id === 'events' ? 'event'
                : 'post';
        if (allFeedItems.some(i => i.type === t)) {
          setFilter(id);
          break;
        }
      }
    }
    setFilterAutoPicked(true);
  }, [isLoading, allFeedItems, filter, filterAutoPicked]);


  return (
    <div className="flex flex-col h-full">
      {/* Mobile Search Drawer - opens from top */}
      <AnimatePresence>
        {mobileSearchOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-x-0 top-0 z-50 bg-background border-b border-border shadow-lg p-4"
          >
            <div className="flex gap-2 items-center">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder={`Search in ${seller?.business_name || 'this store'}...`}
                  value={searchQuery}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  className="pl-9 pr-9"
                  autoFocus
                />
                {searchQuery && (
                  <button
                    onClick={() => handleSearchChange('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2"
                  >
                    <X className="w-4 h-4 text-muted-foreground" />
                  </button>
                )}
              </div>
              <Button variant="ghost" size="sm" onClick={() => setMobileSearchOpen(false)}>
                Cancel
              </Button>
            </div>
            {searchQuery && (
              <p className="text-sm text-muted-foreground mt-2">
                Found {filteredItems.length} result{filteredItems.length !== 1 ? 's' : ''} in this store
              </p>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Filter Tabs - No search button here, search is in top navbar */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="flex items-center overflow-x-auto scrollbar-hide">
          {filters.map(({ id, label, count }) => (
            <button
              key={id}
              onClick={() => setFilter(id)}
              className={cn(
                "flex-shrink-0 px-4 py-3 text-sm font-medium transition-colors relative",
                filter === id 
                  ? "text-foreground" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {label}
              {count > 0 && (
                <span className="ml-1 text-xs text-muted-foreground">({count})</span>
              )}
              {filter === id && (
                <motion.div 
                  layoutId="activeFilter"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary"
                />
              )}
            </button>
          ))}
        </div>
        
        {/* Search indicator when searching */}
        {searchQuery && (
          <div className="px-4 py-2 bg-muted/50 flex items-center justify-between">
            <span className="text-xs text-muted-foreground">
              Showing results for "{searchQuery}" ({filteredItems.length} found)
            </span>
            <button 
              onClick={() => handleSearchChange('')}
              className="text-xs text-primary hover:underline"
            >
              Clear
            </button>
          </div>
        )}
      </div>

      {/* Feed Content - Grid on large screens */}
      <div className="flex-1 p-4">
        {filter === 'media' ? (
          <SellerMediaTab sellerId={sellerId} />
        ) : isLoading ? (
          filter === 'products' ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="space-y-2">
                  <Skeleton className="aspect-square rounded-xl" />
                  <Skeleton className="h-3 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="p-4 border border-border rounded-xl">
                  <div className="flex gap-3">
                    <Skeleton className="w-10 h-10 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-3 w-full" />
                      <Skeleton className="h-32 w-full rounded-xl" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )
        ) : filteredItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <ImageIcon className="w-12 h-12 mb-4 opacity-50" />
            <p className="text-sm">{searchQuery ? `No results for "${searchQuery}"` : 'No content yet'}</p>
            {searchQuery && (
              <button 
                onClick={() => handleSearchChange('')}
                className="mt-2 text-sm text-primary hover:underline"
              >
                Clear search
              </button>
            )}
          </div>
        ) : filter === 'products' ? (
          // Products use HomeProductCard in a grid layout
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredItems.map((item, index) => (
              <motion.div
                key={`product-${item.id}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
              >
                <HomeProductCard
                  id={item.id}
                  title={item.title}
                  price={item.price || 0}
                  images={item.images || []}
                  location={item.location || ''}
                  createdAt={item.created_at}
                  seller={{
                    business_name: seller?.business_name,
                    business_logo_url: seller?.business_logo_url,
                    is_verified: seller?.is_verified,
                  }}
                  onClick={() => handleItemClick(item)}
                  sourcePage="profile"
                />
              </motion.div>
            ))}
          </div>
        ) : (
          // Other content types use the social feed style
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredItems.map((item, index) => (
              <motion.article
                key={`${item.type}-${item.id}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
                className="border border-border rounded-xl hover:bg-muted/30 transition-colors cursor-pointer overflow-hidden"
                onClick={() => handleItemClick(item)}
              >
                <div className="flex gap-3 p-4">
                  {/* Avatar */}
                  <Avatar className="w-10 h-10 flex-shrink-0">
                    <AvatarImage src={seller?.business_logo_url} />
                    <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                      {(seller?.business_name || 'S').charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    {/* Header */}
                    <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
                      <span className="font-semibold text-sm text-foreground truncate">
                        {seller?.business_name}
                      </span>
                      {seller?.is_verified && (
                        <img src={verifiedBadge} alt="Verified" className="w-4 h-4" />
                      )}
                      <span className={cn(
                        "text-[10px] px-1.5 py-0.5 rounded-full font-medium flex items-center gap-1",
                        getTypeColor(item.type)
                      )}>
                        {getTypeIcon(item.type)}
                        {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
                      </span>
                      <span className="text-muted-foreground text-xs">·</span>
                      <span className="text-muted-foreground text-xs">
                        {getTimeAgo(item.created_at)}
                      </span>
                    </div>

                    {/* Title */}
                    {item.title && (
                      <h3 className="font-medium text-sm text-foreground line-clamp-1 mb-1">
                        {item.title}
                      </h3>
                    )}

                    {/* Price for products/promotions - hide for services with no price */}
                    {item.type === 'service' ? (
                      <p className="text-primary font-medium text-sm mb-2">Service</p>
                    ) : item.price && item.type !== 'event' ? (
                      <p className="text-primary font-bold text-base mb-2">
                        {item.currency || 'UGX'} {item.price.toLocaleString()}
                      </p>
                    ) : null}

                    {/* Event date */}
                    {item.type === 'event' && item.event_date && (
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
                        <Calendar className="w-3.5 h-3.5" />
                        {new Date(item.event_date).toLocaleDateString('en-US', {
                          weekday: 'short', month: 'short', day: 'numeric'
                        })}
                        {item.is_free ? (
                          <span className="ml-2 text-green-500 font-medium">Free</span>
                        ) : item.ticket_price && (
                          <span className="ml-2 text-primary font-medium">
                            UGX {item.ticket_price.toLocaleString()}
                          </span>
                        )}
                      </div>
                    )}

                    {/* Images - X.com style with proper object-cover */}
                    {item.images && item.images.length > 0 && (
                      <div className={cn(
                        "mt-2 rounded-xl overflow-hidden border border-border",
                        item.images.length === 2 && "grid grid-cols-2 gap-0.5",
                        item.images.length === 3 && "grid grid-cols-2 gap-0.5",
                        item.images.length >= 4 && "grid grid-cols-2 gap-0.5"
                      )}>
                        {item.images.length === 1 && (
                          <img
                            src={item.images[0]}
                            alt={item.title || 'Image'}
                            loading="lazy" decoding="async" className="w-full aspect-video object-cover"
                          />
                        )}
                        {item.images.length === 2 && item.images.slice(0, 2).map((img: string, idx: number) => (
                          <img
                            key={idx}
                            src={img}
                            alt={`Image ${idx + 1}`}
                            loading="lazy" decoding="async" className="w-full aspect-square object-cover"
                          />
                        ))}
                        {item.images.length === 3 && (
                          <>
                            <img
                              src={item.images[0]}
                              alt="Image 1"
                              loading="lazy" decoding="async" className="row-span-2 w-full h-full object-cover"
                            />
                            {item.images.slice(1, 3).map((img: string, idx: number) => (
                              <img
                                key={idx}
                                src={img}
                                alt={`Image ${idx + 2}`}
                                loading="lazy" decoding="async" className="w-full aspect-square object-cover"
                              />
                            ))}
                          </>
                        )}
                        {item.images.length >= 4 && item.images.slice(0, 4).map((img: string, idx: number) => (
                          <div key={idx} className="relative aspect-square">
                            <img
                              src={img}
                              alt={`Image ${idx + 1}`}
                              loading="lazy" decoding="async" className="w-full h-full object-cover"
                            />
                            {idx === 3 && item.images.length > 4 && (
                              <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                                <span className="text-white text-lg font-bold">+{item.images.length - 4}</span>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex items-center justify-between mt-3 max-w-[320px]" onClick={(e) => e.stopPropagation()}>
                      <InterestedButton
                        contentId={item.id}
                        contentType={getContentType(item.type)}
                        variant="compact"
                        className="h-auto py-1 px-2"
                      />
                      
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedItem(item);
                          setCommentModalOpen(true);
                        }}
                        className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors group"
                      >
                        <MessageCircle className="w-4 h-4 group-hover:scale-110 transition-transform" />
                        <span className="text-xs">{item.comment_count || ''}</span>
                      </button>
                      
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setShareItem(item);
                          setShareModalOpen(true);
                        }}
                        className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors group"
                      >
                        <Share2 className="w-4 h-4 group-hover:scale-110 transition-transform" />
                      </button>
                      
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleBookmark(item.id);
                        }}
                        className={cn(
                          "flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors group",
                          isBookmarked(item.id) && "text-primary"
                        )}
                      >
                        <Bookmark className={cn(
                          "w-4 h-4 group-hover:scale-110 transition-transform",
                          isBookmarked(item.id) && "fill-current"
                        )} />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        )}
      </div>

      {/* Comment Modal */}
      {selectedItem && (
        <CommentModal
          open={commentModalOpen}
          onOpenChange={setCommentModalOpen}
          contentType={selectedItem.type === 'event' ? 'event' : selectedItem.type === 'post' ? 'post' : 'ad'}
          contentId={selectedItem.id}
          images={selectedItem.images}
          author={{
            name: seller?.business_name || '',
            avatar: seller?.business_logo_url || '',
            is_verified: seller?.is_verified,
          }}
          caption={selectedItem.title}
          sellerId={sellerId}
          sellerUserId={seller?.user_id}
        />
      )}

      {/* Share Modal */}
      {shareItem && (
        <ShareModal
          open={shareModalOpen}
          onOpenChange={setShareModalOpen}
          title={shareItem.title || ''}
          description={shareItem.description || ''}
          url={`${getAppBaseUrl()}/${shareItem.type === 'event' ? 'event' : 'ad'}/${shareItem.id}`}
          imageUrl={shareItem.images?.[0]}
        />
      )}
    </div>
  );
};

export default SellerSocialFeed;
