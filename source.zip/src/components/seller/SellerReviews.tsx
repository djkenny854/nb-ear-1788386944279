import React, { useState, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Star, MoreVertical, ChevronRight, ImagePlus, X, ThumbsUp, ThumbsDown } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface Review {
  id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  is_verified: boolean;
  reviewer_id: string;
  helpful_count: number;
  review_images: string[];
  reviewer?: {
    full_name: string | null;
    avatar_url: string | null;
  };
}

interface SellerReviewsProps {
  sellerId: string;
  sellerUserId: string;
}

// Skeleton loader for reviews
export const ReviewsSkeleton = () => (
  <div className="space-y-6">
    <div className="flex gap-8">
      <div className="text-center">
        <Skeleton className="h-16 w-20 mx-auto mb-2 animate-pulse" />
        <Skeleton className="h-4 w-24 mx-auto mb-1 animate-pulse" />
        <Skeleton className="h-3 w-16 mx-auto animate-pulse" />
      </div>
      <div className="flex-1 space-y-2">
        {[5, 4, 3, 2, 1].map((i) => (
          <div key={i} className="flex items-center gap-3">
            <Skeleton className="h-4 w-6 animate-pulse" />
            <Skeleton className="h-2 flex-1 animate-pulse" />
          </div>
        ))}
      </div>
    </div>
    <div className="space-y-6 pt-6 border-t border-border">
      {[1, 2, 3].map((i) => (
        <div key={i} className="space-y-3">
          <div className="flex items-center gap-3">
            <Skeleton className="h-10 w-10 rounded-full animate-pulse" />
            <div className="space-y-1">
              <Skeleton className="h-4 w-32 animate-pulse" />
              <Skeleton className="h-3 w-24 animate-pulse" />
            </div>
          </div>
          <Skeleton className="h-16 w-full animate-pulse" />
          <Skeleton className="h-4 w-40 animate-pulse" />
        </div>
      ))}
    </div>
  </div>
);

// Rating Progress Bar
const RatingBar = ({ rating, count, total }: { rating: number; count: number; total: number }) => {
  const percentage = total > 0 ? (count / total) * 100 : 0;
  return (
    <div className="flex items-center gap-3">
      <span className="text-sm text-muted-foreground w-3">{rating}</span>
      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
        <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: `${percentage}%` }} />
      </div>
    </div>
  );
};

// Star Rating Input
const StarRatingInput = ({ rating, onRatingChange }: { rating: number; onRatingChange: (r: number) => void }) => {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          className="p-1 transition-transform hover:scale-110"
          onMouseEnter={() => setHover(star)}
          onMouseLeave={() => setHover(0)}
          onClick={() => onRatingChange(star)}
        >
          <Star className={`w-8 h-8 transition-colors ${star <= (hover || rating) ? 'fill-primary text-primary' : 'text-muted-foreground'}`} />
        </button>
      ))}
    </div>
  );
};

// Review Images Display - No lightbox, just inline images
const ReviewImages = ({ images }: { images: string[] }) => {
  if (!images || images.length === 0) return null;

  return (
    <div className="flex gap-2 flex-wrap mt-3">
      {images.slice(0, 2).map((url, index) => (
        <img
          key={index}
          src={url}
          alt={`Review image ${index + 1}`}
          className="w-24 h-24 rounded-lg object-cover"
        />
      ))}
    </div>
  );
};

const SellerReviews: React.FC<SellerReviewsProps> = ({ sellerId, sellerUserId }) => {
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [newRating, setNewRating] = useState(0);
  const [newComment, setNewComment] = useState('');
  const [selectedImages, setSelectedImages] = useState<File[]>([]);
  const [imagePreviewUrls, setImagePreviewUrls] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: currentUser } = useQuery({
    queryKey: ['current-user'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      return user;
    },
  });

  // Fetch user's helpful votes
  const { data: userHelpfulVotes = [] } = useQuery({
    queryKey: ['user-helpful-votes', currentUser?.id],
    queryFn: async () => {
      if (!currentUser?.id) return [];
      const { data, error } = await supabase
        .from('review_helpful_votes')
        .select('review_id')
        .eq('user_id', currentUser.id);
      if (error) throw error;
      return data.map(v => v.review_id);
    },
    enabled: !!currentUser?.id,
  });

  const { data: reviews = [], isLoading, refetch } = useQuery({
    queryKey: ['seller-reviews-detailed', sellerUserId],
    queryFn: async () => {
      const { data: reviewsData, error } = await supabase
        .from('reviews')
        .select('*')
        .eq('reviewed_user_id', sellerUserId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      const reviewerIds = reviewsData?.map(r => r.reviewer_id) || [];
      const { data: sellerProfiles } = await supabase
        .from('seller_profiles')
        .select('user_id, business_name, business_logo_url')
        .in('user_id', reviewerIds);
      
      const profileMap = new Map(
        sellerProfiles?.map(p => [p.user_id, { full_name: p.business_name, avatar_url: p.business_logo_url }]) || []
      );

      // Fall back to public auth profiles for reviewers without a seller account
      const missingIds = [...new Set(reviewerIds)].filter(id => !profileMap.has(id));
      if (missingIds.length > 0) {
        const { data: publicProfiles } = await supabase.rpc('get_public_user_profiles', {
          p_user_ids: missingIds,
        });
        publicProfiles?.forEach((p: any) => {
          profileMap.set(p.user_id, { full_name: p.display_name, avatar_url: p.avatar_url });
        });
      }

      return (reviewsData || []).map(review => ({
        ...review,
        helpful_count: review.helpful_count || 0,
        review_images: review.review_images || [],
        reviewer: profileMap.get(review.reviewer_id) || { full_name: null, avatar_url: null },
      })) as Review[];
    },
    enabled: !!sellerUserId,
  });

  // Mutation for helpful votes
  const helpfulMutation = useMutation({
    mutationFn: async ({ reviewId, action }: { reviewId: string; action: 'add' | 'remove' }) => {
      if (!currentUser?.id) throw new Error('Not authenticated');

      if (action === 'add') {
        // Add vote
        const { error: voteError } = await supabase
          .from('review_helpful_votes')
          .insert({ review_id: reviewId, user_id: currentUser.id });
        if (voteError) throw voteError;

        // Increment count
        const review = reviews.find(r => r.id === reviewId);
        const newCount = (review?.helpful_count || 0) + 1;
        const { error: updateError } = await supabase
          .from('reviews')
          .update({ helpful_count: newCount })
          .eq('id', reviewId);
        if (updateError) throw updateError;
      } else {
        // Remove vote
        const { error: voteError } = await supabase
          .from('review_helpful_votes')
          .delete()
          .eq('review_id', reviewId)
          .eq('user_id', currentUser.id);
        if (voteError) throw voteError;

        // Decrement count
        const review = reviews.find(r => r.id === reviewId);
        const newCount = Math.max(0, (review?.helpful_count || 0) - 1);
        const { error: updateError } = await supabase
          .from('reviews')
          .update({ helpful_count: newCount })
          .eq('id', reviewId);
        if (updateError) throw updateError;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['seller-reviews-detailed', sellerUserId] });
      queryClient.invalidateQueries({ queryKey: ['user-helpful-votes', currentUser?.id] });
    },
    onError: (error) => {
      console.error('Error updating helpful vote:', error);
      toast.error('Failed to update vote');
    },
  });

  const handleHelpful = (reviewId: string) => {
    if (!currentUser) {
      toast.error('Please sign in to vote');
      return;
    }

    const hasVoted = userHelpfulVotes.includes(reviewId);
    helpfulMutation.mutate({ reviewId, action: hasVoted ? 'remove' : 'add' });
    toast.success(hasVoted ? 'Vote removed' : 'Marked as helpful');
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    // Max 2 images
    if (files.length + selectedImages.length > 2) {
      toast.error('Maximum 2 images allowed');
      return;
    }

    const validFiles = files.filter(file => {
      if (!file.type.startsWith('image/')) {
        toast.error(`${file.name} is not an image`);
        return false;
      }
      if (file.size > 5 * 1024 * 1024) {
        toast.error(`${file.name} is too large (max 5MB)`);
        return false;
      }
      return true;
    });

    setSelectedImages(prev => [...prev, ...validFiles].slice(0, 2));
    
    // Create preview URLs
    validFiles.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreviewUrls(prev => [...prev, reader.result as string].slice(0, 2));
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
    setImagePreviewUrls(prev => prev.filter((_, i) => i !== index));
  };

  const uploadImages = async (): Promise<string[]> => {
    if (selectedImages.length === 0) return [];

    const uploadedUrls: string[] = [];
    for (const file of selectedImages) {
      const fileExt = file.name.split('.').pop();
      const fileName = `${currentUser?.id}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
      const filePath = `review-images/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('product-images')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('product-images')
        .getPublicUrl(filePath);

      uploadedUrls.push(publicUrl);
    }
    return uploadedUrls;
  };

  const handleSubmitReview = async () => {
    if (!currentUser) {
      toast.error('Please sign in to leave a review');
      return;
    }
    if (newRating === 0) {
      toast.error('Please select a rating');
      return;
    }
    if (currentUser.id === sellerUserId) {
      toast.error('You cannot review yourself');
      return;
    }

    setIsSubmitting(true);
    try {
      // Upload images first
      const imageUrls = await uploadImages();

      const { data: reviewData, error } = await supabase.from('reviews').insert({
        reviewer_id: currentUser.id,
        reviewed_user_id: sellerUserId,
        rating: newRating,
        comment: newComment.trim() || null,
        is_verified: true,
        review_images: imageUrls,
        helpful_count: 0,
      }).select('id').single();

      if (error) {
        if (error.code === '23505') {
          toast.error('You have already reviewed this seller');
        } else {
          throw error;
        }
      } else {
        // Note: Notification is now created automatically via database trigger (notify_new_review)
        // The trigger uses 'review_received' notification_type for consistency

        toast.success('Review submitted successfully!');
        setNewRating(0);
        setNewComment('');
        setSelectedImages([]);
        setImagePreviewUrls([]);
        refetch();
      }
    } catch (error) {
      console.error('Error submitting review:', error);
      toast.error('Failed to submit review');
    } finally {
      setIsSubmitting(false);
    }
  };

  const totalReviews = reviews.length;
  const averageRating = totalReviews > 0 ? reviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews : 0;
  const ratingCounts = [5, 4, 3, 2, 1].map(rating => ({ rating, count: reviews.filter(r => r.rating === rating).length }));

  if (isLoading) return <ReviewsSkeleton />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Ratings and reviews</h3>
        <Button variant="ghost" size="icon" className="rounded-full">
          <ChevronRight className="w-5 h-5" />
        </Button>
      </div>

      <p className="text-xs text-muted-foreground">
        Ratings and reviews are verified and are from people who have purchased from this seller ⓘ
      </p>

      {/* Rating Summary */}
      <div className="flex gap-8">
        <div className="text-center min-w-[80px]">
          <div className="text-5xl font-light text-foreground mb-1">{averageRating.toFixed(1)}</div>
          <div className="flex justify-center mb-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star key={star} className={`w-3 h-3 ${star <= Math.round(averageRating) ? 'fill-primary text-primary' : 'text-muted-foreground'}`} />
            ))}
          </div>
          <p className="text-xs text-muted-foreground">{totalReviews.toLocaleString()}</p>
        </div>
        <div className="flex-1 space-y-1.5">
          {ratingCounts.map(({ rating, count }) => (
            <RatingBar key={rating} rating={rating} count={count} total={totalReviews} />
          ))}
        </div>
      </div>

      {/* Rate This Seller */}
      <div className="pt-6 border-t border-border">
        <h4 className="text-sm font-medium mb-1">Rate this seller</h4>
        <p className="text-xs text-muted-foreground mb-3">Tell others what you think</p>
        <StarRatingInput rating={newRating} onRatingChange={setNewRating} />
        
        {newRating > 0 && (
          <div className="mt-4 space-y-3 animate-in slide-in-from-top-2 duration-200">
            <button onClick={() => document.getElementById('review-textarea')?.focus()} className="text-sm text-primary hover:underline">
              Write a review
            </button>
            <Textarea
              id="review-textarea"
              placeholder="Describe your experience (optional)"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="min-h-[100px] bg-background border-border resize-none"
              maxLength={500}
            />

            {/* Image Upload - Max 2 */}
            <div className="space-y-2">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handleImageSelect}
                className="hidden"
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                disabled={selectedImages.length >= 2}
                className="gap-2"
              >
                <ImagePlus className="w-4 h-4" />
                Add Photos ({selectedImages.length}/2)
              </Button>

              {imagePreviewUrls.length > 0 && (
                <div className="flex gap-2 flex-wrap">
                  {imagePreviewUrls.map((url, index) => (
                    <div key={index} className="relative group">
                      <img
                        src={url}
                        alt={`Preview ${index + 1}`}
                        className="w-20 h-20 object-cover rounded-lg border border-border"
                      />
                      <button
                        onClick={() => removeImage(index)}
                        className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">{newComment.length}/500</span>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" onClick={() => { setNewRating(0); setNewComment(''); setSelectedImages([]); setImagePreviewUrls([]); }}>Cancel</Button>
                <Button size="sm" onClick={handleSubmitReview} disabled={isSubmitting || newRating === 0}>
                  {isSubmitting ? 'Submitting...' : 'Submit'}
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Reviews List */}
      <div className="space-y-6 pt-6 border-t border-border">
        {reviews.length > 0 ? (
          reviews.map((review) => {
            const hasVoted = userHelpfulVotes.includes(review.id);
            return (
              <div key={review.id} className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={review.reviewer?.avatar_url || ''} />
                      <AvatarFallback className="bg-muted text-muted-foreground">
                        {(review.reviewer?.full_name || 'U').charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="font-medium text-sm">{review.reviewer?.full_name || 'EarlyMarket user'}</span>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => toast.info('Report submitted')}>Report review</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className={`w-3.5 h-3.5 ${star <= review.rating ? 'fill-primary text-primary' : 'text-muted-foreground'}`} />
                    ))}
                  </div>
                  <span className="text-xs text-muted-foreground">{format(new Date(review.created_at), 'dd/MM/yyyy')}</span>
                </div>

                {review.comment && <p className="text-sm text-foreground leading-relaxed">{review.comment}</p>}

                {/* Review Images - No lightbox */}
                <ReviewImages images={review.review_images} />

                {/* Helpful section - small icons, no card */}
                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={() => handleHelpful(review.id)}
                    disabled={helpfulMutation.isPending}
                    className={`flex items-center gap-1 text-xs transition-colors ${hasVoted ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`}
                  >
                    <ThumbsUp className={`w-3.5 h-3.5 ${hasVoted ? 'fill-primary' : ''}`} />
                  </button>
                  <button
                    className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
                    onClick={() => toast.info('Thanks for your feedback')}
                  >
                    <ThumbsDown className="w-3.5 h-3.5" />
                  </button>
                  {review.helpful_count > 0 && (
                    <span className="text-xs text-muted-foreground">
                      {review.helpful_count} {review.helpful_count === 1 ? 'person' : 'people'} found this helpful
                    </span>
                  )}
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-8">
            <Star className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No reviews yet</p>
            <p className="text-sm text-muted-foreground mt-1">Be the first to review this seller</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SellerReviews;
