import React, { useState, useEffect, useRef } from 'react';
import { Search, MoreHorizontal, Flag, Ban, Share2, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import SmartVideo from '@/components/media/SmartVideo';

interface ProfileCoverHeaderProps {
  coverImage?: string | null;
  videoUrl?: string | null;
  businessName: string;
  onBack: () => void;
  onShare: () => void;
  onReport: () => void;
  onBlock?: () => void;
  onSearch?: () => void;
}

const ProfileCoverHeader: React.FC<ProfileCoverHeaderProps> = ({
  coverImage,
  videoUrl,
  businessName,
  onBack,
  onShare,
  onReport,
  onBlock,
  onSearch,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const headerRef = useRef<HTMLDivElement>(null);
  const lastYRef = useRef(0);

  useEffect(() => {
    const SHOW_AT = 120;
    const HIDE_NEAR_TOP = 80;
    const DEADBAND = 6;

    const onScroll = (scrollY: number) => {
      const threshold = 200;
      setScrollProgress(Math.min(scrollY / threshold, 1));

      const delta = scrollY - lastYRef.current;
      if (Math.abs(delta) < DEADBAND) return;
      const direction: 'up' | 'down' = delta > 0 ? 'down' : 'up';
      lastYRef.current = scrollY;

      if (scrollY < HIDE_NEAR_TOP) {
        setIsScrolled(false);
      } else if (direction === 'down' && scrollY > SHOW_AT) {
        setIsScrolled(true);
      } else if (direction === 'up') {
        setIsScrolled(false);
      }
    };

    const viewport = document.querySelector('[data-radix-scroll-area-viewport]') as HTMLElement;
    if (viewport) {
      const handler = () => onScroll(viewport.scrollTop);
      viewport.addEventListener('scroll', handler, { passive: true });
      return () => viewport.removeEventListener('scroll', handler);
    } else {
      const handler = () => onScroll(window.scrollY);
      window.addEventListener('scroll', handler, { passive: true });
      return () => window.removeEventListener('scroll', handler);
    }
  }, []);

  const hasMedia = coverImage || videoUrl;

  return (
    <>
      {/* Cover Image/Video Section */}
      <div 
        ref={headerRef}
        className="relative w-full h-[200px] bg-gradient-to-br from-primary/20 to-primary/5 overflow-hidden"
      >
        {videoUrl ? (
          <SmartVideo
            src={videoUrl}
            autoPlayInView
            muted
            loop
            playsInline
            className="absolute inset-0 w-full h-full object-cover"
          />
        ) : coverImage ? (
          <img
            src={coverImage}
            alt="Cover"
            className="absolute inset-0 w-full h-full object-cover"
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-primary/20 to-background" />
        )}
        
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>

      {/* Sticky Navigation Bar - appears on scroll */}
      <div
        className={cn(
          "fixed top-0 left-0 right-0 z-[55] transition-all duration-300 ease-out lg:left-[280px] lg:right-[340px]",
          isScrolled 
            ? "opacity-100 translate-y-0" 
            : "opacity-0 -translate-y-full pointer-events-none"
        )}
        
      >
        {/* Background with dynamic blur */}
        <div 
          className="absolute inset-0 transition-all duration-300"
          style={{
            backgroundImage: hasMedia 
              ? `url(${videoUrl || coverImage})` 
              : 'none',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: `blur(${20 * scrollProgress}px)`,
          }}
        />
        <div className="absolute inset-0 bg-background/80 backdrop-blur-xl" />
        
        {/* Navigation Content */}
        <div className="relative flex items-center justify-between px-4 py-3 border-b border-border/50">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onBack}
              className="rounded-full h-9 w-9"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <span className="font-semibold text-foreground truncate max-w-[200px]">
              {businessName}
            </span>
          </div>
          
          <div className="flex items-center gap-1">
            {onSearch && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={onSearch}
                className="rounded-full h-9 w-9"
              >
                <Search className="w-5 h-5" />
              </Button>
            )}
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full h-9 w-9">
                  <MoreHorizontal className="w-5 h-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48 bg-background">
                <DropdownMenuItem onClick={onShare}>
                  <Share2 className="w-4 h-4 mr-2" />
                  Share Profile
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onReport} className="text-destructive">
                  <Flag className="w-4 h-4 mr-2" />
                  Report
                </DropdownMenuItem>
                {onBlock && (
                  <DropdownMenuItem onClick={onBlock} className="text-destructive">
                    <Ban className="w-4 h-4 mr-2" />
                    Block
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Initial Top Bar (visible before scroll) */}
      <div
        className={cn(
          "absolute top-0 left-0 right-0 z-10 transition-opacity duration-300",
          isScrolled ? "opacity-0 pointer-events-none" : "opacity-100"
        )}
        style={{ top: 0 }}
      >
        <div className="flex items-center justify-between px-4 py-3">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onBack}
            className="rounded-full h-9 w-9 bg-background/30 backdrop-blur-sm hover:bg-background/50"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          
          <div className="flex items-center gap-2">
            {onSearch && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={onSearch}
                className="rounded-full h-9 w-9 bg-background/30 backdrop-blur-sm hover:bg-background/50"
              >
                <Search className="w-5 h-5" />
              </Button>
            )}
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="rounded-full h-9 w-9 bg-background/30 backdrop-blur-sm hover:bg-background/50"
                >
                  <MoreHorizontal className="w-5 h-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48 bg-background">
                <DropdownMenuItem onClick={onShare}>
                  <Share2 className="w-4 h-4 mr-2" />
                  Share Profile
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onReport} className="text-destructive">
                  <Flag className="w-4 h-4 mr-2" />
                  Report
                </DropdownMenuItem>
                {onBlock && (
                  <DropdownMenuItem onClick={onBlock} className="text-destructive">
                    <Ban className="w-4 h-4 mr-2" />
                    Block
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProfileCoverHeader;
