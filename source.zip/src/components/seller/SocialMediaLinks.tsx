import React from 'react';
import { Globe } from 'lucide-react';
import facebookIcon from '@/assets/social-icons/facebook.svg';
import instagramIcon from '@/assets/social-icons/instagram.svg';
import xIcon from '@/assets/social-icons/x.svg';
import linkedinIcon from '@/assets/social-icons/linkedin.svg';
import youtubeIcon from '@/assets/social-icons/youtube.svg';
import tiktokIcon from '@/assets/social-icons/tiktok.svg';
import whatsappIcon from '@/assets/social-icons/whatsapp.svg';

interface SocialMediaLinksProps {
  facebookUrl?: string | null;
  instagramUrl?: string | null;
  twitterUrl?: string | null;
  linkedinUrl?: string | null;
  youtubeUrl?: string | null;
  tiktokUsername?: string | null;
  whatsappNumber?: string | null;
  websiteUrl?: string | null;
}

const SocialMediaLinks: React.FC<SocialMediaLinksProps> = ({
  facebookUrl,
  instagramUrl,
  twitterUrl,
  linkedinUrl,
  youtubeUrl,
  tiktokUsername,
  whatsappNumber,
  websiteUrl,
}) => {
  const socialLinks = [
    { 
      url: facebookUrl, 
      icon: facebookIcon, 
      label: 'Facebook',
      color: '#1877F2'
    },
    { 
      url: instagramUrl, 
      icon: instagramIcon, 
      label: 'Instagram',
      color: '#E4405F'
    },
    { 
      url: twitterUrl, 
      icon: xIcon, 
      label: 'X (Twitter)',
      color: '#000000'
    },
    { 
      url: linkedinUrl, 
      icon: linkedinIcon, 
      label: 'LinkedIn',
      color: '#0A66C2'
    },
    { 
      url: youtubeUrl, 
      icon: youtubeIcon, 
      label: 'YouTube',
      color: '#FF0000'
    },
    { 
      url: tiktokUsername ? `https://tiktok.com/@${tiktokUsername.replace('@', '')}` : null, 
      icon: tiktokIcon, 
      label: 'TikTok',
      color: '#000000'
    },
    { 
      url: whatsappNumber ? `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}` : null, 
      icon: whatsappIcon, 
      label: 'WhatsApp',
      color: '#25D366'
    },
  ].filter(link => link.url);

  // Add website as a special case with Lucide icon
  const hasWebsite = websiteUrl && websiteUrl.trim();

  if (socialLinks.length === 0 && !hasWebsite) return null;

  return (
    <div className="flex flex-wrap gap-2">
      {socialLinks.map((social) => (
        <a
          key={social.label}
          href={social.url!}
          target="_blank"
          rel="noopener noreferrer"
          className="group relative flex items-center justify-center w-8 h-8 rounded-full bg-muted hover:bg-muted/80 transition-all duration-300 hover:scale-110"
          title={social.label}
        >
          <img
            src={social.icon}
            alt={social.label}
            className="w-4 h-4 transition-transform group-hover:scale-110"
            style={{ 
              filter: 'brightness(0) saturate(100%)',
            }}
          />
          <div 
            className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-20 transition-opacity"
            style={{ backgroundColor: social.color }}
          />
        </a>
      ))}
      {hasWebsite && (
        <a
          href={websiteUrl!}
          target="_blank"
          rel="noopener noreferrer"
          className="group relative flex items-center justify-center w-8 h-8 rounded-full bg-muted hover:bg-muted/80 transition-all duration-300 hover:scale-110"
          title="Website"
        >
          <Globe className="w-4 h-4 text-foreground" />
          <div 
            className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-20 transition-opacity bg-primary"
          />
        </a>
      )}
    </div>
  );
};

export default SocialMediaLinks;
