import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Crosshair, Loader2, Info } from 'lucide-react';
import { Map, MapControls, MapMarker, MarkerContent, useMap } from '@/components/ui/map';

import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface BusinessLocationMapProps {
  /** Text query built from district / sub-county for the default centre. */
  query: string;
  /** Optional legacy pasted Google Maps link (kept for URL fallback). */
  pastedUrl: string;
  onPastedUrlChange: (url: string) => void;
}

/**
 * Parse latitude/longitude out of a pasted Google Maps URL.
 * Kept exported for backwards compatibility with the wizard submit code.
 */
export function parseLatLngFromMapsUrl(url: string): { lat: number; lng: number } | null {
  if (!url) return null;
  const at = url.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
  if (at) return { lat: parseFloat(at[1]), lng: parseFloat(at[2]) };
  const q = url.match(/[?&]q=(-?\d+\.\d+),(-?\d+\.\d+)/);
  if (q) return { lat: parseFloat(q[1]), lng: parseFloat(q[2]) };
  const bang = url.match(/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/);
  if (bang) return { lat: parseFloat(bang[1]), lng: parseFloat(bang[2]) };
  // Our own encoded form: em:lat,lng
  const em = url.match(/^em:(-?\d+\.\d+),(-?\d+\.\d+)/);
  if (em) return { lat: parseFloat(em[1]), lng: parseFloat(em[2]) };
  return null;
}

// Rough centres for major Ugandan districts to seed the map before the user
// grants geolocation. Not exhaustive — falls back to Kampala.
const DISTRICT_CENTRES: Record<string, [number, number]> = {
  kampala: [32.5825, 0.3476],
  wakiso: [32.4776, 0.4044],
  mukono: [32.7554, 0.3533],
  jinja: [33.2041, 0.4244],
  entebbe: [32.4636, 0.0512],
  gulu: [32.2881, 2.7746],
  mbarara: [30.6549, -0.6072],
  mbale: [34.1750, 1.0644],
  masaka: [31.7361, -0.3436],
  lira: [32.9019, 2.2350],
  arua: [30.9105, 3.0201],
  fortportal: [30.2748, 0.6710],
};

function seedCenter(query: string): [number, number] {
  const q = (query || '').toLowerCase().replace(/\s+/g, '');
  for (const [key, coords] of Object.entries(DISTRICT_CENTRES)) {
    if (q.includes(key)) return coords;
  }
  return DISTRICT_CENTRES.kampala;
}

/** Invisible child that listens for map clicks and reports lng/lat. */
const MapClickHandler: React.FC<{ onPick: (lng: number, lat: number) => void }> = ({ onPick }) => {
  const { map } = useMap();
  useEffect(() => {
    if (!map) return;
    const handler = (e: any) => onPick(e.lngLat.lng, e.lngLat.lat);
    map.on('click', handler);
    // Show grab cursor as a hint
    const canvas = map.getCanvas();
    if (canvas) canvas.style.cursor = 'crosshair';
    return () => {
      map.off('click', handler);
      if (canvas) canvas.style.cursor = '';
    };
  }, [map, onPick]);
  return null;
};

const BusinessLocationMap: React.FC<BusinessLocationMapProps> = ({

  query,
  pastedUrl,
  onPastedUrlChange,
}) => {
  // Initial coords: pastedUrl (legacy) → district centre → Kampala.
  const initial = useMemo(() => parseLatLngFromMapsUrl(pastedUrl), []); // eslint-disable-line react-hooks/exhaustive-deps
  const [marker, setMarker] = useState<{ lat: number; lng: number } | null>(
    initial ?? null,
  );
  const [locating, setLocating] = useState(false);

  const center: [number, number] = marker
    ? [marker.lng, marker.lat]
    : seedCenter(query);

  // Push the marker back into formData as an `em:` encoded string so the
  // existing parseLatLngFromMapsUrl on submit still picks it up.
  useEffect(() => {
    if (marker) onPastedUrlChange(`em:${marker.lat},${marker.lng}`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [marker?.lat, marker?.lng]);

  const useCurrentLocation = () => {
    if (!('geolocation' in navigator)) {
      toast.error('Your browser does not support location.');
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setMarker({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocating(false);
        toast.success('Pinned your current location. Drag the marker to fine-tune.');
      },
      (err) => {
        setLocating(false);
        toast.error(err.message || 'Could not get your location.');
      },
      { enableHighAccuracy: true, timeout: 10000 },
    );
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4" />
          <span>Pin your exact business location</span>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={useCurrentLocation}
          disabled={locating}
          className="h-8"
        >
          {locating ? (
            <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />
          ) : (
            <Crosshair className="h-3.5 w-3.5 mr-1.5" />
          )}
          Use current location
        </Button>
      </div>

      <motion.div
        initial={{ opacity: 0.6 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="relative w-full overflow-hidden rounded-2xl border border-border"
        style={{ aspectRatio: '16 / 9' }}
      >
        <Map center={center} zoom={marker ? 15 : 12}>
          <MapControls position="top-right" showZoom showLocate />
          {/* Tap anywhere on the map to drop / move the pin */}
          <MapClickHandler onPick={(lng, lat) => setMarker({ lat, lng })} />
          {marker && (
            <MapMarker
              longitude={marker.lng}
              latitude={marker.lat}
              draggable
              onDragEnd={({ lng, lat }) => setMarker({ lat, lng })}
            >
              <MarkerContent>
                <div
                  aria-label="Business location marker"
                  className="h-7 w-7 rounded-full bg-primary border-[3px] border-background shadow-lg cursor-grab active:cursor-grabbing"
                />
              </MarkerContent>
            </MapMarker>
          )}
        </Map>

      </motion.div>

      <div className="flex items-start gap-2 text-xs text-muted-foreground">
        <Info className="h-3.5 w-3.5 mt-0.5 flex-shrink-0" />
        <span>
          {marker
            ? 'Drag the pin — or tap anywhere on the map — to fine-tune your exact spot.'
            : 'Tap “Use current location”, or tap anywhere on the map to drop a pin.'}

        </span>
      </div>
    </div>
  );
};

export default BusinessLocationMap;
