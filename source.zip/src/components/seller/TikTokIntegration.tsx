
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Video, ExternalLink, X, Check, AlertCircle, User } from 'lucide-react';
import { toast } from 'sonner';

interface TikTokIntegrationProps {
  tiktokUsername: string;
  tiktokVideoUrl: string;
  onTikTokChange: (field: string, value: string) => void;
}

interface TikTokProfile {
  username: string;
  displayName: string;
  avatar: string;
  verified: boolean;
  followerCount: string;
}

const TikTokIntegration: React.FC<TikTokIntegrationProps> = ({
  tiktokUsername,
  tiktokVideoUrl,
  onTikTokChange
}) => {
  const [showTikTokForm, setShowTikTokForm] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [profileData, setProfileData] = useState<TikTokProfile | null>(null);
  const [validationError, setValidationError] = useState<string>('');

  const validateTikTokUsername = (username: string): boolean => {
    const tiktokUsernameRegex = /^[a-zA-Z0-9_.]{1,24}$/;
    return tiktokUsernameRegex.test(username);
  };

  const validateTikTokUrl = (url: string): boolean => {
    const tiktokUrlRegex = /^https:\/\/(www\.)?tiktok\.com\/@[\w.-]+\/video\/\d+/;
    return tiktokUrlRegex.test(url);
  };

  const extractTikTokId = (url: string): string => {
    const match = url.match(/video\/(\d+)/);
    return match ? match[1] : '';
  };

  const extractUsernameFromUrl = (url: string): string => {
    const match = url.match(/@([\w.-]+)\/video/);
    return match ? match[1] : '';
  };

  // Mock TikTok profile validation (in a real app, you'd use TikTok's API)
  const validateTikTokProfile = async (username: string): Promise<TikTokProfile | null> => {
    if (!username || !validateTikTokUsername(username)) {
      return null;
    }

    setIsValidating(true);
    setValidationError('');

    try {
      // Simulate API call - in real implementation, you'd call TikTok's API
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock profile data - replace with actual API call
      const mockProfile: TikTokProfile = {
        username,
        displayName: `${username.charAt(0).toUpperCase()}${username.slice(1)}`,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
        verified: Math.random() > 0.7, // Random verification status
        followerCount: `${Math.floor(Math.random() * 1000)}K`
      };

      setProfileData(mockProfile);
      return mockProfile;
    } catch (error) {
      setValidationError('Unable to verify TikTok profile. Please check the username.');
      return null;
    } finally {
      setIsValidating(false);
    }
  };

  const handleUsernameChange = async (value: string) => {
    const cleanValue = value.replace('@', '').trim();
    onTikTokChange('tiktok_username', cleanValue);
    
    if (cleanValue && validateTikTokUsername(cleanValue)) {
      await validateTikTokProfile(cleanValue);
    } else {
      setProfileData(null);
      setValidationError('');
    }
  };

  const handleVideoUrlChange = (value: string) => {
    onTikTokChange('tiktok_video_url', value);
    
    // Auto-extract username from video URL if username is empty
    if (value && !tiktokUsername) {
      const extractedUsername = extractUsernameFromUrl(value);
      if (extractedUsername) {
        onTikTokChange('tiktok_username', extractedUsername);
        validateTikTokProfile(extractedUsername);
      }
    }
  };

  const renderTikTokEmbed = () => {
    if (!tiktokVideoUrl || !validateTikTokUrl(tiktokVideoUrl)) {
      return null;
    }

    const videoId = extractTikTokId(tiktokVideoUrl);
    
    return (
      <div className="mt-4 p-4 bg-gray-50 rounded-lg">
        <h4 className="font-semibold mb-2 flex items-center gap-2">
          <Video className="w-4 h-4" />
          Featured Video Preview
        </h4>
        <div className="aspect-[9/16] max-w-[300px] mx-auto bg-black rounded-lg flex items-center justify-center">
          <div className="text-white text-center">
            <Video className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p className="text-sm opacity-75">TikTok Video</p>
            <p className="text-xs opacity-50">ID: {videoId}</p>
          </div>
        </div>
        <div className="mt-2 text-center">
          <a
            href={tiktokVideoUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-blue-600 hover:text-blue-800 flex items-center justify-center gap-1"
          >
            View on TikTok <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    );
  };

  return (
    <Card className="border-dashed border-2 border-gray-200 opacity-60 cursor-not-allowed">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Video className="w-5 h-5 text-muted-foreground" />
          TikTok Integration
          <Badge variant="outline" className="ml-2 bg-amber-100 text-amber-800 border-amber-300">
            Coming Soon
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-center space-y-4">
          <div className="bg-muted rounded-lg p-6">
            <Video className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground mb-4">
              Connect your TikTok to showcase your products and build trust with customers
            </p>
            <ul className="text-sm text-muted-foreground space-y-1 mb-4">
              <li>• Display your latest videos on your store page</li>
              <li>• Increase customer engagement</li>
              <li>• Build brand authenticity</li>
            </ul>
          </div>
          <Button 
            variant="outline"
            className="w-full"
            disabled
          >
            <Video className="w-4 h-4 mr-2" />
            Connect TikTok Account
          </Button>
          <p className="text-xs text-muted-foreground">
            This feature is currently under development and will be available soon.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default TikTokIntegration;
