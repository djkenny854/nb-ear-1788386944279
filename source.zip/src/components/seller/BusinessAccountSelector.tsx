import React, { useState } from 'react';
import { Check, Cloud, AtSign, Video, Calendar, FileSignature, Crown, Sparkles, Wifi, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { useFeatureToggle } from '@/hooks/useFeatureToggle';
import { toast } from 'sonner';
import EMIIcon from '@/components/icons/EMIIcon';

type AccountType = 'regular' | 'business' | 'organization';

interface BusinessAccountSelectorProps {
  onSelect: (type: AccountType) => void;
}

interface BenefitItem {
  icon: React.ReactNode;
  text: string;
  highlight?: string;
}

interface AIFeature {
  icon: React.ReactNode;
  text: string;
  highlight?: string;
}

const accountBenefits: Record<AccountType, { features: BenefitItem[]; aiFeatures: AIFeature[] }> = {
  regular: {
    features: [
      { icon: <Cloud className="w-4 h-4 text-muted-foreground" />, text: 'Up to 5 active listings' },
      { icon: <AtSign className="w-4 h-4 text-muted-foreground" />, text: 'Basic profile page' },
      { icon: <Video className="w-4 h-4 text-muted-foreground" />, text: 'Direct messaging with buyers' },
      { icon: <Calendar className="w-4 h-4 text-muted-foreground" />, text: 'Listings expire after 30 days' },
    ],
    aiFeatures: [
      { icon: <Sparkles className="w-4 h-4 text-primary" />, text: 'Basic AI-powered listing suggestions' },
    ]
  },
  business: {
    features: [
      { icon: <Cloud className="w-4 h-4 text-muted-foreground" />, text: 'Unlimited product, job & service listings' },
      { icon: <AtSign className="w-4 h-4 text-muted-foreground" />, text: 'Custom store page with unique URL', highlight: '(yourstore.earlymarket.ug)' },
      { icon: <Video className="w-4 h-4 text-muted-foreground" />, text: 'Analytics dashboard & performance insights' },
      { icon: <Calendar className="w-4 h-4 text-muted-foreground" />, text: 'Easier appointment bookings' },
      { icon: <FileSignature className="w-4 h-4 text-muted-foreground" />, text: 'Priority support & verification eligibility' },
      { icon: <Crown className="w-4 h-4 text-muted-foreground" />, text: 'Premium features throughout EarlyMarket' },
    ],
    aiFeatures: [
      { icon: <Sparkles className="w-4 h-4 text-primary" />, text: 'Expanded access to AI models and features' },
      { icon: <EMIIcon className="w-4 h-4" />, text: 'EMI in listings, chat, analytics', highlight: 'and more' },
      { icon: <Wifi className="w-4 h-4 text-primary" />, text: 'Smart recommendations with expanded access' },
    ]
  },
  organization: {
    features: [
      { icon: <Cloud className="w-4 h-4 text-muted-foreground" />, text: 'Everything in Business Account, plus:' },
      { icon: <AtSign className="w-4 h-4 text-muted-foreground" />, text: 'Instant orange verification badge' },
      { icon: <Video className="w-4 h-4 text-muted-foreground" />, text: 'Official organization profile page' },
      { icon: <Calendar className="w-4 h-4 text-muted-foreground" />, text: 'Multiple team members access' },
      { icon: <FileSignature className="w-4 h-4 text-muted-foreground" />, text: 'Event hosting & tender posting' },
      { icon: <Crown className="w-4 h-4 text-muted-foreground" />, text: 'Job posting with application management' },
    ],
    aiFeatures: [
      { icon: <Sparkles className="w-4 h-4 text-primary" />, text: 'Full access to all AI models and features' },
      { icon: <EMIIcon className="w-4 h-4" />, text: 'EMI across all platform features' },
      { icon: <Wifi className="w-4 h-4 text-primary" />, text: 'Advanced analytics powered by AI' },
    ]
  }
};

const accountInfo: Record<AccountType, { name: string; price: string; futurePrice: string; buttonText: string }> = {
  regular: {
    name: 'Regular User',
    price: 'Free',
    futurePrice: '',
    buttonText: 'Continue as Regular User'
  },
  business: {
    name: 'Business Account',
    price: 'Free',
    futurePrice: '$4',
    buttonText: 'Create Business Account'
  },
  organization: {
    name: 'Organization Account',
    price: 'Free',
    futurePrice: '$10',
    buttonText: 'Register Organization'
  }
};

const BusinessAccountSelector: React.FC<BusinessAccountSelectorProps> = ({ onSelect }) => {
  const [selectedType, setSelectedType] = useState<AccountType>('business');
  const [saveAnnually, setSaveAnnually] = useState(false);
  const [receiveUpdates, setReceiveUpdates] = useState(false);
  const { isEnabled: organizationEnabled, isLoading } = useFeatureToggle('organization_onboarding_enabled');

  const handleSelect = () => {
    if (selectedType === 'organization' && !organizationEnabled) {
      toast.error('Organization registration is temporarily unavailable. Please try again later.');
      return;
    }
    onSelect(selectedType);
  };

  const currentBenefits = accountBenefits[selectedType];
  const currentInfo = accountInfo[selectedType];
  const isOrgDisabled = selectedType === 'organization' && !organizationEnabled && !isLoading;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 md:p-8">
      <div className="w-full max-w-4xl">
        <div className="bg-card border border-border rounded-2xl shadow-lg overflow-hidden">
          <div className="grid md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border">
            {/* Left Side - Selection & Pricing */}
            <div className="p-6 md:p-8 space-y-6">
              {/* Account Type Selector */}
              <div className="space-y-4">
                <Select value={selectedType} onValueChange={(value) => setSelectedType(value as AccountType)}>
                  <SelectTrigger className="w-full bg-muted/50 border-border">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                        {selectedType === 'regular' && <span className="text-xs">👤</span>}
                        {selectedType === 'business' && <span className="text-xs">🏢</span>}
                        {selectedType === 'organization' && <span className="text-xs">🏛️</span>}
                      </div>
                      <SelectValue />
                    </div>
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border z-50">
                    <SelectItem value="regular">Regular User</SelectItem>
                    <SelectItem value="business">Business Account</SelectItem>
                    <SelectItem value="organization" disabled={isOrgDisabled}>
                      Organization Account {isOrgDisabled && '(Coming Soon)'}
                    </SelectItem>
                  </SelectContent>
                </Select>

                <h2 className="text-2xl font-semibold text-foreground">
                  Create your {currentInfo.name}
                </h2>
              </div>

              {/* Save Annually Toggle */}
              {selectedType !== 'regular' && (
                <div className="flex items-center gap-3">
                  <Switch
                    checked={saveAnnually}
                    onCheckedChange={setSaveAnnually}
                  />
                  <span className="text-sm text-muted-foreground">Save more on annual</span>
                </div>
              )}

              {/* Discount Badge */}
              {selectedType !== 'regular' && saveAnnually && (
                <div className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-primary/10 text-primary rounded-full text-sm font-medium">
                  <Tag className="w-4 h-4" />
                  10% for 12 months
                </div>
              )}

              {/* Pricing */}
              <div className="space-y-1">
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-primary">{currentInfo.price}</span>
                  {currentInfo.futurePrice && (
                    <span className="text-lg text-muted-foreground line-through">
                      {saveAnnually 
                        ? `${currentInfo.futurePrice}/month` 
                        : `${currentInfo.futurePrice}/month`}
                    </span>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  {selectedType === 'regular' 
                    ? 'Free forever' 
                    : 'Free to create • Premium features coming soon'}
                </p>
              </div>

              {/* Marketing Opt-in */}
              <div className="flex items-start gap-3">
                <Checkbox
                  id="updates"
                  checked={receiveUpdates}
                  onCheckedChange={(checked) => setReceiveUpdates(checked === true)}
                  className="mt-0.5"
                />
                <label htmlFor="updates" className="text-sm text-muted-foreground leading-relaxed cursor-pointer">
                  I'd like to receive feature announcements, tips, offers and opportunities to share feedback
                </label>
              </div>

              {/* CTA Button */}
              <Button
                onClick={handleSelect}
                disabled={isOrgDisabled}
                className="w-full h-12 text-base font-medium"
                size="lg"
              >
                {isOrgDisabled ? 'Temporarily Unavailable' : currentInfo.buttonText}
              </Button>

              {/* Terms */}
              <p className="text-xs text-muted-foreground text-center leading-relaxed">
                Go back to your free account at any time. By continuing, you agree to the{' '}
                <a href="/terms" className="text-primary hover:underline">
                  EarlyMarket Terms of Service
                </a>
              </p>
            </div>

            {/* Right Side - Dynamic Benefits */}
            <div className="p-6 md:p-8 bg-muted/30">
              {/* Premium Features */}
              <div className="space-y-4 mb-8">
                <h3 className="font-semibold text-foreground">
                  {selectedType === 'regular' ? 'Basic features' : 'Premium features'}
                </h3>
                <ul className="space-y-3">
                  {currentBenefits.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-3">
                      {feature.icon}
                      <span className="text-sm text-foreground/80">
                        {feature.text}
                        {feature.highlight && (
                          <span className="text-primary ml-1">{feature.highlight}</span>
                        )}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* AI Features */}
              <div className="space-y-4">
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  <span>EarlyMarket's AI</span>
                  <span className="text-xs px-2 py-0.5 bg-primary/20 text-primary rounded-full font-medium">
                    BETA
                  </span>
                </h3>
                <ul className="space-y-3">
                  {currentBenefits.aiFeatures.map((feature, index) => (
                    <li key={index} className="flex items-start gap-3">
                      {feature.icon}
                      <span className="text-sm text-foreground/80">
                        {feature.text}
                        {feature.highlight && (
                          <span className="text-primary ml-1">{feature.highlight}</span>
                        )}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* EMI Badge */}
              {selectedType !== 'regular' && (
                <div className="mt-6 p-4 bg-card/50 rounded-xl border border-border/50">
                  <div className="flex items-center gap-3">
                    <EMIIcon className="w-8 h-8" />
                    <div>
                      <p className="text-sm font-medium text-foreground">Powered by EMI</p>
                      <p className="text-xs text-muted-foreground">
                        Early Market Intelligence · Smart features to grow your business
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Note */}
        <p className="text-center text-sm text-muted-foreground mt-6">
          You can upgrade or change your account type anytime from settings.
        </p>
      </div>
    </div>
  );
};

export default BusinessAccountSelector;
