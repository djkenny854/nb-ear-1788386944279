import React, { useState } from 'react';
import { Clock, CheckCircle, XCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface DaySchedule {
  open?: string;
  close?: string;
  closed?: boolean;
}

interface WorkingHoursPerDay {
  monday?: DaySchedule;
  tuesday?: DaySchedule;
  wednesday?: DaySchedule;
  thursday?: DaySchedule;
  friday?: DaySchedule;
  saturday?: DaySchedule;
  sunday?: DaySchedule;
}

interface WorkingHoursLegacy {
  days?: string[];
  openTime?: string;
  closeTime?: string;
  is24Hours?: boolean;
  open_time?: string;
  close_time?: string;
  is_24_hours?: boolean;
}

type WorkingHoursData = WorkingHoursPerDay | WorkingHoursLegacy;

interface WorkingHoursProps {
  workingHours?: WorkingHoursData | string | null;
}

const DAYS_ORDER = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
const DAYS_DISPLAY: Record<string, string> = {
  'monday': 'Mon',
  'tuesday': 'Tue',
  'wednesday': 'Wed',
  'thursday': 'Thu',
  'friday': 'Fri',
  'saturday': 'Sat',
  'sunday': 'Sun',
};

const WorkingHours: React.FC<WorkingHoursProps> = ({ workingHours: rawWorkingHours }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  // Parse working hours - handle string JSON or object
  const workingHours: WorkingHoursData | null = React.useMemo(() => {
    if (!rawWorkingHours) return null;
    if (typeof rawWorkingHours === 'string') {
      try {
        return JSON.parse(rawWorkingHours);
      } catch {
        return null;
      }
    }
    return rawWorkingHours as WorkingHoursData;
  }, [rawWorkingHours]);

  // Pre-compute legacy hours (must be before any early returns for hooks rules)
  const legacyHours = workingHours as WorkingHoursLegacy | null;
  const normalizedHours = React.useMemo(() => {
    if (!legacyHours || !legacyHours.days) return null;
    return {
      days: legacyHours.days || [],
      openTime: legacyHours.openTime || legacyHours.open_time || '09:00',
      closeTime: legacyHours.closeTime || legacyHours.close_time || '17:00',
      is24Hours: legacyHours.is24Hours || legacyHours.is_24_hours || false,
    };
  }, [legacyHours]);

  // Check if it's the new per-day format
  const isPerDayFormat = (data: WorkingHoursData | null): data is WorkingHoursPerDay => {
    if (!data) return false;
    return 'monday' in data || 'tuesday' in data || 'wednesday' in data;
  };

  const getCurrentDay = () => {
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    return days[new Date().getDay()];
  };

  const getCurrentTime = () => {
    const now = new Date();
    return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  };

  const formatTime = (time: string) => {
    if (!time) return '';
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours) || 0;
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    return `${hour12}:${minutes || '00'} ${ampm}`;
  };

  // Handle per-day format
  if (isPerDayFormat(workingHours)) {
    const currentDay = getCurrentDay();
    const currentTime = getCurrentTime();
    const todaySchedule = workingHours[currentDay as keyof WorkingHoursPerDay];
    
    const isOpenNow = (): boolean => {
      if (!todaySchedule || todaySchedule.closed) return false;
      if (!todaySchedule.open || !todaySchedule.close) return false;
      return currentTime >= todaySchedule.open && currentTime <= todaySchedule.close;
    };

    const open = isOpenNow();
    const activeDays = DAYS_ORDER.filter(day => {
      const schedule = workingHours[day as keyof WorkingHoursPerDay];
      return schedule && !schedule.closed && schedule.open;
    });

    if (activeDays.length === 0) {
      return (
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-xs font-medium">
            <Clock className="w-3.5 h-3.5 text-muted-foreground" />
            <span>Working Hours</span>
          </div>
          <p className="text-xs text-muted-foreground">Not specified</p>
        </div>
      );
    }

    return (
      <div className="space-y-2">
        <button 
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center justify-between w-full"
        >
          <div className="flex items-center gap-2 text-xs font-medium">
            <Clock className="w-3.5 h-3.5 text-muted-foreground" />
            <span>Working Hours</span>
          </div>
          <div className="flex items-center gap-2">
            <Badge 
              variant={open ? "default" : "secondary"}
              className={`text-[10px] ${open ? "bg-green-500/10 text-green-600 border-green-500/20" : "bg-red-500/10 text-red-600 border-red-500/20"}`}
            >
              {open ? (
                <><CheckCircle className="w-2.5 h-2.5 mr-1" />Open</>
              ) : (
                <><XCircle className="w-2.5 h-2.5 mr-1" />Closed</>
              )}
            </Badge>
            {isExpanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
          </div>
        </button>
        
        {isExpanded && (
          <div className="space-y-2 pt-1">
            {DAYS_ORDER.map((day) => {
              const schedule = workingHours[day as keyof WorkingHoursPerDay];
              const isClosed = !schedule || schedule.closed || !schedule.open;
              const isToday = day === currentDay;
              return (
                <div key={day} className={`flex items-center justify-between text-xs py-1 px-2 rounded ${isToday ? 'bg-primary/10' : ''}`}>
                  <span className={`font-medium ${isToday ? 'text-primary' : 'text-foreground'}`}>{DAYS_DISPLAY[day]}</span>
                  <span className={isClosed ? 'text-muted-foreground' : 'text-foreground'}>
                    {isClosed ? 'Closed' : `${formatTime(schedule!.open!)} - ${formatTime(schedule!.close!)}`}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  // Handle legacy format (use pre-computed normalizedHours from above)
  const isOpenNowLegacy = (): boolean => {
    if (!normalizedHours || !normalizedHours.days || normalizedHours.days.length === 0) return false;
    
    const fullDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const shortDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const dayIndex = new Date().getDay();
    const currentDayFull = fullDays[dayIndex];
    const currentDayShort = shortDays[dayIndex];
    const currentTime = getCurrentTime();
    
    // Match against both full and short day names
    const isDayActive = normalizedHours.days.some(d => 
      d === currentDayFull || d === currentDayShort || d.toLowerCase() === currentDayFull.toLowerCase() || d.toLowerCase() === currentDayShort.toLowerCase()
    );
    if (!isDayActive) return false;
    if (normalizedHours.is24Hours) return true;
    
    return currentTime >= normalizedHours.openTime && currentTime <= normalizedHours.closeTime;
  };

  if (!normalizedHours || !normalizedHours.days || normalizedHours.days.length === 0) {
    return (
      <div className="space-y-3">
        <div className="flex items-center gap-2 text-xs font-medium">
          <Clock className="w-3.5 h-3.5 text-muted-foreground" />
          <span>Working Hours</span>
        </div>
        <p className="text-xs text-muted-foreground">Not specified</p>
      </div>
    );
  }

  const open = isOpenNowLegacy();

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs font-medium">
          <Clock className="w-3.5 h-3.5 text-muted-foreground" />
          <span>Working Hours</span>
        </div>
        <Badge 
          variant={open ? "default" : "secondary"}
          className={`text-[10px] ${open ? "bg-green-500/10 text-green-600 border-green-500/20" : "bg-red-500/10 text-red-600 border-red-500/20"}`}
        >
          {open ? (
            <>
              <CheckCircle className="w-2.5 h-2.5 mr-1" />
              Open
            </>
          ) : (
            <>
              <XCircle className="w-2.5 h-2.5 mr-1" />
              Closed
            </>
          )}
        </Badge>
      </div>
      
      <div className="space-y-1.5">
        {normalizedHours.is24Hours ? (
          <p className="text-xs text-muted-foreground">Open 24 hours</p>
        ) : (
          <p className="text-xs text-muted-foreground">
            {formatTime(normalizedHours.openTime)} - {formatTime(normalizedHours.closeTime)}
          </p>
        )}
        
        <div className="flex flex-wrap gap-1.5 mt-2">
          {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((day) => {
            const shortDay = day.slice(0, 3);
            const isActive = normalizedHours.days.some(d => d === day || d === shortDay || d.toLowerCase() === day.toLowerCase() || d.toLowerCase() === shortDay.toLowerCase());
            const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            const isToday = day === days[new Date().getDay()];
            return (
              <span
                key={day}
                className={`
                  text-[10px] px-1.5 py-0.5 rounded transition-colors
                  ${isActive 
                    ? isToday 
                      ? 'bg-primary text-primary-foreground font-medium' 
                      : 'bg-primary/10 text-primary' 
                    : 'bg-muted text-muted-foreground line-through'
                  }
                `}
              >
                {day.slice(0, 3)}
              </span>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default WorkingHours;