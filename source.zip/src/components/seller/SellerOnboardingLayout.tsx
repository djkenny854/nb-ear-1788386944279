import React from 'react';
import WizardStepSidebar from '@/components/publish/WizardStepSidebar';

interface SellerOnboardingLayoutProps {
  currentStep: number;
  totalSteps: number;
  children: React.ReactNode;
}

const steps = [
  { label: 'Business Identity' },
  { label: 'Location & Contact' },
  { label: 'Profile Branding' },
  { label: 'Operations' },
  { label: 'Terms' },
  { label: 'Review & Submit' },
];

const SellerOnboardingLayout: React.FC<SellerOnboardingLayoutProps> = ({
  currentStep,
  totalSteps,
  children
}) => {
  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <WizardStepSidebar
        steps={steps}
        currentStep={currentStep - 1} // Convert 1-indexed to 0-indexed
        title="Create a Business Account"
      />

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto lg:ml-64">
        <div className="max-w-2xl mx-auto p-4 sm:p-6 md:p-12">
          {children}
        </div>
      </div>
    </div>
  );
};

export default SellerOnboardingLayout;
