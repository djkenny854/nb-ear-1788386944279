
import React, { useRef, useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Play } from 'lucide-react';

interface VideoEmbedProps {
  youtubeUrl?: string;
  tiktokUrl?: string;
  className?: string;
  autoplay?: boolean;
  muted?: boolean;
  onInView?: boolean;
}

const VideoEmbed: React.FC<VideoEmbedProps> = ({ 
  youtubeUrl, 
  tiktokUrl, 
  className = '', 
  autoplay = false, 
  muted = true,
  onInView = true
}) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const getYouTubeEmbedUrl = (url: string) => {
    const videoId = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/)?.[1];
    if (!videoId) return null;
    
    const params = new URLSearchParams({
      controls: '0',
      rel: '0',
      modestbranding: '1',
      showinfo: '0',
      loop: '1',
      playlist: videoId,
      mute: '1',
      iv_load_policy: '3',
      fs: '0',
      disablekb: '1',
      ...(((isPlaying && isVisible) || isHovered) && { autoplay: '1' })
    });
    
    return `https://www.youtube.com/embed/${videoId}?${params.toString()}`;
  };

  const getTikTokEmbedUrl = (url: string) => {
    // Extract TikTok video ID from URL
    const match = url.match(/tiktok\.com\/@[^/]+\/video\/(\d+)/);
    if (!match) return null;
    
    const videoId = match[1];
    return `https://www.tiktok.com/embed/v2/${videoId}`;
  };

  // Intersection Observer for viewport detection
  useEffect(() => {
    if (!onInView) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsVisible(entry.isIntersecting);
        if (entry.isIntersecting && autoplay) {
          setIsPlaying(true);
        }
      },
      { threshold: 0.3 }
    );

    if (iframeRef.current) {
      observer.observe(iframeRef.current);
    }

    return () => observer.disconnect();
  }, [onInView, autoplay]);

  if (!youtubeUrl && !tiktokUrl) {
    return null;
  }

  return (
    <div className={`space-y-4 ${className}`}>
      {youtubeUrl && (
        <Card 
          className="overflow-hidden group"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <div className="relative aspect-video">
            <iframe
              ref={iframeRef}
              src={getYouTubeEmbedUrl(youtubeUrl) || ''}
              title="Product Video"
              className="w-full h-full"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
            {!isPlaying && !isHovered && (
              <div 
                className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/30 transition-all cursor-pointer"
                onClick={() => setIsPlaying(true)}
              >
                <div className="bg-red-600 rounded-full p-4 hover:bg-red-700 transition-colors shadow-lg">
                  <Play className="w-8 h-8 text-white fill-white" />
                </div>
              </div>
            )}
          </div>
        </Card>
      )}
      
      {tiktokUrl && (
        <Card 
          className="overflow-hidden group"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <div className="relative aspect-[9/16] max-w-sm mx-auto">
            {getTikTokEmbedUrl(tiktokUrl) ? (
              <div className="relative w-full h-full">
                <iframe
                  ref={iframeRef}
                  src={getTikTokEmbedUrl(tiktokUrl)}
                  title="TikTok Video"
                  className="w-full h-full rounded-lg"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  scrolling="no"
                  style={{ pointerEvents: 'none' }}
                />
                <div className="absolute inset-0 pointer-events-none" />
              </div>
            ) : (
              <div className="p-4 text-center">
                <p className="text-sm text-gray-600 mb-2">TikTok Video</p>
                <a 
                  href={tiktokUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline inline-flex items-center gap-2"
                >
                  <Play className="w-4 h-4" />
                  View on TikTok
                </a>
              </div>
            )}
          </div>
        </Card>
      )}
    </div>
  );
};

export default VideoEmbed;
