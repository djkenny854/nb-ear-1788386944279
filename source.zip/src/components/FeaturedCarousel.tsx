import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Star, Heart, MessageCircle, User } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import VerificationBadge from './VerificationBadge';
import Autoplay from 'embla-carousel-autoplay';

interface Ad {
  id: string;
  title: string;
  price: number;
  location: string;
  images: string[];
  is_boosted: boolean;
  created_at: string;
  category: string;
  currency?: string;
  seller_id: string;
  seller?: {
    business_name?: string;
    business_logo_url?: string;
    is_verified?: boolean;
    district?: string;
    sub_county?: string;
  };
}

interface FeaturedCarouselProps {
  ads: Ad[];
  onAdClick?: (id: string) => void;
}

const FeaturedCarousel: React.FC<FeaturedCarouselProps> = ({ ads, onAdClick }) => {
  const [isVisible, setIsVisible] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const carouselRef = useRef<HTMLDivElement>(null);
  const carouselId = useRef(Math.random().toString(36).substring(7));
  
  // Generate unique autoplay delay for each carousel instance (7-9 seconds)
  const getUniqueDelay = useCallback(() => {
    const baseDelay = 8000; // 8 seconds base
    const variation = Math.random() * 2000 - 1000; // ±1 second variation
    const uniqueId = parseInt(carouselId.current, 36) % 1000;
    return Math.max(baseDelay + variation + uniqueId, 6000); // Minimum 6 seconds
  }, []);

  // Enhanced viewport visibility detection
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        const wasVisible = isVisible;
        setIsVisible(entry.isIntersecting);
        
        // Log visibility changes for debugging
        if (entry.isIntersecting && !wasVisible) {
          console.log(`FeaturedCarousel ${carouselId.current}: Now visible, starting autoplay`);
        } else if (!entry.isIntersecting && wasVisible) {
          console.log(`FeaturedCarousel ${carouselId.current}: Hidden, stopping autoplay`);
        }
      },
      { 
        threshold: 0.3,
        rootMargin: '50px'
      }
    );

    if (carouselRef.current) {
      observer.observe(carouselRef.current);
    }

    return () => {
      if (carouselRef.current) {
        observer.unobserve(carouselRef.current);
      }
    };
  }, [isVisible]);

  const getCategoryIcon = (category: string) => {
    const icons: { [key: string]: string } = {
      'Cars': '🚗',
      'Electronics': '📱',
      'Fashion': '👔',
      'Home': '🏠',
      'Sports': '⚽',
      'Books': '📚',
    };
    return icons[category] || '📦';
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getDisplayLocation = (ad: Ad) => {
    if (ad.seller?.district && ad.seller?.sub_county) {
      return `${ad.seller.sub_county}, ${ad.seller.district}`;
    }
    if (ad.seller?.district) {
      return ad.seller.district;
    }
    return ad.location || 'Location not specified';
  };

  return (
    <div 
      ref={carouselRef} 
      className="px-4 py-6 bg-white"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Featured Items</h2>
          <Badge className="bg-gradient-to-r from-primary to-orange-600 text-white">
            <Star className="w-3 h-3 mr-1" />
            Featured
          </Badge>
        </div>
        
        <Carousel 
          className="w-full"
          plugins={isVisible && !isPaused ? [
            Autoplay({
              delay: getUniqueDelay(),
              stopOnInteraction: true,
              stopOnMouseEnter: true,
              playOnInit: true,
            }) as any,
          ] : []}
          opts={{
            align: "start",
            loop: true,
            skipSnaps: false,
            dragFree: true,
          }}
        >
          <CarouselContent className="-ml-2 md:-ml-4">
            {ads.map((ad, index) => (
              <CarouselItem 
                key={ad.id} 
                className="pl-2 md:pl-4 basis-4/5 sm:basis-1/2 md:basis-1/3 lg:basis-1/4"
                style={{
                  animationDelay: `${index * 200}ms`
                }}
              >
                <div 
                  className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-xl transition-all duration-500 cursor-pointer group transform hover:-translate-y-1"
                  onClick={() => onAdClick?.(ad.id)}
                >
                  {/* Enhanced Image with better transitions */}
                  <div className="relative aspect-square overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10" />
                    <img
                      src={ad.images[0] || "/placeholder.svg"}
                      alt={ad.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                      loading={index < 4 ? 'eager' : 'lazy'}
                    />
                    
                    {/* Enhanced Boost Badge */}
                    {ad.is_boosted && (
                      <Badge className="absolute top-3 left-3 bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-xs px-2 py-1 shadow-lg backdrop-blur-sm animate-pulse">
                        <Star className="w-3 h-3 mr-1 fill-current" />
                        Featured
                      </Badge>
                    )}

                    {/* Category Tag */}
                    <Badge className="absolute top-3 right-3 bg-black/70 text-white text-xs px-2 py-1 backdrop-blur-sm">
                      {getCategoryIcon(ad.category)} {ad.category}
                    </Badge>
                  </div>

                  {/* Content with improved spacing and typography */}
                  <div className="p-4">
                    {/* Seller Info */}
                    <div className="flex items-center gap-2 mb-3">
                      {ad.seller?.business_logo_url ? (
                        <img
                          src={ad.seller.business_logo_url}
                          alt={ad.seller.business_name || 'Seller'}
                          className="w-5 h-5 rounded-full object-cover border border-gray-200"
                        />
                      ) : (
                        <div className="w-5 h-5 rounded-full bg-gradient-to-r from-primary to-orange-600 flex items-center justify-center">
                          {ad.seller?.business_name ? (
                            <span className="text-white text-xs font-medium">
                              {getInitials(ad.seller.business_name)}
                            </span>
                          ) : (
                            <User className="w-3 h-3 text-white" />
                          )}
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="text-sm font-medium text-gray-900 truncate">
                            {ad.seller?.business_name || 'Seller'}
                          </span>
                          <VerificationBadge 
                            isVerified={ad.seller?.is_verified} 
                            size="sm" 
                            showText={false}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Title */}
                    <h3 className="font-semibold text-gray-900 line-clamp-2 mb-2 text-sm group-hover:text-primary transition-colors duration-300 leading-tight">
                      {ad.title}
                    </h3>
                    
                    {/* Price */}
                    <p className="text-lg font-bold text-primary mb-3">
                      {ad.currency || 'UGX'} {ad.price?.toLocaleString() || '0'}
                    </p>
                    
                    {/* Location and Time */}
                    <div className="flex items-center justify-between text-xs text-gray-600 mb-3">
                      <div className="flex items-center min-w-0 flex-1">
                        <MapPin className="w-3 h-3 mr-1 flex-shrink-0 text-gray-500" />
                        <span className="truncate">{getDisplayLocation(ad)}</span>
                      </div>
                      <span className="ml-2 flex-shrink-0 text-gray-500">
                        {formatDistanceToNow(new Date(ad.created_at), { addSuffix: true })}
                      </span>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-between pt-2 border-t border-gray-100">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 px-3 text-gray-600 hover:text-red-500 hover:bg-red-50 transition-all duration-200"
                        onClick={(e) => {
                          e.stopPropagation();
                          // Handle like
                        }}
                      >
                        <Heart className="w-4 h-4" />
                      </Button>

                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 px-3 text-gray-600 hover:text-blue-500 hover:bg-blue-50 transition-all duration-200"
                        onClick={(e) => {
                          e.stopPropagation();
                          // Handle message
                        }}
                      >
                        <MessageCircle className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          
          {/* Enhanced Navigation Arrows */}
          <CarouselPrevious className="hidden md:flex -left-12 hover:bg-primary hover:text-white transition-all duration-200 shadow-lg" />
          <CarouselNext className="hidden md:flex -right-12 hover:bg-primary hover:text-white transition-all duration-200 shadow-lg" />
        </Carousel>
      </div>
    </div>
  );
};

export default FeaturedCarousel;
