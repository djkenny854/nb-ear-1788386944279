import React from 'react';

// Material Design style inline SVG illustrations for hero banners

export const MarketplaceIllustration: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 400 300" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Shopping bag */}
    <rect x="120" y="80" width="160" height="180" rx="16" fill="white" fillOpacity="0.15" />
    <rect x="130" y="90" width="140" height="160" rx="12" fill="white" fillOpacity="0.2" />
    <path d="M170 90V60C170 43.43 183.43 30 200 30C216.57 30 230 43.43 230 60V90" stroke="white" strokeOpacity="0.5" strokeWidth="6" strokeLinecap="round" fill="none" />
    <rect x="150" y="130" width="50" height="50" rx="8" fill="#4CAF50" fillOpacity="0.6" />
    <rect x="210" y="130" width="50" height="50" rx="8" fill="#FF9800" fillOpacity="0.6" />
    <rect x="150" y="190" width="50" height="50" rx="8" fill="#2196F3" fillOpacity="0.6" />
    <rect x="210" y="190" width="50" height="50" rx="8" fill="#E91E63" fillOpacity="0.6" />
    <circle cx="80" cy="60" r="20" fill="white" fillOpacity="0.1" />
    <circle cx="320" cy="50" r="15" fill="white" fillOpacity="0.1" />
    <circle cx="340" cy="240" r="25" fill="white" fillOpacity="0.08" />
    <circle cx="60" cy="220" r="18" fill="white" fillOpacity="0.08" />
    <path d="M90 120L93 127L100 130L93 133L90 140L87 133L80 130L87 127Z" fill="white" fillOpacity="0.4" />
    <path d="M310 160L313 167L320 170L313 173L310 180L307 173L300 170L307 167Z" fill="white" fillOpacity="0.4" />
  </svg>
);

export const VerificationIllustration: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 400 300" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <circle cx="200" cy="150" r="110" fill="white" fillOpacity="0.05" />
    <circle cx="200" cy="150" r="95" fill="white" fillOpacity="0.08" />
    <circle cx="200" cy="150" r="78" fill="#4CAF50" fillOpacity="0.25" stroke="white" strokeOpacity="0.4" strokeWidth="3" />
    <circle cx="200" cy="150" r="65" fill="#4CAF50" fillOpacity="0.4" stroke="white" strokeOpacity="0.5" strokeWidth="2.5" />
    <circle cx="200" cy="150" r="48" fill="#4CAF50" fillOpacity="0.7" />
    <path d="M175 150L192 167L228 131" stroke="white" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round" />
    <line x1="200" y1="30" x2="200" y2="50" stroke="white" strokeOpacity="0.3" strokeWidth="3" strokeLinecap="round" />
    <line x1="200" y1="250" x2="200" y2="270" stroke="white" strokeOpacity="0.3" strokeWidth="3" strokeLinecap="round" />
    <line x1="85" y1="150" x2="65" y2="150" stroke="white" strokeOpacity="0.3" strokeWidth="3" strokeLinecap="round" />
    <line x1="315" y1="150" x2="335" y2="150" stroke="white" strokeOpacity="0.3" strokeWidth="3" strokeLinecap="round" />
    <circle cx="80" cy="80" r="16" fill="white" fillOpacity="0.1" />
    <path d="M75 80L79 84L86 76" stroke="white" strokeOpacity="0.4" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="320" cy="90" r="14" fill="white" fillOpacity="0.1" />
    <path d="M316 90L319 93L325 86" stroke="white" strokeOpacity="0.4" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M330 210L333 217L340 220L333 223L330 230L327 223L320 220L327 217Z" fill="white" fillOpacity="0.35" />
    <path d="M70 210L73 217L80 220L73 223L70 230L67 223L60 220L67 217Z" fill="white" fillOpacity="0.35" />
  </svg>
);

export const BoostIllustration: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 400 300" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <path d="M200 60C200 60 170 100 170 180C170 220 200 250 200 250C200 250 230 220 230 180C230 100 200 60 200 60Z" fill="white" fillOpacity="0.2" stroke="white" strokeOpacity="0.4" strokeWidth="2" />
    <circle cx="200" cy="140" r="18" fill="#2196F3" fillOpacity="0.6" stroke="white" strokeOpacity="0.5" strokeWidth="2" />
    <circle cx="200" cy="140" r="10" fill="white" fillOpacity="0.3" />
    <path d="M170 190L140 220L170 210Z" fill="#FF9800" fillOpacity="0.5" />
    <path d="M230 190L260 220L230 210Z" fill="#FF9800" fillOpacity="0.5" />
    <path d="M190 250Q200 280 210 250Q205 265 200 270Q195 265 190 250Z" fill="#FF5722" fillOpacity="0.6" />
    <path d="M195 248Q200 268 205 248Q203 258 200 260Q197 258 195 248Z" fill="#FFEB3B" fillOpacity="0.6" />
    <line x1="120" y1="100" x2="100" y2="100" stroke="white" strokeOpacity="0.2" strokeWidth="2" strokeLinecap="round" />
    <line x1="110" y1="130" x2="85" y2="130" stroke="white" strokeOpacity="0.15" strokeWidth="2" strokeLinecap="round" />
    <line x1="280" y1="100" x2="300" y2="100" stroke="white" strokeOpacity="0.2" strokeWidth="2" strokeLinecap="round" />
    <line x1="290" y1="130" x2="315" y2="130" stroke="white" strokeOpacity="0.15" strokeWidth="2" strokeLinecap="round" />
    <path d="M80 70L83 77L90 80L83 83L80 90L77 83L70 80L77 77Z" fill="white" fillOpacity="0.4" />
    <path d="M320 80L323 87L330 90L323 93L320 100L317 93L310 90L317 87Z" fill="white" fillOpacity="0.3" />
  </svg>
);

export const ChatIllustration: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 400 300" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <rect x="100" y="60" width="200" height="120" rx="20" fill="white" fillOpacity="0.18" />
    <path d="M160 180L140 210L180 180" fill="white" fillOpacity="0.18" />
    <rect x="130" y="90" width="120" height="8" rx="4" fill="white" fillOpacity="0.3" />
    <rect x="130" y="110" width="90" height="8" rx="4" fill="white" fillOpacity="0.25" />
    <rect x="130" y="130" width="140" height="8" rx="4" fill="white" fillOpacity="0.2" />
    <rect x="130" y="150" width="60" height="8" rx="4" fill="white" fillOpacity="0.15" />
    <rect x="200" y="190" width="140" height="60" rx="14" fill="white" fillOpacity="0.12" />
    <path d="M300 250L320 270L290 250" fill="white" fillOpacity="0.12" />
    <rect x="220" y="208" width="80" height="6" rx="3" fill="white" fillOpacity="0.25" />
    <rect x="220" y="222" width="100" height="6" rx="3" fill="white" fillOpacity="0.2" />
    <circle cx="235" cy="235" r="3" fill="white" fillOpacity="0.4" />
    <circle cx="248" cy="235" r="3" fill="white" fillOpacity="0.3" />
    <circle cx="261" cy="235" r="3" fill="white" fillOpacity="0.2" />
    <circle cx="70" cy="100" r="18" fill="white" fillOpacity="0.08" />
    <circle cx="350" cy="120" r="14" fill="white" fillOpacity="0.1" />
  </svg>
);

export const JobsIllustration: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 400 300" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <rect x="130" y="100" width="140" height="110" rx="14" fill="white" fillOpacity="0.18" stroke="white" strokeOpacity="0.3" strokeWidth="2" />
    <path d="M170 100V80C170 71.16 177.16 64 186 64H214C222.84 64 230 71.16 230 80V100" stroke="white" strokeOpacity="0.4" strokeWidth="4" strokeLinecap="round" fill="none" />
    <rect x="130" y="140" width="140" height="12" fill="white" fillOpacity="0.15" />
    <rect x="188" y="134" width="24" height="24" rx="4" fill="white" fillOpacity="0.25" stroke="white" strokeOpacity="0.4" strokeWidth="2" />
    <rect x="196" y="142" width="8" height="8" rx="2" fill="white" fillOpacity="0.4" />
    <rect x="60" y="80" width="50" height="65" rx="6" fill="white" fillOpacity="0.1" transform="rotate(-10 60 80)" />
    <rect x="290" y="70" width="50" height="65" rx="6" fill="white" fillOpacity="0.1" transform="rotate(8 290 70)" />
    <path d="M320 200L323 207L330 210L323 213L320 220L317 213L310 210L317 207Z" fill="white" fillOpacity="0.3" />
  </svg>
);

export const SearchIllustration: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 400 300" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <circle cx="180" cy="130" r="65" stroke="white" strokeOpacity="0.35" strokeWidth="6" fill="white" fillOpacity="0.1" />
    <circle cx="180" cy="130" r="50" stroke="white" strokeOpacity="0.2" strokeWidth="2" fill="none" />
    <line x1="230" y1="180" x2="290" y2="240" stroke="white" strokeOpacity="0.4" strokeWidth="10" strokeLinecap="round" />
    <path d="M180 105L185 120L200 125L185 130L180 145L175 130L160 125L175 120Z" fill="white" fillOpacity="0.5" />
    <rect x="50" y="200" width="80" height="55" rx="8" fill="white" fillOpacity="0.1" />
    <rect x="58" y="210" width="50" height="5" rx="2.5" fill="white" fillOpacity="0.2" />
    <rect x="58" y="220" width="35" height="5" rx="2.5" fill="white" fillOpacity="0.15" />
    <rect x="145" y="210" width="80" height="55" rx="8" fill="white" fillOpacity="0.1" />
    <rect x="153" y="220" width="50" height="5" rx="2.5" fill="white" fillOpacity="0.2" />
    <rect x="153" y="230" width="35" height="5" rx="2.5" fill="white" fillOpacity="0.15" />
    <circle cx="320" cy="80" r="12" fill="white" fillOpacity="0.08" />
    <path d="M340 160L343 167L350 170L343 173L340 180L337 173L330 170L337 167Z" fill="white" fillOpacity="0.3" />
  </svg>
);

export const AppDownloadIllustration: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 400 300" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Phone body */}
    <rect x="145" y="30" width="110" height="240" rx="18" fill="white" fillOpacity="0.15" stroke="white" strokeOpacity="0.35" strokeWidth="2.5" />
    <rect x="155" y="55" width="90" height="190" rx="4" fill="white" fillOpacity="0.1" />
    {/* Notch */}
    <rect x="180" y="38" width="40" height="8" rx="4" fill="white" fillOpacity="0.2" />
    {/* App grid on screen */}
    <rect x="165" y="70" width="28" height="28" rx="7" fill="#4CAF50" fillOpacity="0.6" />
    <rect x="200" y="70" width="28" height="28" rx="7" fill="#FF9800" fillOpacity="0.6" />
    <rect x="165" y="108" width="28" height="28" rx="7" fill="#2196F3" fillOpacity="0.6" />
    <rect x="200" y="108" width="28" height="28" rx="7" fill="#E91E63" fillOpacity="0.6" />
    <rect x="165" y="146" width="28" height="28" rx="7" fill="#9C27B0" fillOpacity="0.5" />
    <rect x="200" y="146" width="28" height="28" rx="7" fill="#00BCD4" fillOpacity="0.5" />
    {/* EarlyMarket logo placeholder on screen */}
    <rect x="170" y="190" width="60" height="20" rx="4" fill="white" fillOpacity="0.25" />
    <rect x="178" y="195" width="44" height="4" rx="2" fill="white" fillOpacity="0.4" />
    <rect x="185" y="202" width="30" height="3" rx="1.5" fill="white" fillOpacity="0.3" />
    {/* Home button */}
    <circle cx="200" cy="258" r="8" stroke="white" strokeOpacity="0.2" strokeWidth="1.5" fill="none" />
    {/* Floating elements */}
    <circle cx="70" cy="80" r="22" fill="white" fillOpacity="0.08" />
    <circle cx="330" cy="100" r="18" fill="white" fillOpacity="0.06" />
    <path d="M80 180L83 187L90 190L83 193L80 200L77 193L70 190L77 187Z" fill="white" fillOpacity="0.35" />
    <path d="M320 210L323 217L330 220L323 223L320 230L317 223L310 220L317 217Z" fill="white" fillOpacity="0.3" />
    {/* Download arrow */}
    <path d="M340 60L340 90M340 90L330 80M340 90L350 80" stroke="white" strokeOpacity="0.3" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M60 140L60 170M60 170L50 160M60 170L70 160" stroke="white" strokeOpacity="0.25" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const ServicesIllustration: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 400 300" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Wrench and gear */}
    <circle cx="200" cy="140" r="55" stroke="white" strokeOpacity="0.3" strokeWidth="4" fill="white" fillOpacity="0.08" />
    {/* Gear teeth */}
    <path d="M200 80L206 95H194L200 80Z" fill="white" fillOpacity="0.25" />
    <path d="M200 200L206 185H194L200 200Z" fill="white" fillOpacity="0.25" />
    <path d="M140 140L155 134V146L140 140Z" fill="white" fillOpacity="0.25" />
    <path d="M260 140L245 134V146L260 140Z" fill="white" fillOpacity="0.25" />
    {/* Inner circle */}
    <circle cx="200" cy="140" r="30" fill="white" fillOpacity="0.15" stroke="white" strokeOpacity="0.35" strokeWidth="2" />
    <circle cx="200" cy="140" r="12" fill="white" fillOpacity="0.3" />
    {/* People silhouettes */}
    <circle cx="100" cy="180" r="14" fill="white" fillOpacity="0.12" />
    <rect x="88" y="200" width="24" height="35" rx="8" fill="white" fillOpacity="0.1" />
    <circle cx="300" cy="170" r="14" fill="white" fillOpacity="0.12" />
    <rect x="288" y="190" width="24" height="35" rx="8" fill="white" fillOpacity="0.1" />
    {/* Sparkles */}
    <path d="M80 80L83 87L90 90L83 93L80 100L77 93L70 90L77 87Z" fill="white" fillOpacity="0.35" />
    <path d="M330 250L333 257L340 260L333 263L330 270L327 263L320 260L327 257Z" fill="white" fillOpacity="0.3" />
  </svg>
);
