import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { getIsDataSaverActive } from '@/contexts/AppSettingsContext';

interface ImageCarouselProps {
  images: string[];
  interval?: number; // in milliseconds
  className?: string;
  aspectRatio?: 'square' | 'video' | 'wide';
  showIndicators?: boolean;
  pauseOnHover?: boolean;
}

const ImageCarousel: React.FC<ImageCarouselProps> = ({
  images,
  interval = 6000,
  className,
  aspectRatio = 'square',
  showIndicators = true,
  pauseOnHover = true,
}) => {
  const isDataSaver = getIsDataSaverActive();
  const effectiveImages = isDataSaver ? images.slice(0, 1) : images;
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (isDataSaver || effectiveImages.length <= 1 || isPaused) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % effectiveImages.length);
    }, interval);

    return () => clearInterval(timer);
  }, [effectiveImages.length, interval, isPaused, isDataSaver]);

  const aspectClasses = {
    square: 'aspect-square',
    video: 'aspect-video',
    wide: 'aspect-[16/9]',
  };

  if (effectiveImages.length === 0) {
    return (
      <div className={cn('bg-muted rounded-xl', aspectClasses[aspectRatio], className)} />
    );
  }

  return (
    <div
      className={cn('relative overflow-hidden rounded-xl', aspectClasses[aspectRatio], className)}
      onMouseEnter={() => pauseOnHover && setIsPaused(true)}
      onMouseLeave={() => pauseOnHover && setIsPaused(false)}
    >
      <AnimatePresence mode="wait">
        <motion.img
          key={currentIndex}
          src={effectiveImages[currentIndex] || effectiveImages[0]}
          alt={`Slide ${currentIndex + 1}`}
          className="w-full h-full object-cover"
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.5, ease: 'easeInOut' }}
        />
      </AnimatePresence>

      {/* Progress bar */}
      {!isDataSaver && effectiveImages.length > 1 && (
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-background/20 backdrop-blur-sm">
          <motion.div
            className="h-full bg-primary"
            initial={{ width: '0%' }}
            animate={{ width: isPaused ? `${((currentIndex + 1) / effectiveImages.length) * 100}%` : '100%' }}
            transition={{ duration: isPaused ? 0 : interval / 1000, ease: 'linear' }}
            key={`progress-${currentIndex}-${isPaused}`}
          />
        </div>
      )}

      {/* Dot indicators */}
      {!isDataSaver && showIndicators && effectiveImages.length > 1 && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
          {effectiveImages.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={cn(
                'w-1.5 h-1.5 rounded-full transition-all duration-300',
                idx === currentIndex
                  ? 'bg-primary w-4'
                  : 'bg-background/60 hover:bg-background/80'
              )}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default ImageCarousel;
