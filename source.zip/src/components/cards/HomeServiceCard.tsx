import React from 'react';
import { MapPin, Bookmark, Wrench, Star, BadgeCheck } from 'lucide-react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';
import { useCurrency } from '@/contexts/CurrencyContext';
import { cn } from '@/lib/utils';
import SmartVideo from '@/components/media/SmartVideo';

interface HomeServiceCardProps {
  id: string;
  title: string;
  description?: string | null;
  price?: number | null;
  images: string[];
  videoUrl?: string | null;
  location: string;
  category?: string;
  rating?: number | null;
  reviewCount?: number;
  catalogTitles?: string[];
  seller?: {
    business_name?: string | null;
    business_logo_url?: string | null;
    is_verified?: boolean;
    verification_badge_color?: BadgeColor;
  } | null;
  onClick?: () => void;
  isBookmarked?: boolean;
  onBookmarkToggle?: (e: React.MouseEvent) => void;
  serviceDetails?: {
    starting_price?: number | null;
    experience_years?: number | null;
    qualifications?: string | null;
  } | null;
  /** Render full-width inside vertical lists. Defaults to horizontal scroll size. */
  fullWidth?: boolean;
}

/**
 * Compact horizontal service card — mirrors the loading skeleton.
 * Layout: [ image left ] | business · service title · catalog chips · meta + price
 */
const HomeServiceCard: React.FC<HomeServiceCardProps> = ({
  title,
  price,
  images,
  videoUrl,
  location,
  category,
  rating,
  reviewCount,
  catalogTitles,
  seller,
  onClick,
  isBookmarked = false,
  onBookmarkToggle,
  serviceDetails,
  fullWidth,
}) => {
  const { formatPriceCompact } = useCurrency();
  const displayPrice = serviceDetails?.starting_price || (price && price > 0 ? price : null);

  const isVideoUrl = (url: string) => /\.(mp4|webm|mov|avi)$/i.test(url || '') || url?.includes('.mp4');
  const actualImages = images?.filter((img) => !isVideoUrl(img)) || [];
  const videoFromImages = images?.find(isVideoUrl);
  const effectiveVideoUrl = videoUrl || videoFromImages;
  const mainImage = actualImages[0];

  // Catalog chips fall back to category if none provided
  const chips = (catalogTitles && catalogTitles.length > 0
    ? catalogTitles
    : category
      ? [category]
      : []
  ).slice(0, 3);

  return (
    <motion.button
      whileHover={{ y: -1 }}
      whileTap={{ scale: 0.99 }}
      transition={{ duration: 0.15 }}
      onClick={onClick}
      className={cn(
        'group text-left bg-card rounded-2xl overflow-hidden border border-border/60 hover:border-primary/40 hover:shadow-md transition-all',
        'flex items-stretch gap-3 p-3',
        fullWidth ? 'w-full' : 'w-[320px] sm:w-[340px] shrink-0',
      )}
    >
      {/* Image — left */}
      <div className="relative w-24 h-24 rounded-xl overflow-hidden bg-muted shrink-0">
        {effectiveVideoUrl ? (
          <SmartVideo
            src={effectiveVideoUrl}
            className="w-full h-full object-cover"
            muted
            loop
            playsInline
            autoPlayInView
          />
        ) : mainImage ? (
          <img src={mainImage} alt={title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-primary/10">
            <Wrench className="w-7 h-7 text-primary/50" />
          </div>
        )}
      </div>

      {/* Details — right */}
      <div className="flex-1 min-w-0 flex flex-col justify-between py-0.5">
        {/* Row 1: business + verified */}
        <div className="flex items-center gap-1.5 min-w-0">
          {seller?.business_logo_url && (
            <img
              src={seller.business_logo_url}
              alt=""
              className="w-4 h-4 rounded-full object-cover shrink-0"
            />
          )}
          <span className="text-xs text-muted-foreground truncate font-medium">
            {seller?.business_name || 'Service provider'}
          </span>
          {seller?.is_verified && (
            <UnifiedVerifiedBadge
              isVerified
              badgeColor={seller.verification_badge_color}
              size="sm"
            />
          )}
        </div>

        {/* Row 2: title */}
        <h3 className="font-semibold text-sm text-foreground line-clamp-1 group-hover:text-primary transition-colors">
          {title}
        </h3>

        {/* Row 3: catalog chips */}
        {chips.length > 0 && (
          <div className="flex items-center gap-1 min-w-0">
            <span className="text-[11px] text-muted-foreground truncate">
              {chips.join(' · ')}
            </span>
          </div>
        )}

        {/* Row 4: meta + price + bookmark */}
        <div className="flex items-center justify-between gap-2 pt-0.5">
          <div className="flex items-center gap-2 text-[11px] text-muted-foreground min-w-0">
            {typeof rating === 'number' && rating > 0 && (
              <span className="inline-flex items-center gap-0.5">
                <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                <span className="font-medium text-foreground">{rating.toFixed(1)}</span>
                {reviewCount ? <span>({reviewCount})</span> : null}
              </span>
            )}
            <span className="inline-flex items-center gap-0.5 truncate">
              <MapPin className="w-3 h-3" />
              <span className="truncate">{location}</span>
            </span>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            {displayPrice ? (
              <span className="text-sm font-bold text-primary">
                From {formatPriceCompact(displayPrice)}
              </span>
            ) : (
              <span className="text-[11px] text-muted-foreground italic">Quote</span>
            )}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onBookmarkToggle?.(e);
              }}
              className="p-1 rounded-full hover:bg-muted transition-colors"
              aria-label={isBookmarked ? 'Remove bookmark' : 'Bookmark service'}
            >
              <Bookmark
                className={cn(
                  'w-4 h-4',
                  isBookmarked
                    ? 'fill-primary text-primary'
                    : 'text-muted-foreground hover:text-foreground',
                )}
              />
            </button>
          </div>
        </div>
      </div>
    </motion.button>
  );
};

export default HomeServiceCard;
