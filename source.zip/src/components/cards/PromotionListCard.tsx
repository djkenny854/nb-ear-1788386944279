import React, { useEffect, useState } from 'react';
import { Clock, Zap, Tag } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import UnifiedVerifiedBadge from '@/components/UnifiedVerifiedBadge';

export interface PromotionListCardPromotion {
  id: string;
  title: string;
  description?: string;
  images?: string[];
  discountPercent?: number;
  validUntil?: string | null;
  brand?: {
    name?: string;
    logo?: string;
    isVerified?: boolean;
  };
  productAvatars?: { image: string; name: string }[];
  type?: string;
  promotionSubType?: string;
}

interface Props {
  promotion: PromotionListCardPromotion;
  onClick?: () => void;
}

// Flip-style two-digit slot: previous digit slides UP out, new one comes IN
// from above. Uses pure CSS transforms so it stays smooth on mobile.
const FlipDigit: React.FC<{ value: number; label: string }> = ({ value, label }) => {
  const [display, setDisplay] = useState(value);
  const [prev, setPrev] = useState(value);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    if (value !== display) {
      setPrev(display);
      setDisplay(value);
      setTick((t) => t + 1);
    }
  }, [value, display]);

  const two = String(display).padStart(2, '0');
  const prevTwo = String(prev).padStart(2, '0');

  return (
    <div className="flex flex-col items-center">
      <div className="relative h-7 w-10 overflow-hidden rounded-md bg-foreground text-background font-bold text-lg leading-7 text-center shadow-sm">
        <span
          key={`cur-${tick}`}
          className="absolute inset-0 animate-[flipIn_0.35s_ease-out]"
        >
          {two}
        </span>
        <span
          key={`prev-${tick}`}
          className="absolute inset-0 animate-[flipOut_0.35s_ease-out] opacity-0"
          aria-hidden
        >
          {prevTwo}
        </span>
      </div>
      <span className="mt-0.5 text-[9px] uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
    </div>
  );
};

function useCountdownParts(validUntil?: string | null) {
  const [parts, setParts] = useState({ d: 0, h: 0, m: 0, s: 0, expired: false });
  useEffect(() => {
    if (!validUntil) return;
    const tick = () => {
      const end = new Date(validUntil).getTime();
      const diff = end - Date.now();
      if (diff <= 0) {
        setParts({ d: 0, h: 0, m: 0, s: 0, expired: true });
        return;
      }
      setParts({
        d: Math.floor(diff / 86_400_000),
        h: Math.floor((diff % 86_400_000) / 3_600_000),
        m: Math.floor((diff % 3_600_000) / 60_000),
        s: Math.floor((diff % 60_000) / 1000),
        expired: false,
      });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [validUntil]);
  return parts;
}

const PromotionListCard: React.FC<Props> = ({ promotion, onClick }) => {
  const countdown = useCountdownParts(promotion.validUntil);
  if (countdown.expired) return null;

  const avatars = (promotion.productAvatars || []).filter((p) => p.image);
  const shownAvatars = avatars.slice(0, 3);
  const heroImage =
    promotion.images?.[0] && promotion.images[0] !== '/placeholder.svg'
      ? promotion.images[0]
      : promotion.brand?.logo;

  const subBits: string[] = [];
  if (promotion.brand?.name) subBits.push(promotion.brand.name);
  if (avatars.length) subBits.push(`${avatars.length} product${avatars.length === 1 ? '' : 's'}`);
  if (promotion.discountPercent && promotion.discountPercent > 0) {
    subBits.push(`${promotion.discountPercent}% off`);
  }

  return (
    <article
      onClick={onClick}
      className="group cursor-pointer w-full bg-transparent py-4 border-b border-border/40 last:border-b-0 hover:bg-foreground/[0.02] transition-colors -mx-1 px-1 rounded-md"
    >
      <div className="flex items-start gap-4">
        {/* Left: text */}
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-base sm:text-[17px] leading-snug text-foreground line-clamp-2 group-hover:text-primary transition-colors">
            {promotion.title}
          </h3>

          {/* Brand line */}
          <div className="mt-1.5 flex items-center gap-1.5 text-xs text-muted-foreground min-w-0">
            <span className="truncate font-medium text-foreground/90">
              {promotion.brand?.name || 'Promotion'}
            </span>
            {promotion.brand?.isVerified && (
              <UnifiedVerifiedBadge isVerified size="sm" />
            )}
          </div>

          {/* Description */}
          {promotion.description ? (
            <p className="mt-1.5 text-xs text-muted-foreground line-clamp-2">
              {promotion.description}
            </p>
          ) : null}

          {/* Countdown */}
          <div className="mt-2.5 flex items-center gap-1.5">
            <FlipDigit value={countdown.d} label="Days" />
            <span className="text-muted-foreground font-bold text-base pb-3">:</span>
            <FlipDigit value={countdown.h} label="Hrs" />
            <span className="text-muted-foreground font-bold text-base pb-3">:</span>
            <FlipDigit value={countdown.m} label="Min" />
            <span className="text-muted-foreground font-bold text-base pb-3">:</span>
            <FlipDigit value={countdown.s} label="Sec" />
          </div>

          {/* Meta row: product avatars + sub bits */}
          <div className="mt-2.5 flex items-center gap-2 text-[11px] text-muted-foreground">
            {shownAvatars.length > 0 && (
              <div className="flex -space-x-2">
                {shownAvatars.map((p, i) => (
                  <Avatar key={i} className="h-5 w-5 border-2 border-background ring-0">
                    <AvatarImage src={p.image} alt={p.name} className="object-cover" />
                    <AvatarFallback className="text-[9px] bg-muted">
                      {p.name?.charAt(0) || 'P'}
                    </AvatarFallback>
                  </Avatar>
                ))}
                {avatars.length > shownAvatars.length && (
                  <div className="h-5 w-5 rounded-full bg-muted border-2 border-background flex items-center justify-center text-[8px] font-semibold text-muted-foreground">
                    +{avatars.length - shownAvatars.length}
                  </div>
                )}
              </div>
            )}
            <span className="truncate">{subBits.join(' · ')}</span>
          </div>
        </div>

        {/* Right: circular hero */}
        <div className="shrink-0">
          <div className={cn(
            'relative h-16 w-16 sm:h-[72px] sm:w-[72px] rounded-full overflow-hidden border border-border/60 bg-muted'
          )}>
            {heroImage ? (
              <img src={heroImage} alt={promotion.title} className="h-full w-full object-cover" loading="lazy" />
            ) : (
              <div className="h-full w-full flex items-center justify-center bg-primary/10">
                <Tag className="w-5 h-5 text-primary" />
              </div>
            )}
            {promotion.discountPercent && promotion.discountPercent > 0 && (
              <div className="absolute -bottom-0.5 -right-0.5 bg-destructive text-destructive-foreground text-[9px] font-bold px-1.5 py-0.5 rounded-full border-2 border-background">
                -{promotion.discountPercent}%
              </div>
            )}
            {(promotion.type === 'flash-sale' || promotion.promotionSubType === 'flash_sale') && (
              <div className="absolute top-0 left-0 bg-amber-500 rounded-full p-1 border-2 border-background">
                <Zap className="w-2.5 h-2.5 text-white" />
              </div>
            )}
          </div>
        </div>
      </div>
    </article>
  );
};

export default PromotionListCard;