import React from 'react';
import { Star } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';

export interface NewsStyleServiceCardProps {
  id: string;
  title: string;
  description?: string;
  images?: string[];
  catalogs?: { name: string }[];
  category?: string;
  postCount?: number;
  provider: {
    name: string;
    avatar?: string;
    isVerified?: boolean;
    verificationBadgeColor?: BadgeColor;
    rating?: number;
    reviewCount?: number;
  };
  onClick?: () => void;
}

const isVideo = (u?: string) => !!u && /\.(mp4|webm|mov|avi)$/i.test(u);

const NewsStyleServiceCard: React.FC<NewsStyleServiceCardProps> = ({
  title,
  description,
  images = [],
  catalogs = [],
  category,
  postCount,
  provider,
  onClick,
}) => {
  const actualImages = (images || []).filter((i) => i && !isVideo(i));
  const heroImage = actualImages[0] || provider.avatar;
  // Stacked avatars from work images (up to 3), fallback to provider avatar
  const avatarPool = (actualImages.length > 0 ? actualImages : [provider.avatar].filter(Boolean) as string[]).slice(0, 3);
  const subBits: string[] = [];
  if (provider.name) subBits.push(provider.name);
  if (category) subBits.push(category);
  if (typeof postCount === 'number') subBits.push(`${postCount} post${postCount === 1 ? '' : 's'}`);

  return (
    <article
      onClick={onClick}
      className="group cursor-pointer w-full bg-transparent py-4 border-b border-border/40 last:border-b-0 hover:bg-foreground/[0.02] transition-colors -mx-1 px-1 rounded-md"
    >
      <div className="flex items-start gap-4">
        {/* Text content */}
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-base sm:text-[17px] leading-snug text-foreground line-clamp-2 group-hover:text-primary transition-colors">
            {title}
          </h3>

          {/* Provider line */}
          <div className="mt-1.5 flex items-center gap-1.5 text-xs text-muted-foreground min-w-0">
            <span className="truncate font-medium text-foreground/90">{provider.name}</span>
            {provider.isVerified && (
              <UnifiedVerifiedBadge isVerified badgeColor={provider.verificationBadgeColor} size="sm" />
            )}
            {!!provider.rating && provider.rating > 0 && (
              <>
                <span className="text-muted-foreground/50">·</span>
                <span className="inline-flex items-center gap-0.5">
                  <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                  {provider.rating.toFixed(1)}
                  {provider.reviewCount ? <span className="text-muted-foreground/70 ml-0.5">({provider.reviewCount})</span> : null}
                </span>
              </>
            )}
          </div>

          {/* Catalogs preview (preferred) — falls back to the description */}
          {catalogs.length > 0 ? (
            <p className="mt-1.5 text-xs text-muted-foreground line-clamp-2">
              {catalogs.slice(0, 4).map((c) => c.name).join(' · ')}
              {catalogs.length > 4 ? ` · +${catalogs.length - 4} more` : ''}
            </p>
          ) : description ? (
            <p className="mt-1.5 text-xs text-muted-foreground line-clamp-2">{description}</p>
          ) : null}

          {/* Meta row: stacked avatars + meta bits */}
          <div className="mt-2.5 flex items-center gap-2 text-[11px] text-muted-foreground">
            {avatarPool.length > 0 && (
              <div className="flex -space-x-2">
                {avatarPool.map((src, i) => (
                  <Avatar key={i} className="h-5 w-5 border-2 border-background ring-0">
                    <AvatarImage src={src} alt="" className="object-cover" />
                    <AvatarFallback className="text-[9px] bg-muted">{provider.name?.charAt(0) || 'S'}</AvatarFallback>
                  </Avatar>
                ))}
              </div>
            )}
            <span className="truncate">{subBits.join(' · ')}</span>
          </div>
        </div>

        {/* Circular hero image — falls back to seller logo */}
        <div className="shrink-0">
          <div className={cn(
            'h-16 w-16 sm:h-[72px] sm:w-[72px] rounded-full overflow-hidden border border-border/60 bg-muted'
          )}>
            {heroImage ? (
              <img src={heroImage} alt={title} className="h-full w-full object-cover" loading="lazy" />
            ) : (
              <div className="h-full w-full flex items-center justify-center text-base font-semibold text-muted-foreground bg-muted">
                {provider.name?.charAt(0) || 'S'}
              </div>
            )}
          </div>
        </div>
      </div>
    </article>
  );
};

export default NewsStyleServiceCard;
