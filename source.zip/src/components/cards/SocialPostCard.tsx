import React from 'react';
import { Heart, MessageCircle, Share2, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import type { SocialPost } from '@/data/mockData';

interface SocialPostCardProps {
  post: SocialPost;
  onClick?: () => void;
}

const SocialPostCard: React.FC<SocialPostCardProps> = ({ post, onClick }) => {
  const formatCount = (count: number) => {
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  return (
    <motion.div
      whileHover={{ y: -4, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
      className="group cursor-pointer bg-card rounded-xl overflow-hidden border border-border/50 hover:border-primary/30 hover:shadow-lg transition-all duration-300 min-w-[280px] max-w-[320px]"
    >
      {/* Image */}
      {post.image && (
        <div className="relative aspect-video overflow-hidden">
          <img
            src={post.image}
            alt=""
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
      )}

      {/* Content */}
      <div className="p-4 space-y-3">
        {/* Author */}
        <div className="flex items-center gap-2">
          <img
            src={post.author.avatar}
            alt={post.author.name}
            className="w-8 h-8 rounded-full object-cover"
          />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1">
              <span className="font-semibold text-sm text-foreground truncate">
                {post.author.name}
              </span>
              {post.author.isVerified && (
                <CheckCircle className="w-3 h-3 text-primary fill-primary flex-shrink-0" />
              )}
            </div>
          </div>
        </div>

        {/* Text */}
        <p className="text-sm text-foreground line-clamp-2">{post.content}</p>

        {/* Stats */}
        <div className="flex items-center gap-4 pt-2 border-t border-border/50">
          <button className="flex items-center gap-1 text-muted-foreground hover:text-destructive transition-colors">
            <Heart className="w-4 h-4" />
            <span className="text-xs">{formatCount(post.likes)}</span>
          </button>
          <button className="flex items-center gap-1 text-muted-foreground hover:text-primary transition-colors">
            <MessageCircle className="w-4 h-4" />
            <span className="text-xs">{formatCount(post.comments)}</span>
          </button>
          <button className="flex items-center gap-1 text-muted-foreground hover:text-primary transition-colors">
            <Share2 className="w-4 h-4" />
            <span className="text-xs">{formatCount(post.shares)}</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default SocialPostCard;
