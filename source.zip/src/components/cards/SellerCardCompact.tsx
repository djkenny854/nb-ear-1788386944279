import React from 'react';
import { Star, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import type { Seller } from '@/data/mockData';
import UnifiedVerifiedBadge from '@/components/UnifiedVerifiedBadge';

interface SellerCardCompactProps {
  seller: Seller;
  onClick?: () => void;
}

const SellerCardCompact: React.FC<SellerCardCompactProps> = ({ seller, onClick }) => {
  const formatFollowers = (count: number) => {
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  return (
    <motion.div
      whileHover={{ y: -4, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
      className="group cursor-pointer flex flex-col items-center text-center min-w-[140px] max-w-[160px]"
    >
      {/* Avatar */}
      <div className="relative mb-3">
        <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-border group-hover:border-primary transition-colors duration-300">
          <img
            src={seller.avatar}
            alt={seller.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
        </div>
        {seller.isVerified && (
          <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-background flex items-center justify-center">
            <UnifiedVerifiedBadge 
              isVerified={seller.isVerified} 
              size="md" 
            />
          </div>
        )}
      </div>

      {/* Name */}
      <h3 className="font-semibold text-sm text-foreground line-clamp-1 group-hover:text-primary transition-colors">
        {seller.name}
      </h3>

      {/* Category */}
      <p className="text-xs text-muted-foreground mt-0.5">{seller.category}</p>

      {/* Stats */}
      <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
        <div className="flex items-center gap-1">
          <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
          <span>{seller.rating}</span>
        </div>
        <div className="flex items-center gap-1">
          <Users className="w-3 h-3" />
          <span>{formatFollowers(seller.followers)}</span>
        </div>
      </div>
    </motion.div>
  );
};

export default SellerCardCompact;
