import React, { useEffect, useState } from "react";
import {
  Bookmark,
  ChevronRight,
  Clock,
  MapPin,
  MessageCircle,
  Wrench,
  Star,
} from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import SmartVideo from '@/components/media/SmartVideo';
import { YouTubeIcon, TikTokIcon } from "@/components/icons/SocialIcons";
import { useBookmarks } from "@/hooks/useBookmarks";
import { useViewTracking } from "@/hooks/useViewTracking";
import { videoCdnUrl } from "@/utils/cdnUrl";
import ServiceStatusBadge, { ServiceStatusType } from "@/components/service/ServiceStatusBadge";
import UnifiedVerifiedBadge, { BadgeColor } from "@/components/UnifiedVerifiedBadge";

export interface ServiceCatalogDisplay {
  name: string;
  price?: number | null;
  currency?: string;
  durationMinutes?: number | null;
}

export interface SearchService {
  id: string;
  title: string;
  description: string;
  price: number;
  priceType: "hourly" | "fixed" | "starting_from";
  images: string[];
  videoUrl?: string | null;
  youtubeUrl?: string | null;
  tiktokUrl?: string | null;
  provider: {
    name: string;
    avatar: string;
    isVerified: boolean;
    verificationBadgeColor?: BadgeColor;
    rating: number;
    reviewCount: number;
    serviceStatus?: ServiceStatusType;
  };
  location: string;
  category: string;
  availability: string;
  responseTime: string;
  catalogs?: ServiceCatalogDisplay[];
}

interface SearchServiceCardProps {
  service: SearchService;
  onClick?: () => void;
  updateCount?: number;
  updateAvatars?: string[];
}

function formatUpdateCount(n: number): string {
  if (!n || n <= 0) return '0 updates';
  const compact = new Intl.NumberFormat('en', { notation: 'compact', maximumFractionDigits: 1 }).format(n);
  return `${compact} ${n === 1 ? 'update' : 'updates'}`;
}

const SearchServiceCard: React.FC<SearchServiceCardProps> = ({ service, onClick, updateCount = 0, updateAvatars = [] }) => {
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const bookmarked = isBookmarked(service.id, 'service');
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Fire a view once the card stays in the viewport for 3 seconds.
  const viewRef = useViewTracking({
    contentId: service.id,
    contentType: 'service',
    sourcePage: 'search',
    threshold: 0.5,
    viewDuration: 3000,
  });

  // Check if URL is a video
  const isVideoUrl = (url: string) => {
    return url?.match(/\.(mp4|webm|mov|avi)$/i) || url?.includes('.mp4') || url?.includes('.webm');
  };

  // Filter actual images from video URLs
  const actualImages = service.images?.filter(img => !isVideoUrl(img)) || [];
  const videoFromImages = service.images?.find(img => isVideoUrl(img));
  const rawVideoUrl = service.videoUrl || videoFromImages;
  const effectiveVideoUrl = rawVideoUrl ? videoCdnUrl(rawVideoUrl) : undefined;
  
  const hasActualImages = actualImages.length > 0;
  const hasVideo = !!effectiveVideoUrl;
  const showVideo = hasVideo;

  useEffect(() => {
    if (actualImages.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % actualImages.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [actualImages.length]);

  const formatPrice = () => {
    if (!service.price || service.price <= 0) return null;
    const formatted = new Intl.NumberFormat("en-UG").format(service.price);
    switch (service.priceType) {
      case "hourly":
        return `UGX ${formatted}/hr`;
      case "starting_from":
        return `From UGX ${formatted}`;
      default:
        return `UGX ${formatted}`;
    }
  };

  const handleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleBookmark(service.id, 'service');
  };

  return (
    <motion.article
      ref={viewRef as unknown as React.Ref<HTMLElement>}
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
      className="group cursor-pointer w-full bg-card rounded-2xl overflow-hidden border border-border hover:border-primary/30 hover:shadow-xl transition-all will-change-transform"
      style={{ transform: 'translateZ(0)' }}
      aria-label={`Service: ${service.title}`}
    >
      <div className="flex flex-col sm:flex-row min-h-[180px]">
        {/* Media */}
        <div className="relative w-full sm:w-[280px] md:w-[320px] h-[180px] sm:h-auto sm:max-h-[220px] flex-shrink-0 overflow-hidden">
          {showVideo ? (
            <SmartVideo
              src={effectiveVideoUrl!}
              className="h-full w-full object-cover"
              muted
              loop
              playsInline
              autoPlayInView
            />
          ) : hasActualImages ? (
            <AnimatePresence mode="wait">
              <motion.img
                key={currentImageIndex}
                src={actualImages[currentImageIndex] || "/placeholder.svg"}
                alt={service.title}
                className="h-full w-full object-cover"
                loading="lazy"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.35 }}
              />
            </AnimatePresence>
          ) : (
            <div className="h-full w-full flex items-center justify-center bg-muted">
              <Wrench className="w-12 h-12 text-muted-foreground/30" />
            </div>
          )}

          {/* Gradient overlay */}
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t sm:bg-gradient-to-r from-card/60 via-transparent to-transparent" />

          {/* Category Badge */}
          <div className="absolute left-3 top-3 flex items-center gap-2">
            <Badge className="bg-primary/90 text-primary-foreground backdrop-blur-sm">
              <Wrench className="h-3 w-3 mr-1" />
              Service
            </Badge>
            {service.category && (
              <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm text-xs">
                {service.category}
              </Badge>
            )}
          </div>

          {/* Bookmark */}
          <button
            type="button"
            onClick={handleBookmark}
            className="absolute right-3 top-3 rounded-full bg-background/80 backdrop-blur-sm px-2.5 py-2 border border-border hover:bg-background transition"
            aria-label={bookmarked ? "Remove bookmark" : "Bookmark"}
          >
            <Bookmark className={cn("h-4 w-4", bookmarked && "fill-primary text-primary")} />
          </button>

          {/* Image indicators */}
          {actualImages.length > 1 && (
            <div className="absolute bottom-3 left-3 flex gap-1">
              {actualImages.slice(0, 5).map((_, idx) => (
                <div
                  key={idx}
                  className={cn(
                    "w-1.5 h-1.5 rounded-full transition-all",
                    idx === currentImageIndex ? "bg-white w-3" : "bg-white/50"
                  )}
                />
              ))}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 p-4 sm:p-5 flex flex-col gap-3">
          {/* Title & Description */}
          <header className="min-w-0">
            <h3 className="font-bold text-lg text-foreground line-clamp-2 group-hover:text-primary transition-colors">
              {service.title}
            </h3>
            {service.description && (
              <p className="mt-1.5 text-sm text-muted-foreground line-clamp-2">
                {service.description}
              </p>
            )}
          </header>

          {/* Provider Info */}
          <div className="flex items-center gap-3 min-w-0">
            <Avatar className="h-10 w-10 border-2 border-primary/20">
              <AvatarImage src={service.provider.avatar} alt={service.provider.name} />
              <AvatarFallback className="text-sm font-semibold bg-primary/10 text-primary">
                {service.provider.name?.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 min-w-0">
                <span className="text-sm font-medium text-foreground truncate">{service.provider.name}</span>
                <UnifiedVerifiedBadge 
                  isVerified={service.provider.isVerified} 
                  badgeColor={service.provider.verificationBadgeColor}
                  size="sm" 
                />
              </div>
              <div className="mt-0.5 flex items-center gap-3 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1">
                  <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                  {service.provider.rating.toFixed(1)}
                  {service.provider.reviewCount > 0 && (
                    <span className="text-muted-foreground/70">({service.provider.reviewCount})</span>
                  )}
                </span>
                <span className="inline-flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  <span className="truncate">{service.location}</span>
                </span>
          </div>

          {/* Updates strip */}
          <div className="flex items-center gap-2 -mt-1">
            {updateAvatars.length > 0 ? (
              <div className="flex -space-x-2">
                {updateAvatars.slice(0, 5).map((src, i) => (
                  <span
                    key={i}
                    className="inline-block h-6 w-6 rounded-full ring-2 ring-card overflow-hidden bg-muted"
                  >
                    <img src={src} alt="" className="h-full w-full object-cover" loading="lazy" />
                  </span>
                ))}
              </div>
            ) : (
              <div className="flex -space-x-2">
                {[0, 1, 2].map((i) => (
                  <span
                    key={i}
                    className="inline-block h-6 w-6 rounded-full ring-2 ring-card bg-muted/60"
                  />
                ))}
              </div>
            )}
            <span className="text-xs text-muted-foreground">
              {formatUpdateCount(updateCount)}
            </span>
          </div>

            </div>
          </div>

          {/* Service Catalog Bullets */}
          {service.catalogs && service.catalogs.length > 0 && (
            <div className="space-y-1">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Services offered</p>
              <ul className="space-y-0.5">
                {service.catalogs.slice(0, 4).map((item, idx) => (
                  <li key={idx} className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1.5 text-foreground min-w-0">
                      <span className="w-1 h-1 rounded-full bg-primary shrink-0" />
                      <span className="truncate">{item.name}</span>
                    </span>
                    <span className="text-muted-foreground shrink-0 ml-2">
                      {item.price && item.price > 0 ? `${item.currency || 'UGX'} ${new Intl.NumberFormat().format(item.price)}` : ''}
                      {item.durationMinutes ? ` · ${item.durationMinutes}min` : ''}
                    </span>
                  </li>
                ))}
                {service.catalogs.length > 4 && (
                  <li className="text-xs text-primary font-medium">+{service.catalogs.length - 4} more services</li>
                )}
              </ul>
            </div>
          )}

          {/* Meta Info */}
          <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            {/* Service Status Badge */}
            {service.provider.serviceStatus && (
              <ServiceStatusBadge status={service.provider.serviceStatus} size="sm" />
            )}
            <Badge variant="outline" className="font-normal">
              <Clock className="h-3 w-3 mr-1" />
              {service.responseTime}
            </Badge>
            <Badge variant="outline" className="font-normal text-emerald-600 border-emerald-200 bg-emerald-50 dark:bg-emerald-950/30">
              {service.availability}
            </Badge>
            {/* Social media icons */}
            {(service.youtubeUrl || service.tiktokUrl) && (
              <div className="flex items-center gap-1 ml-auto">
                {service.youtubeUrl && (
                  <a 
                    href={service.youtubeUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="p-1.5 rounded-full hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors"
                  >
                    <YouTubeIcon className="w-4 h-4 text-red-600" />
                  </a>
                )}
                {service.tiktokUrl && (
                  <a 
                    href={service.tiktokUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="p-1.5 rounded-full hover:bg-muted transition-colors"
                  >
                    <TikTokIcon className="w-4 h-4 text-foreground" />
                  </a>
                )}
              </div>
            )}
          </div>

          {/* Price & CTA */}
          <div className="mt-auto pt-3 border-t border-border/50 flex items-center justify-between gap-4">
            <div className="min-w-0">
              {formatPrice() ? (
                <>
                  <div className="text-xs text-muted-foreground">Starting from</div>
                  <div className="font-bold text-xl text-primary">{formatPrice()}</div>
                </>
              ) : (
                <div className="text-sm text-muted-foreground italic">Contact for pricing</div>
              )}
            </div>
            <Button
              size="default"
              className="rounded-full px-6"
              onClick={(e) => e.stopPropagation()}
            >
              <MessageCircle className="h-4 w-4 mr-2" />
              Contact
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>
    </motion.article>
  );
};

export default SearchServiceCard;
