import React, { useState } from 'react';
import { Download, Star, Eye, FileText, Code, Music, Video, Image as ImageIcon, Bookmark } from 'lucide-react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import ImageCarousel from './ImageCarousel';
import type { DigitalProduct } from '@/data/mockData';

interface DigitalProductCardProps {
  product: DigitalProduct;
  onClick?: () => void;
}

const typeIcons: Record<string, React.ReactNode> = {
  'ebook': <FileText className="w-4 h-4" />,
  'software': <Code className="w-4 h-4" />,
  'music': <Music className="w-4 h-4" />,
  'video': <Video className="w-4 h-4" />,
  'graphics': <ImageIcon className="w-4 h-4" />,
  'template': <FileText className="w-4 h-4" />,
};

const DigitalProductCard: React.FC<DigitalProductCardProps> = ({ product, onClick }) => {
  const [isBookmarked, setIsBookmarked] = useState(false);
  
  const handleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsBookmarked(!isBookmarked);
  };
  const formatPrice = (price: number) => {
    if (price === 0) return 'Free';
    if (price >= 1000000) return `UGX ${(price / 1000000).toFixed(1)}M`;
    if (price >= 1000) return `UGX ${(price / 1000).toFixed(0)}K`;
    return `UGX ${price.toLocaleString()}`;
  };

  return (
    <motion.div
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
      className="group cursor-pointer bg-gradient-to-br from-violet-500/10 via-card to-fuchsia-500/10 rounded-2xl overflow-hidden border border-violet-500/20 hover:border-violet-500/40 hover:shadow-xl hover:shadow-violet-500/10 transition-all duration-300 min-w-[200px] max-w-[240px]"
    >
      {/* Image/Preview Area */}
      <div className="relative">
        <ImageCarousel
          images={product.images}
          interval={6000}
          aspectRatio="video"
          showIndicators={product.images.length > 1}
        />
        
        {/* Type Badge */}
        <div className="absolute top-2 left-2">
          <Badge className="bg-violet-500/90 text-white backdrop-blur-sm flex items-center gap-1 text-[10px] px-2 py-0.5">
            {typeIcons[product.type] || <FileText className="w-3 h-3" />}
            {product.type}
          </Badge>
        </div>

        {/* Bookmark Button */}
        <button 
          className="absolute top-2 right-2 w-7 h-7 rounded-full bg-background/60 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={handleBookmark}
        >
          <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-primary text-primary' : 'text-foreground'}`} />
        </button>

        {/* Downloads count */}
        <div className="absolute bottom-2 right-2 flex items-center gap-1 bg-background/80 backdrop-blur-sm rounded-full px-2 py-1">
          <Download className="w-3 h-3 text-violet-500" />
          <span className="text-[10px] text-muted-foreground">{product.downloads}</span>
        </div>
      </div>

      {/* Content */}
      <div className="p-3 space-y-2">
        <h3 className="font-semibold text-sm text-foreground line-clamp-2 leading-tight group-hover:text-violet-500 transition-colors">
          {product.title}
        </h3>

        {/* Rating & Format */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span>{product.rating.toFixed(1)}</span>
          </div>
          <span>•</span>
          <span className="uppercase text-[10px] font-medium bg-muted px-1.5 py-0.5 rounded">
            {product.format}
          </span>
          <span>•</span>
          <span>{product.fileSize}</span>
        </div>

        {/* Price & Action */}
        <div className="flex items-center justify-between pt-2 border-t border-border/50">
          <div className="flex flex-col">
            <span className={`font-bold text-base ${product.price === 0 ? 'text-emerald-500' : 'text-violet-500'}`}>
              {formatPrice(product.price)}
            </span>
            {product.originalPrice && (
              <span className="text-[10px] text-muted-foreground line-through">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>
          <Button
            size="sm"
            className="h-8 px-3 rounded-full bg-violet-500 hover:bg-violet-600 text-white text-xs"
            onClick={(e) => e.stopPropagation()}
          >
            <Download className="w-3 h-3 mr-1" />
            Get
          </Button>
        </div>

        {/* Seller */}
        <div className="flex items-center gap-2">
          <img
            src={product.seller.avatar}
            alt={product.seller.name}
            className="w-4 h-4 rounded-full object-cover"
          />
          <span className="text-[10px] text-muted-foreground truncate">
            {product.seller.name}
          </span>
        </div>
      </div>
    </motion.div>
  );
};

export default DigitalProductCard;
