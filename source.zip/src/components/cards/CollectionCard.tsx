import React from 'react';
import { ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import type { Collection } from '@/data/mockData';

interface CollectionCardProps {
  collection: Collection;
  onClick?: () => void;
}

const CollectionCard: React.FC<CollectionCardProps> = ({ collection, onClick }) => {
  return (
    <motion.div
      whileHover={{ y: -4, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
      className={`group cursor-pointer relative rounded-2xl overflow-hidden min-w-[200px] max-w-[240px] aspect-[4/5] bg-gradient-to-br ${collection.color}`}
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={collection.image}
          alt={collection.title}
          className="w-full h-full object-cover opacity-30 group-hover:opacity-40 group-hover:scale-110 transition-all duration-500"
        />
      </div>

      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

      {/* Content */}
      <div className="absolute inset-0 p-5 flex flex-col justify-end text-white">
        <h3 className="font-bold text-lg leading-tight">{collection.title}</h3>
        <p className="text-sm text-white/80 mt-1">{collection.description}</p>
        
        <div className="flex items-center justify-between mt-4">
          <span className="text-xs text-white/60">{collection.itemCount} items</span>
          <div className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:bg-white/30 transition-colors">
            <ArrowRight className="w-4 h-4" />
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default CollectionCard;
