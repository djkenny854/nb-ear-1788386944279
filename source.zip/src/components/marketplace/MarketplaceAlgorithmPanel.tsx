import React, { useEffect, useMemo, useState } from 'react';
import {
  ChevronRight,
  Plus,
  MapPin,
  SlidersHorizontal,
  X,
  Loader2,
  Check,
  Map as MapIcon,
  Filter,
  Sparkles,
  Tag,
  ShieldCheck,
  RotateCcw
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import useServiceCategories from '@/hooks/useServiceCategories';
import { useBrands } from '@/hooks/useBrands';
import AlgorithmAISummary from './AlgorithmAISummary';
import MarketplaceMap from './MarketplaceMap';

export type MarketplaceTab = 'products' | 'accounts' | 'jobs' | 'services' | 'promos' | 'deals';

interface TabConfig {
  headline: string;
  moreLabel: string;
  moreSubtitle: string;
  lessLabel: string;
  suggestions: string[];
  extraFilters: string[];
}

const CONFIG: Record<MarketplaceTab, TabConfig> = {
  services: {
    headline: "Lately you've been into home repairs, photography and tailoring.",
    moreLabel: 'What services you want to see more of',
    moreSubtitle: 'Based on your activity, summarised by AI',
    lessLabel: 'What you want to see less of',
    suggestions: ['Near me', 'Plumbing', 'Hair & beauty', 'Cleaning', 'Photography', 'Tutoring', 'Catering', 'Tailoring', 'Mechanics', 'Event planning'],
    extraFilters: ['Verified only', 'Top rated', 'Has portfolio', 'Available today', 'Accepts mobile money', 'Same-day service'],
  },
  jobs: {
    headline: "Lately you've been browsing tech roles, sales gigs and remote work.",
    moreLabel: 'What kinds of jobs you want to see more of',
    moreSubtitle: 'Based on your activity, summarised by AI',
    lessLabel: 'What you want to see less of',
    suggestions: ['Near me', 'Remote', 'Full-time', 'Part-time', 'Internship', 'Contract', 'Software', 'Sales', 'Marketing', 'Driving', 'Customer support', 'Construction', 'Hospitality', 'Healthcare', 'Education'],
    extraFilters: ['Verified employers', 'Posted this week', 'No experience needed', 'Pays in USD', 'Urgent hire'],
  },
  accounts: {
    headline: "Lately you've been following local shops, creators and verified sellers.",
    moreLabel: 'What kinds of accounts you want to see more of',
    moreSubtitle: 'Based on your activity, summarised by AI',
    lessLabel: 'What you want to see less of',
    suggestions: ['Verified only', 'Near me', 'Top rated', 'New sellers', 'Fashion', 'Electronics', 'Food', 'Auto', 'Beauty', 'Home'],
    extraFilters: ['Verified only', 'Active this week', '4+ stars', 'Has video'],
  },
  promos: {
    headline: "Lately you've been into flash deals, weekend discounts and free shipping offers.",
    moreLabel: 'What promotions you want to see more of',
    moreSubtitle: 'Based on your activity, summarised by AI',
    lessLabel: 'What you want to see less of',
    suggestions: ['Near me', 'Flash sales', 'Free shipping', 'BOGO', 'Clearance', 'Fashion', 'Electronics', 'Food & drink', 'Beauty', 'Bundles'],
    extraFilters: ['Ends today', 'Ends in 3 days', 'Ends in 7 days', '50%+ off', 'Verified sellers'],
  },
  deals: {
    headline: "Lately you've been eyeing discounted electronics, fashion and home picks.",
    moreLabel: 'What deals you want to see more of',
    moreSubtitle: 'Based on your activity, summarised by AI',
    lessLabel: 'What you want to see less of',
    suggestions: ['Near me', 'Ending soon', 'Biggest discounts', 'Electronics', 'Fashion', 'Home', 'Beauty', 'Phones', 'Groceries', 'Under 50%'],
    extraFilters: ['Ends today', '50%+ off', 'Verified sellers', 'Free delivery'],
  },
  products: {
    headline: "Lately you've been browsing verified electronics, fashion and trending items.",
    moreLabel: 'What products you want to see more of',
    moreSubtitle: 'Personalized product discovery',
    lessLabel: 'What you want to see less of',
    suggestions: ['Near me', 'Electronics', 'Phones', 'Fashion', 'Home & Living', 'Vehicles', 'Beauty', 'Appliances'],
    extraFilters: ['Verified sellers', 'Brand new', 'On sale', 'Fast delivery', 'Price negotiable'],
  },
};

const PRODUCT_CATEGORIES = [
  'All',
  'Electronics',
  'Phones & Tablets',
  'Fashion',
  'Vehicles',
  'Home & Furniture',
  'Beauty & Personal Care',
  'Real Estate',
  'Agriculture & Food',
  'Sports & Fitness',
];

const PRODUCT_CONDITIONS = [
  { label: 'All', value: '' },
  { label: 'Brand New', value: 'brand_new' },
  { label: 'Refurbished', value: 'refurbished' },
  { label: 'Used - Like New', value: 'used_like_new' },
  { label: 'Used - Good', value: 'used_good' },
];

const PRICE_MAX = 10000000;

const DATE_OPTIONS = [
  { label: 'Any time', value: '' },
  { label: 'Today', value: '1' },
  { label: 'Last 7 days', value: '7' },
  { label: 'Last 30 days', value: '30' },
];

const SELLER_TYPES = [
  { label: 'Anyone', value: '' },
  { label: 'Business', value: 'business' },
  { label: 'Individual', value: 'individual' },
];

const formatUgx = (n: number) => {
  if (n >= 1000000) return `${(n / 1000000).toFixed(n % 1000000 === 0 ? 0 : 1)}M`;
  if (n >= 1000) return `${Math.round(n / 1000)}K`;
  return String(n);
};


const requestNearMe = async (): Promise<boolean> => {
  if (!('geolocation' in navigator)) {
    toast.error('Geolocation is not supported on this device');
    return false;
  }
  return new Promise((resolve) => {
    toast.message('Requesting your location…');
    navigator.geolocation.getCurrentPosition(
      () => {
        toast.success('Location detected — showing results near you');
        resolve(true);
      },
      (err) => {
        toast.error(err.code === err.PERMISSION_DENIED
          ? 'Location permission denied. Enable it in your browser settings.'
          : 'Could not detect your location');
        resolve(false);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  });
};

interface PanelBodyProps {
  tab: MarketplaceTab;
  draftSelected: string[];
  draftExcluded: string[];
  setDraftSelected: (next: string[]) => void;
  setDraftExcluded: (next: string[]) => void;
  onSave: () => void;
  saving?: boolean;
  inDrawer?: boolean;
  // Map and product filter synchronization
  searchQuery?: string;
  productFilters?: any;
  onProductFiltersChange?: (updater: (prev: any) => any) => void;
  onDistrictSelect?: (district: string) => void;
}

const PanelBody: React.FC<PanelBodyProps> = ({
  tab,
  draftSelected,
  draftExcluded,
  setDraftSelected,
  setDraftExcluded,
  onSave,
  saving,
  inDrawer,
  searchQuery = '',
  productFilters,
  onProductFiltersChange,
  onDistrictSelect,
}) => {
  // Internal tab: FILTERS vs MAP (defaults to 'filters')
  const [activeInternalTab, setActiveInternalTab] = useState<'filters' | 'map'>('filters');

  const cfg = CONFIG[tab] || CONFIG.products;
  const { categories } = useServiceCategories();

  const categoryNames = useMemo(() => {
    if (tab === 'services') {
      return (categories || []).filter((c) => !c.parent_id).map((c) => c.name).slice(0, 24);
    }
    return [];
  }, [tab, categories]);

  // Brands — only fetched for the products tab (advanced filters live here now)
  const { brands, loading: brandsLoading } = useBrands(
    tab === 'products' ? { category: productFilters?.category || undefined } : {},
  );
  const brandNames = useMemo(
    () => (tab === 'products' ? Array.from(new Set((brands || []).map((b) => b.name))).slice(0, 40) : []),
    [tab, brands],
  );
  const selectedBrands: string[] = productFilters?.brands || [];
  const priceRange: number[] = Array.isArray(productFilters?.priceRange)
    ? productFilters.priceRange
    : [0, PRICE_MAX];


  const toggleSelected = async (s: string) => {
    if (s === 'Near me' && !draftSelected.includes(s)) {
      const ok = await requestNearMe();
      if (!ok) return;
    }
    setDraftSelected(
      draftSelected.includes(s) ? draftSelected.filter((x) => x !== s) : [...draftSelected, s]
    );
  };

  const toggleExcluded = (s: string) =>
    setDraftExcluded(
      draftExcluded.includes(s) ? draftExcluded.filter((x) => x !== s) : [...draftExcluded, s]
    );

  const allActive = draftSelected.length === 0;
  const visibleSuggestions = cfg.suggestions.filter((s) => !draftSelected.includes(s));
  const visibleCategories = categoryNames.filter((s) => !draftSelected.includes(s));
  const visibleExtras = cfg.extraFilters.filter((s) => !draftSelected.includes(s));

  return (
    <div className="flex flex-col h-full min-h-0 bg-background">
      {/* Top Header: FILTERS | MAP Underline Tabs */}
      <div className="shrink-0 pt-0.5 border-b border-border/40">
        <div className="flex items-center justify-between gap-2 px-1 mb-2">
          <h2 className="text-sm font-bold text-foreground capitalize flex items-center gap-1.5 tracking-tight">
            <span>{tab} Discovery</span>
          </h2>
          <div className="flex items-center gap-1.5">
            {tab !== 'products' && (
              <Badge variant="outline" className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border-border/70 bg-muted/40">
                Algorithm AI
              </Badge>
            )}
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                aria-label="Close filters"
                className="h-7 w-7 rounded-full inline-flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>


        {/* Smooth Underline Tabs: FILTERS | MAP */}
        <div className="flex items-stretch border-b border-border/50 relative">
          <button
            type="button"
            onClick={() => setActiveInternalTab('filters')}
            className={cn(
              'relative flex-1 flex items-center justify-center gap-2 py-2.5 px-3 text-xs font-semibold select-none transition-all duration-200 group',
              activeInternalTab === 'filters'
                ? 'text-foreground font-bold'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted/30'
            )}
          >
            <SlidersHorizontal className={cn(
              'h-3.5 w-3.5 transition-transform duration-200',
              activeInternalTab === 'filters' ? 'text-primary scale-105' : 'text-muted-foreground group-hover:text-foreground'
            )} />
            <span className="tracking-wide">FILTERS</span>
            {(draftSelected.length + draftExcluded.length) > 0 && tab !== 'products' && (
              <span className="ml-1 px-1.5 py-0.2 rounded-full bg-foreground text-background text-[10px] font-bold shadow-xs">
                {draftSelected.length + draftExcluded.length}
              </span>
            )}
            {/* Active bottom underline indicator */}
            {activeInternalTab === 'filters' && (
              <span className="absolute bottom-0 inset-x-2 h-[2.5px] bg-primary rounded-t-full shadow-xs transition-all duration-200" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveInternalTab('map')}
            className={cn(
              'relative flex-1 flex items-center justify-center gap-2 py-2.5 px-3 text-xs font-semibold select-none transition-all duration-200 group',
              activeInternalTab === 'map'
                ? 'text-foreground font-bold'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted/30'
            )}
          >
            <MapIcon className={cn(
              'h-3.5 w-3.5 transition-transform duration-200',
              activeInternalTab === 'map' ? 'text-primary scale-105' : 'text-primary/70 group-hover:text-primary'
            )} />
            <span className="tracking-wide">MAP</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
            {/* Active bottom underline indicator */}
            {activeInternalTab === 'map' && (
              <span className="absolute bottom-0 inset-x-2 h-[2.5px] bg-primary rounded-t-full shadow-xs transition-all duration-200" />
            )}
          </button>
        </div>
      </div>

      {/* BODY CONTENT: FILTERS or MAP */}
      {activeInternalTab === 'map' ? (
        /* MAP VIEW */
        <div className="flex-1 min-h-0 pt-2 pb-1">
          <MarketplaceMap
            tab={tab}
            searchQuery={searchQuery}
            selectedCategory={productFilters?.category || ''}
            selectedDistrict={productFilters?.location || ''}
            onDistrictSelect={(district) => {
              if (onDistrictSelect) onDistrictSelect(district);
              if (onProductFiltersChange) {
                onProductFiltersChange((prev: any) => ({ ...prev, location: district }));
              }
            }}
            compact={inDrawer}
          />
        </div>
      ) : tab === 'products' ? (
        /* PRODUCTS SPECIFIC FILTERS */
        <div className="flex-1 min-h-0 overflow-y-auto pr-1 pb-4 pt-3 space-y-5">
          {/* Quick Categories */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <h3 className="text-xs font-bold text-foreground uppercase tracking-wider">Categories</h3>
              {productFilters?.category && (
                <button
                  type="button"
                  onClick={() => onProductFiltersChange?.((prev: any) => ({ ...prev, category: '', subcategory: '' }))}
                  className="text-[11px] font-semibold text-primary hover:underline transition-colors"
                >
                  Clear
                </button>
              )}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {PRODUCT_CATEGORIES.map((cat) => {
                const isSelected = (cat === 'All' && !productFilters?.category) || productFilters?.category === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => {
                      onProductFiltersChange?.((prev: any) => ({
                        ...prev,
                        category: cat === 'All' ? '' : cat,
                        subcategory: '',
                      }));
                    }}
                    className={cn(
                      'px-3 py-1 rounded-full text-xs font-medium border transition-all duration-200 active:scale-95 select-none',
                      isSelected
                        ? 'bg-foreground text-background border-foreground font-semibold shadow-xs'
                        : 'bg-muted/30 border-border/60 text-muted-foreground hover:text-foreground hover:bg-muted/70 hover:border-border'
                    )}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Condition */}
          <div>
            <h3 className="text-xs font-bold text-foreground uppercase tracking-wider mb-2.5">Condition</h3>
            <div className="flex flex-wrap gap-1.5">
              {PRODUCT_CONDITIONS.map((cond) => {
                const isSelected = (cond.value === '' && !productFilters?.condition) || productFilters?.condition === cond.value;
                return (
                  <button
                    key={cond.label}
                    type="button"
                    onClick={() => {
                      onProductFiltersChange?.((prev: any) => ({
                        ...prev,
                        condition: cond.value,
                      }));
                    }}
                    className={cn(
                      'px-3 py-1 rounded-full text-xs font-medium border transition-all duration-200 active:scale-95 select-none',
                      isSelected
                        ? 'bg-foreground text-background border-foreground font-semibold shadow-xs'
                        : 'bg-muted/30 border-border/60 text-muted-foreground hover:text-foreground hover:bg-muted/70 hover:border-border'
                    )}
                  >
                    {cond.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick Toggles */}
          <div className="space-y-2 pt-3 border-t border-border/40">
            <h3 className="text-xs font-bold text-foreground uppercase tracking-wider mb-1.5">Quick Filters</h3>
            
            <label className="flex items-center justify-between p-2.5 rounded-xl border border-border/60 bg-muted/20 hover:bg-muted/50 cursor-pointer transition-all duration-200 group">
              <span className="text-xs font-semibold text-foreground flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-blue-500 transition-transform group-hover:scale-110" />
                Verified Sellers Only
              </span>
              <input
                type="checkbox"
                checked={Boolean(productFilters?.verifiedOnly)}
                onChange={(e) => onProductFiltersChange?.((prev: any) => ({ ...prev, verifiedOnly: e.target.checked }))}
                className="rounded border-border text-primary focus:ring-primary h-4 w-4 cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between p-2.5 rounded-xl border border-border/60 bg-muted/20 hover:bg-muted/50 cursor-pointer transition-all duration-200 group">
              <span className="text-xs font-semibold text-foreground flex items-center gap-2">
                <Tag className="h-4 w-4 text-amber-500 transition-transform group-hover:scale-110" />
                On Sale / Discounts
              </span>
              <input
                type="checkbox"
                checked={Boolean(productFilters?.onSale)}
                onChange={(e) => onProductFiltersChange?.((prev: any) => ({ ...prev, onSale: e.target.checked }))}
                className="rounded border-border text-primary focus:ring-primary h-4 w-4 cursor-pointer"
              />
            </label>
          </div>

          {/* ── Advanced filters (moved from the old modal) ───────────── */}
          <div className="pt-3 border-t border-border/40 space-y-5">
            <h3 className="text-xs font-bold text-foreground uppercase tracking-wider flex items-center gap-1.5">
              <SlidersHorizontal className="h-3.5 w-3.5 text-primary" />
              Advanced filters
            </h3>

            {/* Price range */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">Price range</h4>
                <span className="text-[11px] font-semibold text-foreground tabular-nums">
                  {formatUgx(priceRange[0])} – {formatUgx(priceRange[1])}
                </span>
              </div>
              <Slider
                value={priceRange}
                min={0}
                max={PRICE_MAX}
                step={50000}
                onValueChange={(v) =>
                  onProductFiltersChange?.((prev: any) => ({ ...prev, priceRange: v }))
                }
                className="my-3"
              />
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  inputMode="numeric"
                  value={priceRange[0]}
                  onChange={(e) =>
                    onProductFiltersChange?.((prev: any) => ({
                      ...prev,
                      priceRange: [Number(e.target.value) || 0, priceRange[1]],
                    }))
                  }
                  className="h-8 rounded-lg text-xs"
                  placeholder="Min"
                />
                <span className="text-xs text-muted-foreground">to</span>
                <Input
                  type="number"
                  inputMode="numeric"
                  value={priceRange[1]}
                  onChange={(e) =>
                    onProductFiltersChange?.((prev: any) => ({
                      ...prev,
                      priceRange: [priceRange[0], Number(e.target.value) || PRICE_MAX],
                    }))
                  }
                  className="h-8 rounded-lg text-xs"
                  placeholder="Max"
                />
              </div>
            </div>

            {/* Brands */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">Brands</h4>
                {selectedBrands.length > 0 && (
                  <button
                    type="button"
                    onClick={() => onProductFiltersChange?.((prev: any) => ({ ...prev, brands: [] }))}
                    className="text-[11px] font-semibold text-primary hover:underline"
                  >
                    Clear
                  </button>
                )}
              </div>
              {brandsLoading ? (
                <div className="flex flex-wrap gap-1.5">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="h-7 w-20 rounded-full bg-muted animate-pulse" />
                  ))}
                </div>
              ) : brandNames.length === 0 ? (
                <p className="text-xs text-muted-foreground">No brands for this category</p>
              ) : (
                <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto pr-1">
                  {brandNames.map((b) => {
                    const on = selectedBrands.includes(b);
                    return (
                      <button
                        key={b}
                        type="button"
                        onClick={() =>
                          onProductFiltersChange?.((prev: any) => {
                            const cur: string[] = prev?.brands || [];
                            return {
                              ...prev,
                              brands: cur.includes(b) ? cur.filter((x) => x !== b) : [...cur, b],
                            };
                          })
                        }
                        className={cn(
                          'px-3 py-1 rounded-full text-xs font-medium border transition-all duration-200 active:scale-95',
                          on
                            ? 'bg-foreground text-background border-foreground font-semibold'
                            : 'bg-muted/30 border-border/60 text-muted-foreground hover:text-foreground hover:bg-muted/70'
                        )}
                      >
                        {b}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Date posted */}
            <div>
              <h4 className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider mb-2">Date posted</h4>
              <div className="flex flex-wrap gap-1.5">
                {DATE_OPTIONS.map((opt) => {
                  const on = (productFilters?.datePosted || '') === opt.value;
                  return (
                    <button
                      key={opt.label}
                      type="button"
                      onClick={() => onProductFiltersChange?.((prev: any) => ({ ...prev, datePosted: opt.value }))}
                      className={cn(
                        'px-3 py-1 rounded-full text-xs font-medium border transition-all duration-200 active:scale-95',
                        on
                          ? 'bg-foreground text-background border-foreground font-semibold'
                          : 'bg-muted/30 border-border/60 text-muted-foreground hover:text-foreground hover:bg-muted/70'
                      )}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Seller type */}
            <div>
              <h4 className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider mb-2">Seller type</h4>
              <div className="flex flex-wrap gap-1.5">
                {SELLER_TYPES.map((opt) => {
                  const on = (productFilters?.sellerType || '') === opt.value;
                  return (
                    <button
                      key={opt.label}
                      type="button"
                      onClick={() => onProductFiltersChange?.((prev: any) => ({ ...prev, sellerType: opt.value }))}
                      className={cn(
                        'px-3 py-1 rounded-full text-xs font-medium border transition-all duration-200 active:scale-95',
                        on
                          ? 'bg-foreground text-background border-foreground font-semibold'
                          : 'bg-muted/30 border-border/60 text-muted-foreground hover:text-foreground hover:bg-muted/70'
                      )}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Media features */}
            <div className="space-y-2">
              <h4 className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">Media</h4>
              {[
                { key: 'hasImages', label: 'Has photos' },
                { key: 'hasVideo', label: 'Has video' },
                { key: 'negotiable', label: 'Price negotiable' },
              ].map((f) => (
                <label
                  key={f.key}
                  className="flex items-center justify-between p-2.5 rounded-xl border border-border/60 bg-muted/20 hover:bg-muted/50 cursor-pointer transition-all duration-200"
                >
                  <span className="text-xs font-semibold text-foreground">{f.label}</span>
                  <input
                    type="checkbox"
                    checked={Boolean(productFilters?.[f.key])}
                    onChange={(e) =>
                      onProductFiltersChange?.((prev: any) => ({ ...prev, [f.key]: e.target.checked }))
                    }
                    className="rounded border-border text-primary focus:ring-primary h-4 w-4 cursor-pointer"
                  />
                </label>
              ))}
            </div>

            {/* Reset */}
            <Button
              type="button"
              variant="outline"
              onClick={() =>
                onProductFiltersChange?.((prev: any) => ({
                  ...prev,
                  category: '',
                  subcategory: '',
                  condition: '',
                  brands: [],
                  priceRange: [0, PRICE_MAX],
                  datePosted: '',
                  sellerType: '',
                  verifiedOnly: false,
                  onSale: false,
                  hasImages: false,
                  hasVideo: false,
                  negotiable: false,
                }))
              }
              className="w-full h-9 rounded-full text-xs font-semibold gap-2 border-border/70 hover:bg-muted"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Reset all filters
            </Button>
          </div>

        </div>
      ) : (
        /* ALGORITHM CUSTOMIZATION FILTERS (Services, Accounts, Promos, Deals, Jobs) */
        <div className="flex-1 min-h-0 flex flex-col">
          <div className="flex-1 min-h-0 overflow-y-auto pr-1 pb-4 pt-3">
            {/* Big AI headline */}
            <AlgorithmAISummary tab={tab} selected={draftSelected} excluded={draftExcluded} />

            {/* More of */}
            <div className="mt-6">
              <h3 className="text-sm font-semibold text-foreground">{cfg.moreLabel}</h3>
              <button className="mt-0.5 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors">
                {cfg.moreSubtitle}
                <ChevronRight className="h-3 w-3" />
              </button>

              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => setDraftSelected([])}
                  className={cn(
                    'px-3.5 h-8 rounded-full text-xs font-medium border transition-colors',
                    allActive
                      ? 'bg-foreground text-background border-foreground'
                      : 'bg-transparent border-border text-foreground hover:bg-muted'
                  )}
                >
                  All
                </button>

                {draftSelected.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => toggleSelected(s)}
                    className="px-3.5 h-8 rounded-full text-xs font-medium bg-foreground text-background border border-foreground transition-colors inline-flex items-center gap-1.5"
                  >
                    {s}
                    <X className="h-3 w-3" />
                  </button>
                ))}

                {visibleSuggestions.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => toggleSelected(s)}
                    className="px-3.5 h-8 rounded-full text-xs font-medium bg-transparent border border-border/70 text-muted-foreground hover:text-foreground hover:border-border transition-colors inline-flex items-center gap-1.5"
                  >
                    {s === 'Near me' ? <MapPin className="h-3 w-3" /> : <Plus className="h-3 w-3" />}
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Categories */}
            {visibleCategories.length > 0 && (
              <div className="mt-6">
                <h3 className="text-sm font-semibold text-foreground">Categories</h3>
                <p className="mt-0.5 text-xs text-muted-foreground">Pick categories to feature</p>
                <div className="mt-2.5 flex flex-wrap gap-2">
                  {visibleCategories.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => toggleSelected(s)}
                      className="px-3.5 h-8 rounded-full text-xs font-medium bg-transparent border border-border/70 text-muted-foreground hover:text-foreground hover:border-border transition-colors inline-flex items-center gap-1.5"
                    >
                      <Plus className="h-3 w-3" />
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Extra filters */}
            {visibleExtras.length > 0 && (
              <div className="mt-6">
                <h3 className="text-sm font-semibold text-foreground">More filters</h3>
                <p className="mt-0.5 text-xs text-muted-foreground">Refine results</p>
                <div className="mt-2.5 flex flex-wrap gap-2">
                  {visibleExtras.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => toggleSelected(s)}
                      className="px-3.5 h-8 rounded-full text-xs font-medium bg-transparent border border-border/70 text-muted-foreground hover:text-foreground hover:border-border transition-colors inline-flex items-center gap-1.5"
                    >
                      <Plus className="h-3 w-3" />
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Less of */}
            <div className="mt-6">
              <h3 className="text-sm font-semibold text-foreground">{cfg.lessLabel}</h3>
              <div className="mt-2.5 flex flex-wrap gap-2">
                {draftExcluded.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => toggleExcluded(s)}
                    className="px-3.5 h-8 rounded-full text-xs font-medium bg-muted text-foreground border border-border hover:bg-muted/70 transition-colors inline-flex items-center gap-1.5"
                  >
                    {s}
                    <X className="h-3 w-3" />
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => {
                    const v = window.prompt('Add something to see less of');
                    if (v && !draftExcluded.includes(v)) toggleExcluded(v);
                  }}
                  className="px-3.5 h-8 rounded-full text-xs font-medium bg-transparent border border-border/70 text-muted-foreground hover:text-foreground hover:border-border transition-colors inline-flex items-center gap-1.5"
                >
                  <Plus className="h-3 w-3" />
                  Add
                </button>
              </div>
            </div>

            <div className="h-4" aria-hidden />
          </div>

          {/* Fixed save bar */}
          <div className={cn(
            'shrink-0 pt-3 pb-2 bg-gradient-to-t from-background via-background/95 to-background/70 border-t border-border/40',
            inDrawer && 'pb-4'
          )}>
            <Button
              onClick={onSave}
              disabled={saving}
              className="w-full h-10 rounded-full font-semibold text-xs"
            >
              {saving ? (
                <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Saving…</>
              ) : (
                <><Check className="h-4 w-4 mr-2" /> Save & apply</>
              )}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export interface MarketplaceAlgorithmPanelProps {
  tab: MarketplaceTab;
  selected?: string[];
  excluded?: string[];
  onApply?: (next: { selected: string[]; excluded: string[] }) => void;
  variant?: 'sidebar' | 'mobile-trigger';
  open?: boolean;
  onOpenChange?: (v: boolean) => void;
  hideTrigger?: boolean;
  searchQuery?: string;
  productFilters?: any;
  onProductFiltersChange?: (updater: (prev: any) => any) => void;
  onDistrictSelect?: (district: string) => void;
}

const MarketplaceAlgorithmPanel: React.FC<MarketplaceAlgorithmPanelProps> = ({
  tab,
  selected = [],
  excluded = [],
  onApply,
  variant,
  open: openProp,
  onOpenChange,
  hideTrigger,
  searchQuery,
  productFilters,
  onProductFiltersChange,
  onDistrictSelect,
}) => {
  const [openInternal, setOpenInternal] = useState(false);
  const isControlled = openProp !== undefined;
  const open = isControlled ? openProp! : openInternal;
  const setOpen = (v: boolean) => {
    if (isControlled) onOpenChange?.(v);
    else setOpenInternal(v);
  };
  const [saving, setSaving] = useState(false);

  // Local draft — syncs from props
  const [draftSelected, setDraftSelected] = useState<string[]>(selected);
  const [draftExcluded, setDraftExcluded] = useState<string[]>(excluded);

  useEffect(() => setDraftSelected(selected), [selected, tab]);
  useEffect(() => setDraftExcluded(excluded), [excluded, tab]);

  const handleSave = async () => {
    setSaving(true);
    if (onApply) {
      onApply({ selected: draftSelected, excluded: draftExcluded });
    }
    await new Promise((r) => setTimeout(r, 300));
    setSaving(false);
    setOpen(false);
    toast.success('Your preferences have been updated');
  };

  const showSidebar = variant !== 'mobile-trigger';
  const showMobile = variant !== 'sidebar';

  return (
    <>
      {showSidebar && (
        <aside className="hidden lg:block w-[360px] xl:w-[410px] shrink-0">
          <div className="sticky top-16 h-[calc(100vh-4.5rem)] overflow-hidden pl-2 pr-1 pt-0 pb-2 flex flex-col">
            <PanelBody
              tab={tab}
              draftSelected={draftSelected}
              draftExcluded={draftExcluded}
              setDraftSelected={setDraftSelected}
              setDraftExcluded={setDraftExcluded}
              onSave={handleSave}
              saving={saving}
              searchQuery={searchQuery}
              productFilters={productFilters}
              onProductFiltersChange={onProductFiltersChange}
              onDistrictSelect={onDistrictSelect}
            />
          </div>
        </aside>
      )}

      {showMobile && (
        <div className="lg:hidden">
          <Sheet open={open} onOpenChange={setOpen}>
            {!hideTrigger && (
              <SheetTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="rounded-full gap-1.5 h-9 px-3 text-xs"
                >
                  <SlidersHorizontal className="h-3.5 w-3.5" />
                  Filters & Map
                  {(selected.length + excluded.length) > 0 && (
                    <span className="ml-1 inline-flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full bg-foreground text-background text-[10px] font-semibold">
                      {selected.length + excluded.length}
                    </span>
                  )}
                </Button>
              </SheetTrigger>
            )}
            <SheetContent side="bottom" className="h-[90vh] rounded-t-3xl flex flex-col p-4">
              <PanelBody
                tab={tab}
                draftSelected={draftSelected}
                draftExcluded={draftExcluded}
                setDraftSelected={setDraftSelected}
                setDraftExcluded={setDraftExcluded}
                onSave={handleSave}
                saving={saving}
                inDrawer
                searchQuery={searchQuery}
                productFilters={productFilters}
                onProductFiltersChange={onProductFiltersChange}
                onDistrictSelect={onDistrictSelect}
              />
            </SheetContent>
          </Sheet>
        </div>
      )}
    </>
  );
};

export default MarketplaceAlgorithmPanel;
