import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Search, Bookmark, Mic, ImageIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { useAppSettings } from '@/hooks/useAppSettings';
import MarketplaceSearchDropdown from './MarketplaceSearchDropdown';
import ImageSearchDialog from './ImageSearchDialog';
import { logSearch } from '@/utils/searchHistory';

const PLACEHOLDERS = [
  'Search products, services, sellers…',
  "Try 'iPhone 15 in Kampala'",
  'Find a plumber, tailor, tutor…',
  "Try 'used MacBook Pro under 3m'",
  'Browse jobs, events, promos…',
  "Try '2 bedroom apartment Ntinda'",
];

const RECENT_KEY = 'em_recent_searches';

function pushRecent(q: string, enabled: boolean) {
  if (!enabled) return;
  try {
    const prev: string[] = JSON.parse(localStorage.getItem(RECENT_KEY) || '[]');
    const next = [q, ...prev.filter((p) => p.toLowerCase() !== q.toLowerCase())].slice(0, 5);
    localStorage.setItem(RECENT_KEY, JSON.stringify(next));
  } catch {}
}

interface Props {
  onSearch?: (q: string) => void;
  initialValue?: string;
  className?: string;
}

const MarketplaceSearchBar: React.FC<Props> = ({ onSearch, initialValue = '', className }) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { settings } = useAppSettings();
  const historyEnabled = settings?.save_search_history !== false;

  const [value, setValue] = useState(initialValue);
  const [open, setOpen] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [phIndex, setPhIndex] = useState(0);
  const [recording, setRecording] = useState(false);
  const [imageOpen, setImageOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Rotate placeholder while idle
  useEffect(() => {
    if (isFocused || value) return;
    const t = setInterval(() => setPhIndex((i) => (i + 1) % PLACEHOLDERS.length), 2800);
    return () => clearInterval(t);
  }, [isFocused, value]);

  // Close dropdown on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  // Keep input in sync with parent
  useEffect(() => { setValue(initialValue); }, [initialValue]);

  const submit = useCallback((q: string) => {
    const trimmed = q.trim();
    if (!trimmed) return;
    pushRecent(trimmed, historyEnabled);
    if (historyEnabled) logSearch(trimmed, 'marketplace');
    setOpen(false);
    inputRef.current?.blur();
    if (onSearch) onSearch(trimmed);
    else navigate(`/search?q=${encodeURIComponent(trimmed)}`);
  }, [navigate, onSearch, historyEnabled]);

  const handleVoice = () => {
    const SR = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if (!SR) {
      toast({ title: 'Not supported', description: 'Voice search is not available in this browser', variant: 'destructive' });
      return;
    }
    const recognition = new SR();
    recognition.lang = 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onstart = () => { setRecording(true); toast({ title: 'Listening…' }); };
    recognition.onresult = (e: any) => {
      const transcript = e.results[0][0].transcript;
      setValue(transcript);
      submit(transcript);
    };
    recognition.onerror = () => setRecording(false);
    recognition.onend = () => setRecording(false);
    try { recognition.start(); } catch { setRecording(false); }
  };

  return (
    <div ref={wrapRef} className={cn('relative w-full', className)}>
      <div
        className={cn(
          'group flex items-center gap-1 h-9 md:h-11 pl-3 md:pl-4 pr-1.5 rounded-full bg-transparent border border-border/50 transition-all duration-200',
          isFocused && 'border-primary/40 ring-2 ring-primary/15 bg-background/30'
        )}
      >
        <Search className="w-4 h-4 md:w-[18px] md:h-[18px] text-muted-foreground shrink-0" strokeWidth={2} />

        <input
          ref={inputRef}
          type="text"
          value={value}
          onChange={(e) => { setValue(e.target.value); if (!open) setOpen(true); }}
          onFocus={() => { setIsFocused(true); setOpen(true); }}
          onBlur={() => setIsFocused(false)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') submit(value);
            if (e.key === 'Escape') { setOpen(false); inputRef.current?.blur(); }
          }}
          placeholder={PLACEHOLDERS[phIndex]}
          className="flex-1 h-full bg-transparent border-none outline-none text-xs md:text-[15px] text-foreground placeholder:text-muted-foreground/70 placeholder:text-xs md:placeholder:text-[15px] min-w-0 px-2 md:px-3"
        />

        <button
          onClick={() => navigate('/bookmarks')}
          className="h-8 w-8 shrink-0 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/70 transition-colors"
          aria-label="Saved"
          title="Saved"
        >
          <Bookmark className="w-[18px] h-[18px]" strokeWidth={2} />
        </button>

        <button
          onClick={handleVoice}
          className={cn(
            'h-8 w-8 shrink-0 rounded-full flex items-center justify-center transition-colors',
            recording
              ? 'bg-destructive/15 text-destructive animate-pulse'
              : 'text-muted-foreground hover:text-foreground hover:bg-muted/70'
          )}
          aria-label="Voice search"
          title="Voice search"
        >
          <Mic className="w-[18px] h-[18px]" strokeWidth={2} />
        </button>

        <button
          onClick={() => setImageOpen(true)}
          className="h-8 px-3 shrink-0 rounded-full flex items-center gap-1.5 text-sm font-medium bg-gradient-to-r from-primary/10 to-primary/5 text-primary hover:from-primary/15 hover:to-primary/10 transition-colors"
          aria-label="Search by image"
          title="Visual search"
        >
          <ImageIcon className="w-[15px] h-[15px]" strokeWidth={2} />
          <span className="hidden sm:inline">Visual</span>
        </button>
      </div>

      {open && (
        <MarketplaceSearchDropdown
          query={value}
          onSelect={(q) => { setValue(q); submit(q); }}
          onClose={() => setOpen(false)}
        />
      )}

      <ImageSearchDialog open={imageOpen} onOpenChange={setImageOpen} />
    </div>
  );
};

export default MarketplaceSearchBar;
