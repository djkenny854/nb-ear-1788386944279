import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';

const ROTATING = [
  { line1: 'What are you', line2: 'trying to get done?' },
  { line1: 'Find someone to', line2: 'fix it, build it, design it.' },
  { line1: 'Hire trusted pros', line2: 'right here in Uganda.' },
  { line1: 'Real portfolios.', line2: 'Real reviews. Real people.' },
  { line1: 'From plumbers to', line2: 'photographers — book today.' },
];

/**
 * Centered, transparent headline above the Services tab.
 * No background, no chip, no subtitle, no scroll-driven animation —
 * the hero scrolls off naturally with the page.
 */
const ServicesHero: React.FC = () => {
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setIdx((p) => (p + 1) % ROTATING.length), 3800);
    return () => clearInterval(t);
  }, []);

  const current = ROTATING[idx];

  return (
    <section
      aria-label="Services tagline"
      className="mb-2 px-2 md:px-4 py-6 md:py-10 text-center"
    >
      <div className="min-h-[5.5rem] md:min-h-[7rem] flex items-center justify-center">
        <AnimatePresence mode="wait">
          <motion.h1
            key={idx}
            initial={{ opacity: 0, filter: 'blur(14px)', y: 12 }}
            animate={{ opacity: 1, filter: 'blur(0px)', y: 0 }}
            exit={{ opacity: 0, filter: 'blur(14px)', y: -12 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            className="text-3xl md:text-5xl font-bold tracking-tight leading-[1.05] text-foreground"
          >
            <span className="block">{current.line1}</span>
            <span className="block bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              {current.line2}
            </span>
          </motion.h1>
        </AnimatePresence>
      </div>
    </section>
  );
};

export default ServicesHero;
