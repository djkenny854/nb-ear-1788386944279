import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import {
  MapPin,
  Navigation,
  Crosshair,
  Search,
  SlidersHorizontal,
  X,
  Layers,
  Sparkles,
  Store,
  Briefcase,
  Wrench,
  Percent,
  Tag,
  Star,
  ExternalLink,
  ChevronRight,
  Maximize2,
  Minimize2,
  RefreshCw,
  Eye,
  MessageSquare,
  ShieldCheck,
  Compass
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import {
  Map,
  MapControls,
  MapMarker,
  MarkerContent,
  useMap
} from '@/components/ui/map';
import {
  resolveUgandaCoordinates,
  calculateDistanceKm,
  formatDistance,
  POPULAR_UGANDA_CITIES,
  UGANDA_DISTRICT_COORDS
} from '@/lib/ugandaGeo';
import UnifiedVerifiedBadge from '@/components/UnifiedVerifiedBadge';
import { toast } from 'sonner';

export type MarketplaceMapTab = 'products' | 'services' | 'accounts' | 'jobs' | 'promos' | 'deals';

export interface MapItem {
  id: string;
  title: string;
  subtitle?: string;
  price?: number | null;
  originalPrice?: number | null;
  imageUrl?: string | null;
  type: MarketplaceMapTab;
  locationName: string;
  district: string;
  lat: number;
  lng: number;
  distanceKm?: number | null;
  rating?: number | null;
  reviewCount?: number | null;
  isVerified?: boolean;
  isOnline?: boolean;
  badgeText?: string;
  sellerId?: string;
  sellerName?: string;
  category?: string;
}

interface MarketplaceMapProps {
  tab: MarketplaceMapTab;
  searchQuery?: string;
  selectedCategory?: string;
  selectedDistrict?: string;
  onDistrictSelect?: (district: string) => void;
  className?: string;
  compact?: boolean;
}

// Controller component to smoothly fly/pan the map when requested
const MapViewController: React.FC<{
  center: [number, number];
  zoom: number;
}> = ({ center, zoom }) => {
  const { map } = useMap();
  const prevCenterRef = useRef<[number, number]>(center);

  useEffect(() => {
    if (!map) return;
    const [lng, lat] = center;
    const [prevLng, prevLat] = prevCenterRef.current;
    
    // Only fly if coordinates significantly changed
    if (Math.abs(lng - prevLng) > 0.0001 || Math.abs(lat - prevLat) > 0.0001) {
      map.flyTo({
        center: [lng, lat],
        zoom,
        duration: 1200,
        essential: true,
      });
      prevCenterRef.current = [lng, lat];
    }
  }, [map, center, zoom]);

  return null;
};

export const MarketplaceMap: React.FC<MarketplaceMapProps> = ({
  tab,
  searchQuery = '',
  selectedCategory = '',
  selectedDistrict = '',
  onDistrictSelect,
  className,
  compact = false,
}) => {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<'map' | 'list'>('map');
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locatingUser, setLocatingUser] = useState(false);
  const [selectedRadiusKm, setSelectedRadiusKm] = useState<number | null>(null);
  const [locationSearch, setLocationSearch] = useState('');
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Map center state: defaults to Kampala [32.5825, 0.3476]
  const [mapCenter, setMapCenter] = useState<[number, number]>([32.5825, 0.3476]);
  const [mapZoom, setMapZoom] = useState<number>(11);

  // Auto-pan if selectedDistrict changes from parent
  useEffect(() => {
    if (selectedDistrict) {
      const key = selectedDistrict.toLowerCase().replace(/[^a-z]/g, '');
      const d = UGANDA_DISTRICT_COORDS[key];
      if (d) {
        setMapCenter([d.lng, d.lat]);
        setMapZoom(12);
      }
    }
  }, [selectedDistrict]);

  // Request user GPS
  const handleRequestNearMe = () => {
    if (!('geolocation' in navigator)) {
      toast.error('Geolocation is not supported on this device');
      return;
    }
    setLocatingUser(true);
    toast.message('Detecting your location in Uganda…');

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const coords = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        };
        setUserLocation(coords);
        setMapCenter([coords.lng, coords.lat]);
        setMapZoom(13.5);
        setSelectedRadiusKm(10); // Default to 10km radius
        setLocatingUser(false);
        toast.success('Found your location! Showing nearby commerce');
      },
      (err) => {
        setLocatingUser(false);
        toast.error(
          err.code === err.PERMISSION_DENIED
            ? 'Location permission denied. You can still browse by district.'
            : 'Could not detect your GPS location.'
        );
      },
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 60000 }
    );
  };

  // Fetch marketplace data based on active tab
  const { data: rawItems = [], isLoading, refetch } = useQuery({
    queryKey: ['marketplace-map-items', tab, searchQuery, selectedCategory],
    queryFn: async () => {
      let results: MapItem[] = [];

      if (tab === 'products' || tab === 'deals') {
        let q = supabase
          .from('ads')
          .select(`
            id,
            title,
            price,
            original_price,
            images,
            category,
            subcategory,
            location,
            listing_type,
            has_discount,
            is_boosted,
            seller_id,
            seller_profiles!ads_seller_id_fkey (
              id,
              business_name,
              business_logo_url,
              district,
              sub_county,
              latitude,
              longitude,
              is_verified,
              avg_rating,
              rating_count
            )
          `)
          .limit(80);

        if (tab === 'deals') {
          q = q.or('has_discount.eq.true,is_boosted.eq.true');
        }

        if (searchQuery.trim()) {
          q = q.ilike('title', `%${searchQuery.trim()}%`);
        }

        if (selectedCategory && selectedCategory !== 'all') {
          q = q.ilike('category', `%${selectedCategory}%`);
        }

        const { data, error } = await q;
        if (error) {
          console.warn('[MarketplaceMap] ads query notice, attempting fallback:', error.message);
          // Fallback query without foreign key alias
          const fallbackRes = await supabase
            .from('ads')
            .select(`
              id,
              title,
              price,
              original_price,
              images,
              category,
              subcategory,
              location,
              listing_type,
              has_discount,
              is_boosted,
              seller_id
            `)
            .limit(80);
          
          if (fallbackRes.data) {
            results = fallbackRes.data.map((row: any) => {
              const resolved = resolveUgandaCoordinates(
                row.location,
                row.location,
                null,
                row.id
              );
              return {
                id: row.id,
                title: row.title,
                subtitle: 'Uganda Verified Seller',
                price: row.price,
                originalPrice: row.original_price,
                imageUrl: row.images?.[0] || null,
                type: tab,
                locationName: row.location || resolved.districtName,
                district: resolved.districtName,
                lat: resolved.lat,
                lng: resolved.lng,
                rating: 4.8,
                reviewCount: 10,
                isVerified: true,
                sellerId: row.seller_id,
                category: row.category,
                badgeText: row.has_discount ? 'SALE' : undefined,
              };
            });
          }
        }

        if (data) {
          results = data.map((row: any) => {
            const seller = Array.isArray(row.seller_profiles)
              ? row.seller_profiles[0]
              : row.seller_profiles;

            const sellerCoords =
              seller?.latitude && seller?.longitude
                ? { lat: Number(seller.latitude), lng: Number(seller.longitude) }
                : null;

            const targetLocation = row.location || seller?.district || seller?.sub_county;
            const targetDistrict = seller?.district || row.location;

            const resolved = resolveUgandaCoordinates(
              targetLocation,
              targetDistrict,
              sellerCoords,
              row.id
            );

            return {
              id: row.id,
              title: row.title,
              subtitle: seller?.business_name || 'Verified Merchant',
              price: row.price,
              originalPrice: row.original_price,
              imageUrl: row.images?.[0] || null,
              type: tab,
              locationName: row.location || (seller?.district ? `${seller.district}` : resolved.districtName),
              district: resolved.districtName,
              lat: resolved.lat,
              lng: resolved.lng,
              rating: seller?.avg_rating || 4.8,
              reviewCount: seller?.rating_count || 12,
              isVerified: seller?.is_verified ?? true,
              sellerId: seller?.id || row.seller_id,
              sellerName: seller?.business_name,
              category: row.category,
              badgeText: row.has_discount ? 'SALE' : undefined,
            };
          });
        }
      } else if (tab === 'services') {
        // Query both service listings from ads and service providers from seller_profiles
        try {
          const [adsRes, sellersRes] = await Promise.all([
            supabase
              .from('ads')
              .select(`
                id,
                title,
                price,
                images,
                category,
                subcategory,
                location,
                seller_id,
                seller_profiles!ads_seller_id_fkey (
                  id,
                  business_name,
                  business_logo_url,
                  district,
                  sub_county,
                  latitude,
                  longitude,
                  is_verified,
                  avg_rating,
                  rating_count
                )
              `)
              .eq('listing_type', 'services')
              .limit(50),
            supabase
              .from('seller_profiles')
              .select(`
                id,
                business_name,
                business_bio,
                business_logo_url,
                district,
                sub_county,
                latitude,
                longitude,
                is_verified,
                avg_rating,
                rating_count,
                primary_focus,
                business_category,
                current_service_status
              `)
              .or('primary_focus.eq.services,services_count.gt.0,business_category.ilike.%service%')
              .limit(40)
          ]);

          const serviceAds = (adsRes.data || []).map((row: any) => {
            const seller = Array.isArray(row.seller_profiles)
              ? row.seller_profiles[0]
              : row.seller_profiles;

            const sellerCoords =
              seller?.latitude && seller?.longitude
                ? { lat: Number(seller.latitude), lng: Number(seller.longitude) }
                : null;

            const targetLocation = row.location || seller?.district || seller?.sub_county;
            const targetDistrict = seller?.district || row.location;

            const resolved = resolveUgandaCoordinates(
              targetLocation,
              targetDistrict,
              sellerCoords,
              row.id
            );

            return {
              id: row.id,
              title: row.title,
              subtitle: seller?.business_name || 'Professional Service',
              price: row.price,
              imageUrl: row.images?.[0] || null,
              type: 'services' as MarketplaceMapTab,
              locationName: row.location || (seller?.district ? `${seller.district}` : resolved.districtName),
              district: resolved.districtName,
              lat: resolved.lat,
              lng: resolved.lng,
              rating: seller?.avg_rating || 4.9,
              reviewCount: seller?.rating_count || 14,
              isVerified: seller?.is_verified ?? true,
              sellerId: seller?.id || row.seller_id,
              sellerName: seller?.business_name,
              category: row.category || 'Services',
              badgeText: 'Service',
            };
          });

          const serviceSellers = (sellersRes.data || []).map((seller: any) => {
            const sellerCoords =
              seller.latitude && seller.longitude
                ? { lat: Number(seller.latitude), lng: Number(seller.longitude) }
                : null;

            const resolved = resolveUgandaCoordinates(
              seller.district || seller.sub_county,
              seller.district,
              sellerCoords,
              seller.id
            );

            return {
              id: seller.id,
              title: seller.business_name || 'Professional Service',
              subtitle: seller.business_category || 'Service Provider',
              imageUrl: seller.business_logo_url || null,
              type: 'services' as MarketplaceMapTab,
              locationName: seller.district || resolved.districtName,
              district: resolved.districtName,
              lat: resolved.lat,
              lng: resolved.lng,
              rating: seller.avg_rating || 4.9,
              reviewCount: seller.rating_count || 18,
              isVerified: seller.is_verified ?? true,
              sellerId: seller.id,
              sellerName: seller.business_name,
              category: seller.business_category || 'Services',
              badgeText: seller.current_service_status === 'available' ? 'Available Today' : 'Verified Pro',
            };
          });

          // Combine with deduplication
          const seenIds = new Set<string>();
          results = [];
          for (const item of [...serviceAds, ...serviceSellers]) {
            if (!seenIds.has(item.id)) {
              seenIds.add(item.id);
              results.push(item);
            }
          }
        } catch (err: any) {
          console.warn('[MarketplaceMap] services error:', err.message);
        }
      } else if (tab === 'accounts') {
        let q = supabase
          .from('seller_profiles')
          .select(`
            id,
            business_name,
            business_bio,
            business_logo_url,
            district,
            sub_county,
            latitude,
            longitude,
            is_verified,
            avg_rating,
            rating_count,
            primary_focus,
            business_category
          `)
          .limit(80);

        if (searchQuery.trim()) {
          q = q.ilike('business_name', `%${searchQuery.trim()}%`);
        }

        const { data, error } = await q;
        if (data) {
          results = data.map((seller: any) => {
            const sellerCoords = seller.latitude && seller.longitude
              ? { lat: Number(seller.latitude), lng: Number(seller.longitude) }
              : null;

            const resolved = resolveUgandaCoordinates(
              seller.district || seller.sub_county,
              seller.district,
              sellerCoords,
              seller.id
            );

            return {
              id: seller.id,
              title: seller.business_name || 'EarlyMarket Seller',
              subtitle: seller.business_category || 'Verified Business',
              imageUrl: seller.business_logo_url || null,
              type: 'accounts' as MarketplaceMapTab,
              locationName: seller.district || resolved.districtName,
              district: resolved.districtName,
              lat: resolved.lat,
              lng: resolved.lng,
              rating: seller.avg_rating || 4.8,
              reviewCount: seller.rating_count || 15,
              isVerified: seller.is_verified ?? true,
              sellerId: seller.id,
              sellerName: seller.business_name,
              category: seller.business_category || 'Merchant',
              badgeText: seller.is_verified ? 'Verified Store' : undefined,
            };
          });
        }
      } else if (tab === 'promos') {
        // Query promotions and discounted items
        try {
          const { data, error } = await supabase
            .from('ads')
            .select(`
              id,
              title,
              price,
              original_price,
              images,
              category,
              location,
              seller_id,
              has_discount,
              is_boosted,
              seller_profiles!ads_seller_id_fkey (
                id,
                business_name,
                business_logo_url,
                district,
                sub_county,
                latitude,
                longitude,
                is_verified,
                avg_rating
              )
            `)
            .or('has_discount.eq.true,listing_type.eq.promotions,is_boosted.eq.true')
            .limit(80);

          if (data && data.length > 0) {
            results = data.map((row: any) => {
              const seller = Array.isArray(row.seller_profiles)
                ? row.seller_profiles[0]
                : row.seller_profiles;

              const sellerCoords = seller?.latitude && seller?.longitude
                ? { lat: Number(seller.latitude), lng: Number(seller.longitude) }
                : null;

              const resolved = resolveUgandaCoordinates(
                row.location || seller?.district || seller?.sub_county,
                seller?.district || row.location,
                sellerCoords,
                row.id
              );

              const discountPct = row.original_price && row.price && row.original_price > row.price
                ? Math.round(((row.original_price - row.price) / row.original_price) * 100)
                : null;

              return {
                id: row.id,
                title: row.title,
                subtitle: seller?.business_name || 'Special Promotion',
                price: row.price,
                originalPrice: row.original_price,
                imageUrl: row.images?.[0] || null,
                type: 'promos' as MarketplaceMapTab,
                locationName: row.location || (seller?.district ? `${seller.district}` : resolved.districtName),
                district: resolved.districtName,
                lat: resolved.lat,
                lng: resolved.lng,
                rating: seller?.avg_rating || 4.9,
                isVerified: seller?.is_verified ?? true,
                sellerId: seller?.id || row.seller_id,
                sellerName: seller?.business_name,
                category: row.category,
                badgeText: discountPct ? `-${discountPct}% OFF` : 'SPECIAL PROMO',
              };
            });
          }
        } catch (err: any) {
          console.warn('[MarketplaceMap] promos query notice:', err.message);
        }
      } else if (tab === 'jobs') {
        // Query jobs
        try {
          const { data, error } = await supabase
            .from('ads')
            .select(`
              id,
              title,
              price,
              images,
              category,
              location,
              seller_id,
              seller_profiles!ads_seller_id_fkey (
                id,
                business_name,
                business_logo_url,
                district,
                sub_county,
                latitude,
                longitude,
                is_verified
              )
            `)
            .eq('listing_type', 'jobs')
            .limit(60);

          if (data) {
            results = data.map((row: any) => {
              const seller = Array.isArray(row.seller_profiles)
                ? row.seller_profiles[0]
                : row.seller_profiles;

              const sellerCoords = seller?.latitude && seller?.longitude
                ? { lat: Number(seller.latitude), lng: Number(seller.longitude) }
                : null;

              const resolved = resolveUgandaCoordinates(
                row.location || seller?.district || seller?.sub_county,
                seller?.district || row.location,
                sellerCoords,
                row.id
              );

              return {
                id: row.id,
                title: row.title,
                subtitle: seller?.business_name || 'Hiring Employer',
                price: row.price,
                imageUrl: row.images?.[0] || null,
                type: 'jobs' as MarketplaceMapTab,
                locationName: row.location || (seller?.district ? `${seller.district}` : resolved.districtName),
                district: resolved.districtName,
                lat: resolved.lat,
                lng: resolved.lng,
                rating: 4.8,
                isVerified: seller?.is_verified ?? true,
                sellerId: seller?.id || row.seller_id,
                sellerName: seller?.business_name,
                category: row.category || 'Jobs',
                badgeText: 'Hiring',
              };
            });
          }
        } catch (err: any) {
          console.warn('[MarketplaceMap] jobs query notice:', err.message);
        }
      } else {
        results = [];
      }

      return results;
    },
    staleTime: 60000,
  });

  // Calculate distance for each item if userLocation is available
  const itemsWithDistance = useMemo(() => {
    return rawItems.map((item) => {
      let distanceKm: number | null = null;
      if (userLocation) {
        distanceKm = calculateDistanceKm(
          userLocation.lat,
          userLocation.lng,
          item.lat,
          item.lng
        );
      }
      return {
        ...item,
        distanceKm,
      };
    });
  }, [rawItems, userLocation]);

  // Filter items by radius if user selected a radius
  const filteredItems = useMemo(() => {
    let list = itemsWithDistance;
    if (selectedRadiusKm && userLocation) {
      list = list.filter((item) => item.distanceKm != null && item.distanceKm <= selectedRadiusKm);
    }
    // Sort by distance if GPS active
    if (userLocation) {
      list = [...list].sort((a, b) => (a.distanceKm ?? 9999) - (b.distanceKm ?? 9999));
    }
    return list;
  }, [itemsWithDistance, selectedRadiusKm, userLocation]);

  // Selected item object for card preview
  const selectedItem = useMemo(() => {
    if (!selectedItemId) return null;
    return filteredItems.find((i) => i.id === selectedItemId) || null;
  }, [selectedItemId, filteredItems]);

  // Handle item click action
  const handleItemAction = (item: MapItem) => {
    if (item.type === 'products' || item.type === 'deals') {
      navigate(`/ad/${item.id}`);
    } else if (item.type === 'services') {
      navigate(item.sellerId ? `/seller/${item.sellerId}` : `/service/${item.id}`);
    } else if (item.type === 'accounts') {
      navigate(`/seller/${item.id}`);
    } else if (item.type === 'promos') {
      navigate(`/promotion/${item.id}`);
    } else {
      navigate(`/ad/${item.id}`);
    }
  };

  // Quick jump to Uganda city
  const handleCityJump = (city: (typeof POPULAR_UGANDA_CITIES)[0]) => {
    setMapCenter(city.coords);
    setMapZoom(city.zoom);
    if (onDistrictSelect) onDistrictSelect(city.name);
    toast.message(`Exploring ${city.name}`);
  };

  // District cluster summary for header badge
  const districtCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    filteredItems.forEach((item) => {
      counts[item.district] = (counts[item.district] || 0) + 1;
    });
    return counts;
  }, [filteredItems]);

  return (
    <div
      className={cn(
        'relative flex flex-col w-full h-full min-h-0 bg-background text-foreground rounded-xl overflow-hidden border border-border/40 shadow-sm',
        isFullscreen && 'fixed inset-0 z-50 rounded-none border-none',
        className
      )}
    >
      {/* Map Header Controls */}
      <div className="shrink-0 p-3 bg-background/95 backdrop-blur-md border-b border-border/50 z-10 space-y-2.5">
        {/* Top line: Search Location, Locate GPS, Map/List Tabs & Fullscreen */}
        <div className="flex items-center gap-2">
          {/* Location search bar */}
          <div className="relative flex-1 group">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground group-focus-within:text-primary transition-colors" />
            <input
              type="text"
              placeholder="Search Uganda location or town…"
              value={locationSearch}
              onChange={(e) => setLocationSearch(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && locationSearch.trim()) {
                  const resolved = resolveUgandaCoordinates(locationSearch, locationSearch);
                  setMapCenter([resolved.lng, resolved.lat]);
                  setMapZoom(13);
                  toast.success(`Jumped to ${resolved.districtName}`);
                }
              }}
              className="w-full h-8 pl-8 pr-7 text-xs bg-muted/50 hover:bg-muted/70 focus:bg-background border border-border/60 focus:border-primary/80 rounded-full outline-none focus:ring-2 focus:ring-primary/20 transition-all duration-200"
            />
            {locationSearch && (
              <button
                type="button"
                onClick={() => setLocationSearch('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-0.5 text-muted-foreground hover:text-foreground rounded-full transition-colors"
              >
                <X className="h-3 w-3" />
              </button>
            )}
          </div>

          {/* Locate GPS Button */}
          <Button
            type="button"
            size="sm"
            variant={userLocation ? 'default' : 'outline'}
            onClick={handleRequestNearMe}
            disabled={locatingUser}
            className={cn(
              'h-8 px-3 rounded-full text-xs font-semibold gap-1.5 shrink-0 transition-all duration-200 active:scale-95 shadow-xs',
              userLocation
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-600 ring-2 ring-emerald-500/20'
                : 'border-border/70 hover:bg-muted text-foreground'
            )}
            title="Use current GPS location"
          >
            <Crosshair className={cn('h-3.5 w-3.5', locatingUser && 'animate-spin text-primary')} />
            <span className="hidden sm:inline">{userLocation ? 'Near Me' : 'Locate'}</span>
          </Button>

          {/* Map / List Underline Sub-tabs */}
          <div className="flex items-center border-b border-border/40 gap-0.5 shrink-0 pb-0.5">
            <button
              type="button"
              onClick={() => setViewMode('map')}
              className={cn(
                'relative pb-1 px-2.5 text-xs font-semibold transition-all duration-200 select-none flex items-center gap-1',
                viewMode === 'map'
                  ? 'text-foreground font-bold'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              <span>Map</span>
              {viewMode === 'map' && (
                <span className="absolute bottom-0 inset-x-1 h-[2px] bg-primary rounded-full shadow-xs transition-all duration-200" />
              )}
            </button>
            <button
              type="button"
              onClick={() => setViewMode('list')}
              className={cn(
                'relative pb-1 px-2.5 text-xs font-semibold transition-all duration-200 select-none flex items-center gap-1',
                viewMode === 'list'
                  ? 'text-foreground font-bold'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              <span>List</span>
              <span className="text-[10px] px-1 py-0.2 rounded-full bg-muted text-muted-foreground font-medium">
                {filteredItems.length}
              </span>
              {viewMode === 'list' && (
                <span className="absolute bottom-0 inset-x-1 h-[2px] bg-primary rounded-full shadow-xs transition-all duration-200" />
              )}
            </button>
          </div>

          {/* Fullscreen Button */}
          <button
            type="button"
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 rounded-full hover:bg-muted text-muted-foreground hover:text-foreground transition-all duration-200 shrink-0 active:scale-95"
            title={isFullscreen ? 'Exit Fullscreen' : 'Expand Map'}
          >
            {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </button>
        </div>

        {/* Quick jump districts pills & radius filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5 text-xs">
          {userLocation && (
            <div className="flex items-center gap-1 shrink-0 mr-1 border-r border-border/50 pr-2">
              <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider">Radius:</span>
              {[5, 10, 25].map((km) => (
                <button
                  key={km}
                  type="button"
                  onClick={() => setSelectedRadiusKm(selectedRadiusKm === km ? null : km)}
                  className={cn(
                    'px-2.5 py-0.5 rounded-full text-xs font-medium border transition-all duration-200 active:scale-95',
                    selectedRadiusKm === km
                      ? 'bg-primary text-primary-foreground border-primary font-bold shadow-xs'
                      : 'bg-muted/40 border-border/60 text-muted-foreground hover:text-foreground hover:bg-muted'
                  )}
                >
                  {km}km
                </button>
              ))}
            </div>
          )}

          {/* Smooth District Jump Chips */}
          <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider shrink-0 flex items-center gap-1">
            <Compass className="h-3 w-3 text-primary shrink-0" />
            Jump:
          </span>
          {POPULAR_UGANDA_CITIES.map((city) => {
            const isCityActive =
              Math.abs(mapCenter[0] - city.coords[0]) < 0.04 &&
              Math.abs(mapCenter[1] - city.coords[1]) < 0.04;

            return (
              <button
                key={city.name}
                type="button"
                onClick={() => handleCityJump(city)}
                className={cn(
                  'px-3 py-1 rounded-full text-xs font-medium shrink-0 transition-all duration-200 active:scale-95 select-none border',
                  isCityActive
                    ? 'bg-primary text-primary-foreground border-primary font-bold shadow-xs'
                    : 'bg-muted/40 hover:bg-muted text-muted-foreground hover:text-foreground border-border/60 hover:border-border'
                )}
              >
                {city.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Map / List View Container */}
      <div className="relative flex-1 min-h-0 w-full overflow-hidden">
        {viewMode === 'map' ? (
          <div className="relative w-full h-full">
            <Map
              center={mapCenter}
              zoom={mapZoom}
              className="w-full h-full"
            >
              <MapViewController center={mapCenter} zoom={mapZoom} />
              <MapControls position="top-right" showZoom showLocate />

              {/* User location pulse marker */}
              {userLocation && (
                <MapMarker
                  longitude={userLocation.lng}
                  latitude={userLocation.lat}
                >
                  <MarkerContent>
                    <div className="relative flex items-center justify-center">
                      <div className="absolute w-7 h-7 bg-emerald-500/30 rounded-full animate-ping" />
                      <div className="relative w-4 h-4 bg-emerald-600 border-2 border-white rounded-full shadow-md flex items-center justify-center">
                        <div className="w-1.5 h-1.5 bg-white rounded-full" />
                      </div>
                    </div>
                  </MarkerContent>
                </MapMarker>
              )}

              {/* Commerce items markers */}
              {filteredItems.map((item) => {
                const isSelected = selectedItemId === item.id;

                return (
                  <MapMarker
                    key={item.id}
                    longitude={item.lng}
                    latitude={item.lat}
                    onClick={() => {
                      setSelectedItemId(item.id);
                      setMapCenter([item.lng, item.lat]);
                    }}
                  >
                    <MarkerContent>
                      <div
                        className={cn(
                          'group cursor-pointer transition-all duration-200 flex items-center gap-1.5 px-2.5 py-1 rounded-full border shadow-sm select-none',
                          isSelected
                            ? 'bg-foreground text-background border-foreground scale-110 shadow-md ring-2 ring-primary ring-offset-1 z-30'
                            : 'bg-background/95 hover:bg-background text-foreground border-border/80 hover:border-foreground/60 hover:scale-105 z-10'
                        )}
                        title={`${item.title} • ${item.district || item.locationName}`}
                      >
                        {/* Tab-specific marker icon */}
                        {item.type === 'products' || item.type === 'deals' ? (
                          <Tag className="h-3 w-3 shrink-0 text-primary" />
                        ) : item.type === 'services' ? (
                          <Wrench className="h-3 w-3 shrink-0 text-blue-500" />
                        ) : item.type === 'promos' ? (
                          <Percent className="h-3 w-3 shrink-0 text-amber-500" />
                        ) : item.type === 'jobs' ? (
                          <Briefcase className="h-3 w-3 shrink-0 text-purple-500" />
                        ) : (
                          <Store className="h-3 w-3 shrink-0 text-emerald-500" />
                        )}

                        <span className="text-[11px] font-bold truncate max-w-[85px]">
                          {item.price
                            ? `UGX ${(item.price / 1000).toFixed(0)}k`
                            : item.title.split(' ')[0]}
                        </span>

                        {item.district && (
                          <span className={cn(
                            'text-[9px] px-1 py-0.2 rounded font-semibold shrink-0 uppercase tracking-tight',
                            isSelected
                              ? 'bg-background/20 text-background'
                              : 'bg-muted text-muted-foreground'
                          )}>
                            {item.district.slice(0, 7)}
                          </span>
                        )}

                        {item.isVerified && (
                          <UnifiedVerifiedBadge size="sm" className="h-3 w-3 shrink-0" />
                        )}
                      </div>
                    </MarkerContent>
                  </MapMarker>
                );
              })}
            </Map>

            {/* Bottom floating result card when marker selected */}
            {selectedItem && (
              <div className="absolute bottom-3 left-3 right-3 z-30 animate-in fade-in slide-in-from-bottom-3 duration-200">
                <Card className="p-3 bg-background/95 backdrop-blur-md border-border/70 shadow-lg rounded-2xl">
                  <div className="flex items-start gap-3">
                    {/* Item Image / Avatar */}
                    <div className="relative w-16 h-16 rounded-xl overflow-hidden bg-muted shrink-0 border border-border/50">
                      {selectedItem.imageUrl ? (
                        <img
                          src={selectedItem.imageUrl}
                          alt={selectedItem.title}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-muted-foreground bg-muted/70">
                          {selectedItem.type === 'services' ? (
                            <Wrench className="h-6 w-6" />
                          ) : selectedItem.type === 'accounts' ? (
                            <Store className="h-6 w-6" />
                          ) : (
                            <Tag className="h-6 w-6" />
                          )}
                        </div>
                      )}
                      {selectedItem.badgeText && (
                        <Badge className="absolute top-1 left-1 text-[9px] px-1 py-0 h-4 bg-amber-500 text-white font-bold border-none">
                          {selectedItem.badgeText}
                        </Badge>
                      )}
                    </div>

                    {/* Content info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-1">
                        <h4 className="font-semibold text-xs text-foreground truncate pr-2">
                          {selectedItem.title}
                        </h4>
                        <button
                          type="button"
                          onClick={() => setSelectedItemId(null)}
                          className="p-1 text-muted-foreground hover:text-foreground rounded-full hover:bg-muted transition-colors -mr-1 -mt-1"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>

                      {/* Subtitle / Seller */}
                      {selectedItem.subtitle && (
                        <div className="flex items-center gap-1 text-[11px] text-muted-foreground truncate mt-0.5">
                          <span>{selectedItem.subtitle}</span>
                          {selectedItem.isVerified && (
                            <UnifiedVerifiedBadge size="sm" className="h-3 w-3 shrink-0" />
                          )}
                        </div>
                      )}

                      {/* Location & Distance */}
                      <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground mt-1 truncate">
                        <MapPin className="h-3 w-3 text-primary shrink-0" />
                        <span className="truncate">{selectedItem.locationName}</span>
                        {selectedItem.distanceKm != null && (
                          <span className="font-medium text-emerald-600 dark:text-emerald-400 shrink-0">
                            • {formatDistance(selectedItem.distanceKm)}
                          </span>
                        )}
                      </div>

                      {/* Price & Action button */}
                      <div className="flex items-center justify-between mt-2 pt-1 border-t border-border/40">
                        <div>
                          {selectedItem.price != null ? (
                            <span className="text-xs font-bold text-foreground">
                              UGX {selectedItem.price.toLocaleString()}
                            </span>
                          ) : (
                            <span className="text-[11px] font-medium text-muted-foreground">
                              {selectedItem.category || 'Available'}
                            </span>
                          )}
                        </div>

                        <Button
                          size="sm"
                          onClick={() => handleItemAction(selectedItem)}
                          className="h-7 px-3 text-xs font-semibold rounded-full gap-1"
                        >
                          <span>
                            {selectedItem.type === 'services'
                              ? 'View Service'
                              : selectedItem.type === 'accounts'
                              ? 'View Store'
                              : selectedItem.type === 'promos'
                              ? 'View Promo'
                              : selectedItem.type === 'jobs'
                              ? 'View Job'
                              : 'View Product'}
                          </span>
                          <ChevronRight className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              </div>
            )}
          </div>
        ) : (
          /* List Mode (Distance-sorted cards) */
          <div className="h-full overflow-y-auto p-3 space-y-2.5">
            {isLoading ? (
              <div className="p-8 text-center text-xs text-muted-foreground">
                <RefreshCw className="h-5 w-5 animate-spin mx-auto mb-2 text-primary" />
                Loading nearby marketplace items…
              </div>
            ) : filteredItems.length === 0 ? (
              <div className="p-8 text-center text-xs text-muted-foreground">
                <Compass className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
                No results found in this area. Try zooming out or selecting another district.
              </div>
            ) : (
              filteredItems.map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    setSelectedItemId(item.id);
                    setMapCenter([item.lng, item.lat]);
                    setViewMode('map');
                  }}
                  className="group cursor-pointer p-2.5 rounded-xl border border-border/60 hover:border-foreground/50 bg-background/80 hover:bg-muted/40 transition-all flex items-center gap-3"
                >
                  <div className="w-14 h-14 rounded-lg bg-muted overflow-hidden shrink-0 border border-border/40">
                    {item.imageUrl ? (
                      <img
                        src={item.imageUrl}
                        alt={item.title}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                        {item.type === 'services' ? (
                          <Wrench className="h-5 w-5 text-blue-500" />
                        ) : item.type === 'accounts' ? (
                          <Store className="h-5 w-5 text-emerald-500" />
                        ) : item.type === 'jobs' ? (
                          <Briefcase className="h-5 w-5 text-purple-500" />
                        ) : item.type === 'promos' ? (
                          <Percent className="h-5 w-5 text-amber-500" />
                        ) : (
                          <Tag className="h-5 w-5 text-primary" />
                        )}
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-semibold text-foreground truncate group-hover:text-primary transition-colors">
                      {item.title}
                    </h4>
                    <p className="text-[11px] text-muted-foreground truncate">
                      {item.subtitle || item.category}
                    </p>
                    <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground mt-1">
                      <MapPin className="h-3 w-3 text-primary shrink-0" />
                      <span className="truncate">{item.locationName}</span>
                      {item.distanceKm != null && (
                        <span className="text-emerald-600 dark:text-emerald-400 font-medium shrink-0">
                          ({formatDistance(item.distanceKm)})
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    {item.price != null && (
                      <div className="text-xs font-bold text-foreground">
                        UGX {(item.price / 1000).toFixed(0)}k
                      </div>
                    )}
                    <span className="text-[10px] text-primary font-medium inline-flex items-center gap-0.5 mt-1">
                      Show pin <ChevronRight className="h-2.5 w-2.5" />
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Footer bar showing active district info & quick count */}
      <div className="shrink-0 px-3 py-1.5 bg-muted/40 border-t border-border/40 flex items-center justify-between text-[11px] text-muted-foreground">
        <span className="truncate">
          📍 {filteredItems.length} {tab} in Uganda
        </span>
        {userLocation && (
          <span className="text-emerald-600 dark:text-emerald-400 font-medium shrink-0">
            GPS Active
          </span>
        )}
      </div>
    </div>
  );
};

export default MarketplaceMap;
