import React, { useEffect, useState } from 'react';
import { Clock, TrendingUp, Sparkles, ChevronRight, X } from 'lucide-react';
import { useAppSettings } from '@/hooks/useAppSettings';
import { predictSuggestions } from '@/lib/searchPredictions';

interface Props {
  query: string;
  onSelect: (q: string) => void;
  onClose: () => void;
}

const RECENT_KEY = 'em_recent_searches';

function getRecent(): string[] {
  try { return JSON.parse(localStorage.getItem(RECENT_KEY) || '[]').slice(0, 5); } catch { return []; }
}
function setRecentStore(items: string[]) {
  try { localStorage.setItem(RECENT_KEY, JSON.stringify(items.slice(0, 5))); } catch {}
}

const TRENDING = ['iPhone 15', 'Sofa set', 'MacBook Pro', 'Plumber Kampala', '2 bedroom apartment'];

const MarketplaceSearchDropdown: React.FC<Props> = ({ query, onSelect }) => {
  const { settings } = useAppSettings();
  const historyEnabled = settings?.save_search_history !== false;
  const [recent, setRecent] = useState<string[]>(() => (historyEnabled ? getRecent() : []));

  useEffect(() => {
    if (historyEnabled) setRecent(getRecent());
    else setRecent([]);
  }, [historyEnabled, query]);

  const suggestions = predictSuggestions(query, 6);
  const showRecent = !query.trim() && historyEnabled && recent.length > 0;
  const showTrending = !query.trim();
  const showSuggestions = !!query.trim() && suggestions.length > 0;

  const removeRecent = (e: React.MouseEvent, item: string) => {
    e.stopPropagation();
    const next = recent.filter((r) => r !== item);
    setRecent(next);
    setRecentStore(next);
  };

  const clearAllRecent = () => {
    setRecent([]);
    setRecentStore([]);
  };

  return (
    <div className="absolute left-0 right-0 top-[calc(100%+8px)] bg-popover border border-border rounded-2xl shadow-2xl overflow-hidden z-[60] max-h-[65vh] overflow-y-auto">
      {showRecent && (
        <div className="py-1">
          <div className="flex items-center justify-between px-4 py-2 bg-muted/30">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Recent</span>
            <button onClick={clearAllRecent} className="text-[11px] text-muted-foreground hover:text-foreground transition-colors">
              Clear all
            </button>
          </div>
          {recent.map((r) => (
            <button
              key={r}
              onClick={() => onSelect(r)}
              className="group w-full flex items-center gap-3 px-4 py-2.5 hover:bg-muted/50 transition-colors text-left"
            >
              <Clock className="w-4 h-4 text-muted-foreground shrink-0" strokeWidth={1.8} />
              <span className="flex-1 text-sm text-foreground truncate">{r}</span>
              <span
                onClick={(e) => removeRecent(e, r)}
                role="button"
                className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-all"
                aria-label="Remove from history"
              >
                <X className="w-3.5 h-3.5" />
              </span>
            </button>
          ))}
        </div>
      )}

      {!query.trim() && !historyEnabled && (
        <div className="px-4 py-3 text-[11px] text-muted-foreground bg-muted/30 border-b border-border">
          Search history is off. Enable it in Settings → Privacy to save recent searches.
        </div>
      )}

      {showSuggestions && (
        <div className="py-1">
          <div className="px-4 py-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground bg-muted/30">
            Suggestions
          </div>
          {suggestions.map((s) => (
            <button
              key={s}
              onClick={() => onSelect(s)}
              className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-muted/50 transition-colors text-left"
            >
              <Sparkles className="w-4 h-4 text-primary/70 shrink-0" strokeWidth={1.8} />
              <span className="flex-1 text-sm text-foreground truncate">
                <HighlightMatch text={s} query={query} />
              </span>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
          ))}
        </div>
      )}

      {query.trim() && !showSuggestions && (
        <div className="px-4 py-3 text-xs text-muted-foreground">
          Press <kbd className="px-1.5 py-0.5 rounded border border-border bg-muted text-[10px]">Enter</kbd> to search for "{query.trim()}"
        </div>
      )}

      {showTrending && (
        <div className="py-1 border-t border-border">
          <div className="px-4 py-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground bg-muted/30">Trending</div>
          {TRENDING.map((t) => (
            <button key={t} onClick={() => onSelect(t)} className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-muted/50 transition-colors text-left">
              <TrendingUp className="w-4 h-4 text-muted-foreground shrink-0" strokeWidth={1.8} />
              <span className="flex-1 text-sm text-foreground truncate">{t}</span>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

const HighlightMatch: React.FC<{ text: string; query: string }> = ({ text, query }) => {
  const q = query.trim();
  if (!q) return <>{text}</>;
  const idx = text.toLowerCase().indexOf(q.toLowerCase());
  if (idx === -1) return <>{text}</>;
  return (
    <>
      {text.slice(0, idx)}
      <span className="font-semibold text-foreground">{text.slice(idx, idx + q.length)}</span>
      {text.slice(idx + q.length)}
    </>
  );
};

export default MarketplaceSearchDropdown;
