import React, { useState, useEffect, useRef } from 'react';
import { Search, SlidersHorizontal, ArrowUpDown, X, Camera, Mic, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export type MarketplaceTabValue = 'products' | 'services' | 'accounts' | 'jobs' | 'promos' | 'deals';

interface Tab {
  value: MarketplaceTabValue;
  label: string;
}

const TABS: Tab[] = [
  { value: 'products', label: 'Products' },
  { value: 'services', label: 'Services' },
  { value: 'accounts', label: 'Accounts' },
  { value: 'promos', label: 'Promotions' },
];

const SORT_OPTIONS: { value: string; label: string }[] = [
  { value: 'recent', label: 'Most recent' },
  { value: 'price_low', label: 'Price: Low to High' },
  { value: 'price_high', label: 'Price: High to Low' },
  { value: 'popular', label: 'Most popular' },
];

interface Props {
  activeTab: MarketplaceTabValue;
  onTabChange: (v: MarketplaceTabValue) => void;
  query: string;
  onQueryChange: (v: string) => void;
  onSubmitQuery?: (v: string) => void;
  onFilterClick?: () => void;
  onAlgorithmClick?: () => void;
  onImageSearch?: () => void;
  filterCount?: number;
  sortBy?: string;
  onSortChange?: (v: string) => void;
  title?: string;
}

/**
 * Fixed marketplace top bar.
 * - Title hidden on mobile; tab pills (Products / Services / Accounts / Deals)
 *   are shown on all screen sizes.
 * - Filter icon: on desktop it only shows on the Products tab (the algorithm
 *   sidebar covers the other tabs). On mobile it's always visible and opens
 *   either the advanced filters (Products) or the algorithm drawer (others).
 * - Products tab exposes visual (image) search + voice search inside the input.
 * - Search only runs on submit (Enter / icon), never while typing.
 */
const MarketplaceTopBar: React.FC<Props> = ({
  activeTab,
  onTabChange,
  query,
  onQueryChange,
  onSubmitQuery,
  onFilterClick,
  onAlgorithmClick,
  onImageSearch,
  filterCount = 0,
  sortBy = 'recent',
  onSortChange,
  title = 'Marketplace',
}) => {
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const isProducts = activeTab === 'products';

  useEffect(() => {
    if (mobileSearchOpen) {
      requestAnimationFrame(() => inputRef.current?.focus());
    }
  }, [mobileSearchOpen]);

  const handleFilter = () => {
    if (isProducts) onFilterClick?.();
    else onAlgorithmClick?.();
  };

  const startVoice = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      alert('Voice search is not supported in your browser');
      return;
    }
    const recognition = new SR();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    setIsListening(true);
    recognition.onresult = (e: any) => {
      const transcript = e.results[0][0].transcript;
      onQueryChange(transcript);
      onSubmitQuery?.(transcript);
      setIsListening(false);
      setMobileSearchOpen(false);
    };
    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);
    recognition.start();
  };

  const InputExtras = (
    <div className="flex items-center gap-0.5 shrink-0">
      {isProducts && (
        <button
          type="button"
          onClick={onImageSearch}
          aria-label="Search by image"
          title="Search by image"
          className="h-7 w-7 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
        >
          <Camera className="w-4 h-4" strokeWidth={2} />
        </button>
      )}
      <button
        type="button"
        onClick={startVoice}
        disabled={isListening}
        aria-label="Voice search"
        title="Voice search"
        className={cn(
          'h-7 w-7 rounded-full flex items-center justify-center transition-colors',
          isListening
            ? 'bg-destructive text-destructive-foreground animate-pulse'
            : 'text-muted-foreground hover:text-foreground hover:bg-muted',
        )}
      >
        {isListening ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mic className="w-4 h-4" strokeWidth={2} />}
      </button>
    </div>
  );

  return (
    <div className="fixed top-0 right-0 left-0 md:left-[72px] lg:left-[275px] xl:left-[300px] z-[80] bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 border-b border-border/60">
      <div className="max-w-7xl mx-auto px-3 md:px-6 h-14 flex items-center gap-2 md:gap-3">
        {/* Title — desktop only */}
        {!mobileSearchOpen && (
          <h1 className="hidden md:block text-lg md:text-2xl font-semibold tracking-tight text-foreground shrink-0">
            {title}
          </h1>
        )}

        <div className="hidden md:block flex-1" />

        {/* Tabs pill group — visible on all sizes; scrollable on mobile */}
        {!mobileSearchOpen && (
          <div className="flex-1 md:flex-none min-w-0 overflow-x-auto scrollbar-hide">
            <div className="flex items-center gap-0.5 rounded-full bg-muted/60 p-1 w-max mx-auto md:mx-0">
              {TABS.map((tab) => {
                const active = tab.value === activeTab;
                return (
                  <button
                    key={tab.value}
                    type="button"
                    onClick={() => onTabChange(tab.value)}
                    className={cn(
                      'px-3 md:px-4 h-8 text-xs md:text-sm rounded-full transition-colors font-medium whitespace-nowrap',
                      active
                        ? 'bg-background text-foreground shadow-sm'
                        : 'text-muted-foreground hover:text-foreground',
                    )}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Filter icon — desktop: products only; mobile: always */}
        {!mobileSearchOpen && (isProducts || true) && (
          <button
            type="button"
            onClick={handleFilter}
            aria-label="Filters"
            title="Filters"
            className={cn(
              'relative shrink-0 inline-flex items-center justify-center h-9 w-9 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors',
              !isProducts && 'md:hidden',
            )}
          >
            <SlidersHorizontal className="w-[18px] h-[18px]" strokeWidth={2} />
            {isProducts && filterCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-[16px] px-1 rounded-full bg-primary text-primary-foreground text-[10px] font-bold inline-flex items-center justify-center ring-2 ring-background">
                {filterCount}
              </span>
            )}
          </button>
        )}

        {/* Sort icon */}
        {!mobileSearchOpen && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                aria-label="Sort"
                title="Sort"
                className="shrink-0 inline-flex items-center justify-center h-9 w-9 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors"
              >
                <ArrowUpDown className="w-[18px] h-[18px]" strokeWidth={2} />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel>Sort by</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {SORT_OPTIONS.map((opt) => (
                <DropdownMenuItem
                  key={opt.value}
                  onClick={() => onSortChange?.(opt.value)}
                  className={cn(sortBy === opt.value && 'bg-accent text-accent-foreground')}
                >
                  {opt.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        )}

        {/* Desktop search input */}
        {!mobileSearchOpen && (
          <div className="hidden md:flex items-center h-9 w-56 lg:w-72 pl-3 pr-1.5 rounded-full bg-muted/60 hover:bg-muted transition-colors focus-within:ring-2 focus-within:ring-primary/25">
            <Search className="w-4 h-4 text-muted-foreground shrink-0" strokeWidth={2} />
            <input
              value={query}
              onChange={(e) => onQueryChange(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') onSubmitQuery?.(query);
              }}
              placeholder="Search the marketplace"
              className="flex-1 h-full bg-transparent border-none outline-none text-sm text-foreground placeholder:text-muted-foreground/70 min-w-0 pl-2 pr-1"
            />
            {InputExtras}
          </div>
        )}

        {/* Mobile: search icon (collapsed) */}
        {!mobileSearchOpen && (
          <button
            type="button"
            onClick={() => setMobileSearchOpen(true)}
            aria-label="Search"
            title="Search"
            className="md:hidden shrink-0 inline-flex items-center justify-center h-9 w-9 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors"
          >
            <Search className="w-[18px] h-[18px]" strokeWidth={2} />
          </button>
        )}

        {/* Mobile: expanded search input */}
        {mobileSearchOpen && (
          <div className="flex items-center gap-2 w-full">
            <div className="flex items-center h-9 flex-1 pl-3 pr-1.5 rounded-full bg-muted/60 focus-within:ring-2 focus-within:ring-primary/25">
              <Search className="w-4 h-4 text-muted-foreground shrink-0" strokeWidth={2} />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => onQueryChange(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    onSubmitQuery?.(query);
                    setMobileSearchOpen(false);
                  }
                  if (e.key === 'Escape') setMobileSearchOpen(false);
                }}
                placeholder="Search the marketplace"
                className="flex-1 h-full bg-transparent border-none outline-none text-sm text-foreground placeholder:text-muted-foreground/70 min-w-0 pl-2 pr-1"
              />
              {InputExtras}
            </div>
            <button
              type="button"
              onClick={() => onSubmitQuery?.(query)}
              className="shrink-0 inline-flex items-center justify-center h-9 px-3 rounded-full bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
            >
              Search
            </button>
            <button
              type="button"
              onClick={() => setMobileSearchOpen(false)}
              aria-label="Close search"
              className="shrink-0 inline-flex items-center justify-center h-9 w-9 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors"
            >
              <X className="w-[18px] h-[18px]" strokeWidth={2} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default MarketplaceTopBar;
