import React, { useState, useEffect } from 'react';
import { Search, X, Filter, MapPin, DollarSign, Loader2, TrendingUp, Clock, Star, ShoppingBag, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Drawer, DrawerContent, DrawerTrigger } from '@/components/ui/drawer';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

interface SearchResult {
  id: string;
  title: string;
  price: number;
  location: string;
  category: string;
  images: string[];
  seller_name: string;
  created_at: string;
}

interface SearchDrawerProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

const SearchDrawer: React.FC<SearchDrawerProps> = ({ isOpen, onOpenChange }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    const saved = localStorage.getItem('recentSearches');
    if (saved) {
      setRecentSearches(JSON.parse(saved));
    }
  }, []);

  const searchAds = async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([]);
      return;
    }

    setLoading(true);
    try {
      let queryBuilder = supabase
        .from('ads')
        .select(`
          id,
          title,
          price,
          location,
          category,
          images,
          created_at,
          seller_id,
          seller_profiles(business_name)
        `)
        .eq('status', 'active');

      const keywords = searchQuery.trim().toLowerCase().split(/\s+/);
      const orConditions = keywords.flatMap(keyword => [
        `title.ilike.%${keyword}%`,
        `description.ilike.%${keyword}%`,
        `category.ilike.%${keyword}%`
      ]).join(',');
      queryBuilder = queryBuilder.or(orConditions);

      const { data, error } = await queryBuilder.limit(20);

      if (error) throw error;

      const formattedResults = data?.map(ad => ({
        id: ad.id,
        title: ad.title,
        price: ad.price || 0,
        location: ad.location,
        category: ad.category,
        images: ad.images || [],
        seller_name: (ad.seller_profiles as any)?.business_name || 'Unknown Seller',
        created_at: ad.created_at
      })) || [];

      setResults(formattedResults);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (searchQuery: string) => {
    if (!searchQuery.trim()) return;
    
    const updated = [searchQuery, ...recentSearches.filter(s => s !== searchQuery)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem('recentSearches', JSON.stringify(updated));
    
    searchAds(searchQuery);
  };

  const handleResultClick = (adId: string) => {
    navigate(`/ad/${adId}`);
    onOpenChange(false);
  };

  useEffect(() => {
    if (query) {
      const debounce = setTimeout(() => {
        searchAds(query);
      }, 300);
      return () => clearTimeout(debounce);
    } else {
      setResults([]);
    }
  }, [query]);

  return (
    <Drawer open={isOpen} onOpenChange={onOpenChange}>
      <DrawerContent className="max-h-[90vh] bg-background">
        <div className="mx-auto w-12 h-1.5 flex-shrink-0 rounded-full bg-muted my-3" />
        
        <div className="px-4 pb-8 overflow-y-auto">
          {/* Search Input */}
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search products, services, sellers..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch(query)}
              className="pl-10 pr-4 h-12 text-base border-2 focus:border-primary rounded-xl"
              autoFocus
            />
            {loading && (
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                <Loader2 className="h-4 w-4 animate-spin text-primary" />
              </div>
            )}
          </div>

          {/* Recent Searches */}
          {!query && recentSearches.length > 0 && (
            <div className="mb-6">
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <Clock className="w-4 h-4 text-muted-foreground" />
                Recent Searches
              </h3>
              <div className="flex flex-wrap gap-2">
                {recentSearches.map((search, index) => (
                  <Badge
                    key={index}
                    variant="secondary"
                    className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors text-xs px-3 py-1.5 rounded-full"
                    onClick={() => {
                      setQuery(search);
                      handleSearch(search);
                    }}
                  >
                    {search}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Loading State */}
          {loading && (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex gap-3 p-3 rounded-xl bg-muted/50">
                  <Skeleton className="w-20 h-20 rounded-lg" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-3 w-1/2" />
                    <Skeleton className="h-4 w-1/3" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Results */}
          {!loading && results.length > 0 && (
            <div className="space-y-3">
              {results.map((result) => (
                <div
                  key={result.id}
                  className="flex gap-3 p-3 rounded-xl bg-card border border-border cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => handleResultClick(result.id)}
                >
                  <div className="w-20 h-20 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                    {result.images.length > 0 ? (
                      <img
                        src={result.images[0]}
                        alt={result.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <ShoppingBag className="w-6 h-6 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm text-foreground line-clamp-2 mb-1">
                      {result.title}
                    </h4>
                    <p className="text-xs text-muted-foreground mb-1">{result.location}</p>
                    <p className="text-sm font-bold text-primary">
                      UGX {result.price?.toLocaleString() || 'Contact'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* No Results */}
          {!loading && query && results.length === 0 && (
            <div className="text-center py-8">
              <Search className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">No results found for "{query}"</p>
            </div>
          )}

          {/* Empty State */}
          {!query && !loading && (
            <div className="text-center py-8">
              <TrendingUp className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">Start typing to search</p>
            </div>
          )}
        </div>
      </DrawerContent>
    </Drawer>
  );
};

export default SearchDrawer;
