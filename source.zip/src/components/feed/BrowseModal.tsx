import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Briefcase, Calendar, Tag, ShoppingBag, MapPin, Eye, MessageCircle, Bookmark, Heart, Users } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { format, formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import { getSellerProfileUrl } from '@/lib/sellerUrl';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';

export type BrowseCategory = 'jobs' | 'events' | 'promotions' | 'services' | 'sellers';

interface BrowseModalProps {
  isOpen: boolean;
  onClose: () => void;
  category: BrowseCategory;
}

interface SellerProfile {
  id: string;
  business_name: string;
  business_logo_url: string | null;
  is_verified: boolean;
  verification_badge_color?: BadgeColor;
  store_slug?: string;
}

interface Job {
  id: string;
  title: string;
  description?: string;
  location: string;
  images?: string[];
  view_count?: number;
  save_count?: number;
  company_name?: string;
  job_type?: string;
  created_at: string;
  seller?: SellerProfile;
}

interface Event {
  id: string;
  title: string;
  description: string;
  location: string;
  event_date: string;
  is_free?: boolean;
  cover_image?: string;
  images?: string[];
  view_count?: number;
  seller?: SellerProfile;
}

interface Promotion {
  id: string;
  title: string;
  description?: string;
  price?: number;
  original_price?: number;
  discount_percentage?: number;
  images?: string[];
  view_count?: number;
  save_count?: number;
  created_at: string;
  seller?: SellerProfile;
}

interface Service {
  id: string;
  title: string;
  description?: string;
  location: string;
  price?: number;
  images?: string[];
  view_count?: number;
  save_count?: number;
  created_at: string;
  seller?: SellerProfile;
}

interface Seller {
  id: string;
  business_name: string;
  business_logo_url: string | null;
  is_verified: boolean;
  verification_badge_color?: BadgeColor;
  store_slug?: string;
  follower_count?: number;
}

const MAX_ITEMS = 12;

const categoryConfig: Record<BrowseCategory, { title: string; icon: React.ReactNode; color: string }> = {
  jobs: { title: 'Jobs', icon: <Briefcase className="w-5 h-5" />, color: 'text-blue-500' },
  events: { title: 'Events', icon: <Calendar className="w-5 h-5" />, color: 'text-purple-500' },
  promotions: { title: 'Deals', icon: <Tag className="w-5 h-5" />, color: 'text-orange-500' },
  services: { title: 'Services', icon: <ShoppingBag className="w-5 h-5" />, color: 'text-green-500' },
  sellers: { title: 'Top Sellers', icon: <Users className="w-5 h-5" />, color: 'text-cyan-500' },
};

// Removed VerifiedBadge - using UnifiedVerifiedBadge instead

const EngagementBar = ({ views, saves, comments }: { views?: number; saves?: number; comments?: number }) => (
  <div className="flex items-center gap-4 mt-3 text-muted-foreground">
    {views !== undefined && (
      <div className="flex items-center gap-1.5 text-xs hover:text-primary transition-colors">
        <Eye className="w-4 h-4" />
        <span>{views.toLocaleString()}</span>
      </div>
    )}
    {saves !== undefined && (
      <div className="flex items-center gap-1.5 text-xs hover:text-primary transition-colors">
        <Bookmark className="w-4 h-4" />
        <span>{saves.toLocaleString()}</span>
      </div>
    )}
    {comments !== undefined && (
      <div className="flex items-center gap-1.5 text-xs hover:text-primary transition-colors">
        <MessageCircle className="w-4 h-4" />
        <span>{comments.toLocaleString()}</span>
      </div>
    )}
  </div>
);

const PostHeader = ({ seller, timestamp }: { seller?: SellerProfile; timestamp?: string }) => {
  if (!seller) return null;
  
  return (
    <div className="flex items-center gap-2 mb-2">
      <Avatar className="w-10 h-10 ring-2 ring-border/30">
        <AvatarImage src={seller.business_logo_url || ''} />
        <AvatarFallback className="bg-muted text-foreground font-bold text-sm">
          {seller.business_name?.charAt(0)}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1">
          <span className="font-bold text-sm truncate">{seller.business_name}</span>
          <UnifiedVerifiedBadge 
            isVerified={seller.is_verified} 
            badgeColor={seller.verification_badge_color}
            size="sm" 
          />
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <span>@{seller.store_slug || seller.business_name?.toLowerCase().replace(/\s+/g, '')}</span>
          {timestamp && (
            <>
              <span>·</span>
              <span>{formatDistanceToNow(new Date(timestamp), { addSuffix: false })}</span>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

const BrowseModal: React.FC<BrowseModalProps> = ({ isOpen, onClose, category }) => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [sellers, setSellers] = useState<Seller[]>([]);

  useEffect(() => {
    if (!isOpen) return;
    
    const fetchData = async () => {
      setLoading(true);
      try {
        switch (category) {
          case 'jobs': {
            const { data } = await supabase
              .from('ads')
              .select(`
                id, title, description, location, images, view_count, save_count, created_at,
                job_details(company_name, job_type),
                seller_profiles(id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug)
              `)
              .eq('status', 'active')
              .eq('listing_type', 'jobs')
              .order('created_at', { ascending: false })
              .limit(MAX_ITEMS);
            if (data) {
              setJobs(data.map(j => ({
                id: j.id,
                title: j.title,
                description: j.description,
                location: j.location,
                images: j.images,
                view_count: j.view_count,
                save_count: j.save_count,
                created_at: j.created_at,
                company_name: (j.job_details as any)?.[0]?.company_name,
                job_type: (j.job_details as any)?.[0]?.job_type,
                seller: j.seller_profiles as any
              })));
            }
            break;
          }
          case 'events': {
            const { data } = await supabase
              .from('events')
              .select(`
                id, title, description, location, event_date, is_free, cover_image, images, view_count,
                seller_profiles(id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug)
              `)
              .eq('is_active', true)
              .gte('event_date', new Date().toISOString())
              .order('event_date', { ascending: true })
              .limit(MAX_ITEMS);
            if (data) {
              setEvents(data.map(e => ({
                ...e,
                seller: e.seller_profiles as any
              })));
            }
            break;
          }
          case 'promotions': {
            const { data } = await supabase
              .from('ads')
              .select(`
                id, title, description, price, original_price, has_discount, images, view_count, save_count, created_at,
                seller_profiles(id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug)
              `)
              .eq('status', 'active')
              .eq('listing_type', 'promotions')
              .order('created_at', { ascending: false })
              .limit(MAX_ITEMS);
            if (data) {
              setPromotions(data.map(p => ({
                id: p.id,
                title: p.title,
                description: p.description,
                price: p.price,
                original_price: p.original_price,
                images: p.images,
                view_count: p.view_count,
                save_count: p.save_count,
                created_at: p.created_at,
                discount_percentage: p.original_price && p.price ? Math.round((1 - p.price / p.original_price) * 100) : undefined,
                seller: p.seller_profiles as any
              })));
            }
            break;
          }
          case 'services': {
            const { data } = await supabase
              .from('ads')
              .select(`
                id, title, description, location, price, images, view_count, save_count, created_at,
                seller_profiles(id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug)
              `)
              .eq('status', 'active')
              .eq('listing_type', 'services')
              .order('created_at', { ascending: false })
              .limit(MAX_ITEMS);
            if (data) {
              setServices(data.map(s => ({
                ...s,
                seller: s.seller_profiles as any
              })));
            }
            break;
          }
          case 'sellers': {
            const { data } = await supabase
              .from('seller_profiles')
              .select('id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug, follower_count')
              .eq('is_active', true)
              .eq('is_verified', true)
              .order('follower_count', { ascending: false })
              .limit(MAX_ITEMS);
            if (data) setSellers(data);
            break;
          }
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [isOpen, category]);

  const handleItemClick = (id: string) => {
    onClose();
    switch (category) {
      case 'jobs':
        navigate(`/job/${id}`);
        break;
      case 'events':
        navigate(`/event/${id}`);
        break;
      case 'promotions':
        navigate(`/promotion/${id}`);
        break;
      case 'services':
        navigate(`/service/${id}`);
        break;
    }
  };

  const handleSellerClick = (seller: Seller) => {
    onClose();
    navigate(getSellerProfileUrl(seller));
  };

  const config = categoryConfig[category];

  // Grid card component for consistent styling
  const GridCard = ({ 
    image, 
    title, 
    subtitle, 
    badge, 
    price, 
    originalPrice,
    discountPercent,
    meta,
    seller,
    onClick 
  }: {
    image?: string;
    title: string;
    subtitle?: string;
    badge?: { text: string; color: string };
    price?: number;
    originalPrice?: number;
    discountPercent?: number;
    meta?: React.ReactNode;
    seller?: SellerProfile;
    onClick: () => void;
  }) => (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
      className="bg-card border border-border rounded-xl overflow-hidden cursor-pointer hover:border-primary/50 hover:shadow-lg transition-all"
      onClick={onClick}
    >
      {/* Image - filter out video URLs */}
      <div className="relative aspect-[4/3] bg-muted">
        {image && !image.match(/\.(mp4|webm|mov|avi|mkv)(\?|$)/i) && !image.includes('video:') ? (
          <img src={image} alt={title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Eye className="w-8 h-8 text-muted-foreground/50" />
          </div>
        )}
        {badge && (
          <span className={cn(
            "absolute top-2 left-2 px-2 py-0.5 rounded-full text-[10px] font-bold",
            badge.color
          )}>
            {badge.text}
          </span>
        )}
        {discountPercent && discountPercent > 0 && (
          <span className="absolute top-2 right-2 px-2 py-0.5 bg-destructive text-destructive-foreground rounded-full text-[10px] font-bold">
            -{discountPercent}%
          </span>
        )}
      </div>

      {/* Content */}
      <div className="p-3">
        {/* Seller info */}
        {seller && (
          <div className="flex items-center gap-1.5 mb-2">
            <Avatar className="w-5 h-5">
              <AvatarImage src={seller.business_logo_url || ''} />
              <AvatarFallback className="text-[10px] bg-muted">
                {seller.business_name?.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <span className="text-xs text-muted-foreground truncate flex-1">
              {seller.business_name}
            </span>
            <UnifiedVerifiedBadge 
              isVerified={seller.is_verified} 
              badgeColor={seller.verification_badge_color}
              size="xs" 
            />
          </div>
        )}

        <h3 className="font-semibold text-sm line-clamp-2 leading-tight mb-1">{title}</h3>
        
        {subtitle && (
          <p className="text-xs text-muted-foreground line-clamp-1 mb-2">{subtitle}</p>
        )}

        {/* Price */}
        {price !== undefined && (
          <div className="flex items-center gap-2">
            <span className="text-primary font-bold text-sm">
              UGX {price.toLocaleString()}
            </span>
            {originalPrice && (
              <span className="text-xs text-muted-foreground line-through">
                {originalPrice.toLocaleString()}
              </span>
            )}
          </div>
        )}

        {/* Meta info */}
        {meta && (
          <div className="mt-2 text-xs text-muted-foreground">
            {meta}
          </div>
        )}
      </div>
    </motion.div>
  );

  const renderContent = () => {
    if (loading) {
      return (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 p-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="bg-card border border-border rounded-xl overflow-hidden animate-pulse">
              <div className="aspect-[4/3] bg-muted" />
              <div className="p-3 space-y-2">
                <div className="h-3 w-16 bg-muted rounded" />
                <div className="h-4 w-full bg-muted rounded" />
                <div className="h-3 w-20 bg-muted rounded" />
              </div>
            </div>
          ))}
        </div>
      );
    }

    switch (category) {
      case 'jobs':
        return (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 p-4">
            {jobs.map((job) => (
              <GridCard
                key={job.id}
                image={job.images?.[0]}
                title={job.title}
                subtitle={job.company_name}
                badge={job.job_type ? { text: job.job_type, color: 'bg-blue-500/90 text-white' } : undefined}
                seller={job.seller}
                meta={
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    <span className="truncate">{job.location}</span>
                  </div>
                }
                onClick={() => handleItemClick(job.id)}
              />
            ))}
          </div>
        );

      case 'events':
        return (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 p-4">
            {events.map((event) => (
              <GridCard
                key={event.id}
                image={event.cover_image || event.images?.[0]}
                title={event.title}
                badge={event.is_free ? { text: 'Free Entry', color: 'bg-green-500/90 text-white' } : undefined}
                seller={event.seller}
                meta={
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      <span>{format(new Date(event.event_date), 'MMM d')}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      <span className="truncate">{event.location}</span>
                    </div>
                  </div>
                }
                onClick={() => handleItemClick(event.id)}
              />
            ))}
          </div>
        );

      case 'promotions':
        return (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 p-4">
            {promotions.map((promo) => (
              <GridCard
                key={promo.id}
                image={promo.images?.[0]}
                title={promo.title}
                price={promo.price}
                originalPrice={promo.original_price}
                discountPercent={promo.discount_percentage}
                seller={promo.seller}
                onClick={() => handleItemClick(promo.id)}
              />
            ))}
          </div>
        );

      case 'services':
        return (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 p-4">
            {services.map((service) => (
              <GridCard
                key={service.id}
                image={service.images?.[0]}
                title={service.title}
                price={service.price}
                seller={service.seller}
                meta={
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    <span className="truncate">{service.location}</span>
                  </div>
                }
                onClick={() => handleItemClick(service.id)}
              />
            ))}
          </div>
        );

      case 'sellers':
        return (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 p-4">
            {sellers.map((seller) => (
              <motion.div
                key={seller.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                whileHover={{ scale: 1.02 }}
                className="bg-card border border-border rounded-xl p-4 cursor-pointer hover:border-primary/50 hover:shadow-lg transition-all text-center"
                onClick={() => handleSellerClick(seller)}
              >
                <Avatar className="w-16 h-16 mx-auto mb-3 ring-2 ring-border">
                  <AvatarImage src={seller.business_logo_url || ''} />
                  <AvatarFallback className="bg-muted text-lg font-bold">
                    {seller.business_name?.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex items-center justify-center gap-1 mb-1">
                  <span className="font-bold text-sm truncate">{seller.business_name}</span>
                  <UnifiedVerifiedBadge 
                    isVerified={seller.is_verified} 
                    badgeColor={seller.verification_badge_color}
                    size="sm" 
                  />
                </div>
                <p className="text-xs text-muted-foreground mb-2">
                  @{seller.store_slug || seller.business_name?.toLowerCase().replace(/\s+/g, '')}
                </p>
                {seller.follower_count !== undefined && (
                  <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
                    <Users className="w-3.5 h-3.5" />
                    <span>{seller.follower_count.toLocaleString()}</span>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-hidden flex flex-col p-0 gap-0">
        <DialogHeader className="px-4 py-3 border-b border-border flex-shrink-0 sticky top-0 bg-background z-10">
          <DialogTitle className={cn("flex items-center gap-2 text-lg font-bold", config.color)}>
            {config.icon}
            {config.title}
          </DialogTitle>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto">
          {renderContent()}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BrowseModal;
