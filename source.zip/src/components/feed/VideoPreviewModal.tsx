import React, { useState, useRef, useEffect, useCallback } from 'react';
import { videoCdnUrl } from '@/utils/cdnUrl';
import { motion, AnimatePresence, PanInfo, useMotionValue, useTransform } from 'framer-motion';
import { ThumbsUp, MessageCircle, Share2, Bookmark, Play, ArrowLeft, BarChart3, Volume2, VolumeX, ExternalLink, Pause, MapPin, Briefcase, Calendar, Clock, Tag, Percent, Users, Wrench, DollarSign, Timer, RotateCcw, SkipBack, SkipForward, MoreVertical, UserPlus, UserMinus, EyeOff, HelpCircle, Download } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import SmartVideo from '@/components/media/SmartVideo';
import { Drawer, DrawerContent } from '@/components/ui/drawer';
import UnifiedVerifiedBadge from '@/components/UnifiedVerifiedBadge';
import { getSellerProfileUrl } from '@/lib/sellerUrl';
import { useVideoModal } from '@/contexts/VideoModalContext';
import { useInterested } from '@/hooks/useEngagement';
import { useFollow } from '@/hooks/useFollow';
import { toast } from 'sonner';
import videoPlaceholder from '@/assets/video-placeholder.webp';
import { prefetchVideo, prefetchPoster } from '@/utils/videoPrefetch';

interface FeedItem {
  id: string;
  title: string;
  description: string;
  price: number;
  images: string[];
  category: string;
  location: string;
  created_at: string;
  listing_type: string;
  content_type?: 'ad' | 'post' | 'event';
  b2_video_url?: string | null;
  youtube_url?: string | null;
  tiktok_url?: string | null;
  currency?: string;
  seller: {
    id: string;
    business_name: string;
    business_logo_url: string;
    is_verified: boolean;
    verification_badge_color?: string | null;
  };
  is_liked?: boolean;
  is_saved?: boolean;
  like_count: number;
  view_count: number;
  job_details?: {
    company_name?: string;
    salary_min?: number;
    salary_max?: number;
    salary_currency?: string;
    job_type?: string;
    work_location?: string;
    number_of_positions?: number;
    application_deadline?: string;
  };
  service_details?: {
    starting_price?: number;
    experience_years?: number;
    service_area?: string[];
    pricing_type?: string;
  };
  event_details?: {
    event_date?: string;
    end_date?: string;
    venue_name?: string;
    venue_address?: string;
    is_free?: boolean;
    ticket_price?: number;
    ticket_currency?: string;
    max_attendees?: number;
    current_attendees?: number;
  };
  promotion_details?: {
    discount_percentage?: number | null;
    is_seller_wide?: boolean;
    promotion_type?: string;
    valid_until?: string;
    start_at?: string;
    brand_name?: string;
  };
  digital_product_details?: {
    file_type?: string;
    file_size?: string;
    license_type?: string;
  };
}

interface VideoPreviewModalProps {
  item: FeedItem;
  isOpen: boolean;
  onClose: () => void;
  onLike: (id: string) => void;
  onSave: (id: string) => void;
  onShare: (item: FeedItem) => void;
  onComment: (item: FeedItem) => void;
}

// Specs Carousel Component - horizontal scrolling specs
const SpecsCarousel: React.FC<{ specs: { label: string; value: string; icon?: React.ReactNode }[] }> = ({ specs }) => {
  if (specs.length === 0) return null;
  
  return (
    <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
      {specs.map((spec, idx) => (
        <div 
          key={idx}
          className="flex-shrink-0 flex items-center gap-1.5 bg-white/20 backdrop-blur-sm rounded-full px-3 py-1.5"
        >
          {spec.icon && <span className="text-white/80">{spec.icon}</span>}
          <span className="text-white text-xs font-medium whitespace-nowrap">{spec.value}</span>
        </div>
      ))}
    </div>
  );
};

// Get dynamic specs based on listing type
const getSpecsForListingType = (item: FeedItem): { label: string; value: string; icon?: React.ReactNode }[] => {
  const specs: { label: string; value: string; icon?: React.ReactNode }[] = [];
  const currency = item.currency || 'UGX';
  
  switch (item.listing_type) {
    case 'jobs':
      if (item.job_details) {
        if (item.job_details.salary_min || item.job_details.salary_max) {
          const salaryStr = item.job_details.salary_min && item.job_details.salary_max
            ? `${(item.job_details.salary_currency || 'UGX')} ${item.job_details.salary_min?.toLocaleString()}-${item.job_details.salary_max?.toLocaleString()}`
            : `${(item.job_details.salary_currency || 'UGX')} ${(item.job_details.salary_min || item.job_details.salary_max)?.toLocaleString()}`;
          specs.push({ label: 'Salary', value: salaryStr, icon: <DollarSign className="w-3 h-3" /> });
        }
        if (item.job_details.job_type) {
          specs.push({ label: 'Type', value: item.job_details.job_type.replace('_', ' '), icon: <Briefcase className="w-3 h-3" /> });
        }
        if (item.job_details.work_location) {
          specs.push({ label: 'Location', value: item.job_details.work_location, icon: <MapPin className="w-3 h-3" /> });
        }
        if (item.job_details.number_of_positions && item.job_details.number_of_positions > 1) {
          specs.push({ label: 'Positions', value: `${item.job_details.number_of_positions} openings`, icon: <Users className="w-3 h-3" /> });
        }
      }
      break;
      
    case 'services':
      if (item.service_details) {
        if (item.service_details.starting_price) {
          specs.push({ label: 'From', value: `${currency} ${item.service_details.starting_price.toLocaleString()}`, icon: <DollarSign className="w-3 h-3" /> });
        }
        if (item.service_details.experience_years) {
          specs.push({ label: 'Experience', value: `${item.service_details.experience_years} years`, icon: <Wrench className="w-3 h-3" /> });
        }
        if (item.service_details.service_area && item.service_details.service_area.length > 0) {
          specs.push({ label: 'Area', value: item.service_details.service_area[0], icon: <MapPin className="w-3 h-3" /> });
        }
      }
      if (item.location) {
        specs.push({ label: 'Location', value: item.location, icon: <MapPin className="w-3 h-3" /> });
      }
      break;
      
    case 'promotions':
      if (item.promotion_details) {
        if (item.promotion_details.discount_percentage) {
          specs.push({ label: 'Discount', value: `${item.promotion_details.discount_percentage}% OFF`, icon: <Percent className="w-3 h-3" /> });
        }
        if (item.promotion_details.brand_name) {
          specs.push({ label: 'Brand', value: item.promotion_details.brand_name, icon: <Tag className="w-3 h-3" /> });
        }
        if (item.promotion_details.valid_until) {
          const endDate = new Date(item.promotion_details.valid_until);
          specs.push({ label: 'Ends', value: endDate.toLocaleDateString(), icon: <Timer className="w-3 h-3" /> });
        }
      }
      break;
      
    case 'events':
      if (item.content_type === 'event' && item.event_details) {
        if (item.event_details.event_date) {
          const date = new Date(item.event_details.event_date);
          specs.push({ label: 'Date', value: date.toLocaleDateString(), icon: <Calendar className="w-3 h-3" /> });
        }
        if (item.event_details.venue_name) {
          specs.push({ label: 'Venue', value: item.event_details.venue_name, icon: <MapPin className="w-3 h-3" /> });
        }
        if (item.event_details.is_free) {
          specs.push({ label: 'Price', value: 'Free Entry', icon: <DollarSign className="w-3 h-3" /> });
        } else if (item.event_details.ticket_price) {
          specs.push({ label: 'Ticket', value: `${item.event_details.ticket_currency || 'UGX'} ${item.event_details.ticket_price.toLocaleString()}`, icon: <DollarSign className="w-3 h-3" /> });
        }
      }
      break;
      
    case 'digital_products':
      if (item.price > 0) {
        specs.push({ label: 'Price', value: `${currency} ${item.price.toLocaleString()}`, icon: <DollarSign className="w-3 h-3" /> });
      }
      if (item.digital_product_details?.file_type) {
        specs.push({ label: 'Type', value: item.digital_product_details.file_type, icon: <Tag className="w-3 h-3" /> });
      }
      specs.push({ label: 'Category', value: item.category, icon: <Tag className="w-3 h-3" /> });
      break;
      
    default: // physical_products and others
      if (item.price > 0) {
        specs.push({ label: 'Price', value: `${currency} ${item.price.toLocaleString()}`, icon: <DollarSign className="w-3 h-3" /> });
      }
      specs.push({ label: 'Category', value: item.category, icon: <Tag className="w-3 h-3" /> });
      if (item.location) {
        specs.push({ label: 'Location', value: item.location, icon: <MapPin className="w-3 h-3" /> });
      }
      break;
  }
  
  return specs;
};

// Get gallery header based on listing type
const getGalleryHeader = (listingType: string): string => {
  switch (listingType) {
    case 'services': return 'Service Gallery';
    case 'jobs': return 'Company Photos';
    case 'events': return 'Event Photos';
    case 'promotions': return 'Promotion Images';
    default: return 'Images';
  }
};

// Dynamic Drawer Content based on listing type
const DynamicDrawerContent: React.FC<{ item: FeedItem; onClose: () => void; onViewDetails: () => void }> = ({ item, onClose, onViewDetails }) => {
  const navigate = useNavigate();
  const currency = item.currency || 'UGX';
  
  const renderPriceSection = () => {
    switch (item.listing_type) {
      case 'jobs':
        if (item.job_details?.salary_min || item.job_details?.salary_max) {
          const salaryStr = item.job_details.salary_min && item.job_details.salary_max
            ? `${(item.job_details.salary_currency || 'UGX')} ${item.job_details.salary_min?.toLocaleString()} - ${item.job_details.salary_max?.toLocaleString()}`
            : `${(item.job_details.salary_currency || 'UGX')} ${(item.job_details.salary_min || item.job_details.salary_max)?.toLocaleString()}`;
          return (
            <div className="text-xl font-bold text-primary mb-2">
              {salaryStr}
              <span className="text-sm font-normal text-muted-foreground ml-1">/month</span>
            </div>
          );
        }
        return null;
        
      case 'services':
        if (item.service_details?.starting_price) {
          return (
            <div className="text-xl font-bold text-primary mb-2">
              Starting from {currency} {item.service_details.starting_price.toLocaleString()}
            </div>
          );
        }
        return null;
        
      case 'promotions':
        if (item.promotion_details?.discount_percentage) {
          return (
            <div className="text-xl font-bold text-green-500 mb-2">
              {item.promotion_details.discount_percentage}% OFF
            </div>
          );
        }
        return null;
        
      case 'events':
        if (item.event_details?.is_free) {
          return <div className="text-xl font-bold text-green-500 mb-2">Free Entry</div>;
        }
        if (item.event_details?.ticket_price) {
          return (
            <div className="text-xl font-bold text-primary mb-2">
              {item.event_details.ticket_currency || 'UGX'} {item.event_details.ticket_price.toLocaleString()}
            </div>
          );
        }
        return null;
        
      default:
        if (item.price > 0) {
          return (
            <div className="text-xl font-bold text-primary mb-2">
              {currency} {item.price.toLocaleString()}
            </div>
          );
        }
        return null;
    }
  };
  
  const renderDetailsSection = () => {
    switch (item.listing_type) {
      case 'jobs':
        return (
          <div className="space-y-2 mb-4">
            {item.job_details?.company_name && (
              <div className="flex items-center gap-2 text-sm">
                <Briefcase className="w-4 h-4 text-muted-foreground" />
                <span>{item.job_details.company_name}</span>
              </div>
            )}
            {item.job_details?.job_type && (
              <div className="flex items-center gap-2 text-sm">
                <Clock className="w-4 h-4 text-muted-foreground" />
                <span>{item.job_details.job_type.replace('_', ' ')}</span>
              </div>
            )}
            {item.job_details?.work_location && (
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                <span>{item.job_details.work_location}</span>
              </div>
            )}
            {item.job_details?.number_of_positions && item.job_details.number_of_positions > 1 && (
              <div className="flex items-center gap-2 text-sm">
                <Users className="w-4 h-4 text-muted-foreground" />
                <span>{item.job_details.number_of_positions} positions available</span>
              </div>
            )}
            {item.job_details?.application_deadline && (
              <div className="flex items-center gap-2 text-sm text-orange-500">
                <Timer className="w-4 h-4" />
                <span>Deadline: {new Date(item.job_details.application_deadline).toLocaleDateString()}</span>
              </div>
            )}
          </div>
        );
        
      case 'services':
        return (
          <div className="space-y-2 mb-4">
            {item.service_details?.experience_years && (
              <div className="flex items-center gap-2 text-sm">
                <Wrench className="w-4 h-4 text-muted-foreground" />
                <span>{item.service_details.experience_years} years experience</span>
              </div>
            )}
            {item.service_details?.service_area && item.service_details.service_area.length > 0 && (
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                <span>Service area: {item.service_details.service_area.join(', ')}</span>
              </div>
            )}
            {item.location && (
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                <span>{item.location}</span>
              </div>
            )}
          </div>
        );
        
      case 'promotions':
        return (
          <div className="space-y-2 mb-4">
            {item.promotion_details?.brand_name && (
              <div className="flex items-center gap-2 text-sm">
                <Tag className="w-4 h-4 text-muted-foreground" />
                <span>Brand: {item.promotion_details.brand_name}</span>
              </div>
            )}
            {item.promotion_details?.valid_until && (
              <div className="flex items-center gap-2 text-sm text-orange-500">
                <Timer className="w-4 h-4" />
                <span>Valid until: {new Date(item.promotion_details.valid_until).toLocaleDateString()}</span>
              </div>
            )}
            {item.promotion_details?.is_seller_wide && (
              <Badge variant="secondary" className="text-xs">Store-wide Sale</Badge>
            )}
          </div>
        );
        
      case 'events':
        return (
          <div className="space-y-2 mb-4">
            {item.event_details?.event_date && (
              <div className="flex items-center gap-2 text-sm">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                <span>{new Date(item.event_details.event_date).toLocaleString()}</span>
              </div>
            )}
            {item.event_details?.venue_name && (
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                <span>{item.event_details.venue_name}</span>
              </div>
            )}
            {item.event_details?.venue_address && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span className="ml-6">{item.event_details.venue_address}</span>
              </div>
            )}
            {item.event_details?.max_attendees && (
              <div className="flex items-center gap-2 text-sm">
                <Users className="w-4 h-4 text-muted-foreground" />
                <span>{item.event_details.current_attendees || 0} / {item.event_details.max_attendees} attendees</span>
              </div>
            )}
          </div>
        );
        
      default:
        return (
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Badge variant="secondary" className="text-xs">{item.category}</Badge>
            <span className="text-muted-foreground text-xs">{item.location}</span>
          </div>
        );
    }
  };
  
  return (
    <>
      <div className="flex items-center gap-3 mb-4">
        <Avatar className="w-12 h-12 border border-border">
          <AvatarImage src={item.seller.business_logo_url} />
          <AvatarFallback className="bg-primary/10 text-primary">
            {item.seller.business_name.charAt(0)}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-foreground truncate">{item.seller.business_name}</span>
            {item.seller.is_verified && (
              <UnifiedVerifiedBadge isVerified badgeColor={item.seller.verification_badge_color} size="sm" />
            )}
          </div>
          <span className="text-sm text-muted-foreground">{item.location}</span>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="rounded-full text-xs"
          onClick={() => {
            onClose();
            navigate(getSellerProfileUrl(item.seller));
          }}
        >
          View Profile
        </Button>
      </div>

      <h2 className="text-lg font-bold text-foreground mb-2">{item.title}</h2>
      <p className="text-muted-foreground text-sm mb-4 leading-relaxed">{item.description}</p>

      {renderPriceSection()}
      {renderDetailsSection()}

      {(() => {
        // Filter out video URLs - only show actual images in the drawer
        const imageOnly = item.images.filter(img => 
          !img.match(/\.(mp4|webm|mov|avi|mkv)(\?|$)/i) && 
          !img.includes('video') &&
          !img.startsWith('video:')
        );
        if (imageOnly.length === 0) return null;
        return (
          <div className="mb-4">
            <h3 className="text-sm font-medium text-foreground mb-2">{getGalleryHeader(item.listing_type)}</h3>
            <div className="grid grid-cols-3 gap-2">
              {imageOnly.slice(0, 6).map((img, idx) => (
                <img
                  key={idx}
                  src={img}
                  alt={`${item.title} ${idx + 1}`}
                  className="w-full aspect-square object-cover rounded-lg border border-border"
                />
              ))}
            </div>
          </div>
        );
      })()}

      <Button 
        className="w-full rounded-full" 
        onClick={onViewDetails}
      >
        <ExternalLink className="w-4 h-4 mr-2" />
        View Full Details
      </Button>
    </>
  );
};

const VideoPreviewModal: React.FC<VideoPreviewModalProps> = ({
  item,
  isOpen,
  onClose,
  onLike,
  onSave,
  onShare,
  onComment
}) => {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState('0:00');
  const [duration, setDuration] = useState('0:00');
  const [isClosing, setIsClosing] = useState(false);
  const [isEnded, setIsEnded] = useState(false);
  
  // Use global mute state and modal state
  const { globalMuted, setGlobalMuted, setIsVideoModalOpen } = useVideoModal();
  
  // Use the same interested hook as XStyleFeedCard
  const { isInterested, count: interestedCount, toggleInterested, isLoading: interestedLoading } = useInterested(item.id, item.content_type || 'ad');
  const { isFollowing, toggleFollow, isLoading: followLoading } = useFollow(item.seller.id);
  
  const y = useMotionValue(0);
  const x = useMotionValue(0);
  const scale = useTransform(y, [-100, 0, 200], [1, 1, 0.85]);
  const opacity = useTransform(x, [-300, 0, 300], [0.4, 1, 0.4]);

  // Auto-hide controls after 3s of inactivity
  const scheduleHide = useCallback(() => {
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    hideTimerRef.current = setTimeout(() => setControlsVisible(false), 3000);
  }, []);

  useEffect(() => {
    if (isOpen && controlsVisible) scheduleHide();
    return () => {
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, [isOpen, controlsVisible, scheduleHide]);

  // Track modal open state to pause feed videos
  useEffect(() => {
    if (isOpen) {
      setIsVideoModalOpen(true);
    }
    return () => {
      if (isOpen) {
        setIsVideoModalOpen(false);
      }
    };
  }, [isOpen, setIsVideoModalOpen]);

  useEffect(() => {
    if (isOpen && videoRef.current) {
      videoRef.current.muted = globalMuted;
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
      setDrawerOpen(false);
      setIsClosing(false);
      setIsEnded(false);
    }
  }, [isOpen, globalMuted]);

  useEffect(() => {
    if (drawerOpen && videoRef.current && isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  }, [drawerOpen]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const updateProgress = () => {
      const prog = (video.currentTime / video.duration) * 100;
      setProgress(isNaN(prog) ? 0 : prog);
      setCurrentTime(formatTime(video.currentTime));
    };

    const updateDuration = () => {
      setDuration(formatTime(video.duration));
    };

    const handleEnded = () => {
      setIsEnded(true);
      setIsPlaying(false);
    };

    video.addEventListener('timeupdate', updateProgress);
    video.addEventListener('loadedmetadata', updateDuration);
    video.addEventListener('ended', handleEnded);
    return () => {
      video.removeEventListener('timeupdate', updateProgress);
      video.removeEventListener('loadedmetadata', updateDuration);
      video.removeEventListener('ended', handleEnded);
    };
  }, []);

  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    // Swipe left to close (mirrors back navigation)
    if (info.offset.x < -120 || (info.offset.x < -60 && info.velocity.x < -300)) {
      setIsClosing(true);
      setTimeout(() => {
        onClose();
        setIsClosing(false);
      }, 200);
      return;
    }
    if (info.offset.y > 100 && info.velocity.y > 0) {
      setDrawerOpen(true);
    } else if (info.offset.y < -100 && info.velocity.y < 0) {
      setIsClosing(true);
      setTimeout(() => {
        onClose();
        setIsClosing(false);
      }, 200);
    }
  };

  const togglePlay = useCallback(() => {
    if (videoRef.current) {
      if (isEnded) {
        // Replay from start
        videoRef.current.currentTime = 0;
        videoRef.current.play();
        setIsEnded(false);
        setIsPlaying(true);
      } else if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play();
        setIsPlaying(true);
      }
    }
  }, [isPlaying, isEnded]);

  const handleReplay = useCallback(() => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play();
      setIsEnded(false);
      setIsPlaying(true);
    }
  }, []);

  const skipForward = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      videoRef.current.currentTime = Math.min(videoRef.current.currentTime + 10, videoRef.current.duration);
    }
  }, []);

  const skipBackward = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      videoRef.current.currentTime = Math.max(videoRef.current.currentTime - 10, 0);
    }
  }, []);

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      const newMuted = !globalMuted;
      videoRef.current.muted = newMuted;
      setGlobalMuted(newMuted);
    }
  };

  const handleViewFullDetails = () => {
    onClose();
    const contentType = item.content_type;
    const listingType = item.listing_type;
    if (contentType === 'event') {
      navigate(`/event/${item.id}`);
    } else if (listingType === 'services') {
      navigate(`/service/${item.id}`);
    } else if (listingType === 'promotions') {
      navigate(`/promotion/${item.id}`);
    } else {
      navigate(`/ad/${item.id}`);
    }
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const video = videoRef.current;
    if (!video) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    video.currentTime = pos * video.duration;
    if (isEnded) {
      setIsEnded(false);
      video.play();
      setIsPlaying(true);
    }
  };

  const formatCount = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count.toString();
  };

  const sanitizedVideoUrl = React.useMemo(() => {
    if (!item.b2_video_url) return '';
    let clean = videoCdnUrl(item.b2_video_url) || item.b2_video_url;
    while (clean.match(/^https:\/\/https:\/\//)) {
      clean = clean.replace(/^https:\/\/https:\/\//, 'https://');
    }
    return clean;
  }, [item.b2_video_url]);

  // Warm the cache as soon as the modal mounts (covers the case where the
  // user opens a video that wasn't visible in the feed yet).
  React.useEffect(() => {
    if (isOpen) {
      prefetchPoster(videoPlaceholder);
      if (sanitizedVideoUrl) prefetchVideo(sanitizedVideoUrl);
    }
  }, [isOpen, sanitizedVideoUrl]);

  const handleDrawerClose = () => {
    setDrawerOpen(false);
    if (videoRef.current && !isEnded) {
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  };
  
  // Get specs for the item
  const specs = getSpecsForListingType(item);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[200] bg-black"
        >
          <motion.div
            drag
            dragConstraints={{ top: 0, bottom: 0, left: 0, right: 0 }}
            dragElastic={0.3}
            onDragEnd={handleDragEnd}
            style={{ x, y, scale: isClosing ? 0.85 : scale, opacity, willChange: 'transform' }}
            className="h-full w-full relative flex flex-col origin-bottom"
          >
            {/* Top controls */}
            <motion.div
              animate={{ opacity: controlsVisible ? 1 : 0 }}
              transition={{ duration: 0.2 }}
              style={{ pointerEvents: controlsVisible ? 'auto' : 'none' }}
              className="absolute top-0 left-0 right-0 z-50 safe-area-inset-top"
            >
              <div className="flex items-center justify-between px-4 py-3">
                <button
                  onClick={onClose}
                  className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-white active:scale-95 transition-transform"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                
                <div className="flex items-center gap-2">
                  <button
                    onClick={toggleMute}
                    className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-white active:scale-95 transition-transform"
                  >
                    {globalMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); setMenuOpen(true); }}
                    aria-label="More options"
                    className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-white active:scale-95 transition-transform"
                  >
                    <MoreVertical className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>

            {/* Video */}
            <div
              className="flex-1 flex items-center justify-center"
              onClick={() => {
                if (controlsVisible) {
                  setControlsVisible(false);
                  if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
                } else {
                  setControlsVisible(true);
                  scheduleHide();
                }
              }}
              onDoubleClick={togglePlay}
            >
              <SmartVideo
                ref={videoRef}
                src={sanitizedVideoUrl}
                poster={videoPlaceholder}
                className="w-full h-full object-contain"
                style={{ transform: 'translateZ(0)', backfaceVisibility: 'hidden' }}
                playsInline
                autoPlay
                muted={globalMuted}
              />

              {/* Center play/pause/replay overlay */}
              <AnimatePresence>
                {(isEnded || !isPlaying) && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="absolute inset-0 flex items-center justify-center pointer-events-none"
                  >
                    <div className="w-16 h-16 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center">
                      {isEnded ? (
                        <RotateCcw className="w-8 h-8 text-white" />
                      ) : (
                        <Play className="w-8 h-8 text-white ml-1" fill="white" />
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Sharp linear gradient overlay at bottom for readability */}
            <motion.div
              animate={{ opacity: controlsVisible ? 1 : 0 }}
              transition={{ duration: 0.2 }}
              className="absolute bottom-0 left-0 right-0 h-[55%] bg-gradient-to-t from-black via-black/70 to-transparent pointer-events-none z-5"
            />

            {/* Bottom content area - organized non-overlapping layout */}
            <motion.div
              animate={{ opacity: controlsVisible ? 1 : 0, y: controlsVisible ? 0 : 20 }}
              transition={{ duration: 0.2 }}
              style={{ pointerEvents: controlsVisible ? 'auto' : 'none' }}
              className="absolute bottom-0 left-0 right-0 z-10 pb-[88px]"
            >
              {/* Progress bar with skip controls - at top */}
              <div className="px-4 mb-3">
                <div className="flex items-center gap-2">
                  {/* Skip backward 10s button */}
                  <button
                    onClick={skipBackward}
                    className="w-9 h-9 flex items-center justify-center text-white/90 hover:text-white transition-colors relative"
                  >
                    <SkipBack className="w-4 h-4" />
                    <span className="absolute -bottom-2.5 text-[8px] text-white/60 font-medium">10s</span>
                  </button>
                  
                  {/* Play/pause button */}
                  <button 
                    onClick={(e) => { e.stopPropagation(); togglePlay(); }} 
                    className="w-9 h-9 flex items-center justify-center text-white"
                  >
                    {isEnded ? (
                      <RotateCcw className="w-4 h-4" />
                    ) : isPlaying ? (
                      <Pause className="w-4 h-4" fill="white" />
                    ) : (
                      <Play className="w-4 h-4 ml-0.5" fill="white" />
                    )}
                  </button>

                  {/* Skip forward 10s button */}
                  <button
                    onClick={skipForward}
                    className="w-9 h-9 flex items-center justify-center text-white/90 hover:text-white transition-colors relative"
                  >
                    <SkipForward className="w-4 h-4" />
                    <span className="absolute -bottom-2.5 text-[8px] text-white/60 font-medium">10s</span>
                  </button>
                  
                  {/* Progress bar */}
                  <div 
                    className="flex-1 h-1 bg-white/20 rounded-full cursor-pointer overflow-hidden"
                    onClick={handleProgressClick}
                  >
                    <div 
                      className="h-full bg-white rounded-full transition-all duration-100"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  
                  {/* Time display */}
                  <span className="text-white/70 text-xs font-medium min-w-[60px] text-right">
                    {currentTime} / {duration}
                  </span>
                </div>
              </div>

              {/* Account info - single line */}
              <div className="px-4 mb-2">
                <div className="flex items-center gap-2">
                  <Avatar
                    className="w-8 h-8 border border-white/30 cursor-pointer shrink-0"
                    onClick={(e) => {
                      e.stopPropagation();
                      onClose();
                      navigate(getSellerProfileUrl(item.seller));
                    }}
                  >
                    <AvatarImage src={item.seller.business_logo_url} />
                    <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                      {item.seller.business_name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="font-semibold text-white text-sm truncate">{item.seller.business_name}</span>
                  {item.seller.is_verified && (
                    <UnifiedVerifiedBadge isVerified badgeColor={item.seller.verification_badge_color} size="sm" />
                  )}
                </div>
              </div>
              
              {/* Product title */}
              <div className="px-4 mb-1">
                <h3 className="text-white font-semibold text-base line-clamp-1">{item.title}</h3>
              </div>

              {/* Description - 3 lines max with Show More */}
              {item.description && (
                <div className="px-4 mb-2">
                  <p className="text-white/80 text-xs line-clamp-3 leading-relaxed">{item.description}</p>
                  {item.description.length > 120 && (
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setDrawerOpen(true);
                      }}
                      className="text-white/60 text-xs mt-0.5 hover:text-white transition-colors"
                    >
                      Show more
                    </button>
                  )}
                </div>
              )}

              {/* Horizontal specs carousel */}
              <div className="px-4">
                <SpecsCarousel specs={specs} />
              </div>
            </motion.div>

            {/* Bottom action bar */}
            <motion.div
              animate={{ opacity: controlsVisible ? 1 : 0, y: controlsVisible ? 0 : 40 }}
              transition={{ duration: 0.2 }}
              style={{ pointerEvents: controlsVisible ? 'auto' : 'none' }}
              className="absolute bottom-0 left-0 right-0 bg-black/80 backdrop-blur-sm border-t border-white/10 safe-area-inset-bottom z-20"
            >
              <div className="flex items-center justify-around py-3 px-2">
                {/* Comment */}
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onComment(item);
                  }}
                  className="flex flex-col items-center gap-0.5 text-white/80 active:scale-95 transition-transform min-w-[50px]"
                >
                  <MessageCircle className="w-5 h-5" />
                  
                </button>

                {/* Interested (ThumbsUp) */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleInterested();
                  }}
                  disabled={interestedLoading}
                  className={cn(
                    "flex flex-col items-center gap-0.5 active:scale-95 transition-transform min-w-[50px]",
                    isInterested ? "text-primary" : "text-white/80"
                  )}
                >
                  <ThumbsUp className={cn("w-5 h-5", isInterested && "fill-current")} />
                  
                </button>

                {/* Views */}
                <button className="flex flex-col items-center gap-0.5 text-white/80 min-w-[50px]">
                  <BarChart3 className="w-5 h-5" />
                  <span className="text-[10px]">{formatCount(item.view_count)}</span>
                </button>

                {/* Save */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSave(item.id);
                  }}
                  className={cn(
                    "flex flex-col items-center gap-0.5 active:scale-95 transition-transform min-w-[50px]",
                    item.is_saved ? "text-primary" : "text-white/80"
                  )}
                >
                  <Bookmark className={cn("w-5 h-5", item.is_saved && "fill-current")} />
                  <span className="text-[10px]">Save</span>
                </button>

                {/* Share */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onShare(item);
                  }}
                  className="flex flex-col items-center gap-0.5 text-white/80 active:scale-95 transition-transform min-w-[50px]"
                >
                  <Share2 className="w-5 h-5" />
                  <span className="text-[10px]">Share</span>
                </button>
              </div>
            </motion.div>

            {/* Swipe hint */}
            <motion.div
              animate={{ opacity: drawerOpen || !controlsVisible ? 0 : 1 }}
              className="absolute bottom-[130px] left-1/2 -translate-x-1/2 z-10"
            >
              <div className="flex flex-col items-center gap-1">
                <div className="w-8 h-1 bg-white/40 rounded-full" />
                <span className="text-white/50 text-[10px]">Swipe left to close • Swipe down for details</span>
              </div>
            </motion.div>
          </motion.div>

          {/* Drawer with dynamic content */}
          <Drawer open={drawerOpen} onOpenChange={setDrawerOpen} onClose={handleDrawerClose}>
            <DrawerContent className="max-h-[85vh] bg-card z-[250]">
              <div className="mx-auto w-12 h-1.5 flex-shrink-0 rounded-full bg-muted my-3" />
              
              <div className="overflow-y-auto px-4 pb-8">
                <DynamicDrawerContent 
                  item={item} 
                  onClose={onClose} 
                  onViewDetails={handleViewFullDetails} 
                />
              </div>
            </DrawerContent>
          </Drawer>

          {/* Three-dot menu drawer */}
          <Drawer open={menuOpen} onOpenChange={setMenuOpen}>
            <DrawerContent className="bg-card z-[260]">
              <div className="mx-auto w-12 h-1.5 flex-shrink-0 rounded-full bg-muted my-3" />
              <div className="px-2 pb-6">
                <button
                  onClick={async () => {
                    if (followLoading) return;
                    await toggleFollow();
                    setMenuOpen(false);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-muted text-left"
                >
                  {isFollowing ? <UserMinus className="w-5 h-5 text-muted-foreground" /> : <UserPlus className="w-5 h-5 text-muted-foreground" />}
                  <span className="text-sm text-foreground">
                    {isFollowing ? 'Unfollow' : 'Follow'} {item.seller.business_name}
                  </span>
                </button>
                <button
                  onClick={() => { toast.success("Thanks — we'll show you less like this"); setMenuOpen(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-muted text-left"
                >
                  <EyeOff className="w-5 h-5 text-muted-foreground" />
                  <span className="text-sm text-foreground">Not interested</span>
                </button>
                <button
                  onClick={() => { toast("You're seeing this because it matches your interests and activity."); setMenuOpen(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-muted text-left"
                >
                  <HelpCircle className="w-5 h-5 text-muted-foreground" />
                  <span className="text-sm text-foreground">Why am I seeing this?</span>
                </button>
                <button
                  onClick={() => { onShare(item); setMenuOpen(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-muted text-left"
                >
                  <Share2 className="w-5 h-5 text-muted-foreground" />
                  <span className="text-sm text-foreground">Share video</span>
                </button>
                <button
                  disabled
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left opacity-40 cursor-not-allowed"
                >
                  <Download className="w-5 h-5 text-muted-foreground" />
                  <span className="text-sm text-foreground">Download (disabled)</span>
                </button>
              </div>
            </DrawerContent>
          </Drawer>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default VideoPreviewModal;
