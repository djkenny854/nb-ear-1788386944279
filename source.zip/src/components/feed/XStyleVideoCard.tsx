import React, { useState, useRef, useEffect, useCallback } from 'react';
import { videoCdnUrl } from '@/utils/cdnUrl';
import { MessageCircle, Share2, BarChart3, Bookmark, Play, Volume2, VolumeX, Calendar, MapPin, Ticket, Loader2, ThumbsUp, Briefcase, DollarSign, ExternalLink } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import FeedCardMenu from './FeedCardMenu';
import { getClampedRatio } from '@/components/media/AdaptiveMedia';
import { useIsMobile } from '@/hooks/use-mobile';
import { setCurrentlyPlayingVideo } from '@/components/SocialFeed';
import { useViewTracking } from '@/hooks/useViewTracking';
import { useEngagement, useInterested } from '@/hooks/useEngagement';
import { useAuth } from '@/components/auth/AuthContext';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';
import { useVideoModal } from '@/contexts/VideoModalContext';
import { motion } from 'framer-motion';
import confetti from 'canvas-confetti';
import { formatThresholdCount } from '@/lib/formatThreshold';
import videoPlaceholder from '@/assets/video-placeholder.webp';
import { prefetchVideo } from '@/utils/videoPrefetch';
import SmartVideo from '@/components/media/SmartVideo';
import { useGlobalSettingsSafe } from '@/contexts/AppSettingsContext';

interface FeedItemBase {
  id: string;
  title: string;
  description: string;
  price: number;
  images: string[];
  category: string;
  location: string;
  created_at: string;
  listing_type: string;
  content_type: 'ad' | 'post' | 'event';
  b2_video_url?: string | null;
  youtube_url?: string | null;
  tiktok_url?: string | null;
  video_thumbnail_url?: string | null;
  video_width?: number | null;
  video_height?: number | null;
  job_details?: {
    job_posting_type?: 'single' | 'multiple';
  };
  seller: {
    id: string;
    user_id: string;
    business_name: string;
    business_logo_url: string;
    is_verified: boolean;
    verification_badge_color?: BadgeColor;
  };
  is_sponsored?: boolean;
  is_liked?: boolean;
  is_saved?: boolean;
  like_count: number;
  view_count: number;
  comment_count?: number;
  event_details?: {
    event_date?: string;
    end_date?: string;
    venue_name?: string;
    venue_address?: string;
    is_free?: boolean;
    ticket_price?: number;
    ticket_currency?: string;
  };
}

interface XStyleVideoCardProps {
  item: FeedItemBase;
  onLike: (id: string) => void;
  onSave: (id: string) => void;
  onShare: () => void;
  onComment: () => void;
  onSellerClick: () => void;
  onVideoClick: () => void;
  onItemClick: () => void;
  scrollContainer?: HTMLElement | null;
  autoplayEnabled?: boolean;
}

const XStyleVideoCard: React.FC<XStyleVideoCardProps> = ({
  item,
  onLike,
  onSave,
  onShare,
  onComment,
  onSellerClick,
  onVideoClick,
  onItemClick,
  scrollContainer,
  autoplayEnabled = true
}) => {
  const isMobile = useIsMobile();
  const videoRef = useRef<HTMLVideoElement>(null);
  const blurVideoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const interestedBtnRef = useRef<HTMLButtonElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const [aspectRatio, setAspectRatio] = useState<number>(16/9);
  const ratioFromPoster = useRef(false);
  const hasStoredDims = !!(item.video_width && item.video_height);
  const [isLoading, setIsLoading] = useState(true);
  const [isInView, setIsInView] = useState(false);
  const [progress, setProgress] = useState(0);
  const [likeAnimating, setLikeAnimating] = useState(false);
  const [decodeFailed, setDecodeFailed] = useState(false);
  const progressRef = useRef<HTMLDivElement>(null);
  
  // Use global mute state
  const { globalMuted, setGlobalMuted } = useVideoModal();
  const { isDataSaverActive } = useGlobalSettingsSafe();
  const effectiveAutoplay = autoplayEnabled && !isDataSaverActive;
  
  const { user } = useAuth();
  const { trackClick } = useEngagement();
  const { isInterested, count: interestedCount, toggleInterested, isLoading: interestedLoading } = useInterested(
    item.id,
    item.content_type,
    { initialCount: (item as any).like_count, initialInterested: (item as any).is_interested }
  );
  
  // View tracking - fires after 4 seconds in viewport (silent readers count too)
  const viewRef = useViewTracking({
    contentId: item.id,
    contentType: item.content_type,
    sourcePage: 'feed',
    threshold: 0.5,
    viewDuration: 4000,
  });
  
  const handleItemClick = () => {
    trackClick(item.id, item.content_type, 'item', 'feed');
    onItemClick();
  };
  
  const handleSellerClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    trackClick(item.id, item.content_type, 'seller', 'feed');
    onSellerClick();
  };
  
  const handleVideoClickWithTracking = (e: React.MouseEvent) => {
    e.stopPropagation();
    trackClick(item.id, item.content_type, 'video', 'feed');
    // For posts, always open the full post detail (with comments + embeds)
    // on both mobile and desktop. For ads/events keep the previous mobile-only behaviour.
    if (item.content_type === 'post' || isMobile) {
      onVideoClick();
    }
  };

  const formatCount = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count > 0 ? count.toString() : '';
  };

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds}s`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const formatEventDate = (dateString?: string) => {
    if (!dateString) return 'Date TBD';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
  };

  // Get poster image from item images (exclude video URLs)
  const posterImage = React.useMemo(() => {
    const images = item.images || [];
    const imageOnly = images.filter(img => !img.match(/\.(mp4|webm|mov|avi)$/i) && !img.includes('video'));
    return item.video_thumbnail_url || imageOnly[0] || videoPlaceholder;
  }, [item.images, item.video_thumbnail_url]);

  // Sanitize video URL
  const sanitizedVideoUrl = React.useMemo(() => {
    if (!item.b2_video_url) return '';
    let clean = videoCdnUrl(item.b2_video_url) || item.b2_video_url;
    while (clean.match(/^https:\/\/https:\/\//)) {
      clean = clean.replace(/^https:\/\/https:\/\//, 'https://');
    }
    return clean;
  }, [item.b2_video_url]);

  // Use the clean URL as the video src. We rely on a real `poster` attribute
  // (below) for the first-frame preview instead of a `#t=0.1` media fragment —
  // the fragment caused black playback on some desktop browsers.
  const videoSrc = sanitizedVideoUrl;

  // Warm the HTTP cache for this video so the modal opens instantly later.
  useEffect(() => {
    if (sanitizedVideoUrl) prefetchVideo(sanitizedVideoUrl);
  }, [sanitizedVideoUrl]);

  // Stored video dimensions win — they are the exact ratio the post detail view
  // uses, so the feed frame matches what the user sees inside the post.
  useEffect(() => {
    if (item.video_width && item.video_height) {
      ratioFromPoster.current = true;
      setAspectRatio(item.video_width / item.video_height);
    }
  }, [item.video_width, item.video_height]);

  // Otherwise derive a stable aspect ratio from the poster image BEFORE the video loads
  // so the container is sized correctly up-front (prevents layout shift / CLS).
  useEffect(() => {
    if (hasStoredDims) return;
    if (!posterImage || posterImage === videoPlaceholder) return;
    const img = new Image();
    img.onload = () => {
      if (img.naturalWidth && img.naturalHeight) {
        ratioFromPoster.current = true;
        setAspectRatio(img.naturalWidth / img.naturalHeight);
      }
    };
    img.src = posterImage;
  }, [posterImage, hasStoredDims]);

  // Detect video aspect ratio and track progress
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleLoadedMetadata = () => {
      const ratio = video.videoWidth / video.videoHeight;
      // Only adopt the video's intrinsic ratio if the poster didn't already
      // establish one — keeps the container dimensions constant before playback.
      if (!ratioFromPoster.current && ratio) setAspectRatio(ratio);
      setIsLoading(false);
    };

    const handleWaiting = () => setIsLoading(true);
    const handlePlaying = () => setIsLoading(false);
    const handleCanPlay = () => setIsLoading(false);
    const handleTimeUpdate = () => {
      if (video.duration) {
        setProgress((video.currentTime / video.duration) * 100);
      }
    };

    video.addEventListener('loadedmetadata', handleLoadedMetadata);
    video.addEventListener('waiting', handleWaiting);
    video.addEventListener('playing', handlePlaying);
    video.addEventListener('canplay', handleCanPlay);
    video.addEventListener('timeupdate', handleTimeUpdate);
    
    return () => {
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
      video.removeEventListener('waiting', handleWaiting);
      video.removeEventListener('playing', handlePlaying);
      video.removeEventListener('canplay', handleCanPlay);
      video.removeEventListener('timeupdate', handleTimeUpdate);
    };
  }, []);

  // Decode failure detection lives inside SmartVideo now — attaching a second
  // watchdog to the same element double-paused playable videos.

  // (Blur backdrop is a static poster image now — nothing to keep in sync.)


  // Intersection Observer for video visibility and autoplay
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          setIsInView(entry.isIntersecting && entry.intersectionRatio >= 0.5);
        });
      },
      { threshold: [0.1, 0.5, 0.8], root: null }
    );

    observer.observe(container);
    return () => observer.disconnect();
  }, []);

  // Handle autoplay based on visibility and video modal state
  const { isVideoModalOpen } = useVideoModal();
  
  useEffect(() => {
    const video = videoRef.current;
    const blurVideo = blurVideoRef.current;
    if (!video || !effectiveAutoplay) return;

    // If video modal is open, pause all feed videos
    if (isVideoModalOpen) {
      video.pause();
      blurVideo?.pause();
      setIsPlaying(false);
      return;
    }

    if (!isInView) {
      video.pause();
      blurVideo?.pause();
      setIsPlaying(false);
      return;
    }

    // In view: SmartVideo attaches `src` lazily on its own IntersectionObserver,
    // so the first play() can land on an element that has no source yet and
    // rejects permanently (card spins forever while the post detail page — which
    // attaches eagerly — plays fine). Retry until the element actually has data.
    setCurrentlyPlayingVideo(video);
    let cancelled = false;

    const tryPlay = () => {
      if (cancelled) return;
      // Nothing to play yet — wait for SmartVideo to attach the source.
      if (!video.currentSrc && !video.getAttribute('src')) return;
      video.play()
        .then(() => { if (!cancelled) setIsPlaying(true); })
        .catch(() => {
          if (cancelled) return;
          video.muted = true;
          video.play().then(() => { if (!cancelled) setIsPlaying(true); }).catch(() => {});
        });
    };

    tryPlay();
    video.addEventListener('loadedmetadata', tryPlay);
    video.addEventListener('loadeddata', tryPlay);
    video.addEventListener('canplay', tryPlay);
    // Final safety net for engines that attach the source without firing any of
    // the above in time (Android WebView, Safari after bfcache restore).
    const poll = window.setInterval(() => {
      if (cancelled) return;
      if (video.paused) tryPlay(); else window.clearInterval(poll);
    }, 600);

    blurVideo?.play().catch(() => {});

    return () => {
      cancelled = true;
      window.clearInterval(poll);
      video.removeEventListener('loadedmetadata', tryPlay);
      video.removeEventListener('loadeddata', tryPlay);
      video.removeEventListener('canplay', tryPlay);
    };
  }, [isInView, effectiveAutoplay, isVideoModalOpen, videoSrc]);


  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      const newMuted = !globalMuted;
      videoRef.current.muted = newMuted;
      setGlobalMuted(newMuted); // Update global state
    }
  };

  // Remove the old handleVideoClick and use the tracked one
  // Old handleVideoClick was here
  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const video = videoRef.current;
    const progressBar = progressRef.current;
    if (!video || !progressBar) return;
    
    const rect = progressBar.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    video.currentTime = pos * video.duration;
  };

  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    const video = videoRef.current;
    const blurVideo = blurVideoRef.current;
    if (!video) return;
    
    if (isPlaying) {
      video.pause();
      blurVideo?.pause();
      setIsPlaying(false);
    } else {
      setCurrentlyPlayingVideo(video);
      // Ensure src is attached (data-saver mode leaves it off until play tap),
      // then start playback on the next frame after React re-renders.
      setIsPlaying(true);
      requestAnimationFrame(() => {
        video.play().catch(() => setIsPlaying(false));
        blurVideo?.play().catch(() => {});
      });
    }
  };

  // Determine if video is portrait (TikTok-style)
  const isPortrait = aspectRatio < 0.8;

  // Clamp to X-style feed range (4:5 portrait max … 16:9 landscape max) so the
  // frame never gets taller than 4:5 or wider than 16:9. Cover fill handles the rest.
  const clampedRatio = getClampedRatio(aspectRatio, 'feed');

  // Absolute pixel ceiling (X.com style) — keeps container constant, no CLS.
  const maxFrameHeight = 512;

  return (
    <article 
      ref={viewRef}
      className="border-b border-border hover:bg-muted/30 transition-colors cursor-pointer"
      onClick={handleItemClick}
    >
      <div className="flex gap-3 px-4 pt-3 pb-1">
        {/* Avatar */}
        <div className="flex-shrink-0">
          <Avatar
            className="w-10 h-10 cursor-pointer hover:opacity-90 transition-opacity"
            onClick={handleSellerClick}
          >
            <AvatarImage src={item.seller.business_logo_url} />
            <AvatarFallback className="bg-primary/10 text-primary font-semibold">
              {item.seller.business_name.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-center gap-1 flex-wrap">
            <span
              className="font-semibold text-[14px] text-foreground hover:underline cursor-pointer truncate"
              onClick={handleSellerClick}
            >
              {item.seller.business_name}
            </span>
            <UnifiedVerifiedBadge 
              isVerified={item.seller.is_verified} 
              badgeColor={item.seller.verification_badge_color}
              size="sm" 
            />
            {/* Sponsored label */}
            {item.is_sponsored && (
              <span className="text-[10px] px-1.5 py-0.5 rounded-full font-medium bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">
                Sponsored
              </span>
            )}
            {/* Listing type label */}
            {item.content_type === 'ad' && item.listing_type && item.listing_type !== 'physical_products' && (
              <span className={cn(
                "text-[10px] px-1.5 py-0.5 rounded-full font-medium",
                item.listing_type === 'services' && "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
                item.listing_type === 'jobs' && "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
                item.listing_type === 'promotions' && "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400",
                item.listing_type === 'digital_products' && "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400"
              )}>
                {item.listing_type === 'services' ? 'Service' : 
                 item.listing_type === 'jobs' ? 'Job' :
                 item.listing_type === 'promotions' ? 'Promo' :
                 item.listing_type === 'digital_products' ? 'Digital' : ''}
              </span>
            )}
            {item.content_type === 'event' && (
              <span className="text-[10px] px-1.5 py-0.5 rounded-full font-medium bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400">
                Event
              </span>
            )}
            <div className="ml-auto relative z-10">
              <FeedCardMenu
                itemId={item.id}
                itemType={item.content_type}
                sellerId={item.seller.id}
                sellerUserId={item.seller.user_id}
                sellerName={item.seller.business_name}
                onSave={() => onSave(item.id)}
                isSaved={item.is_saved}
              />
            </div>
          </div>

          {/* Post content */}
          <div className="mt-0.5">
            {item.title && (
              <h3 className="text-[14px] font-semibold text-foreground mb-0.5">
                {item.title}
              </h3>
            )}
            
            {item.description && (
              <p className="text-[14px] text-foreground leading-[18px] whitespace-pre-wrap break-words line-clamp-3">
                {item.description}
              </p>
            )}

            {/* Event specific info */}
            {item.content_type === 'event' && item.event_details && (
              <div className="mt-2 flex flex-wrap gap-2 text-sm">
                <span className="flex items-center gap-1 text-muted-foreground">
                  <Calendar className="w-4 h-4" />
                  {formatEventDate(item.event_details.event_date)}
                </span>
                {item.event_details.venue_name && (
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <MapPin className="w-4 h-4" />
                    {item.event_details.venue_name}
                  </span>
                )}
                <span className="flex items-center gap-1">
                  <Ticket className="w-4 h-4 text-primary" />
                  {item.event_details.is_free ? (
                    <span className="text-green-500 font-medium">Free</span>
                  ) : (
                    <span className="text-primary font-medium">
                      {item.event_details.ticket_currency || 'UGX'} {item.event_details.ticket_price?.toLocaleString()}
                    </span>
                  )}
                </span>
              </div>
            )}

            {/* Price for ads */}
            {item.content_type === 'ad' && item.price > 0 && (
              <p className="text-primary font-bold text-lg mt-1">
                UGX {item.price.toLocaleString()}
              </p>
            )}

            {/* Video container - X.com style with blur background for portrait */}
            <div
              ref={containerRef}
              className={cn(
                "mt-2 rounded-2xl overflow-hidden border border-border relative",
                isPortrait ? "bg-muted" : "bg-black"
              )}
              style={
                { aspectRatio: String(clampedRatio), maxHeight: maxFrameHeight }
              }
              onMouseEnter={() => setShowControls(true)}
              onMouseLeave={() => setShowControls(false)}
              onClick={handleVideoClickWithTracking}
            >
              {/* Blurred backdrop for portrait — poster image, not a second
                  video stream (that doubled bandwidth and starved the real
                  player on mobile networks). */}
              {isPortrait && !isMobile && posterImage && (
                <div
                  aria-hidden
                  className="absolute inset-0 blur-2xl scale-110 opacity-50 bg-center bg-cover"
                  style={{ backgroundImage: `url(${posterImage})` }}
                />
              )}

              {/* Loading spinner - only for buffering after initial load */}
              {!isLoading && isPlaying && videoRef.current?.readyState !== undefined && videoRef.current.readyState < 3 && (
                <div className="absolute inset-0 z-10 flex items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-black/60 flex items-center justify-center">
                    <Loader2 className="w-6 h-6 text-white animate-spin" />
                  </div>
                </div>
              )}

              {/* Loading overlay shown over the video's first frame until it plays */}
              {isLoading && (
                <div className="absolute inset-0 z-10 flex items-center justify-center pointer-events-none">
                  <div className="relative flex flex-col items-center gap-2">
                    <div className="w-14 h-14 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center">
                      <Play className="w-7 h-7 text-white ml-0.5" fill="white" />
                    </div>
                    <Loader2 className="w-5 h-5 text-white/60 animate-spin" />
                  </div>
                </div>
              )}

              {/* Main video — same engine the service-workspace reels use */}
              <SmartVideo
                ref={videoRef}
                src={videoSrc}
                poster={posterImage !== videoPlaceholder ? posterImage : undefined}
                className={cn(
                  "absolute inset-0 w-full h-full",
                  "object-cover"
                )}
                loop
                muted={globalMuted}
                playsInline
                controlsList="nodownload nofullscreen noremoteplayback"
                disablePictureInPicture
                onContextMenu={(e) => e.preventDefault()}
                onReady={() => setIsLoading(false)}
                onLoadedData={() => setIsLoading(false)}
              />

              {decodeFailed && posterImage && (
                <div className="absolute inset-0 z-20 bg-black">
                  <img src={posterImage} alt="" className="absolute inset-0 w-full h-full object-cover" />
                </div>
              )}

              {/* Desktop: Play button on hover (top-left) */}
              {!isMobile && (
                <button
                  onClick={togglePlay}
                  className={cn(
                    "absolute top-3 left-3 w-9 h-9 rounded-full bg-black/70 flex items-center justify-center text-white transition-opacity z-20",
                    showControls ? "opacity-100" : "opacity-0"
                  )}
                >
                  {isPlaying ? (
                    <div className="w-3 h-3 flex gap-0.5">
                      <div className="w-1 h-full bg-white rounded-sm" />
                      <div className="w-1 h-full bg-white rounded-sm" />
                    </div>
                  ) : (
                    <Play className="w-4 h-4 ml-0.5" fill="currentColor" />
                  )}
                </button>
              )}

              {/* Center play overlay when paused */}
              {!isPlaying && !isLoading && (
                <div className="absolute inset-0 flex items-center justify-center z-[15] pointer-events-none">
                  <div className="w-14 h-14 rounded-full bg-black/60 flex items-center justify-center">
                    <Play className="w-7 h-7 text-white ml-1" fill="currentColor" />
                  </div>
                </div>
              )}

              {/* Desktop: Mute button on hover (top-right) */}
              {!isMobile && (
                <button
                  onClick={toggleMute}
                  className={cn(
                    "absolute top-3 right-3 w-9 h-9 rounded-full bg-black/70 flex items-center justify-center text-white transition-opacity z-20",
                    showControls ? "opacity-100" : "opacity-0"
                  )}
                >
                  {globalMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              )}

              {/* Mobile: Mute button (always visible) */}
              {isMobile && (
                <button
                  onClick={toggleMute}
                  className="absolute bottom-4 right-3 w-8 h-8 rounded-full bg-black/70 flex items-center justify-center text-white z-20"
                >
                  {globalMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              )}

              {/* Video duration indicator */}
              {videoRef.current?.duration && (
                <div className="absolute bottom-4 left-3 px-1.5 py-0.5 rounded bg-black/70 text-white text-xs font-medium z-20">
                  {Math.floor((videoRef.current.duration - (videoRef.current.currentTime || 0)) / 60)}:{String(Math.floor((videoRef.current.duration - (videoRef.current.currentTime || 0)) % 60)).padStart(2, '0')}
                </div>
              )}

              {/* Job CTA - View Full Details button */}
              {item.content_type === 'ad' && item.listing_type === 'jobs' && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onItemClick();
                  }}
                  className="absolute bottom-8 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full bg-primary/90 hover:bg-primary text-primary-foreground text-sm font-semibold shadow-lg z-20 flex items-center gap-2 backdrop-blur-sm transition-colors"
                >
                  <Briefcase className="w-4 h-4" />
                  View Full Job Details
                </button>
              )}

              {/* Progress bar at bottom - always seekable */}
              <div 
                ref={progressRef}
                className="absolute bottom-0 left-0 right-0 h-1 bg-white/30 cursor-pointer z-20"
                onClick={handleProgressClick}
              >
                <div 
                  className="h-full bg-white transition-all duration-100"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>

            {/* Grid layout for video + images when item has 4+ images */}
            {item.images && item.images.length >= 4 && (
              <div className="mt-[2px] grid grid-cols-3 gap-[2px] rounded-b-2xl overflow-hidden">
                {item.images.slice(0, 3).map((img, idx) => (
                  <div key={idx} className="relative h-[80px] sm:h-[90px]">
                    <img 
                      src={img} 
                      alt={`Image ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                    {idx === 2 && item.images.length > 3 && (
                      <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                        <span className="text-white text-sm font-bold">+{item.images.length - 3}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Action buttons - X.com style, no repost for videos */}
          <div className="flex items-center justify-between max-w-[400px] mt-2 mb-1.5 -ml-2 md:w-full">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onComment();
              }}
              className="flex items-center gap-0.5 group"
            >
              <div className="p-1.5 rounded-full group-hover:bg-primary/10 transition-colors">
                <MessageCircle className="w-4 h-4 text-muted-foreground group-hover:text-primary" />
              </div>
              
            </button>

            {/* Like - Thumbs up with confetti */}
            <button
              ref={interestedBtnRef}
              onClick={async (e) => {
                e.stopPropagation();
                if (!user) {
                  onLike(item.id);
                  return;
                }
                setLikeAnimating(true);
                if (interestedBtnRef.current && !isInterested) {
                  const rect = interestedBtnRef.current.getBoundingClientRect();
                  const x = (rect.left + rect.width / 2) / window.innerWidth;
                  const y = (rect.top + rect.height / 2) / window.innerHeight;
                  confetti({
                    particleCount: 30,
                    spread: 60,
                    startVelocity: 15,
                    gravity: 0.8,
                    ticks: 40,
                    origin: { x, y },
                    colors: ['hsl(var(--primary))', '#FFD700', '#FF6B6B', '#4ECDC4'],
                    scalar: 0.6,
                  });
                }
                await toggleInterested();
                setTimeout(() => setLikeAnimating(false), 300);
              }}
              disabled={interestedLoading}
              className="flex items-center gap-0.5 group"
              title="Like"
            >
              <motion.div 
                className="p-1.5 rounded-full group-hover:bg-primary/10 transition-colors"
                animate={likeAnimating ? { rotate: [0, -15, 15, -10, 10, 0], scale: [1, 1.2, 1] } : {}}
                transition={{ duration: 0.3 }}
              >
                <ThumbsUp className={cn(
                  "w-4 h-4 transition-colors",
                  isInterested ? "text-primary fill-primary" : "text-muted-foreground group-hover:text-primary"
                )} />
              </motion.div>
              {formatThresholdCount(interestedCount) && (
                <span className="text-[12px] text-muted-foreground group-hover:text-primary">
                  {formatThresholdCount(interestedCount)}
                </span>
              )}
            </button>

            {formatThresholdCount(item.view_count) && (
            <button className="flex items-center gap-0.5 group">
              <div className="p-1.5 rounded-full group-hover:bg-primary/10 transition-colors">
                <BarChart3 className="w-4 h-4 text-muted-foreground group-hover:text-primary" />
              </div>
              <span className="text-[12px] text-muted-foreground group-hover:text-primary">
                {formatThresholdCount(item.view_count)} views
              </span>
            </button>
            )}

            <div className="relative z-30 flex items-center pr-1">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onSave(item.id);
                }}
                onPointerDown={(e) => e.stopPropagation()}
                aria-label="Bookmark"
                className="relative z-30 inline-flex items-center justify-center min-h-[44px] min-w-[44px] sm:h-9 sm:w-9 sm:min-h-0 sm:min-w-0 rounded-full hover:bg-primary/10 transition-colors touch-manipulation"
              >
                <Bookmark className={cn(
                  "w-4 h-4 transition-colors pointer-events-none",
                  item.is_saved ? "text-primary fill-primary" : "text-muted-foreground hover:text-primary"
                )} />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onShare();
                }}
                onPointerDown={(e) => e.stopPropagation()}
                aria-label="Share"
                className="relative z-30 inline-flex items-center justify-center min-h-[44px] min-w-[44px] sm:h-9 sm:w-9 sm:min-h-0 sm:min-w-0 rounded-full hover:bg-primary/10 transition-colors touch-manipulation"
              >
                <Share2 className="w-4 h-4 text-muted-foreground hover:text-primary pointer-events-none" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </article>
  );
};

export default React.memo(XStyleVideoCard, (prev, next) =>
  prev.item?.id === next.item?.id &&
  prev.item?.is_liked === next.item?.is_liked &&
  prev.item?.is_saved === next.item?.is_saved &&
  prev.item?.like_count === next.item?.like_count &&
  prev.item?.comment_count === next.item?.comment_count &&
  prev.item?.view_count === next.item?.view_count
);

