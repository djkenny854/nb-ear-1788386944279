import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, X, Briefcase, Calendar, Tag, ShoppingBag, Users, TrendingUp, Compass, Zap, MapPin, MoreHorizontal, Package, Plus, Check } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { useCurrency } from '@/contexts/CurrencyContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useIsMobile } from '@/hooks/use-mobile';
import XStyleFeedCard from './XStyleFeedCard';
import XStyleVideoCard from './XStyleVideoCard';
import { getSellerProfileUrl } from '@/lib/sellerUrl';
import { format } from 'date-fns';
import UnifiedVerifiedBadge from '@/components/UnifiedVerifiedBadge';
import { useUniversalSearch, ContentType } from '@/hooks/useUniversalSearch';
import { useAIFeatureFlags } from '@/hooks/useAIFeatureFlags';

interface FeedItem {
  id: string;
  title: string;
  description: string;
  price: number;
  images: string[];
  category: string;
  location: string;
  created_at: string;
  listing_type: string;
  content_type: 'ad' | 'post' | 'event';
  b2_video_url?: string | null;
  youtube_url?: string | null;
  tiktok_url?: string | null;
  seller: {
    id: string;
    user_id: string;
    business_name: string;
    business_logo_url: string;
    is_verified: boolean;
  };
  is_liked?: boolean;
  is_saved?: boolean;
  like_count: number;
  view_count: number;
  job_details?: any;
  service_details?: any;
  promotion_details?: any;
  event_details?: any;
}

interface SellerResult {
  id: string;
  business_name: string;
  business_logo_url: string | null;
  is_verified: boolean;
  verification_badge_color?: string | null;
  store_slug: string | null;
  follower_count: number | null;
}

interface TrendingItem {
  category: string;
  count: number;
}

interface BoostedAd {
  id: string;
  title: string;
  price: number;
  images: string[];
}

interface LatestJob {
  id: string;
  title: string;
  location: string;
  company_name?: string;
  job_type?: string;
}

interface UpcomingEvent {
  id: string;
  title: string;
  location: string;
  event_date: string;
  is_free?: boolean;
}

type ContentFilter = 'all' | 'products' | 'jobs' | 'events' | 'promotions' | 'services' | 'sellers';

interface FeedSearchPanelProps {
  onLike: (id: string) => void;
  onSave: (id: string) => void;
  onShare: (item: FeedItem) => void;
  onComment: (item: FeedItem) => void;
}

// Primary filter tabs (Events lives in the overflow "+" menu)
const primaryFilters: { value: ContentFilter; label: string; icon: React.ElementType }[] = [
  { value: 'all', label: 'All', icon: Compass },
  { value: 'products', label: 'Products', icon: Package },
  { value: 'services', label: 'Services', icon: ShoppingBag },
  { value: 'jobs', label: 'Jobs', icon: Briefcase },
  { value: 'promotions', label: 'Promos', icon: Tag },
  { value: 'sellers', label: 'Sellers', icon: Users },
];

const extraFilters: { value: ContentFilter; label: string; icon: React.ElementType }[] = [
  { value: 'events', label: 'Events', icon: Calendar },
];

const ROTATING_PLACEHOLDERS = [
  'Search products…',
  "Try 'iPhone 15'",
  'Find services near you…',
  'Search sellers, shops…',
  "Try 'plumber in Kampala'",
  'Discover jobs, events, promos…',
];

const FeedSearchPanel: React.FC<FeedSearchPanelProps> = ({
  onLike,
  onSave,
  onShare,
  onComment,
}) => {
  const { aiSemanticSearchEnabled } = useAIFeatureFlags();
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [submittedQuery, setSubmittedQuery] = useState('');
  const { formatPriceCompact } = useCurrency();
  const [activeFilter, setActiveFilter] = useState<ContentFilter>('all');
  const [results, setResults] = useState<FeedItem[]>([]);
  const [sellerResults, setSellerResults] = useState<SellerResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const isMobile = useIsMobile();
  const [pickerOpen, setPickerOpen] = useState(false);
  const [phIndex, setPhIndex] = useState(0);
  const [isFocused, setIsFocused] = useState(false);

  // Rotate placeholder when idle
  useEffect(() => {
    if (isFocused || query) return;
    const t = setInterval(() => setPhIndex(i => (i + 1) % ROTATING_PLACEHOLDERS.length), 2800);
    return () => clearInterval(t);
  }, [isFocused, query]);

  // Sanitize search input to prevent XSS / SQL injection patterns.
  const sanitizeQuery = (raw: string): string => {
    // eslint-disable-next-line no-control-regex
    const controlChars = /[\x00-\x1F\x7F]/g;
    return raw
      .replace(/<[^>]*>/g, '')
      .replace(controlChars, '')
      .replace(/--|;|\/\*|\*\//g, '')
      .replace(/['"`\\%]/g, '')
      .trim()
      .slice(0, 100);
  };

  const handleSubmitSearch = () => {
    setSubmittedQuery(sanitizeQuery(query));
  };
  
  // Explore mode data (shown when "all" filter is active without search query)
  const [trendingItems, setTrendingItems] = useState<TrendingItem[]>([]);
  const [recommendedSellers, setRecommendedSellers] = useState<SellerResult[]>([]);
  const [latestJobs, setLatestJobs] = useState<LatestJob[]>([]);
  const [upcomingEvents, setUpcomingEvents] = useState<UpcomingEvent[]>([]);
  const [boostedAds, setBoostedAds] = useState<BoostedAd[]>([]);
  const [loadingExplore, setLoadingExplore] = useState(true);

  // Fetch explore content when in "all" mode without search
  useEffect(() => {
    if (activeFilter === 'all' && !query.trim()) {
      const fetchExploreContent = async () => {
        setLoadingExplore(true);
        try {
          // Fetch trending categories
          const { data: categories } = await supabase
            .from('ads')
            .select('category')
            .eq('status', 'active');
          
          if (categories) {
            const counts: { [key: string]: number } = {};
            categories.forEach((item: any) => {
              counts[item.category] = (counts[item.category] || 0) + 1;
            });
            const trending = Object.entries(counts)
              .map(([category, count]) => ({ category, count }))
              .sort((a, b) => b.count - a.count)
              .slice(0, 5);
            setTrendingItems(trending);
          }

          // Fetch recommended sellers (15)
          const { data: sellers } = await supabase
            .from('seller_profiles')
            .select('id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug, follower_count')
            .eq('is_active', true)
            .order('follower_count', { ascending: false })
            .limit(15);
          
          if (sellers) setRecommendedSellers(sellers);

          // Fetch latest jobs
          const { data: jobs } = await supabase
            .from('ads')
            .select(`id, title, location, job_details(company_name, job_type)`)
            .eq('status', 'active')
            .eq('listing_type', 'jobs')
            .order('created_at', { ascending: false })
            .limit(5);
          
          if (jobs) {
            setLatestJobs(jobs.map((j: any) => ({
              id: j.id,
              title: j.title,
              location: j.location,
              company_name: j.job_details?.[0]?.company_name,
              job_type: j.job_details?.[0]?.job_type
            })));
          }

          // Fetch upcoming events
          const { data: events } = await supabase
            .from('events')
            .select('id, title, location, event_date, is_free')
            .eq('is_active', true)
            .gte('event_date', new Date().toISOString())
            .order('event_date', { ascending: true })
            .limit(5);
          
          if (events) setUpcomingEvents(events);

          // Fetch boosted ads
          const { data: boosted } = await supabase
            .from('ads')
            .select('id, title, price, images')
            .eq('status', 'active')
            .eq('is_boosted', true)
            .limit(5);
          
          if (boosted) setBoostedAds(boosted);

        } catch (error) {
          console.error('Error fetching explore content:', error);
        } finally {
          setLoadingExplore(false);
        }
      };
      fetchExploreContent();
    }
  }, [activeFilter, query]);

  // Fetch content based on filter and submitted query (only on Enter / button press)
  useEffect(() => {
    const query = submittedQuery; // shadow: effect uses submitted value, not live input
    const fetchContent = async () => {
      // Skip fetching if in explore mode without search
      if (activeFilter === 'all' && !query.trim()) {
        setResults([]);
        setSellerResults([]);
        return;
      }
      
      setLoading(true);
      
      try {
        // Fetch sellers if filter is 'sellers' or 'all' with query
        if (activeFilter === 'sellers' || (activeFilter === 'all' && query.trim().length >= 2)) {
          const { data: sellers, error: sellersError } = await supabase
            .from('seller_profiles')
            .select('id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug, follower_count')
            .ilike('business_name', query.trim() ? `%${query}%` : '%')
            .eq('is_active', true)
            .order('follower_count', { ascending: false })
            .limit(activeFilter === 'sellers' ? 20 : 5);

          if (!sellersError && sellers) {
            setSellerResults(sellers);
          }
        } else {
          setSellerResults([]);
        }

        // Fetch feed items based on filter
        if (activeFilter !== 'sellers') {
          // Use semantic search when there's a query (2+ chars) and flag is on
          let semanticData: any = null;
          if (query.trim().length >= 2 && aiSemanticSearchEnabled) {
            try {
              const searchContentTypes: string[] = [];
              if (activeFilter === 'all' || activeFilter === 'products') searchContentTypes.push('products');
              if (activeFilter === 'all' || activeFilter === 'services') searchContentTypes.push('services');
              if (activeFilter === 'all' || activeFilter === 'jobs') searchContentTypes.push('jobs');
              if (activeFilter === 'all' || activeFilter === 'promotions') searchContentTypes.push('promotions');
              if (activeFilter === 'all' || activeFilter === 'events') searchContentTypes.push('events');

              const { data, error } = await supabase.functions.invoke('semantic-search', {
                body: {
                  query: query.trim(),
                  filters: { contentTypes: searchContentTypes },
                  limit: 30,
                },
              });

              if (!error && data && !data.error) {
                semanticData = data;
              }
            } catch (err) {
              console.warn('Semantic search failed in feed, falling back:', err);
            }
          }

          // Collect ad IDs from semantic results
          let semanticAdIds: string[] = [];
          if (semanticData) {
            const allAds = [
              ...(semanticData.products || []),
              ...(semanticData.services || []),
              ...(semanticData.jobs || []),
              ...(semanticData.promotions || []),
            ];
            semanticAdIds = allAds.map((a: any) => a.id);
          }

          // Fetch events
          let eventsData: any[] = [];
          if (activeFilter === 'events' || activeFilter === 'all') {
            if (semanticData && semanticData.events && semanticData.events.length > 0) {
              eventsData = semanticData.events;
            } else {
              let eventsQuery = supabase
                .from('events')
                .select(`
                  id, title, description, category, location, created_at, view_count, images,
                  event_date, end_date, venue_name, venue_address, is_free, ticket_price, ticket_currency,
                  seller_profiles(id, user_id, business_name, business_logo_url, is_verified)
                `)
                .eq('is_active', true)
                .order('created_at', { ascending: false });

              if (query.trim()) {
                eventsQuery = eventsQuery.ilike('title', `%${query}%`);
              }

              const { data: events } = await eventsQuery.limit(activeFilter === 'events' ? 20 : 5);
              eventsData = events || [];
            }
          }

          // Fetch ads - use semantic IDs if available, else fallback
          let adsData: any[] = [];
          if (activeFilter !== 'events') {
            if (semanticAdIds.length > 0) {
              // Fetch full ad details for semantic results
              const { data: ads } = await supabase
                .from('ads')
                .select(`
                  id, title, description, price, images, category, location, created_at,
                  view_count, save_count, listing_type, b2_video_url, youtube_url, tiktok_url,
                  seller_profiles(id, user_id, business_name, business_logo_url, is_verified)
                `)
                .in('id', semanticAdIds)
                .eq('status', 'active');

              adsData = ads || [];
            } else {
              // Original fallback query
              let listingType: string | null = null;
              switch (activeFilter) {
                case 'jobs': listingType = 'jobs'; break;
                case 'promotions': listingType = 'promotions'; break;
                case 'services': listingType = 'services'; break;
              }

              let adsQuery = supabase
                .from('ads')
                .select(`
                  id, title, description, price, images, category, location, created_at,
                  view_count, save_count, listing_type, b2_video_url, youtube_url, tiktok_url,
                  seller_profiles(id, user_id, business_name, business_logo_url, is_verified)
                `)
                .eq('status', 'active')
                .order('created_at', { ascending: false });

              if (listingType) {
                adsQuery = adsQuery.eq('listing_type', listingType);
              } else if (activeFilter === 'products') {
                adsQuery = adsQuery.not('listing_type', 'in', '("jobs","promotions","services")');
              }

              const { data: ads } = await adsQuery.limit(50);
              adsData = ads || [];

              // Client-side filtering for non-semantic fallback
              if (query.trim() && listingType === 'jobs') {
                const jobIds = adsData.map(ad => ad.id);
                if (jobIds.length > 0) {
                  const { data: jobDetails } = await supabase
                    .from('job_details')
                    .select('ad_id, positions, campaign_title, company_name')
                    .in('ad_id', jobIds);
                  
                  const searchLower = query.toLowerCase();
                  adsData = adsData.filter(ad => {
                    if (ad.title.toLowerCase().includes(searchLower)) return true;
                    if (ad.description?.toLowerCase().includes(searchLower)) return true;
                    const jobDetail = jobDetails?.find(j => j.ad_id === ad.id);
                    if (jobDetail) {
                      if (jobDetail.campaign_title?.toLowerCase().includes(searchLower)) return true;
                      if (jobDetail.company_name?.toLowerCase().includes(searchLower)) return true;
                      if (jobDetail.positions && Array.isArray(jobDetail.positions)) {
                        return jobDetail.positions.some((pos: any) => pos.role?.toLowerCase().includes(searchLower));
                      }
                    }
                    return false;
                  });
                }
              } else if (query.trim()) {
                // Order-independent token matching
                const tokens = query.toLowerCase().split(/\s+/).filter(t => t.length > 1);
                adsData = adsData.filter(ad => {
                  const haystack = [ad.title, ad.description, ad.category, ad.location].filter(Boolean).join(' ').toLowerCase();
                  return tokens.some(token => haystack.includes(token));
                });
              }
            }
          }

          // Transform and combine results
          const transformedAds: FeedItem[] = adsData
            .filter((ad: any) => ad.seller_profiles)
            .map((ad: any) => ({
            id: ad.id,
            title: ad.title,
            description: ad.description || '',
            price: ad.price || 0,
            images: ad.images || [],
            category: ad.category,
            location: ad.location,
            created_at: ad.created_at,
            listing_type: ad.listing_type,
            content_type: 'ad' as const,
            b2_video_url: ad.b2_video_url,
            youtube_url: ad.youtube_url,
            tiktok_url: ad.tiktok_url,
            seller: ad.seller_profiles,
            is_liked: false,
            is_saved: false,
            like_count: 0,
            view_count: ad.view_count || 0,
          }));

          const transformedEvents: FeedItem[] = (Array.isArray(eventsData) ? eventsData : [])
            .filter((event: any) => event.seller_profiles)
            .map((event: any) => ({
            id: event.id,
            title: event.title,
            description: event.description || '',
            price: event.ticket_price || 0,
            images: event.images || [],
            category: event.category,
            location: event.location,
            created_at: event.created_at,
            listing_type: 'events',
            content_type: 'event' as const,
            seller: event.seller_profiles,
            is_liked: false,
            is_saved: false,
            like_count: 0,
            view_count: event.view_count || 0,
            event_details: {
              event_date: event.event_date,
              end_date: event.end_date,
              venue_name: event.venue_name,
              venue_address: event.venue_address,
              is_free: event.is_free,
              ticket_price: event.ticket_price,
              ticket_currency: event.ticket_currency,
            },
          }));

          const combined = [...transformedAds, ...transformedEvents].sort(
            (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
          );

          setResults(combined);
        } else {
          setResults([]);
        }

        setHasSearched(true);
      } catch (error) {
        console.error('Search error:', error);
      } finally {
        setLoading(false);
      }
    };

    // Run immediately when submittedQuery or filter changes (no per-keystroke debounce)
    fetchContent();
  }, [submittedQuery, activeFilter, aiSemanticSearchEnabled]);

  const handleSellerClick = (seller: SellerResult) => {
    navigate(`/business/${seller.store_slug || seller.id}`);
  };

  const handleItemClick = (item: FeedItem) => {
    if (item.content_type === 'event') {
      navigate(`/event/${item.id}`);
    } else {
      switch (item.listing_type) {
        case 'jobs':
          navigate(`/job/${item.id}`);
          break;
        case 'promotions':
          navigate(`/promotion/${item.id}`);
          break;
        case 'services':
          navigate(`/service/${item.id}`);
          break;
        default:
          navigate(`/ad/${item.id}`);
      }
    }
  };

  const activeExtra = extraFilters.find(f => f.value === activeFilter);
  const tabsToRender = activeExtra ? [...primaryFilters, activeExtra] : primaryFilters;

  const ExtraPicker = isMobile ? (
    <Drawer open={pickerOpen} onOpenChange={setPickerOpen}>
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle>More categories</DrawerTitle>
        </DrawerHeader>
        <div className="px-4 pb-6 grid gap-2">
          {extraFilters.map((opt) => {
            const Icon = opt.icon;
            const active = opt.value === activeFilter;
            return (
              <button
                key={opt.value}
                onClick={() => { setActiveFilter(opt.value); setPickerOpen(false); }}
                className={cn(
                  'flex items-center gap-3 rounded-xl border border-border px-4 py-3 text-left transition-colors',
                  active ? 'bg-primary/10 border-primary text-primary' : 'hover:bg-muted'
                )}
              >
                <Icon className="w-5 h-5" />
                <span className="flex-1 font-medium">{opt.label}</span>
                {active && <Check className="w-4 h-4" />}
              </button>
            );
          })}
        </div>
      </DrawerContent>
    </Drawer>
  ) : (
    <Dialog open={pickerOpen} onOpenChange={setPickerOpen}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>More categories</DialogTitle>
        </DialogHeader>
        <div className="grid gap-2">
          {extraFilters.map((opt) => {
            const Icon = opt.icon;
            const active = opt.value === activeFilter;
            return (
              <button
                key={opt.value}
                onClick={() => { setActiveFilter(opt.value); setPickerOpen(false); }}
                className={cn(
                  'flex items-center gap-3 rounded-xl border border-border px-4 py-3 text-left transition-colors',
                  active ? 'bg-primary/10 border-primary text-primary' : 'hover:bg-muted'
                )}
              >
                <Icon className="w-5 h-5" />
                <span className="flex-1 font-medium">{opt.label}</span>
                {active && <Check className="w-4 h-4" />}
              </button>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );

  return (
    <div className="flex flex-col min-h-full">
      {/* Search input - rectangular, icon inside, no submit button (Enter to search) */}
      <div className="p-3 border-b border-border">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSubmitSearch();
          }}
          className={cn(
            'relative flex items-center gap-2 h-12 px-3 rounded-xl bg-muted/40 border transition-colors',
            isFocused ? 'border-primary bg-background' : 'border-transparent hover:border-border'
          )}
        >
          <Search className="w-5 h-5 text-muted-foreground shrink-0" strokeWidth={2} />
          <input
            ref={inputRef}
            type="search"
            inputMode="search"
            enterKeyHint="search"
            autoComplete="off"
            spellCheck={false}
            maxLength={100}
            placeholder={ROTATING_PLACEHOLDERS[phIndex]}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            className="flex-1 bg-transparent border-0 outline-none text-[15px] text-foreground placeholder:text-muted-foreground/70 min-w-0"
          />
          {query && (
            <button
              type="button"
              onClick={() => { setQuery(''); setSubmittedQuery(''); inputRef.current?.focus(); }}
              className="p-1 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              aria-label="Clear search"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </form>
      </div>

      {/* Animated underline tabs */}
      <div className="border-b border-border">
        <div className="flex items-center gap-0 overflow-x-auto scrollbar-hide px-2">
          {tabsToRender.map((tab) => {
            const Icon = tab.icon;
            const active = tab.value === activeFilter;
            return (
              <button
                key={tab.value}
                onClick={() => setActiveFilter(tab.value)}
                className={cn(
                  'relative shrink-0 px-3 h-11 flex items-center gap-1.5 text-sm font-medium transition-colors',
                  active ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
                )}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {active && (
                  <motion.span
                    layoutId="feed-search-tab-underline"
                    className="absolute left-2 right-2 bottom-0 h-[2px] rounded-full bg-primary"
                    transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                  />
                )}
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => setPickerOpen(true)}
            className="shrink-0 ml-1 mr-2 inline-flex items-center justify-center w-8 h-8 rounded-full border border-border bg-background text-muted-foreground hover:text-primary hover:border-primary transition-colors"
            aria-label="More categories"
            title="More categories"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {ExtraPicker}



      {/* Results */}
      <div className="flex-1">
        {loading || (activeFilter === 'all' && !query.trim() && loadingExplore) ? (
          <div className="p-4 space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex gap-3">
                <Skeleton className="w-12 h-12 rounded-full flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                  <Skeleton className="h-32 w-full rounded-xl" />
                </div>
              </div>
            ))}
          </div>
        ) : activeFilter === 'all' && !query.trim() ? (
          /* Explore Mode - Show sidebar-like content */
          <div className="space-y-4 p-3">
            {/* Trending Section */}
            {trendingItems.length > 0 && (
              <div className="bg-muted/5 rounded-2xl overflow-hidden">
                <div className="px-4 py-3">
                  <h2 className="text-lg font-bold">Trends for you</h2>
                </div>
                <div className="divide-y divide-border/10">
                  {trendingItems.map((item, idx) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className="px-4 py-3 hover:bg-muted/10 cursor-pointer transition-colors"
                      onClick={() => navigate(`/search?category=${encodeURIComponent(item.category)}&contentType=all`)}
                    >
                      <p className="text-xs text-muted-foreground">Trending in Uganda</p>
                      <p className="font-bold text-[15px] mt-0.5">{item.category}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{item.count.toLocaleString()} listings</p>
                    </motion.div>
                  ))}
                </div>
                <button 
                  className="w-full px-4 py-3 text-left text-primary hover:bg-muted/10 transition-colors text-[15px]"
                  onClick={() => navigate('/search')}
                >
                  Show more
                </button>
              </div>
            )}

            {/* Who to follow Section */}
            {recommendedSellers.length > 0 && (
              <div className="bg-muted/5 rounded-2xl overflow-hidden">
                <div className="px-4 py-3">
                  <h2 className="text-lg font-bold">Who to follow</h2>
                </div>
                <div className="divide-y divide-border/10">
                  {recommendedSellers.slice(0, 5).map((seller, idx) => (
                    <motion.button
                      key={seller.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      onClick={() => handleSellerClick(seller)}
                      className="w-full px-4 py-3 flex items-center gap-3 hover:bg-muted/10 transition-colors text-left"
                    >
                      <Avatar className="w-10 h-10 flex-shrink-0 ring-1 ring-border/30">
                        <AvatarImage src={seller.business_logo_url || ''} />
                        <AvatarFallback className="bg-muted text-foreground font-bold text-sm">
                          {seller.business_name?.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="font-bold text-[15px] truncate">{seller.business_name}</span>
                          {seller.is_verified && (
                            <UnifiedVerifiedBadge isVerified badgeColor={seller.verification_badge_color} size="sm" />
                          )}
                        </div>
                        <p className="text-muted-foreground text-sm truncate">
                          @{seller.store_slug || seller.business_name?.toLowerCase().replace(/\s+/g, '')}
                        </p>
                      </div>
                    </motion.button>
                  ))}
                </div>
                <button 
                  className="w-full px-4 py-3 text-left text-primary hover:bg-muted/10 transition-colors text-[15px]"
                  onClick={() => setActiveFilter('sellers')}
                >
                  Show more
                </button>
              </div>
            )}

            {/* Latest Jobs Section */}
            {latestJobs.length > 0 && (
              <div className="bg-muted/5 rounded-2xl overflow-hidden">
                <div className="px-4 py-3 flex items-center gap-2">
                  <Briefcase className="w-5 h-5 text-blue-500" />
                  <h2 className="text-lg font-bold">Latest Jobs</h2>
                </div>
                <div className="divide-y divide-border/10">
                  {latestJobs.map((job, idx) => (
                    <motion.div 
                      key={job.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className="px-4 py-3 hover:bg-muted/10 cursor-pointer transition-colors"
                      onClick={() => navigate(`/job/${job.id}`)}
                    >
                      <p className="font-semibold text-[15px] line-clamp-1">{job.title}</p>
                      {job.company_name && (
                        <p className="text-sm text-muted-foreground line-clamp-1">{job.company_name}</p>
                      )}
                      <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                        <MapPin className="w-3 h-3" />
                        <span className="line-clamp-1">{job.location}</span>
                        {job.job_type && (
                          <span className="px-2 py-0.5 bg-blue-500/10 text-blue-500 rounded-full text-[11px]">
                            {job.job_type}
                          </span>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
                <button 
                  className="w-full px-4 py-3 text-left text-primary hover:bg-muted/10 transition-colors text-[15px]"
                  onClick={() => navigate('/search?contentType=jobs')}
                >
                  Browse all jobs
                </button>
              </div>
            )}

            {/* Upcoming Events Section */}
            {upcomingEvents.length > 0 && (
              <div className="bg-muted/5 rounded-2xl overflow-hidden">
                <div className="px-4 py-3 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-purple-500" />
                  <h2 className="text-lg font-bold">Upcoming Events</h2>
                </div>
                <div className="divide-y divide-border/10">
                  {upcomingEvents.map((event, idx) => (
                    <motion.div 
                      key={event.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className="px-4 py-3 hover:bg-muted/10 cursor-pointer transition-colors"
                      onClick={() => navigate(`/event/${event.id}`)}
                    >
                      <p className="font-semibold text-[15px] line-clamp-1">{event.title}</p>
                      <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                        <Calendar className="w-3 h-3" />
                        <span>{format(new Date(event.event_date), 'MMM d, yyyy')}</span>
                        {event.is_free && (
                          <span className="px-2 py-0.5 bg-green-500/10 text-green-500 rounded-full text-[11px]">
                            Free
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                        <MapPin className="w-3 h-3" />
                        <span className="line-clamp-1">{event.location}</span>
                      </div>
                    </motion.div>
                  ))}
                </div>
                <button 
                  className="w-full px-4 py-3 text-left text-primary hover:bg-muted/10 transition-colors text-[15px]"
                  onClick={() => navigate('/search?contentType=events')}
                >
                  Browse all events
                </button>
              </div>
            )}

            {/* Promoted Section */}
            {boostedAds.length > 0 && (
              <div className="bg-muted/5 rounded-2xl overflow-hidden">
                <div className="px-4 py-3 flex items-center gap-2">
                  <Zap className="w-5 h-5 text-yellow-500" />
                  <h2 className="text-lg font-bold">Promoted</h2>
                </div>
                <div className="divide-y divide-border/10">
                  {boostedAds.slice(0, 3).map((ad, idx) => (
                    <motion.div 
                      key={ad.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className="px-4 py-3 hover:bg-muted/10 cursor-pointer transition-colors"
                      onClick={() => navigate(`/ad/${ad.id}`)}
                    >
                      <div className="flex gap-3">
                        {ad.images?.[0] && (
                          <img 
                            src={ad.images[0]} 
                            alt={ad.title}
                            className="w-16 h-16 object-cover rounded-lg flex-shrink-0"
                          />
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-[15px] line-clamp-2">{ad.title}</p>
                          <p className="text-primary font-bold text-sm mt-1">
                            {formatPriceCompact(ad.price || 0)}
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <>
            {/* Sellers section */}
            {sellerResults.length > 0 && (
              <div className="border-b border-border">
                <div className="px-4 py-3">
                  <h3 className="font-semibold text-sm text-muted-foreground flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    Sellers
                  </h3>
                </div>
                <div className="pb-2">
                  {sellerResults.map((seller) => (
                    <motion.button
                      key={seller.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      onClick={() => handleSellerClick(seller)}
                      className="w-full px-4 py-3 flex items-center gap-3 hover:bg-muted/50 transition-colors text-left"
                    >
                      <Avatar className="w-11 h-11 flex-shrink-0 ring-1 ring-border/30">
                        <AvatarImage src={seller.business_logo_url || ''} />
                        <AvatarFallback className="bg-muted text-foreground font-semibold">
                          {seller.business_name?.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-semibold text-[15px] truncate">{seller.business_name}</span>
                          {seller.is_verified && (
                            <UnifiedVerifiedBadge isVerified badgeColor={seller.verification_badge_color} size="sm" />
                          )}
                        </div>
                        <p className="text-muted-foreground text-sm truncate">
                          @{seller.store_slug || seller.business_name?.toLowerCase().replace(/\s+/g, '')}
                          {seller.follower_count ? ` · ${seller.follower_count.toLocaleString()} followers` : ''}
                        </p>
                      </div>
                    </motion.button>
                  ))}
                </div>
              </div>
            )}

            {/* Feed results */}
            {results.length > 0 ? (
              <div>
                {activeFilter !== 'sellers' && results.length > 0 && sellerResults.length > 0 && (
                  <div className="px-4 py-3 border-b border-border">
                    <h3 className="font-semibold text-sm text-muted-foreground flex items-center gap-2">
                  {activeFilter === 'jobs' && <Briefcase className="w-4 h-4" />}
                      {activeFilter === 'events' && <Calendar className="w-4 h-4" />}
                      {activeFilter === 'promotions' && <Tag className="w-4 h-4" />}
                      {activeFilter === 'services' && <ShoppingBag className="w-4 h-4" />}
                      {activeFilter === 'all' && <TrendingUp className="w-4 h-4" />}
                      {activeFilter === 'all' ? 'Latest' : [...primaryFilters, ...extraFilters].find(f => f.value === activeFilter)?.label}
                    </h3>
                  </div>
                )}
                {results.map((item) => (
                  <div key={item.id}>
                    {item.b2_video_url ? (
                      <XStyleVideoCard
                        item={item}
                        onVideoClick={() => handleItemClick(item)}
                        onLike={onLike}
                        onSave={onSave}
                        onShare={() => onShare(item)}
                        onComment={() => onComment(item)}
                        onSellerClick={() => navigate(getSellerProfileUrl(item.seller))}
                        onItemClick={() => handleItemClick(item)}
                        autoplayEnabled={false}
                      />
                    ) : (
                      <XStyleFeedCard
                        item={item}
                        onLike={onLike}
                        onSave={onSave}
                        onShare={() => onShare(item)}
                        onComment={() => onComment(item)}
                        onSellerClick={() => navigate(getSellerProfileUrl(item.seller))}
                        onClick={() => handleItemClick(item)}
                      />
                    )}
                  </div>
                ))}
              </div>
            ) : hasSearched && activeFilter !== 'sellers' && !sellerResults.length ? (
              <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                  <Search className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold mb-2">
                  {query ? `No results for "${query}"` : `No ${activeFilter === 'all' ? 'content' : activeFilter} found`}
                </h3>
                <p className="text-muted-foreground text-sm max-w-sm">
                  {query ? 'Try a different search term or filter' : 'Check back later for new content'}
                </p>
              </div>
            ) : null}
          </>
        )}
      </div>
    </div>
  );
};

export default FeedSearchPanel;
