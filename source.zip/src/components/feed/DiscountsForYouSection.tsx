import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Percent, X, BadgeCheck, Package, ChevronRight } from 'lucide-react';

interface AttachedProduct {
  id: string;
  title: string;
  image: string;
}

interface PromotionItem {
  id: string;
  ad_id: string;
  title: string;
  image: string;
  offer_type: string;
  promotion_type: string | null;
  discount_percentage: number | null;
  discount_amount: number | null;
  brand_name: string;
  valid_until: string | null;
  attached_products: AttachedProduct[];
  product_count: number;
  seller: {
    id: string;
    business_name: string;
    is_verified: boolean;
  };
}

const DiscountsForYouSection: React.FC = () => {
  const navigate = useNavigate();
  const [promotions, setPromotions] = useState<PromotionItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    fetchPromotions();
  }, []);

  const fetchPromotions = async () => {
    try {
      // Fetch promotions with discount offer_type
      const { data, error } = await supabase
        .from('promotion_details')
        .select(`
          id,
          ad_id,
          offer_type,
          promotion_type,
          discount_percentage,
          discount_amount,
          brand_name,
          valid_until,
          ads!inner(
            id,
            title,
            images,
            status,
            seller_profiles(
              id,
              business_name,
              is_verified
            )
          )
        `)
        .eq('offer_type', 'Discount')
        .eq('ads.status', 'active')
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) throw error;

      // Fetch attached products for each promotion
      const promotionIds = (data || []).map((p: any) => p.id);
      
      let attachedProductsMap: Record<string, AttachedProduct[]> = {};
      let productCountMap: Record<string, number> = {};
      
      if (promotionIds.length > 0) {
        const { data: ppData } = await supabase
          .from('promotion_products')
          .select(`
            promotion_id,
            ads(id, title, images)
          `)
          .in('promotion_id', promotionIds);

        if (ppData) {
          for (const pp of ppData as any[]) {
            const promoId = pp.promotion_id;
            if (!attachedProductsMap[promoId]) {
              attachedProductsMap[promoId] = [];
              productCountMap[promoId] = 0;
            }
            productCountMap[promoId]++;
            if (attachedProductsMap[promoId].length < 4) {
              attachedProductsMap[promoId].push({
                id: pp.ads?.id || '',
                title: pp.ads?.title || '',
                image: pp.ads?.images?.[0] || '/placeholder.svg',
              });
            }
          }
        }
      }

      const formatted: PromotionItem[] = (data || []).map((item: any) => {
        const ad = item.ads;
        const seller = ad.seller_profiles;
        return {
          id: item.id,
          ad_id: item.ad_id,
          title: ad.title,
          image: ad.images?.[0] || '/placeholder.svg',
          offer_type: item.offer_type,
          promotion_type: item.promotion_type,
          discount_percentage: item.discount_percentage,
          discount_amount: item.discount_amount,
          brand_name: item.brand_name,
          valid_until: item.valid_until,
          attached_products: attachedProductsMap[item.id] || [],
          product_count: productCountMap[item.id] || 0,
          seller: {
            id: seller.id,
            business_name: seller.business_name,
            is_verified: seller.is_verified,
          },
        };
      });

      setPromotions(formatted);
    } catch (error) {
      console.error('Error fetching promotions:', error);
    } finally {
      setLoading(false);
    }
  };

  if (dismissed) return null;

  if (loading) {
    return (
      <div className="mx-4 my-4 rounded-2xl border border-border bg-card overflow-hidden">
        <div className="p-4 border-b border-border">
          <Skeleton className="h-5 w-32" />
        </div>
        <div className="divide-y divide-border">
          {[1, 2, 3].map(i => (
            <div key={i} className="p-4 flex items-start gap-3">
              <Skeleton className="w-14 h-14 rounded-xl" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-40" />
                <Skeleton className="h-3 w-24" />
                <div className="flex gap-1">
                  <Skeleton className="w-6 h-6 rounded-full" />
                  <Skeleton className="w-6 h-6 rounded-full" />
                  <Skeleton className="w-6 h-6 rounded-full" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (promotions.length === 0) return null;

  const currency = localStorage.getItem('app_currency') || 'UGX';

  return (
    <div className="mx-4 my-4 rounded-2xl border border-border bg-card overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 flex items-center justify-between border-b border-border">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-gradient-to-br from-red-500 to-orange-500">
            <Percent className="w-3.5 h-3.5 text-white" />
          </div>
          <h3 className="font-bold text-base text-foreground">Discounts for you</h3>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="p-1 rounded-full hover:bg-muted transition-colors"
        >
          <X className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      {/* Promotions list */}
      <div className="divide-y divide-border">
        {promotions.map(promo => (
          <div
            key={promo.id}
            onClick={() => navigate(`/promotion/${promo.ad_id}`)}
            className="p-4 flex items-start gap-3 hover:bg-muted/50 transition-colors cursor-pointer"
          >
            {/* Promotion image */}
            <div className="w-14 h-14 rounded-xl overflow-hidden bg-muted shrink-0 relative">
              <img
                src={promo.image}
                alt={promo.title}
                className="w-full h-full object-cover"
              />
              {/* Discount badge overlay */}
              {promo.discount_percentage && promo.discount_percentage > 0 && (
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-red-500 to-red-500/80 text-white text-[9px] font-bold text-center py-0.5">
                  -{promo.discount_percentage}%
                </div>
              )}
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-sm text-foreground line-clamp-1">
                {promo.title}
              </h4>
              
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-xs text-muted-foreground truncate">
                  {promo.seller.business_name}
                </span>
                {promo.seller.is_verified && (
                  <BadgeCheck className="w-3.5 h-3.5 text-primary shrink-0" />
                )}
              </div>

              {/* Labels */}
              <div className="flex flex-wrap gap-1 mt-1.5">
                {promo.promotion_type && (
                  <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-4">
                    {promo.promotion_type}
                  </Badge>
                )}
                {promo.discount_percentage && promo.discount_percentage > 0 && (
                  <Badge className="text-[10px] px-1.5 py-0 h-4 bg-red-500/10 text-red-600 dark:text-red-400 border-0">
                    {promo.discount_percentage}% OFF
                  </Badge>
                )}
                {promo.discount_amount && promo.discount_amount > 0 && (
                  <Badge className="text-[10px] px-1.5 py-0 h-4 bg-red-500/10 text-red-600 dark:text-red-400 border-0">
                    {currency} {promo.discount_amount.toLocaleString()} OFF
                  </Badge>
                )}
              </div>

              {/* Attached product avatars */}
              {promo.attached_products.length > 0 && (
                <div className="flex items-center gap-1 mt-2">
                  <div className="flex -space-x-2">
                    {promo.attached_products.map((product) => (
                      <Avatar key={product.id} className="w-6 h-6 border-2 border-card">
                        <AvatarImage src={product.image} className="object-cover" />
                        <AvatarFallback className="bg-muted text-[8px]">
                          <Package className="w-3 h-3" />
                        </AvatarFallback>
                      </Avatar>
                    ))}
                  </div>
                  <span className="text-[10px] text-muted-foreground ml-1">
                    {promo.product_count} product{promo.product_count !== 1 ? 's' : ''} attached
                  </span>
                </div>
              )}
            </div>

            <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0 mt-1" />
          </div>
        ))}
      </div>

      {/* Show more */}
      <div
        onClick={() => navigate('/marketplace?content_type=promotions')}
        className="px-4 py-3 text-primary text-sm font-medium hover:bg-muted/50 transition-colors cursor-pointer border-t border-border"
      >
        Show more
      </div>
    </div>
  );
};

export default DiscountsForYouSection;
