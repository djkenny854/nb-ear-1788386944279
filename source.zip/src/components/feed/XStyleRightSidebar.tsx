import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Zap, MoreHorizontal, Briefcase, Calendar, MapPin, Tag, ShoppingBag, Users, ChevronLeft, Eye, Bookmark } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import SearchDropdown from './SearchDropdown';
import { getSellerProfileUrl } from '@/lib/sellerUrl';
import { supabase } from '@/integrations/supabase/client';
import { format, formatDistanceToNow } from 'date-fns';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';

// Browse categories type
type BrowseCategory = 'jobs' | 'events' | 'promotions' | 'services' | 'sellers' | null;

interface TrendingItem {
  category: string;
  count: number;
}

interface SellerToFollow {
  id: string;
  business_name: string;
  business_logo_url: string;
  is_verified: boolean;
  verification_badge_color?: BadgeColor;
  store_slug?: string;
}

interface BoostedAd {
  id: string;
  title: string;
  price: number;
  images: string[];
}

interface LatestJob {
  id: string;
  title: string;
  location: string;
  company_name?: string;
  job_type?: string;
}

interface UpcomingEvent {
  id: string;
  title: string;
  location: string;
  event_date: string;
  is_free?: boolean;
}

interface LatestPromotion {
  id: string;
  title: string;
  discount_percentage?: number;
  original_price?: number;
  price?: number;
}

interface LatestService {
  id: string;
  title: string;
  location: string;
  price?: number;
}

interface RecommendedSeller {
  id: string;
  business_name: string;
  business_logo_url: string | null;
  is_verified: boolean;
  store_slug?: string;
  follower_count?: number;
}

interface XStyleRightSidebarProps {
  trendingItems: TrendingItem[];
  sellersToFollow: SellerToFollow[];
  boostedAds: BoostedAd[];
  loadingTrending: boolean;
  loadingSellers: boolean;
  loadingBoosted: boolean;
  currentTrendingIndex: number;
  currentBoostedIndex: number;
  followingStates: { [key: string]: boolean };
  onFollowSeller: (sellerId: string) => void;
  isOpen?: boolean;
  searchQuery?: string;
  onSearchChange?: (query: string) => void;
  onSearch?: (query: string) => void;
}

// State for managing sellers to follow with replacement on follow

// Animated skeleton with shimmer effect
const ShimmerSkeleton = ({ className }: { className?: string }) => (
  <div className={cn("relative overflow-hidden rounded-md bg-muted/30", className)}>
    <div className="absolute inset-0 -translate-x-full animate-[shimmer_2s_infinite] bg-gradient-to-r from-transparent via-muted/50 to-transparent" />
  </div>
);

const RightSidebarSkeleton = () => (
  <div className="space-y-4">
    {/* Search skeleton */}
    <ShimmerSkeleton className="h-12 w-full rounded-full" />
    
    {/* Trending skeleton */}
    <div className="rounded-2xl p-4 bg-muted/5">
      <ShimmerSkeleton className="h-6 w-32 mb-4" />
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="space-y-2">
            <ShimmerSkeleton className="h-3 w-24" />
            <ShimmerSkeleton className="h-5 w-32" />
            <ShimmerSkeleton className="h-3 w-20" />
          </div>
        ))}
      </div>
    </div>
    
    {/* Who to follow skeleton */}
    <div className="rounded-2xl p-4 bg-muted/5">
      <ShimmerSkeleton className="h-6 w-28 mb-4" />
      {[...Array(3)].map((_, i) => (
        <div key={i} className="flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <ShimmerSkeleton className="w-10 h-10 rounded-full" />
            <div className="space-y-2">
              <ShimmerSkeleton className="h-4 w-24" />
              <ShimmerSkeleton className="h-3 w-20" />
            </div>
          </div>
          <ShimmerSkeleton className="h-8 w-20 rounded-full" />
        </div>
      ))}
    </div>
  </div>
);

// Category tab config
const categoryTabs: { id: BrowseCategory; label: string; icon: React.ReactNode; color: string }[] = [
  { id: 'jobs', label: 'Jobs', icon: <Briefcase className="w-4 h-4" />, color: 'text-blue-500' },
  { id: 'events', label: 'Events', icon: <Calendar className="w-4 h-4" />, color: 'text-purple-500' },
  { id: 'promotions', label: 'Deals', icon: <Tag className="w-4 h-4" />, color: 'text-orange-500' },
  { id: 'services', label: 'Services', icon: <ShoppingBag className="w-4 h-4" />, color: 'text-green-500' },
  { id: 'sellers', label: 'Sellers', icon: <Users className="w-4 h-4" />, color: 'text-cyan-500' },
];

const XStyleRightSidebar: React.FC<XStyleRightSidebarProps> = ({
  trendingItems,
  sellersToFollow: initialSellersToFollow,
  boostedAds,
  loadingTrending,
  loadingSellers,
  loadingBoosted,
  currentTrendingIndex,
  currentBoostedIndex,
  followingStates,
  onFollowSeller,
  isOpen = true,
}) => {
  const navigate = useNavigate();
  const [latestJobs, setLatestJobs] = useState<LatestJob[]>([]);
  const [upcomingEvents, setUpcomingEvents] = useState<UpcomingEvent[]>([]);
  const [latestPromotions, setLatestPromotions] = useState<LatestPromotion[]>([]);
  const [latestServices, setLatestServices] = useState<LatestService[]>([]);
  const [recommendedSellers, setRecommendedSellers] = useState<RecommendedSeller[]>([]);
  const [loadingJobs, setLoadingJobs] = useState(true);
  const [loadingEvents, setLoadingEvents] = useState(true);
  const [loadingPromotions, setLoadingPromotions] = useState(true);
  const [loadingServices, setLoadingServices] = useState(true);
  const [loadingRecommendedSellers, setLoadingRecommendedSellers] = useState(true);
  
  // Browse category for inline view (replaces modal on desktop)
  const [activeBrowseCategory, setActiveBrowseCategory] = useState<BrowseCategory>(null);
  const [browseCategoryData, setBrowseCategoryData] = useState<any[]>([]);
  const [loadingBrowseData, setLoadingBrowseData] = useState(false);
  
  // Local sellers to follow state for replacement functionality
  const [displayedSellers, setDisplayedSellers] = useState<SellerToFollow[]>(initialSellersToFollow);
  const [allSellersPool, setAllSellersPool] = useState<SellerToFollow[]>([]);
  const [followedIds, setFollowedIds] = useState<Set<string>>(new Set());

  const isLoading = loadingTrending || loadingSellers || loadingBoosted;
  
  // Update displayed sellers when initial props change
  useEffect(() => {
    if (initialSellersToFollow.length > 0 && displayedSellers.length === 0) {
      setDisplayedSellers(initialSellersToFollow);
    }
  }, [initialSellersToFollow]);
  
  // Fetch mixed sellers pool (verified + non-verified)
  useEffect(() => {
    const fetchMixedSellers = async () => {
      try {
        const { data: sellers } = await supabase
          .from('seller_profiles')
          .select('id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug')
          .eq('is_active', true)
          .order('follower_count', { ascending: false })
          .limit(30);

        if (sellers) {
          setAllSellersPool(sellers as SellerToFollow[]);
          // If no initial sellers, set displayed from pool
          if (displayedSellers.length === 0) {
            setDisplayedSellers(sellers.slice(0, 5) as SellerToFollow[]);
          }
        }
      } catch (error) {
        console.error('Error fetching sellers pool:', error);
      }
    };
    fetchMixedSellers();
  }, []);
  
  // Handle follow and replace seller
  const handleFollowAndReplace = (sellerId: string) => {
    // Call parent handler
    onFollowSeller(sellerId);
    
    // Track followed ID
    setFollowedIds(prev => new Set([...prev, sellerId]));
    
    // Find a replacement seller from pool
    const currentIds = new Set(displayedSellers.map(s => s.id));
    const replacement = allSellersPool.find(
      s => !currentIds.has(s.id) && !followedIds.has(s.id) && s.id !== sellerId
    );
    
    if (replacement) {
      // Replace the followed seller with a new one after a brief delay
      setTimeout(() => {
        setDisplayedSellers(prev => 
          prev.map(s => s.id === sellerId ? replacement : s)
        );
      }, 500);
    } else {
      // Just remove if no replacement available
      setTimeout(() => {
        setDisplayedSellers(prev => prev.filter(s => s.id !== sellerId));
      }, 500);
    }
  };
  
  // Handle browse category selection - fetch full data for inline display
  const handleBrowseCategory = async (category: BrowseCategory) => {
    if (category === activeBrowseCategory) {
      setActiveBrowseCategory(null);
      setBrowseCategoryData([]);
      return;
    }
    
    setActiveBrowseCategory(category);
    setLoadingBrowseData(true);
    
    try {
      let data: any[] = [];
      
      switch (category) {
        case 'jobs': {
          const { data: jobs } = await supabase
            .from('ads')
            .select(`
              id, title, location, images, view_count, save_count, created_at,
              job_details(company_name, job_type),
              seller_profiles(id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug)
            `)
            .eq('status', 'active')
            .eq('listing_type', 'jobs')
            .order('created_at', { ascending: false })
            .limit(12);
          data = jobs?.map(j => ({
            id: j.id,
            title: j.title,
            location: j.location,
            images: j.images,
            company_name: (j.job_details as any)?.[0]?.company_name,
            job_type: (j.job_details as any)?.[0]?.job_type,
            created_at: j.created_at,
            seller: j.seller_profiles
          })) || [];
          break;
        }
        case 'events': {
          const { data: events } = await supabase
            .from('events')
            .select(`
              id, title, location, event_date, is_free, cover_image, images, view_count,
              seller_profiles(id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug)
            `)
            .eq('is_active', true)
            .gte('event_date', new Date().toISOString())
            .order('event_date', { ascending: true })
            .limit(12);
          data = events?.map(e => ({ ...e, seller: e.seller_profiles })) || [];
          break;
        }
        case 'promotions': {
          const { data: promos } = await supabase
            .from('ads')
            .select(`
              id, title, price, original_price, has_discount, images, view_count, save_count, created_at,
              seller_profiles(id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug)
            `)
            .eq('status', 'active')
            .eq('listing_type', 'promotions')
            .order('created_at', { ascending: false })
            .limit(12);
          data = promos?.map(p => ({
            ...p,
            discount_percentage: p.original_price && p.price ? Math.round((1 - p.price / p.original_price) * 100) : undefined,
            seller: p.seller_profiles
          })) || [];
          break;
        }
        case 'services': {
          const { data: services } = await supabase
            .from('ads')
            .select(`
              id, title, location, price, images, view_count, save_count, created_at,
              seller_profiles(id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug)
            `)
            .eq('status', 'active')
            .eq('listing_type', 'services')
            .order('created_at', { ascending: false })
            .limit(12);
          data = services?.map(s => ({ ...s, seller: s.seller_profiles })) || [];
          break;
        }
        case 'sellers': {
          const { data: sellers } = await supabase
            .from('seller_profiles')
            .select('id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug, follower_count')
            .eq('is_active', true)
            .order('follower_count', { ascending: false })
            .limit(12);
          data = sellers || [];
          break;
        }
      }
      
      setBrowseCategoryData(data);
    } catch (error) {
      console.error('Error fetching browse data:', error);
    } finally {
      setLoadingBrowseData(false);
    }
  };

  // Fetch latest jobs
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const { data: jobs } = await supabase
          .from('ads')
          .select(`
            id, title, location,
            job_details(company_name, job_type)
          `)
          .eq('status', 'active')
          .eq('listing_type', 'jobs')
          .order('created_at', { ascending: false })
          .limit(3);

        if (jobs) {
          setLatestJobs(jobs.map(j => ({
            id: j.id,
            title: j.title,
            location: j.location,
            company_name: (j.job_details as any)?.[0]?.company_name,
            job_type: (j.job_details as any)?.[0]?.job_type
          })));
        }
      } catch (error) {
        console.error('Error fetching jobs:', error);
      } finally {
        setLoadingJobs(false);
      }
    };
    fetchJobs();
  }, []);

  // Fetch upcoming events
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const { data: events } = await supabase
          .from('events')
          .select('id, title, location, event_date, is_free')
          .eq('is_active', true)
          .gte('event_date', new Date().toISOString())
          .order('event_date', { ascending: true })
          .limit(3);

        if (events) {
          setUpcomingEvents(events);
        }
      } catch (error) {
        console.error('Error fetching events:', error);
      } finally {
        setLoadingEvents(false);
      }
    };
    fetchEvents();
  }, []);

  // Fetch latest promotions
  useEffect(() => {
    const fetchPromotions = async () => {
      try {
        const { data: promos } = await supabase
          .from('ads')
          .select('id, title, price, original_price, has_discount')
          .eq('status', 'active')
          .eq('listing_type', 'promotions')
          .order('created_at', { ascending: false })
          .limit(3);

        if (promos) {
          setLatestPromotions(promos.map(p => ({
            id: p.id,
            title: p.title,
            price: p.price,
            original_price: p.original_price,
            discount_percentage: p.original_price && p.price ? Math.round((1 - p.price / p.original_price) * 100) : undefined
          })));
        }
      } catch (error) {
        console.error('Error fetching promotions:', error);
      } finally {
        setLoadingPromotions(false);
      }
    };
    fetchPromotions();
  }, []);

  // Fetch latest services
  useEffect(() => {
    const fetchServices = async () => {
      try {
        const { data: services } = await supabase
          .from('ads')
          .select('id, title, location, price')
          .eq('status', 'active')
          .eq('listing_type', 'services')
          .order('created_at', { ascending: false })
          .limit(3);

        if (services) {
          setLatestServices(services);
        }
      } catch (error) {
        console.error('Error fetching services:', error);
      } finally {
        setLoadingServices(false);
      }
    };
    fetchServices();
  }, []);

  // Fetch recommended sellers (mix of verified and non-verified)
  useEffect(() => {
    const fetchRecommendedSellers = async () => {
      try {
        const { data: sellers } = await supabase
          .from('seller_profiles')
          .select('id, business_name, business_logo_url, is_verified, store_slug, follower_count')
          .eq('is_active', true)
          .order('follower_count', { ascending: false })
          .limit(5);

        if (sellers) {
          setRecommendedSellers(sellers);
        }
      } catch (error) {
        console.error('Error fetching recommended sellers:', error);
      } finally {
        setLoadingRecommendedSellers(false);
      }
    };
    fetchRecommendedSellers();
  }, []);

  const handleTrendingClick = (category: string) => {
    navigate(`/search?category=${encodeURIComponent(category)}&contentType=all`);
  };

  // Render browse category content inline
  const renderBrowseCategoryContent = () => {
    if (!activeBrowseCategory) return null;

    const activeTab = categoryTabs.find(t => t.id === activeBrowseCategory);

    return (
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: 'auto' }}
        exit={{ opacity: 0, height: 0 }}
        className="bg-muted/5 rounded-2xl overflow-hidden"
      >
        {/* Header with back button */}
        <div className="px-4 py-3 flex items-center gap-2 border-b border-border/10">
          <button
            onClick={() => setActiveBrowseCategory(null)}
            className="p-1 rounded-full hover:bg-muted/20 transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <span className={cn("font-bold text-lg", activeTab?.color)}>{activeTab?.label}</span>
        </div>

        {loadingBrowseData ? (
          <div className="p-4 space-y-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="flex gap-3">
                <ShimmerSkeleton className="w-16 h-16 rounded-lg flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <ShimmerSkeleton className="h-4 w-3/4" />
                  <ShimmerSkeleton className="h-3 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="divide-y divide-border/10 max-h-[400px] overflow-y-auto">
            {browseCategoryData.map((item, idx) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="p-3 hover:bg-muted/10 cursor-pointer transition-colors flex gap-3"
                onClick={() => {
                  if (activeBrowseCategory === 'sellers') {
                    navigate(getSellerProfileUrl(item));
                  } else if (activeBrowseCategory === 'jobs') {
                    navigate(`/job/${item.id}`);
                  } else if (activeBrowseCategory === 'events') {
                    navigate(`/event/${item.id}`);
                  } else if (activeBrowseCategory === 'promotions') {
                    navigate(`/promotion/${item.id}`);
                  } else if (activeBrowseCategory === 'services') {
                    navigate(`/service/${item.id}`);
                  }
                }}
              >
                {/* Thumbnail */}
                {activeBrowseCategory === 'sellers' ? (
                  <Avatar className="w-12 h-12 flex-shrink-0 ring-1 ring-border/30">
                    <AvatarImage src={item.business_logo_url || ''} />
                    <AvatarFallback className="bg-muted text-foreground font-bold text-sm">
                      {item.business_name?.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                ) : (
                  <div className="w-16 h-16 rounded-lg bg-muted overflow-hidden flex-shrink-0">
                    {(item.images?.[0] || item.cover_image) ? (
                      <img 
                        src={item.images?.[0] || item.cover_image} 
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Eye className="w-5 h-5 text-muted-foreground/50" />
                      </div>
                    )}
                  </div>
                )}

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm line-clamp-1">
                    {activeBrowseCategory === 'sellers' ? item.business_name : item.title}
                  </p>
                  
                  {activeBrowseCategory === 'jobs' && item.company_name && (
                    <p className="text-xs text-muted-foreground line-clamp-1">{item.company_name}</p>
                  )}
                  
                  {activeBrowseCategory === 'events' && (
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Calendar className="w-3 h-3" />
                      <span>{format(new Date(item.event_date), 'MMM d')}</span>
                      {item.is_free && (
                        <span className="ml-1 px-1.5 py-0.5 bg-green-500/10 text-green-500 rounded text-[10px]">Free</span>
                      )}
                    </div>
                  )}
                  
                  {activeBrowseCategory === 'promotions' && (
                    <div className="flex items-center gap-2 mt-0.5">
                      {item.discount_percentage && (
                        <span className="px-1.5 py-0.5 bg-orange-500/10 text-orange-500 rounded text-[10px] font-bold">
                          -{item.discount_percentage}%
                        </span>
                      )}
                      <span className="text-primary font-bold text-xs">
                        UGX {item.price?.toLocaleString()}
                      </span>
                    </div>
                  )}
                  
                  {activeBrowseCategory === 'services' && (
                    <>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <MapPin className="w-3 h-3" />
                        <span className="line-clamp-1">{item.location}</span>
                      </div>
                      {item.price && (
                        <p className="text-primary font-bold text-xs mt-0.5">
                          From UGX {item.price.toLocaleString()}
                        </p>
                      )}
                    </>
                  )}
                  
                  {activeBrowseCategory === 'sellers' && (
                    <p className="text-xs text-muted-foreground">
                      {item.follower_count ? `${item.follower_count.toLocaleString()} followers` : '@' + (item.store_slug || item.business_name?.toLowerCase().replace(/\s+/g, ''))}
                    </p>
                  )}
                  
                  {(activeBrowseCategory === 'jobs' || activeBrowseCategory === 'services') && item.location && (
                    <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                      <MapPin className="w-3 h-3" />
                      <span className="line-clamp-1">{item.location}</span>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* View all link */}
        <button 
          className="w-full px-4 py-3 text-left text-primary hover:bg-muted/10 transition-colors text-[15px] border-t border-border/10"
          onClick={() => {
            // Navigate to search page with correct contentType
            navigate(`/search?contentType=${activeBrowseCategory}`);
          }}
        >
          View all in Search
        </button>
      </motion.div>
    );
  };

  return (
    <div className="space-y-4">
      {/* X.com style Search with dropdown */}
      <SearchDropdown />

      {/* Browse Category Tabs - Desktop inline version */}
      <div className="bg-muted/5 rounded-2xl overflow-hidden">
        <div className="px-4 py-3">
          <h2 className="text-lg font-bold mb-3">Browse</h2>
          <div className="flex flex-wrap gap-2">
            {categoryTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => handleBrowseCategory(tab.id)}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium transition-all",
                  activeBrowseCategory === tab.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted/30 hover:bg-muted/50 text-foreground"
                )}
              >
                <span className={activeBrowseCategory === tab.id ? "" : tab.color}>{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Inline browse content */}
        <AnimatePresence mode="wait">
          {activeBrowseCategory && renderBrowseCategoryContent()}
        </AnimatePresence>
      </div>

      {isLoading ? (
        <RightSidebarSkeleton />
      ) : (
        <>
          {/* Trending - X.com style transparent card */}
          <div className="bg-muted/5 rounded-2xl overflow-hidden">
            <div className="px-4 py-3">
              <h2 className="text-xl font-bold">Trends for you</h2>
            </div>
            
            <div className="divide-y divide-border/10">
              {trendingItems.slice(0, 4).map((item, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="px-4 py-3 hover:bg-muted/10 cursor-pointer transition-colors"
                  onClick={() => handleTrendingClick(item.category)}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground">Trending in Uganda</p>
                      <p className="font-bold text-[15px] mt-0.5">{item.category}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{item.count.toLocaleString()} listings</p>
                    </div>
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full -mr-2 opacity-0 group-hover:opacity-100">
                      <MoreHorizontal className="w-4 h-4 text-muted-foreground" />
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
            
            <button 
              className="w-full px-4 py-3 text-left text-primary hover:bg-muted/10 transition-colors text-[15px]"
              onClick={() => navigate('/search')}
            >
              Show more
            </button>
          </div>

          {/* Who to follow - X.com style transparent */}
          <div className="bg-muted/5 rounded-2xl overflow-hidden">
            <div className="px-4 py-3">
              <h2 className="text-xl font-bold">Who to follow</h2>
            </div>
            
            <div className="divide-y divide-border/10">
              {displayedSellers.map((seller, idx) => (
                <motion.div 
                  key={seller.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ delay: idx * 0.1 }}
                  className="px-4 py-3 hover:bg-muted/10 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div 
                      className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
                      onClick={() => navigate(getSellerProfileUrl(seller))}
                    >
                      <Avatar className="w-10 h-10 flex-shrink-0 ring-1 ring-border/30">
                        <AvatarImage src={seller.business_logo_url} />
                        <AvatarFallback className="bg-muted text-foreground font-bold text-sm">
                          {seller.business_name?.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="font-bold text-[15px] truncate">{seller.business_name}</span>
                          <UnifiedVerifiedBadge 
                            isVerified={seller.is_verified} 
                            badgeColor={seller.verification_badge_color}
                            size="sm" 
                          />
                        </div>
                        <p className="text-muted-foreground text-sm truncate">
                          @{seller.store_slug || seller.business_name?.toLowerCase().replace(/\s+/g, '')}
                        </p>
                      </div>
                    </div>
                    <Button 
                      size="sm" 
                      variant={followingStates[seller.id] ? "outline" : "default"}
                      className={cn(
                        "rounded-full font-bold h-8 px-4 text-sm flex-shrink-0 transition-all duration-200",
                        followingStates[seller.id] 
                          ? "bg-transparent border-border hover:border-red-500 hover:text-red-500 hover:bg-red-500/10" 
                          : "bg-foreground text-background hover:bg-foreground/90"
                      )}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleFollowAndReplace(seller.id);
                      }}
                    >
                      {followingStates[seller.id] ? 'Following' : 'Follow'}
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
            
            <button 
              className="w-full px-4 py-3 text-left text-primary hover:bg-muted/10 transition-colors text-[15px]"
              onClick={() => navigate('/search?contentType=sellers')}
            >
              Show more
            </button>
          </div>

          {/* Boosted Posts - Subtle card */}
          {boostedAds.length > 0 && (
            <div className="bg-muted/5 rounded-2xl overflow-hidden">
              <div className="px-4 py-3 flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-500" />
                <h2 className="text-xl font-bold">Promoted</h2>
              </div>
              
              <AnimatePresence mode="wait">
                <motion.div 
                  key={currentBoostedIndex}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="px-4 py-3 hover:bg-muted/10 cursor-pointer transition-colors"
                  onClick={() => navigate(`/ad/${boostedAds[currentBoostedIndex].id}`)}
                >
                  {boostedAds[currentBoostedIndex].images.length > 0 && (
                    <img 
                      src={boostedAds[currentBoostedIndex].images[0]} 
                      alt={boostedAds[currentBoostedIndex].title}
                      className="w-full h-32 object-cover rounded-xl mb-2"
                    />
                  )}
                  <p className="font-semibold text-sm line-clamp-2">{boostedAds[currentBoostedIndex].title}</p>
                  <p className="text-primary font-bold text-sm mt-1">
                    UGX {boostedAds[currentBoostedIndex].price?.toLocaleString()}
                  </p>
                  
                  {/* Dots indicator */}
                  <div className="flex gap-1.5 mt-3 justify-center">
                    {boostedAds.map((_, idx) => (
                      <div 
                        key={idx} 
                        className={cn(
                          "h-1.5 rounded-full transition-all duration-300",
                          idx === currentBoostedIndex ? "w-6 bg-primary" : "w-1.5 bg-muted-foreground/30"
                        )} 
                      />
                    ))}
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          )}
        </>
      )}

      {/* Footer links - X.com style */}
      <div className="px-4 py-3">
        <div className="flex flex-wrap gap-x-3 gap-y-1 text-[13px] text-muted-foreground">
          <a href="/docs" className="hover:underline">Terms</a>
          <a href="/docs" className="hover:underline">Privacy</a>
          <a href="/docs" className="hover:underline">Cookies</a>
          <a href="/docs" className="hover:underline">Ads</a>
          <a href="/docs" className="hover:underline">More</a>
        </div>
        <p className="text-[13px] text-muted-foreground mt-2">© 2025 EarlyMarket</p>
      </div>
    </div>
  );
};

export default XStyleRightSidebar;