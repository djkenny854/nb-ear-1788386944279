import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/components/auth/AuthContext';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Pin } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';
import RailScroller from '@/components/common/RailScroller';

interface PinnedProduct {
  id: string;
  ad_id: string;
  title: string;
  price: number;
  images: string[];
  seller: {
    id: string;
    business_name: string;
    business_logo_url: string;
    is_verified: boolean;
    verification_badge_color?: BadgeColor;
  };
}

const PinnedByFollowedSection: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const { data: pinnedProducts = [], isLoading } = useQuery({
    queryKey: ['pinned-by-followed', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];

      // Get followed user IDs
      const { data: follows } = await supabase
        .from('follows')
        .select('following_id')
        .eq('follower_id', user.id);

      if (!follows || follows.length === 0) return [];

      const followedUserIds = follows.map(f => f.following_id);
      const followedCount = followedUserIds.length;

      // Get seller profiles of followed users
      const { data: sellerProfiles } = await supabase
        .from('seller_profiles')
        .select('id, user_id, business_name, business_logo_url, is_verified')
        .in('user_id', followedUserIds);

      if (!sellerProfiles || sellerProfiles.length === 0) return [];

      const sellerIds = sellerProfiles.map(sp => sp.id);

      // Get pinned ads from those sellers
      const { data: pinnedAds } = await supabase
        .from('pinned_ads')
        .select('ad_id, seller_id, pin_order')
        .in('seller_id', sellerIds)
        .order('pin_order', { ascending: true });

      if (!pinnedAds || pinnedAds.length === 0) return [];

      // Logic: If follows <= 5, allow multiple from each seller. If > 5, show one from each (max 20)
      let selectedPinnedAds: typeof pinnedAds;
      
      if (followedCount > 5) {
        // Show only one pinned item from each seller
        const seenSellers = new Set<string>();
        selectedPinnedAds = pinnedAds.filter(pa => {
          if (seenSellers.has(pa.seller_id)) return false;
          seenSellers.add(pa.seller_id);
          return true;
        }).slice(0, 20);
      } else {
        // Show multiple from each seller, up to 20 total
        selectedPinnedAds = pinnedAds.slice(0, 20);
      }

      // Get the actual ad details
      const adIds = selectedPinnedAds.map(pa => pa.ad_id);
      const { data: ads } = await supabase
        .from('ads')
        .select('id, title, price, images, seller_id')
        .in('id', adIds)
        .eq('status', 'active');

      if (!ads) return [];

      // Map to include seller info, maintaining order
      const adMap = new Map(ads.map(ad => [ad.id, ad]));
      return selectedPinnedAds
        .map(pa => {
          const ad = adMap.get(pa.ad_id);
          if (!ad) return null;
          const seller = sellerProfiles.find(sp => sp.id === ad.seller_id);
          return {
            id: ad.id,
            ad_id: ad.id,
            title: ad.title,
            price: ad.price || 0,
            images: ad.images || [],
            seller: {
              id: seller?.id || '',
              business_name: seller?.business_name || 'Unknown',
              business_logo_url: seller?.business_logo_url || '',
              is_verified: seller?.is_verified || false
            }
          };
        })
        .filter(Boolean) as PinnedProduct[];
    },
    enabled: !!user?.id,
    staleTime: 60000, // 1 minute
  });

  // Don't show section if not logged in or loading
  if (!user?.id) return null;
  
  if (isLoading) {
    return (
      <div className="border-b border-border py-4 px-4">
        <div className="flex items-center gap-2 mb-3">
          <Skeleton className="w-4 h-4 rounded" />
          <Skeleton className="h-5 w-40" />
        </div>
        <div className="flex gap-3 overflow-x-auto scrollbar-hide">
          {[1, 2, 3].map(i => (
            <Skeleton key={i} className="w-32 h-40 rounded-xl flex-shrink-0" />
          ))}
        </div>
      </div>
    );
  }

  // Don't show section if no pinned products
  if (pinnedProducts.length === 0) return null;

  return (
    <div className="border-b border-border py-4 bg-muted/20">
      <div className="px-4 flex items-center mb-3">
        <div className="flex items-center gap-2">
          <Pin className="w-4 h-4 text-primary" />
          <h3 className="font-semibold text-sm text-foreground">Pinned by People You Follow</h3>
        </div>
      </div>
      
      <RailScroller>
      <div className="flex gap-3 overflow-x-auto scrollbar-hide px-4 pb-2" data-carousel>
        {pinnedProducts.map((product) => (
          <div
            key={product.id}
            className="flex-shrink-0 w-36 cursor-pointer group"
            onClick={() => navigate(`/ad/${product.id}`)}
          >
            <div className="relative aspect-square rounded-xl overflow-hidden bg-muted mb-2">
              {product.images[0] ? (
                <img
                  src={product.images[0]}
                  alt={product.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                  No image
                </div>
              )}
              <div className="absolute top-2 left-2">
                <Badge variant="secondary" className="text-[10px] px-1.5 py-0.5 bg-primary/90 text-primary-foreground">
                  <Pin className="w-2.5 h-2.5 mr-0.5" />
                  Pinned
                </Badge>
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="flex items-center gap-1">
                <Avatar className="w-4 h-4">
                  <AvatarImage src={product.seller.business_logo_url} />
                  <AvatarFallback className="text-[8px]">
                    {product.seller.business_name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <span className="text-[10px] text-muted-foreground truncate flex-1">
                  {product.seller.business_name}
                </span>
                <UnifiedVerifiedBadge 
                  isVerified={product.seller.is_verified} 
                  badgeColor={product.seller.verification_badge_color}
                  size="xs" 
                />
              </div>
              <h4 className="text-xs font-medium line-clamp-2 leading-tight">
                {product.title}
              </h4>
              {product.price > 0 && (
                <p className="text-xs font-bold text-primary">
                  UGX {product.price.toLocaleString()}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
      </RailScroller>
    </div>
  );
};

export default PinnedByFollowedSection;
