import React, { useRef, useState, useEffect } from 'react';
import { ChevronRight, ChevronLeft, Pin, Percent, Store, Heart } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useCurrency } from '@/contexts/CurrencyContext';

interface ProductItem {
  id: string;
  title: string;
  price: number;
  images: string[];
  seller_id: string;
  seller_name: string;
  seller_logo?: string;
  is_pinned?: boolean;
  has_discount?: boolean;
  original_price?: number;
}

// Transparent X-style horizontal product card
const XStyleProductCard: React.FC<{ product: ProductItem; showDiscount?: boolean }> = ({ 
  product, 
  showDiscount 
}) => {
  const navigate = useNavigate();
  const { formatPriceCompact } = useCurrency();
  return (
    <div 
      onClick={() => navigate(`/ad/${product.id}`)}
      className="flex-shrink-0 w-[120px] cursor-pointer group"
    >
      <div className="relative aspect-square rounded-xl overflow-hidden mb-1.5 bg-foreground/5 border border-border/30">
        {product.images?.[0] ? (
          <img 
            src={product.images[0]} 
            alt={product.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground">
            <Store className="w-6 h-6" />
          </div>
        )}
        {showDiscount && product.original_price && (
          <Badge className="absolute top-1.5 left-1.5 bg-red-500/90 backdrop-blur-sm text-white text-[9px] px-1 py-0">
            {Math.round(((product.original_price - product.price) / product.original_price) * 100)}% OFF
          </Badge>
        )}
        {product.is_pinned && (
          <div className="absolute top-1.5 right-1.5 w-4 h-4 bg-primary/90 backdrop-blur-sm rounded-full flex items-center justify-center">
            <Pin className="w-2.5 h-2.5 text-primary-foreground" />
          </div>
        )}
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300 flex items-center justify-center">
          <Heart className="w-5 h-5 text-white opacity-0 group-hover:opacity-80 transition-opacity duration-300" />
        </div>
      </div>
      <p className="text-[11px] font-medium text-foreground line-clamp-1">{product.title}</p>
      <div className="flex items-center gap-1">
        <span className="text-[11px] font-bold text-primary">{formatPriceCompact(product.price)}</span>
        {showDiscount && product.original_price && (
          <span className="text-[9px] text-muted-foreground line-through">
            {product.original_price.toLocaleString()}
          </span>
        )}
      </div>
    </div>
  );
};

// Loading skeleton for carousel
const CarouselSkeleton: React.FC = () => (
  <div className="bg-transparent border border-border/20 rounded-xl p-3">
    <div className="flex items-center justify-between mb-2">
      <div className="flex items-center gap-2">
        <Skeleton className="w-4 h-4 rounded-full" />
        <Skeleton className="w-24 h-3" />
      </div>
      <Skeleton className="w-12 h-3" />
    </div>
    <div className="flex gap-2 overflow-hidden">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex-shrink-0 w-[120px]">
          <Skeleton className="aspect-square rounded-xl mb-1.5" />
          <Skeleton className="w-full h-3 mb-1" />
          <Skeleton className="w-14 h-3" />
        </div>
      ))}
    </div>
  </div>
);

// Navigation buttons component
const CarouselNavButtons: React.FC<{
  onPrev: () => void;
  onNext: () => void;
  canScrollPrev: boolean;
  canScrollNext: boolean;
}> = ({ onPrev, onNext, canScrollPrev, canScrollNext }) => (
  <div className="hidden md:flex items-center gap-1">
    <Button
      variant="ghost"
      size="icon"
      onClick={(e) => { e.stopPropagation(); onPrev(); }}
      disabled={!canScrollPrev}
      className={cn(
        "h-6 w-6 rounded-full",
        !canScrollPrev && "opacity-30 cursor-not-allowed"
      )}
    >
      <ChevronLeft className="w-4 h-4" />
    </Button>
    <Button
      variant="ghost"
      size="icon"
      onClick={(e) => { e.stopPropagation(); onNext(); }}
      disabled={!canScrollNext}
      className={cn(
        "h-6 w-6 rounded-full",
        !canScrollNext && "opacity-30 cursor-not-allowed"
      )}
    >
      <ChevronRight className="w-4 h-4" />
    </Button>
  </div>
);

// Custom hook for carousel scroll
const useCarouselScroll = (scrollRef: React.RefObject<HTMLDivElement>) => {
  const [canScrollPrev, setCanScrollPrev] = useState(false);
  const [canScrollNext, setCanScrollNext] = useState(true);

  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollPrev(scrollLeft > 0);
      setCanScrollNext(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  useEffect(() => {
    checkScroll();
    const el = scrollRef.current;
    if (el) {
      el.addEventListener('scroll', checkScroll);
      return () => el.removeEventListener('scroll', checkScroll);
    }
  }, []);

  const scrollPrev = () => {
    scrollRef.current?.scrollBy({ left: -240, behavior: 'smooth' });
  };

  const scrollNext = () => {
    scrollRef.current?.scrollBy({ left: 240, behavior: 'smooth' });
  };

  return { canScrollPrev, canScrollNext, scrollPrev, scrollNext };
};

// Pinned Products Section - Transparent X-style
export const XStylePinnedSection: React.FC<{ 
  products: ProductItem[]; 
  loading?: boolean;
}> = ({ products, loading }) => {
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  const { canScrollPrev, canScrollNext, scrollPrev, scrollNext } = useCarouselScroll(scrollRef);
  
  if (loading) return <CarouselSkeleton />;
  if (!products || products.length === 0) return null;

  return (
    <div className="bg-transparent border border-border/20 rounded-xl p-3 mb-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-primary/10 flex items-center justify-center">
            <Pin className="w-2.5 h-2.5 text-primary" />
          </div>
          <h3 className="font-semibold text-[13px] text-foreground">Pinned Products</h3>
        </div>
        <div className="flex items-center gap-2">
          <CarouselNavButtons 
            onPrev={scrollPrev} 
            onNext={scrollNext} 
            canScrollPrev={canScrollPrev}
            canScrollNext={canScrollNext}
          />
          <button 
            onClick={() => navigate('/search?filter=pinned')}
            className="text-[11px] text-primary flex items-center gap-0.5 hover:underline"
          >
            See all
          </button>
        </div>
      </div>
      <div 
        ref={scrollRef}
        className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide scroll-smooth"
      >
        {products.slice(0, 10).map((product) => (
          <XStyleProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

// Discounted Products Section - Transparent X-style  
export const XStyleDiscountSection: React.FC<{ 
  products: ProductItem[]; 
  loading?: boolean;
}> = ({ products, loading }) => {
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  const { canScrollPrev, canScrollNext, scrollPrev, scrollNext } = useCarouselScroll(scrollRef);
  
  if (loading) return <CarouselSkeleton />;
  if (!products || products.length === 0) return null;

  return (
    <div className="bg-transparent border border-border/20 rounded-xl p-3 mb-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-red-500/10 flex items-center justify-center">
            <Percent className="w-2.5 h-2.5 text-red-500" />
          </div>
          <h3 className="font-semibold text-[13px] text-foreground">Hot Deals</h3>
          <Badge variant="destructive" className="text-[9px] px-1 py-0 h-4">SALE</Badge>
        </div>
        <div className="flex items-center gap-2">
          <CarouselNavButtons 
            onPrev={scrollPrev} 
            onNext={scrollNext} 
            canScrollPrev={canScrollPrev}
            canScrollNext={canScrollNext}
          />
          <button 
            onClick={() => navigate('/search?filter=discounts')}
            className="text-[11px] text-primary flex items-center gap-0.5 hover:underline"
          >
            See all
          </button>
        </div>
      </div>
      <div 
        ref={scrollRef}
        className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide scroll-smooth"
      >
        {products.slice(0, 10).map((product) => (
          <XStyleProductCard key={product.id} product={product} showDiscount />
        ))}
      </div>
    </div>
  );
};

// More from Seller Section - Transparent X-style
export const XStyleSellerSection: React.FC<{ 
  seller_id: string;
  seller_name: string;
  seller_logo?: string;
  products: ProductItem[];
  loading?: boolean;
}> = ({ seller_id, seller_name, seller_logo, products, loading }) => {
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  const { canScrollPrev, canScrollNext, scrollPrev, scrollNext } = useCarouselScroll(scrollRef);
  
  if (loading) return <CarouselSkeleton />;
  if (!products || products.length === 0) return null;

  return (
    <div className="bg-transparent border border-border/20 rounded-xl p-3 mb-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          {seller_logo ? (
            <img src={seller_logo} alt={seller_name} className="w-4 h-4 rounded-full object-cover" />
          ) : (
            <div className="w-4 h-4 rounded-full bg-primary/10 flex items-center justify-center">
              <Store className="w-2.5 h-2.5 text-primary" />
            </div>
          )}
          <h3 className="font-semibold text-[13px] text-foreground">More from {seller_name}</h3>
        </div>
        <div className="flex items-center gap-2">
          <CarouselNavButtons 
            onPrev={scrollPrev} 
            onNext={scrollNext} 
            canScrollPrev={canScrollPrev}
            canScrollNext={canScrollNext}
          />
          <button 
            onClick={() => navigate(`/business/${seller_id}`)}
            className="text-[11px] text-primary flex items-center gap-0.5 hover:underline"
          >
            View store
          </button>
        </div>
      </div>
      <div 
        ref={scrollRef}
        className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide scroll-smooth"
      >
        {products.slice(0, 10).map((product) => (
          <XStyleProductCard 
            key={product.id} 
            product={product} 
            showDiscount={product.has_discount} 
          />
        ))}
      </div>
    </div>
  );
};

export { CarouselSkeleton };