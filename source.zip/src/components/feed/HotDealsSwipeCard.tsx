import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { Bookmark, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useBookmarks } from '@/hooks/useBookmarks';
import { Skeleton } from '@/components/ui/skeleton';
import HotDealsSourcesDialog, { DealSource } from '@/components/sections/HotDealsSourcesDialog';
import EarlyMarketAIIcon from '@/components/icons/EarlyMarketAIIcon';

interface DealLike {
  id: string;
  title: string;
  price: number;
  original_price?: number;
  images: string[];
  seller_id: string;
  seller_name: string;
  seller_logo?: string;
  is_verified?: boolean;
  store_slug?: string | null;
}

interface Props {
  deals: DealLike[];
  loading?: boolean;
  sources?: DealSource[];
  aiHref?: string;
}

const ROTATE_MS = 6000;
const SWIPE_THRESHOLD = 60;

const slideVariants = {
  enter: (dir: number) => ({ x: dir > 0 ? 320 : -320, opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (dir: number) => ({ x: dir > 0 ? -320 : 320, opacity: 0 }),
};

const HotDealsSwipeCard: React.FC<Props> = ({ deals, loading, sources, aiHref }) => {
  const navigate = useNavigate();
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const [[index, dir], setState] = useState<[number, number]>([0, 1]);
  const [paused, setPaused] = useState(false);
  const [sourcesOpen, setSourcesOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(true);

  const items = useMemo(() => deals.slice(0, 20), [deals]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => setInView(entry.isIntersecting),
      { threshold: 0.4 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    if (paused || !inView || items.length <= 1) return;
    const t = setInterval(() => {
      setState(([i]) => [(i + 1) % items.length, 1]);
    }, ROTATE_MS);
    return () => clearInterval(t);
  }, [paused, inView, items.length]);

  if (loading) {
    return (
      <div className="px-4 py-3">
        <Skeleton className="h-40 w-full rounded-2xl" />
      </div>
    );
  }
  if (!items.length) return null;

  const deal = items[((index % items.length) + items.length) % items.length];
  const discount = deal.original_price
    ? Math.round(((deal.original_price - deal.price) / deal.original_price) * 100)
    : 0;

  const uniqueSellers = Array.from(new Map(items.map((d) => [d.seller_id, d])).values());
  const avatars = uniqueSellers.slice(0, 5);
  const totalSources = uniqueSellers.length;

  const bookmarked = isBookmarked(deal.id, 'product');

  const advance = (delta: number) => {
    setState(([i]) => [(i + delta + items.length) % items.length, delta]);
  };

  const onDragEnd = (_: unknown, info: PanInfo) => {
    if (info.offset.x < -SWIPE_THRESHOLD) advance(1);
    else if (info.offset.x > SWIPE_THRESHOLD) advance(-1);
    setPaused(false);
  };

  return (
    <div
      ref={containerRef}
      className="py-3 bg-transparent"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="flex items-center justify-between mb-2 px-3">
        <div className="flex items-center gap-2">
          <span className="text-[13px] font-bold text-foreground">Hot Deals</span>
          <button
            onClick={() => setSourcesOpen(true)}
            className="text-[10px] text-red-500 font-semibold hover:underline"
          >
            {totalSources} sellers
          </button>
        </div>
      </div>

      <div className="relative bg-transparent overflow-hidden">
        <AnimatePresence mode="wait" custom={dir}>
          <motion.div
            key={deal.id}
            custom={dir}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 0.35, ease: 'easeOut' }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.2}
            onDragStart={() => setPaused(true)}
            onDragEnd={onDragEnd}
            className="w-full bg-transparent"
          >
            <div
              role="button"
              tabIndex={0}
              onClick={() => navigate(`/ad/${deal.id}`)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  navigate(`/ad/${deal.id}`);
                }
              }}
              className="w-full text-left bg-transparent cursor-pointer select-none"
            >
              <div className="flex gap-3 p-3">
                <div className="relative w-24 h-24 rounded-xl overflow-hidden bg-muted flex-shrink-0">
                  {deal.images?.[0] && (
                    <img
                      src={deal.images[0]}
                      alt={deal.title}
                      loading="lazy"
                      decoding="async"
                      className="w-full h-full object-cover pointer-events-none"
                      draggable={false}
                    />
                  )}
                  {discount > 0 && (
                    <div className="absolute bottom-1 left-1 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                      -{discount}%
                    </div>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <h3 className="text-[14px] font-semibold text-foreground line-clamp-2 leading-snug">
                    {deal.title}
                  </h3>
                  <div className="flex items-center gap-1 mt-1 text-[11px] text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    <span>Limited offer</span>
                  </div>
                  <p className="text-[12px] text-muted-foreground mt-1 line-clamp-2">
                    {discount > 0
                      ? `Save ${discount}% on this deal from ${deal.seller_name}.`
                      : `Special offer from ${deal.seller_name}.`}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between border-t border-border/30 px-3 py-2 bg-transparent">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    setSourcesOpen(true);
                  }}
                  className="flex items-center gap-2 rounded-full px-1 py-0.5 hover:bg-muted/60 transition-colors"
                >
                  <div className="flex -space-x-2">
                    {avatars.map((a) => (
                      <img
                        key={a.seller_id}
                        src={a.seller_logo || '/placeholder.svg'}
                        alt={a.seller_name}
                        className="w-5 h-5 rounded-full border border-background object-cover bg-muted"
                      />
                    ))}
                  </div>
                  <span className="text-[11px] text-muted-foreground hover:text-foreground">
                    {totalSources} {totalSources === 1 ? 'source' : 'sources'}
                  </span>
                </button>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    aria-label="Ask EarlyMarket AI about this deal"
                    onClick={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      const prompt = `Tell me more about this deal: "${deal.title}" from ${deal.seller_name}${deal.original_price ? ` (was ${deal.original_price}, now ${deal.price})` : ''}. Is it worth it?`;
                      navigate(`/ai?prompt=${encodeURIComponent(prompt)}&context=hot-deal&dealId=${deal.id}`);
                    }}
                    className="inline-flex items-center justify-center h-10 w-10 rounded-full hover:bg-primary/10"
                    title="Ask EarlyMarket AI"
                  >
                    <EarlyMarketAIIcon className="w-7 h-7" />
                  </button>
                  <button
                    type="button"
                    aria-label="Bookmark"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleBookmark(deal.id, 'product');
                    }}
                    className="inline-flex items-center justify-center h-8 w-8 rounded-full hover:bg-muted"
                  >
                    <Bookmark
                      className={`w-4 h-4 ${
                        bookmarked ? 'fill-primary text-primary' : 'text-muted-foreground'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {items.length > 1 && (
          <div className="absolute top-2 right-2 flex gap-1 pointer-events-none">
            {items.slice(0, Math.min(items.length, 8)).map((_, i) => (
              <span
                key={i}
                className={`h-1 rounded-full transition-all ${
                  i === index % 8 ? 'w-3 bg-red-500' : 'w-1 bg-muted-foreground/30'
                }`}
              />
            ))}
          </div>
        )}
      </div>

      <HotDealsSourcesDialog
        open={sourcesOpen}
        onOpenChange={setSourcesOpen}
        sources={sources || uniqueSellers.map((u) => ({
          seller_id: u.seller_id,
          business_name: u.seller_name,
          business_logo_url: u.seller_logo,
          is_verified: u.is_verified,
          store_slug: u.store_slug || null,
        }))}
      />
    </div>
  );
};

export default HotDealsSwipeCard;
