import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { BadgeCheck, Zap, X, MapPin, Clock, DollarSign, Briefcase } from 'lucide-react';
import { getSellerProfileUrl } from '@/lib/sellerUrl';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

interface ServiceItem {
  id: string;
  title: string;
  description: string;
  price: number;
  location: string;
  images: string[];
  seller: {
    id: string;
    business_name: string;
    business_logo_url: string | null;
    is_verified: boolean;
  };
  service_details?: {
    starting_price?: number;
    experience_years?: number;
    service_area?: string[];
  };
}

const ROTATING_TITLES = [
  'Services for you',
  'Expert help nearby',
  'Professional services',
  'Top-rated services',
  'Trusted experts'
];

const ServicesForYouSection: React.FC = () => {
  const navigate = useNavigate();
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [dismissed, setDismissed] = useState(false);
  const [currentTitleIndex, setCurrentTitleIndex] = useState(0);

  useEffect(() => {
    fetchServices();
  }, []);

  // Rotate title every 3 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTitleIndex(prev => (prev + 1) % ROTATING_TITLES.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const fetchServices = async () => {
    try {
      const { data, error } = await supabase
        .from('ads')
        .select(`
          id,
          title,
          description,
          price,
          location,
          images,
          seller_profiles(
            id,
            business_name,
            business_logo_url,
            is_verified
          ),
          service_details(
            starting_price,
            experience_years,
            service_area
          )
        `)
        .eq('listing_type', 'services')
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) throw error;

      const formattedServices: ServiceItem[] = (data || []).map((item: any) => ({
        id: item.id,
        title: item.title,
        description: item.description || '',
        price: item.price || 0,
        location: item.location,
        images: item.images || [],
        seller: {
          id: item.seller_profiles?.id || '',
          business_name: item.seller_profiles?.business_name || 'Regular User',
          business_logo_url: item.seller_profiles?.business_logo_url || '',
          is_verified: item.seller_profiles?.is_verified || false,
        },
        service_details: item.service_details?.[0] || null,
      }));

      setServices(formattedServices);
    } catch (error) {
      console.error('Error fetching services:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceClick = (service: ServiceItem) => {
    navigate(`/ad/${service.id}`);
  };

  if (dismissed) {
    return null;
  }

  if (loading) {
    return (
      <div className="mx-4 my-4 rounded-2xl border border-border bg-card overflow-hidden">
        <div className="p-4 border-b border-border">
          <Skeleton className="h-5 w-32" />
        </div>
        <div className="divide-y divide-border">
          {[1, 2, 3].map(i => (
            <div key={i} className="p-4 flex items-start gap-3">
              <Skeleton className="w-12 h-12 rounded-lg" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-3 w-full" />
                <div className="flex gap-2">
                  <Skeleton className="h-5 w-16 rounded-full" />
                  <Skeleton className="h-5 w-16 rounded-full" />
                </div>
              </div>
              <Skeleton className="h-8 w-16 rounded-full" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (services.length === 0) {
    return null;
  }

  return (
    <div className="mx-4 my-4 rounded-2xl border border-border bg-card overflow-hidden">
      {/* Header with animated title */}
      <div className="px-4 py-3 flex items-center justify-between border-b border-border bg-gradient-to-r from-blue-500/10 to-purple-500/10">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-gradient-to-br from-blue-500 to-purple-500">
            <Zap className="w-3.5 h-3.5 text-white" />
          </div>
          <div className="relative h-5 overflow-hidden">
            <AnimatePresence mode="wait">
              <motion.h3
                key={currentTitleIndex}
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: -20, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="font-bold text-base text-white drop-shadow-sm"
              >
                {ROTATING_TITLES[currentTitleIndex]}
              </motion.h3>
            </AnimatePresence>
          </div>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="p-1 rounded-full hover:bg-muted transition-colors"
        >
          <X className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      {/* Services list */}
      <div className="divide-y divide-border">
        {services.map(service => (
          <div
            key={service.id}
            onClick={() => handleServiceClick(service)}
            className="p-4 flex items-start gap-3 hover:bg-muted/50 transition-colors cursor-pointer"
          >
            {/* Service image */}
            <div className="w-12 h-12 rounded-lg overflow-hidden bg-muted shrink-0">
              {service.images?.[0] ? (
                <img 
                  src={service.images[0]} 
                  alt={service.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Briefcase className="w-5 h-5 text-muted-foreground" />
                </div>
              )}
            </div>

            {/* Service info */}
            <div className="flex-1 min-w-0">
              {/* Service title */}
              <h4 className="font-semibold text-sm text-foreground line-clamp-1 mb-0.5">
                {service.title}
              </h4>
              
              {/* Description */}
              <p className="text-xs text-muted-foreground line-clamp-1 mb-2">
                {service.description}
              </p>

              {/* Specs as chips */}
              <div className="flex flex-wrap gap-1.5 mb-2">
                {(service.service_details?.starting_price || service.price > 0) && (
                  <Badge variant="secondary" className="text-[10px] px-2 py-0.5 h-5 gap-1">
                    <DollarSign className="w-2.5 h-2.5" />
                    From {localStorage.getItem('app_currency') || 'UGX'} {(service.service_details?.starting_price || service.price).toLocaleString()}
                  </Badge>
                )}
                {service.service_details?.experience_years && (
                  <Badge variant="secondary" className="text-[10px] px-2 py-0.5 h-5 gap-1">
                    <Clock className="w-2.5 h-2.5" />
                    {service.service_details.experience_years} yrs exp
                  </Badge>
                )}
                {service.location && (
                  <Badge variant="secondary" className="text-[10px] px-2 py-0.5 h-5 gap-1">
                    <MapPin className="w-2.5 h-2.5" />
                    {service.location}
                  </Badge>
                )}
              </div>

              {/* Seller info */}
              <div className="flex items-center gap-1">
                <Avatar className="w-4 h-4">
                  <AvatarImage src={service.seller.business_logo_url || undefined} />
                  <AvatarFallback className="text-[8px] bg-primary/10 text-primary">
                    {service.seller.business_name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <span className="text-[11px] text-muted-foreground truncate">
                  {service.seller.business_name}
                </span>
                {service.seller.is_verified && (
                  <BadgeCheck className="w-3 h-3 text-primary shrink-0" />
                )}
              </div>
            </div>

            {/* View button */}
            <Button
              size="sm"
              variant="outline"
              className="rounded-full h-8 px-4 text-xs font-medium shrink-0"
              onClick={(e) => {
                e.stopPropagation();
                handleServiceClick(service);
              }}
            >
              View
            </Button>
          </div>
        ))}
      </div>

      {/* Show more link */}
      <div 
        onClick={() => navigate('/search?contentType=services')}
        className="px-4 py-3 text-primary text-sm font-medium hover:bg-muted/50 transition-colors cursor-pointer"
      >
        Show more
      </div>
    </div>
  );
};

export default ServicesForYouSection;
