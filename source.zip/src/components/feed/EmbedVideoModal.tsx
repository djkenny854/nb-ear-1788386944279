import React from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ExternalLink } from 'lucide-react';

interface EmbedVideoModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  url: string;
  type: 'youtube' | 'tiktok';
}

function getYouTubeEmbedUrl(url: string): string | null {
  const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
  const match = url.match(regex);
  return match ? `https://www.youtube.com/embed/${match[1]}?autoplay=1&rel=0` : null;
}

function getTikTokEmbedUrl(url: string): string | null {
  // Extract video ID from TikTok URL
  const regex = /tiktok\.com\/@[^\/]+\/video\/(\d+)/;
  const match = url.match(regex);
  return match ? `https://www.tiktok.com/embed/v2/${match[1]}` : null;
}

const EmbedVideoModal: React.FC<EmbedVideoModalProps> = ({ open, onOpenChange, url, type }) => {
  const embedUrl = type === 'youtube' ? getYouTubeEmbedUrl(url) : getTikTokEmbedUrl(url);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl p-0 overflow-hidden border-0 bg-black" hideCloseButton>
        <div className="relative">
          {embedUrl ? (
            <iframe
              src={embedUrl}
              title={type === 'youtube' ? 'YouTube Video' : 'TikTok Video'}
              className="w-full aspect-video"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <div className="w-full aspect-video flex items-center justify-center text-white">
              <p>Unable to embed this video</p>
            </div>
          )}
          <div className="flex items-center justify-between p-3 bg-background">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onOpenChange(false)}
              className="text-muted-foreground"
            >
              Close
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open(url, '_blank')}
              className="gap-1"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Open in {type === 'youtube' ? 'YouTube' : 'TikTok'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EmbedVideoModal;
