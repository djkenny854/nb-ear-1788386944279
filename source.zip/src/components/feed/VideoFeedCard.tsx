import React, { useState, useRef, useEffect } from 'react';
import { videoCdnUrl } from '@/utils/cdnUrl';
import { Heart, MessageCircle, Share2, Bookmark, Eye, Play, Volume2, VolumeX } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import SmartVideo from '@/components/media/SmartVideo';
import { useIsMobile } from '@/hooks/use-mobile';
import UnifiedVerifiedBadge from '@/components/UnifiedVerifiedBadge';
import { useCurrency } from '@/contexts/CurrencyContext';
import videoPlaceholder from '@/assets/video-placeholder.webp';
import { prefetchVideo } from '@/utils/videoPrefetch';
import { getClampedRatio } from '@/components/media/AdaptiveMedia';

interface FeedItem {
  id: string;
  title: string;
  description: string;
  price: number;
  images: string[];
  category: string;
  location: string;
  created_at: string;
  listing_type: string;
  content_type?: 'ad' | 'post' | 'event';
  b2_video_url?: string | null;
  seller: {
    id: string;
    business_name: string;
    business_logo_url: string;
    is_verified: boolean;
    verification_badge_color?: string | null;
  };
  is_liked?: boolean;
  is_saved?: boolean;
  like_count: number;
  view_count: number;
  event_details?: {
    event_date?: string;
    end_date?: string;
    venue_name?: string;
    venue_address?: string;
    is_free?: boolean;
    ticket_price?: number;
    ticket_currency?: string;
    max_attendees?: number;
    current_attendees?: number;
  };
}

interface VideoFeedCardProps {
  item: FeedItem;
  onVideoClick: () => void;
  onLike: (id: string) => void;
  onSave: (id: string) => void;
  onShare: () => void;
  onSellerClick: () => void;
  scrollContainer?: HTMLElement | null;
}

const VideoFeedCard: React.FC<VideoFeedCardProps> = ({
  item,
  onVideoClick,
  onLike,
  onSave,
  onShare,
  onSellerClick,
  scrollContainer
}) => {
  const isMobile = useIsMobile();
  const { formatPrice } = useCurrency();
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [showControls, setShowControls] = useState(false);
  const [videoAspectRatio, setVideoAspectRatio] = useState<'portrait' | 'landscape' | 'square'>('portrait');
  const [ratioNum, setRatioNum] = useState<number>(9 / 16);
  const [isVideoReady, setIsVideoReady] = useState(false);

  // Handle video click - only open modal on mobile
  const handleVideoClick = () => {
    if (isMobile) {
      onVideoClick();
    }
  };

  // Detect video aspect ratio
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleLoadedMetadata = () => {
      const ratio = video.videoWidth / video.videoHeight;
      if (ratio) setRatioNum(ratio);
      if (ratio < 0.8) {
        setVideoAspectRatio('portrait');
      } else if (ratio > 1.2) {
        setVideoAspectRatio('landscape');
      } else {
        setVideoAspectRatio('square');
      }
    };

    video.addEventListener('loadedmetadata', handleLoadedMetadata);
    return () => video.removeEventListener('loadedmetadata', handleLoadedMetadata);
  }, []);

  // Intersection Observer for autoplay
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && entry.intersectionRatio >= 0.5) {
          video.play()
            .then(() => setIsPlaying(true))
            .catch(() => {});
        } else {
          video.pause();
          setIsPlaying(false);
        }
      },
      { threshold: [0.3, 0.5, 0.7], root: scrollContainer || null }
    );

    observer.observe(video);
    return () => observer.disconnect();
  }, [scrollContainer]);

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  // Sanitize video URL
  const sanitizedVideoUrl = React.useMemo(() => {
    if (!item.b2_video_url) return '';
    let clean = videoCdnUrl(item.b2_video_url) || item.b2_video_url;
    while (clean.match(/^https:\/\/https:\/\//)) {
      clean = clean.replace(/^https:\/\/https:\/\//, 'https://');
    }
    return clean;
  }, [item.b2_video_url]);

  // Warm HTTP cache so opening the full modal is instant on repeat visits.
  React.useEffect(() => {
    if (sanitizedVideoUrl) prefetchVideo(sanitizedVideoUrl);
  }, [sanitizedVideoUrl]);

  const formatCount = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count.toString();
  };

  return (
    <div
      ref={containerRef}
      className="bg-card md:rounded-2xl shadow-sm border-x-0 md:border border-y border-border md:mb-4 hover:shadow-md transition-shadow overflow-hidden mx-0"
    >
      {/* Header with seller info */}
      <div className="px-2 py-4 md:p-4 md:pb-2">
        <div className="flex items-center gap-3">
          <Avatar
            className="w-10 h-10 cursor-pointer"
            onClick={onSellerClick}
          >
            <AvatarImage src={item.seller.business_logo_url} />
            <AvatarFallback>
              {item.seller.business_name.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1">
              <span
                className="font-bold text-sm hover:underline cursor-pointer"
                onClick={onSellerClick}
              >
              {item.seller.business_name}
            </span>
            {item.seller.is_verified && (
              <UnifiedVerifiedBadge isVerified badgeColor={item.seller.verification_badge_color} size="sm" />
            )}
            </div>
            <Badge variant="secondary" className="text-xs mt-1">
              {item.content_type === 'event' ? '🎉 Event' : item.category}
            </Badge>
          </div>
        </div>

        {/* Description */}
        <div className="mt-3">
          <h2 className="font-semibold text-base mb-1">{item.title}</h2>
          {item.description && (
            <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>
          )}
          
          {/* Event details */}
          {item.content_type === 'event' && item.event_details ? (
            <div className="space-y-2 mt-2">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge className="bg-primary/10 text-primary border-primary/20">
                  📅 {item.event_details.event_date ? new Date(item.event_details.event_date).toLocaleDateString('en-US', {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  }) : 'Date TBD'}
                </Badge>
                {item.event_details.is_free ? (
                  <Badge className="bg-green-500/10 text-green-600 border-green-500/20">Free Entry</Badge>
                ) : item.event_details.ticket_price ? (
                  <Badge variant="secondary">
                    {formatPrice(item.event_details.ticket_price || 0)}
                  </Badge>
                ) : null}
              </div>
              {item.event_details.venue_name && (
                <p className="text-sm text-muted-foreground">
                  📍 {item.event_details.venue_name}
                  {item.event_details.venue_address && ` - ${item.event_details.venue_address}`}
                </p>
              )}
            </div>
          ) : (
            <p className="text-primary font-bold text-lg mt-1">
              {formatPrice(item.price || 0)}
            </p>
          )}
        </div>
      </div>

      {/* Video container - respects aspect ratio */}
      <div
        className={cn(
          "relative overflow-hidden mx-2 mb-2 md:mx-2 md:mb-2 rounded-xl",
          videoAspectRatio === 'portrait' ? "bg-muted" : "bg-black",
          isMobile && "cursor-pointer"
        )}
        style={{ aspectRatio: String(getClampedRatio(ratioNum, 'feed')), maxHeight: 512 }}
        onMouseEnter={() => setShowControls(true)}
        onMouseLeave={() => setShowControls(false)}
        onClick={handleVideoClick}
      >
        {/* Black placeholder with play icon until video loads */}
        {!isVideoReady && (
          <div className="absolute inset-0 bg-black flex items-center justify-center z-10">
            <div className="flex flex-col items-center gap-2">
              <div className="w-14 h-14 rounded-full bg-white/10 flex items-center justify-center">
                <Play className="w-7 h-7 text-white ml-0.5" fill="white" />
              </div>
              <div className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
            </div>
          </div>
        )}

        <SmartVideo
          ref={videoRef}
          src={sanitizedVideoUrl}
          poster={videoPlaceholder}
          className={cn(
            "w-full h-full select-none",
            "object-cover",
            !isVideoReady && "opacity-0"
          )}
          style={{ WebkitUserSelect: 'none', userSelect: 'none', pointerEvents: 'auto' }}
          loop
          muted={isMuted}
          playsInline
          controlsList="nodownload nofullscreen noremoteplayback noplaybackrate"
          disablePictureInPicture
          onContextMenu={(e) => e.preventDefault()}
          onLoadedData={() => setIsVideoReady(true)}
          onReady={() => setIsVideoReady(true)}
          onTouchStart={(e) => e.currentTarget.dataset.touched = 'true'}
          onTouchEnd={(e) => {
            // Prevent Samsung browser long-press download
            if (e.currentTarget.dataset.touched) {
              e.currentTarget.dataset.touched = '';
            }
          }}
        />

        {/* Play overlay when paused - only show after video is ready */}
        {isVideoReady && !isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/30">
            <div className="w-16 h-16 rounded-full bg-black/60 flex items-center justify-center">
              <Play className="w-8 h-8 text-white ml-1" fill="white" />
            </div>
          </div>
        )}

        {/* Mute button */}
        <button
          onClick={toggleMute}
          className={cn(
            "absolute bottom-3 right-3 w-8 h-8 rounded-full bg-black/60 flex items-center justify-center text-white transition-opacity",
            showControls || !isPlaying ? "opacity-100" : "opacity-0"
          )}
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>

        {/* View count badge */}
        <div className="absolute top-3 left-3 flex items-center gap-1 bg-black/60 text-white text-xs px-2 py-1 rounded-full">
          <Eye className="w-3 h-3" />
          <span>{formatCount(item.view_count)}</span>
        </div>

        {/* Tap to expand hint - only show on mobile */}
        {isMobile && (
          <div className={cn(
            "absolute bottom-3 left-3 text-white text-xs bg-black/60 px-2 py-1 rounded-full transition-opacity",
            showControls ? "opacity-100" : "opacity-0"
          )}>
            Tap for full view
          </div>
        )}
      </div>

      {/* Action buttons */}
      <div className="px-2 pb-3 md:px-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onLike(item.id);
            }}
            className={cn(
              "flex items-center gap-1.5 text-sm transition-colors",
              item.is_liked ? "text-red-500" : "text-muted-foreground hover:text-red-500"
            )}
          >
            <Heart className={cn("w-5 h-5", item.is_liked && "fill-current")} />
            
          </button>

          <button className="flex items-center gap-1.5 text-sm text-muted-foreground">
            <Eye className="w-5 h-5" />
            <span>{formatCount(item.view_count)}</span>
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onSave(item.id);
            }}
            className={cn(
              "text-muted-foreground hover:text-primary transition-colors",
              item.is_saved && "text-primary"
            )}
          >
            <Bookmark className={cn("w-5 h-5", item.is_saved && "fill-current")} />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onShare();
            }}
            className="text-muted-foreground hover:text-primary transition-colors"
          >
            <Share2 className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default React.memo(VideoFeedCard, (prev, next) =>
  prev.item.id === next.item.id &&
  prev.item.is_liked === next.item.is_liked &&
  prev.item.is_saved === next.item.is_saved &&
  prev.item.like_count === next.item.like_count &&
  prev.item.view_count === next.item.view_count &&
  prev.scrollContainer === next.scrollContainer
);
