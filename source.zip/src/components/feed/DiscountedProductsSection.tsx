import React, { useRef, useState, useEffect } from 'react';
import { ChevronRight, ChevronLeft, Percent, BadgeCheck } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import verifiedBadge from '@/assets/verified-badge.png';
import { useIsMobile } from '@/hooks/use-mobile';
import HotDealsRotatingCard from './HotDealsRotatingCard';
import RailScroller from '@/components/common/RailScroller';

interface DiscountedProduct {
  id: string;
  title: string;
  price: number;
  original_price?: number;
  images: string[];
  seller_id: string;
  seller_name: string;
  seller_logo?: string;
  is_verified?: boolean;
}

const DiscountedProductCard: React.FC<{ product: DiscountedProduct }> = ({ product }) => {
  const navigate = useNavigate();
  const discountPercent = product.original_price 
    ? Math.round(((product.original_price - product.price) / product.original_price) * 100)
    : 0;
  
  return (
    <div 
      onClick={() => navigate(`/ad/${product.id}`)}
      className="flex-shrink-0 w-[160px] cursor-pointer group"
    >
      <div className="relative aspect-square rounded-2xl overflow-hidden mb-2 bg-gradient-to-br from-red-500/10 to-orange-500/10 border border-border/30">
        {product.images?.[0] ? (
          <img 
            src={product.images[0]} 
            alt={product.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground">
            <Percent className="w-8 h-8" />
          </div>
        )}
        
        {/* Discount badge */}
        <div className="absolute top-2 left-2">
          <Badge className="bg-gradient-to-r from-red-500 to-orange-500 text-white text-[10px] px-2 py-0.5 font-bold shadow-lg">
            -{discountPercent}%
          </Badge>
        </div>

        {/* Verified badge */}
        {product.is_verified && (
          <div className="absolute top-2 right-2">
            <img src={verifiedBadge} alt="Verified" className="w-5 h-5" />
          </div>
        )}

        {/* Hover overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>
      
      <p className="text-[13px] font-medium text-foreground line-clamp-1 mb-1">{product.title}</p>
      
      <div className="flex items-center gap-2">
        {/* Show discount percentage prominently */}
        {discountPercent > 0 && (
          <span className="text-[14px] font-bold text-red-500">
            {discountPercent}% OFF
          </span>
        )}
        {/* Only show price if it's valid (not 0) */}
        {product.price > 0 && (
          <span className="text-[12px] text-muted-foreground">
            {(localStorage.getItem('app_currency') || 'UGX')} {product.price?.toLocaleString()}
          </span>
        )}
      </div>
      
      {/* Seller info */}
      <div className="flex items-center gap-1 mt-1">
        <span className="text-[10px] text-muted-foreground truncate">{product.seller_name}</span>
        {product.is_verified && (
          <BadgeCheck className="w-3 h-3 text-primary flex-shrink-0" />
        )}
      </div>
    </div>
  );
};

const DiscountedSkeleton: React.FC = () => (
  <div className="border-b border-border py-4 px-4">
    <div className="flex items-center justify-between mb-3">
      <div className="flex items-center gap-2">
        <Skeleton className="w-5 h-5 rounded-full" />
        <Skeleton className="w-36 h-4" />
      </div>
      <Skeleton className="w-14 h-4" />
    </div>
    <div className="flex gap-3 overflow-hidden">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="flex-shrink-0 w-[160px]">
          <Skeleton className="aspect-square rounded-2xl mb-2" />
          <Skeleton className="w-full h-3 mb-1" />
          <Skeleton className="w-20 h-4" />
        </div>
      ))}
    </div>
  </div>
);

interface DiscountedProductsSectionProps {
  products: DiscountedProduct[];
  loading?: boolean;
}

const DiscountedProductsSection: React.FC<DiscountedProductsSectionProps> = ({ 
  products, 
  loading 
}) => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollPrev, setCanScrollPrev] = useState(false);
  const [canScrollNext, setCanScrollNext] = useState(true);

  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollPrev(scrollLeft > 0);
      setCanScrollNext(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  useEffect(() => {
    checkScroll();
    const el = scrollRef.current;
    if (el) {
      el.addEventListener('scroll', checkScroll);
      return () => el.removeEventListener('scroll', checkScroll);
    }
  }, [products]);

  const scrollPrev = () => {
    scrollRef.current?.scrollBy({ left: -320, behavior: 'smooth' });
  };

  const scrollNext = () => {
    scrollRef.current?.scrollBy({ left: 320, behavior: 'smooth' });
  };
  
  if (loading) return <DiscountedSkeleton />;
  if (!products || products.length === 0) return null;

  // Mobile gets the rotating Perplexity-style card; desktop keeps the carousel.
  if (isMobile) {
    return <HotDealsRotatingCard deals={products.slice(0, 20)} loading={loading} />;
  }

  return (
    <div className="border-b border-border py-4 bg-gradient-to-r from-red-500/5 via-transparent to-orange-500/5">
      <div className="flex items-center justify-between mb-3 px-4">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-gradient-to-br from-red-500 to-orange-500">
            <Percent className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-[15px] text-foreground">Hot Deals</span>
          <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 border-red-500/30 text-red-500">
            Save up to 70%
          </Badge>
        </div>
        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => { e.stopPropagation(); scrollPrev(); }}
              disabled={!canScrollPrev}
              className={cn(
                "h-7 w-7 rounded-full",
                !canScrollPrev && "opacity-30 cursor-not-allowed"
              )}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => { e.stopPropagation(); scrollNext(); }}
              disabled={!canScrollNext}
              className={cn(
                "h-7 w-7 rounded-full",
                !canScrollNext && "opacity-30 cursor-not-allowed"
              )}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
          <button 
            onClick={() => navigate('/search?contentType=promotions')}
            className="text-[12px] text-red-500 font-medium flex items-center gap-0.5 hover:underline"
          >
            See all
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>
      </div>
      <RailScroller>
      <div 
        ref={scrollRef}
        className="flex gap-3 overflow-x-auto pb-2 px-4 scrollbar-hide scroll-smooth"
      >
        {products.map((product) => (
          <DiscountedProductCard key={product.id} product={product} />
        ))}
      </div>
      </RailScroller>
    </div>
  );
};

export default DiscountedProductsSection;
