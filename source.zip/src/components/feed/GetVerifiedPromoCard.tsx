import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BadgeCheck, Shield, TrendingUp, Star, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const GetVerifiedPromoCard: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="border-b border-border">
      <div className="mx-4 my-4">
        <div 
          className="relative overflow-hidden rounded-2xl p-5 sm:p-6"
          style={{
            background: 'linear-gradient(135deg, hsl(var(--card)) 0%, hsl(var(--muted)) 50%, hsl(var(--card)) 100%)',
            border: '1px solid hsl(var(--border))',
          }}
        >
          {/* Subtle gradient overlay */}
          <div 
            className="absolute inset-0 opacity-40"
            style={{
              background: 'linear-gradient(135deg, hsl(var(--primary) / 0.08) 0%, transparent 50%, hsl(var(--primary) / 0.05) 100%)',
            }}
          />

          <div className="relative z-10 flex items-start gap-4">
            {/* Left: Text content */}
            <div className="flex-1 min-w-0 space-y-3">
              {/* Title with italic accent */}
              <div>
                <h3 className="text-lg sm:text-xl font-bold text-foreground leading-tight">
                  Get Verified:{' '}
                  <span className="italic text-primary">Stand Out</span>
                </h3>
                <p className="text-xs text-muted-foreground mt-1">
                  Join trusted sellers on EarlyMarket
                </p>
              </div>

              {/* Stats boxes */}
              <div className="flex gap-2">
                <div className="flex-1 rounded-lg border border-border bg-background/60 backdrop-blur-sm px-3 py-2 text-center">
                  <p className="text-base sm:text-lg font-bold text-foreground">3×</p>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                    More Views
                  </p>
                </div>
                <div className="flex-1 rounded-lg border border-border bg-background/60 backdrop-blur-sm px-3 py-2 text-center">
                  <p className="text-base sm:text-lg font-bold text-foreground">~85%</p>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                    Trust Rate
                  </p>
                </div>
              </div>

              {/* Benefits text */}
              <p className="text-xs text-muted-foreground leading-relaxed">
                Verified sellers get a <span className="text-foreground font-medium italic">trust badge</span>, priority in search,
                and buyers are more likely to engage with verified profiles.
              </p>

              {/* CTA Button */}
              <Button 
                onClick={(e) => {
                  e.stopPropagation();
                  navigate('/verification');
                }}
                size="sm"
                className="gap-1.5 rounded-full text-xs font-semibold px-5"
              >
                <Shield className="w-3.5 h-3.5" />
                Get Verified Now
              </Button>
            </div>

            {/* Right: 3D-style verification badge SVG */}
            <div className="flex-shrink-0 w-20 h-20 sm:w-24 sm:h-24 self-center">
              <svg 
                viewBox="0 0 120 120" 
                className="w-full h-full drop-shadow-lg"
                style={{ filter: 'drop-shadow(0 4px 12px hsl(var(--primary) / 0.3))' }}
              >
                {/* Outer glow ring */}
                <defs>
                  <linearGradient id="badge-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="hsl(var(--primary))" />
                    <stop offset="50%" stopColor="hsl(var(--primary) / 0.8)" />
                    <stop offset="100%" stopColor="hsl(var(--primary) / 0.6)" />
                  </linearGradient>
                  <linearGradient id="badge-shine" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="white" stopOpacity="0.4" />
                    <stop offset="50%" stopColor="white" stopOpacity="0.1" />
                    <stop offset="100%" stopColor="white" stopOpacity="0" />
                  </linearGradient>
                  <filter id="badge-shadow">
                    <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="hsl(var(--primary))" floodOpacity="0.3" />
                  </filter>
                </defs>
                
                {/* Shield/badge shape with 3D effect */}
                <path 
                  d="M60 8 L95 25 C100 28 105 35 105 42 L105 65 C105 82 85 100 60 112 C35 100 15 82 15 65 L15 42 C15 35 20 28 25 25 Z"
                  fill="url(#badge-grad)"
                  filter="url(#badge-shadow)"
                />
                
                {/* Inner lighter layer for 3D depth */}
                <path 
                  d="M60 14 L90 29 C94 31 98 37 98 43 L98 64 C98 78 81 94 60 105 C39 94 22 78 22 64 L22 43 C22 37 26 31 30 29 Z"
                  fill="hsl(var(--primary) / 0.9)"
                />
                
                {/* Shine overlay */}
                <path 
                  d="M60 14 L90 29 C94 31 98 37 98 43 L98 50 C80 55 40 48 22 43 L22 43 C22 37 26 31 30 29 Z"
                  fill="url(#badge-shine)"
                />
                
                {/* Checkmark */}
                <path 
                  d="M42 58 L55 71 L80 46"
                  fill="none"
                  stroke="hsl(var(--primary-foreground))"
                  strokeWidth="6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />

                {/* Star accents */}
                <circle cx="30" cy="20" r="2" fill="hsl(var(--primary) / 0.5)" />
                <circle cx="92" cy="18" r="1.5" fill="hsl(var(--primary) / 0.4)" />
                <circle cx="100" cy="55" r="1" fill="hsl(var(--primary) / 0.3)" />
              </svg>
            </div>
          </div>

          {/* Decorative corner accents */}
          <div className="absolute top-0 right-0 w-20 h-20 opacity-10">
            <Sparkles className="w-full h-full text-primary" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default GetVerifiedPromoCard;
