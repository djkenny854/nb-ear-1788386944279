import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { videoCdnUrl, imageCdnUrl } from '@/utils/cdnUrl';
import { MessageCircle, Share2, BarChart3, Bookmark, Calendar, MapPin, Ticket, Loader2, ChevronDown, ChevronUp, ThumbsUp, Briefcase, DollarSign, Users, ExternalLink, Wrench, Globe, Percent, Clock, Timer, Tag, Sparkles, Phone, Home, Play } from 'lucide-react';
import { YouTubeIcon, TikTokIcon } from '@/components/icons/SocialIcons';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';
import FeedCardMenu from './FeedCardMenu';
import PromotionProductsCarousel from './PromotionProductsCarousel';
import AttachedProductsCarousel from './AttachedProductsCarousel';
import EmbedVideoModal from './EmbedVideoModal';
import { motion, AnimatePresence } from 'framer-motion';
import { useViewTracking } from '@/hooks/useViewTracking';
import { useEngagement, useInterested } from '@/hooks/useEngagement';
import { useFollow } from '@/hooks/useFollow';
import { useAuth } from '@/components/auth/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import ServiceStatusBadge, { ServiceStatusType } from '@/components/service/ServiceStatusBadge';
import { useNavigate } from 'react-router-dom';
import { useCurrency } from '@/contexts/CurrencyContext';
import { formatThresholdCount } from '@/lib/formatThreshold';
import confetti from 'canvas-confetti';
import videoPlaceholder from '@/assets/video-placeholder.webp';
import AdaptiveMedia from '@/components/media/AdaptiveMedia';
import { useGlobalSettingsSafe } from '@/contexts/AppSettingsContext';

interface FeedItemBase {
  id: string;
  title: string;
  description: string;
  price: number;
  original_price?: number | null;
  has_discount?: boolean;
  images: string[];
  category: string;
  location: string;
  created_at: string;
  listing_type: string;
  content_type: 'ad' | 'post' | 'event';
  b2_video_url?: string | null;
  video_thumbnail_url?: string | null;
  media_dimensions?: { w: number; h: number }[] | null;
  video_width?: number | null;
  video_height?: number | null;
  youtube_url?: string | null;
  tiktok_url?: string | null;
  website_url?: string | null;
  tags?: string[];
  attached_services?: string[];
  attached_products?: string[];
  seller: {
    id: string;
    user_id: string;
    business_name: string;
    business_logo_url: string;
    is_verified: boolean;
    verification_badge_color?: BadgeColor;
    current_service_status?: ServiceStatusType;
  };
  is_sponsored?: boolean;
  is_liked?: boolean;
  is_saved?: boolean;
  like_count: number;
  view_count: number;
  comment_count?: number;
  job_details?: {
    company_name?: string;
    salary_min?: number;
    salary_max?: number;
    salary_currency?: string;
    job_type?: string;
    work_location?: string;
    positions?: { role: string; quantity: number; job_type?: string; salary_min?: number; salary_max?: number; salary_negotiable?: boolean; requirements?: string }[];
    number_of_positions?: number;
    job_posting_type?: 'single' | 'multiple';
    campaign_title?: string;
    apply_method?: string;
    application_deadline?: string;
  };
  service_details?: {
    starting_price?: number;
    experience_years?: number;
    service_area?: string[];
    pricing_type?: string;
    accommodation_type?: string;
    price_period?: string;
    amenities?: string[];
    booking_method?: string;
    booking_phone?: string;
    booking_url?: string;
  };
  event_details?: {
    event_date?: string;
    end_date?: string;
    venue_name?: string;
    venue_address?: string;
    is_free?: boolean;
    ticket_price?: number;
    ticket_currency?: string;
    max_attendees?: number;
    current_attendees?: number;
  };
  currency?: string;
  promotion_details?: {
    discount_percentage?: number | null;
    is_seller_wide?: boolean;
    promotion_type?: string;
    valid_until?: string;
    start_at?: string;
    brand_name?: string;
  };
}

interface XStyleFeedCardProps {
  item: FeedItemBase;
  onLike: (id: string) => void;
  onSave: (id: string) => void;
  onShare: () => void;
  onComment: () => void;
  onSellerClick: () => void;
  onClick: () => void;
  onVideoClick?: (videoUrl: string) => void;
}

// Smart image component that respects aspect ratio - X.com style
// Handles tall images (like TikTok format) by showing them in a scrollable container
const AspectRatioImage: React.FC<{ 
  src: string; 
  alt: string; 
  className?: string;
  isMultiple?: boolean;
  showFullImage?: boolean;
}> = ({ src, alt, className, isMultiple = false, showFullImage = false }) => {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);
  const [isTallImage, setIsTallImage] = useState(false);
  const [naturalDimensions, setNaturalDimensions] = useState({ width: 0, height: 0 });
  const imgRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  // Sub-1KB blurred preview of the same object (BlurHash equivalent on web).
  const blurSrc = useMemo(() => imageCdnUrl(src, { width: 24, quality: 20 }), [src]);

  // Calculate if image is taller than a threshold (TikTok-style aspect ratio)
  const checkImageDimensions = () => {
    if (imgRef.current) {
      const { naturalWidth, naturalHeight } = imgRef.current;
      setNaturalDimensions({ width: naturalWidth, height: naturalHeight });
      // If aspect ratio is taller than 3:4 (0.75), it's a tall image
      const aspectRatio = naturalWidth / naturalHeight;
      setIsTallImage(aspectRatio < 0.6); // TikTok-style is typically 9:16 (0.5625)
    }
  };

  if (error) {
    return (
      <div className={cn("bg-muted flex items-center justify-center", className)}>
        <span className="text-muted-foreground text-xs">Image unavailable</span>
      </div>
    );
  }

  // For multiple images in grid, use cover
  if (isMultiple) {
    return (
      <div className={cn("relative overflow-hidden bg-muted", className)}>
        {!loaded && blurSrc && (
          <img
            src={blurSrc}
            alt=""
            aria-hidden
            draggable={false}
            className="absolute inset-0 w-full h-full object-cover scale-110 blur-xl"
          />
        )}
        <img 
          ref={imgRef}
          src={src} 
          alt={alt}
          loading="lazy"
          decoding="async"
          // @ts-expect-error - fetchpriority is standard HTML, React 18 uses lowercase attribute
          fetchpriority="low"
          className={cn(
            "w-full h-full object-cover transition-opacity duration-300 select-none",
            loaded ? "opacity-100" : "opacity-0"
          )}
          onLoad={() => setLoaded(true)}
          onError={() => setError(true)}
          onContextMenu={(e) => e.preventDefault()}
          draggable={false}
        />
      </div>
    );
  }

  // For posts and single images - handle tall images like X does
  return (
    <div 
      ref={containerRef}
      className={cn(
        "relative overflow-hidden bg-muted rounded-2xl",
        // For tall images, limit max height and make scrollable (like X)
        isTallImage && "max-h-[420px] sm:max-h-[500px] overflow-y-auto scrollbar-hide",
        className
      )}
    >
      {!loaded && (
        <div className="absolute inset-0 bg-muted min-h-[200px]">
          {blurSrc && (
            <img
              src={blurSrc}
              alt=""
              aria-hidden
              draggable={false}
              className="w-full h-full object-cover scale-110 blur-xl"
            />
          )}
        </div>
      )}
      
      <img 
        ref={imgRef}
        src={src} 
        alt={alt}
        loading="lazy"
        decoding="async"
        className={cn(
          "w-full h-auto transition-opacity duration-300 select-none",
          loaded ? "opacity-100" : "opacity-0"
        )}
        onLoad={() => {
          setLoaded(true);
          checkImageDimensions();
        }}
        onError={() => setError(true)}
        onContextMenu={(e) => e.preventDefault()}
        draggable={false}
      />

      {/* Scroll indicator for tall images */}
      {isTallImage && loaded && (
        <div className="sticky bottom-2 left-1/2 -translate-x-1/2 w-fit mx-auto">
          <div className="bg-black/60 backdrop-blur-sm text-white text-[10px] px-2 py-1 rounded-full flex items-center gap-1">
            <ChevronDown className="w-3 h-3 animate-bounce" />
            <span>Scroll to see more</span>
          </div>
        </div>
      )}
    </div>
  );
};

// Promotion Countdown Badge Component
const PromotionCountdownBadge: React.FC<{ 
  startAt?: string; 
  validUntil?: string;
}> = ({ startAt, validUntil }) => {
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; mins: number; secs: number } | null>(null);
  const [status, setStatus] = useState<'upcoming' | 'live' | 'ended'>('live');

  useEffect(() => {
    const calculateTime = () => {
      const now = new Date();
      const start = startAt ? new Date(startAt) : null;
      const end = validUntil ? new Date(validUntil) : null;

      // If hasn't started yet
      if (start && now < start) {
        setStatus('upcoming');
        const diff = start.getTime() - now.getTime();
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const secs = Math.floor((diff % (1000 * 60)) / 1000);
        setTimeLeft({ days, hours, mins, secs });
        return;
      }

      // If has end time and not ended
      if (end) {
        if (now > end) {
          setStatus('ended');
          setTimeLeft(null);
          return;
        }
        setStatus('live');
        const diff = end.getTime() - now.getTime();
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const secs = Math.floor((diff % (1000 * 60)) / 1000);
        setTimeLeft({ days, hours, mins, secs });
        return;
      }

      // No timing info - still show as live without countdown
      setStatus('live');
      setTimeLeft(null);
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [startAt, validUntil]);

  // Show "Live Now" badge even without countdown if status is live and no end time
  if (!timeLeft && status === 'live' && !validUntil) {
    return (
      <Badge 
        variant="outline" 
        className="text-xs flex items-center gap-1 border-green-500 text-green-600 dark:text-green-400"
      >
        <Sparkles className="w-3 h-3" />
        Live Now
      </Badge>
    );
  }

  if (!timeLeft) return null;

  if (status === 'ended') {
    return (
      <Badge variant="secondary" className="text-xs bg-muted text-muted-foreground">
        Ended
      </Badge>
    );
  }

  const formatTimeUnit = (value: number, unit: string) => {
    if (value <= 0) return null;
    return `${value}${unit}`;
  };

  const timeString = [
    timeLeft.days > 0 ? `${timeLeft.days}d` : null,
    `${timeLeft.hours.toString().padStart(2, '0')}h`,
    `${timeLeft.mins.toString().padStart(2, '0')}m`,
    timeLeft.days === 0 ? `${timeLeft.secs.toString().padStart(2, '0')}s` : null
  ].filter(Boolean).join(' ');

  return (
    <Badge 
      variant="outline" 
      className={cn(
        "text-xs flex items-center gap-1",
        status === 'upcoming' 
          ? "border-amber-500 text-amber-600 dark:text-amber-400" 
          : "border-red-500 text-red-600 dark:text-red-400"
      )}
    >
      {status === 'upcoming' ? (
        <>
          <Clock className="w-3 h-3" />
          Starts in {timeString}
        </>
      ) : (
        <>
          <Timer className="w-3 h-3" />
          Ends in {timeString}
        </>
      )}
    </Badge>
  );
};

// Application Deadline Countdown Badge for Jobs
const DeadlineCountdownBadge: React.FC<{ deadline: string }> = ({ deadline }) => {
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; mins: number } | null>(null);

  useEffect(() => {
    const calculate = () => {
      const now = new Date();
      const end = new Date(deadline);
      const diff = end.getTime() - now.getTime();
      if (diff <= 0) {
        setTimeLeft(null);
        return;
      }
      setTimeLeft({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        mins: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
      });
    };
    calculate();
    const interval = setInterval(calculate, 60000);
    return () => clearInterval(interval);
  }, [deadline]);

  if (!timeLeft) return <Badge variant="secondary" className="text-[10px]">Deadline passed</Badge>;

  const isUrgent = timeLeft.days <= 2;
  const timeStr = timeLeft.days > 0 
    ? `${timeLeft.days}d ${timeLeft.hours}h left`
    : `${timeLeft.hours}h ${timeLeft.mins}m left`;

  return (
    <Badge 
      variant="outline" 
      className={cn(
        "text-[10px] flex items-center gap-0.5",
        isUrgent 
          ? "border-red-500 text-red-600 dark:text-red-400" 
          : "border-amber-500 text-amber-600 dark:text-amber-400"
      )}
    >
      <Timer className="w-3 h-3" />
      {timeStr}
    </Badge>
  );
};

// Helper to parse and render text with links, phone numbers, and @mentions
const RichText: React.FC<{ text: string }> = ({ text }) => {
  const parts = useMemo(() => {
    // Regex patterns for URLs, phone numbers, and @mentions
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const phoneRegex = /(\+?[\d\s\-()]{10,})/g;
    const mentionRegex = /@(\w+)/g;
    
    // Combined pattern
    const combinedRegex = /(https?:\/\/[^\s]+)|(\+?[\d\s\-()]{10,})|(@\w+)/g;
    
    const result: { type: 'text' | 'url' | 'phone' | 'mention'; content: string }[] = [];
    let lastIndex = 0;
    let match;
    
    while ((match = combinedRegex.exec(text)) !== null) {
      // Add text before match
      if (match.index > lastIndex) {
        result.push({ type: 'text', content: text.slice(lastIndex, match.index) });
      }
      
      // Determine match type
      if (match[1]) {
        result.push({ type: 'url', content: match[1] });
      } else if (match[2]) {
        result.push({ type: 'phone', content: match[2] });
      } else if (match[3]) {
        result.push({ type: 'mention', content: match[3] });
      }
      
      lastIndex = match.index + match[0].length;
    }
    
    // Add remaining text
    if (lastIndex < text.length) {
      result.push({ type: 'text', content: text.slice(lastIndex) });
    }
    
    return result;
  }, [text]);
  
  return (
    <>
      {parts.map((part, idx) => {
        switch (part.type) {
          case 'url':
            return (
              <a
                key={idx}
                href={part.content}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                className="text-primary hover:underline"
              >
                {part.content}
              </a>
            );
          case 'phone':
            return (
              <a
                key={idx}
                href={`tel:${part.content.replace(/[\s\-()]/g, '')}`}
                onClick={(e) => e.stopPropagation()}
                className="text-primary hover:underline"
              >
                {part.content}
              </a>
            );
          case 'mention':
            return (
              <span
                key={idx}
                onClick={(e) => e.stopPropagation()}
                className="text-primary hover:underline cursor-pointer"
              >
                {part.content}
              </span>
            );
          default:
            return <span key={idx}>{part.content}</span>;
        }
      })}
    </>
  );
};

// Attached Services Section Component
const AttachedServicesSection: React.FC<{ serviceIds: string[] }> = ({ serviceIds }) => {
  const navigate = useNavigate();
  const { formatPrice } = useCurrency();
  const [services, setServices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchServices = async () => {
      if (!serviceIds || serviceIds.length === 0) {
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('ads')
          .select(`
            id, title, price, images,
            seller_profiles(business_name)
          `)
          .in('id', serviceIds)
          .eq('listing_type', 'services')
          .eq('status', 'active')
          .limit(3);

        if (!error && data) {
          setServices(data);
        }
      } catch (err) {
        console.error('Failed to fetch attached services:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchServices();
  }, [serviceIds]);

  if (loading) {
    return (
      <div className="mt-3 flex items-center gap-2 text-muted-foreground text-sm">
        <Loader2 className="w-4 h-4 animate-spin" />
        <span>Loading services...</span>
      </div>
    );
  }

  if (services.length === 0) return null;

  return (
    <div className="mt-3 space-y-2">
      <div className="flex items-center gap-1.5 text-muted-foreground">
        <Wrench className="w-3.5 h-3.5" />
        <span className="text-xs font-medium">Attached Services</span>
      </div>
      <div className="space-y-2">
        {services.map((service) => (
          <div
            key={service.id}
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/service/${service.id}`);
            }}
            className="flex items-center gap-3 p-2.5 rounded-xl border border-border bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer"
          >
            {service.images?.[0] && (
              <img
                src={service.images[0]}
                alt={service.title}
                className="w-12 h-12 rounded-lg object-cover flex-shrink-0"
              />
            )}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">{service.title}</p>
              {typeof service.price === 'number' && !isNaN(service.price) && service.price > 0 && (
                <p className="text-xs text-primary font-medium">
                  From {formatPrice(service.price)}
                </p>
              )}
            </div>
            <ExternalLink className="w-4 h-4 text-muted-foreground flex-shrink-0" />
          </div>
        ))}
      </div>
    </div>
  );
};

const XStyleFeedCard: React.FC<XStyleFeedCardProps> = ({
  item,
  onLike,
  onSave,
  onShare,
  onComment,
  onSellerClick,
  onClick,
  onVideoClick
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [likeAnimating, setLikeAnimating] = useState(false);
  const [realtimeViewCount, setRealtimeViewCount] = useState(item.view_count);
  const [embedVideoUrl, setEmbedVideoUrl] = useState<string | null>(null);
  const [embedVideoType, setEmbedVideoType] = useState<'youtube' | 'tiktok'>('youtube');
  const descriptionRef = useRef<HTMLDivElement>(null);
  const [isOverflowing, setIsOverflowing] = useState(false);
  const interestedBtnRef = useRef<HTMLButtonElement>(null);
  
  const { user } = useAuth();
  const { trackClick, trackView } = useEngagement();
  const { isInterested, count: interestedCount, toggleInterested, isLoading: interestedLoading } = useInterested(
    item.id,
    item.content_type,
    { initialCount: (item as any).like_count, initialInterested: (item as any).is_interested }
  );
  const { isFollowing, toggleFollow, isLoading: followLoading } = useFollow(item.seller.user_id);
  const { formatPrice, currency } = useCurrency();
  const { isDataSaverActive } = useGlobalSettingsSafe();
  
  // View tracking - fires after 4 seconds in viewport (silent readers count too)
  const viewRef = useViewTracking({
    contentId: item.id,
    contentType: item.content_type,
    sourcePage: 'feed',
    threshold: 0.5,
    viewDuration: 4000,
  });

  // Helper: trigger a view on interaction (only one per session)
  const triggerInteractionView = useCallback(() => {
    const viewKey = `interaction-${item.content_type}-${item.id}`;
    if (!sessionStorage.getItem(viewKey)) {
      sessionStorage.setItem(viewKey, '1');
      trackView(item.id, item.content_type, 'feed', 1);
    }
  }, [item.id, item.content_type, trackView]);

  // Real-time subscription for view count and engagements
  useEffect(() => {
    setRealtimeViewCount(item.view_count);
    
    // Subscribe to content_views changes for this item
    const channel = supabase
      .channel(`feed-card-${item.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'content_views',
          filter: `content_id=eq.${item.id}`
        },
        () => {
          setRealtimeViewCount(prev => prev + 1);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [item.id, item.view_count]);

  // Check description overflow for line-clamp
  useEffect(() => {
    if (descriptionRef.current) {
      setIsOverflowing(descriptionRef.current.scrollHeight > descriptionRef.current.clientHeight);
    }
  }, [item.description]);

  // Helper to detect video URLs in images array
  const isVideoUrl = (url: string) => url?.match(/\.(mp4|webm|mov|avi)$/i) || url?.includes('.mp4') || url?.includes('.webm');

  const playPopSound = () => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.setValueAtTime(600, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.15);
    } catch {}
  };

  const handleLikeClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!user) {
      onLike(item.id);
      return;
    }
    
    triggerInteractionView();
    setLikeAnimating(true);
    
    // Confetti burst from button position
    if (interestedBtnRef.current && !isInterested) {
      const rect = interestedBtnRef.current.getBoundingClientRect();
      const x = (rect.left + rect.width / 2) / window.innerWidth;
      const y = (rect.top + rect.height / 2) / window.innerHeight;
      confetti({
        particleCount: 30,
        spread: 60,
        startVelocity: 15,
        gravity: 0.8,
        ticks: 40,
        origin: { x, y },
        colors: ['hsl(var(--primary))', '#FFD700', '#FF6B6B', '#4ECDC4'],
        scalar: 0.6,
      });
      playPopSound();
    }
    
    try {
      await toggleInterested();
    } catch (err: any) {
      // surface failure so users aren't confused by a silent no-op
      const { toast } = await import('sonner');
      toast.error(err?.message || 'Could not update interest');
    }
    setTimeout(() => setLikeAnimating(false), 300);
  };

  const handleFollowClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFollow();
  };
  
  const handleItemClick = () => {
    trackClick(item.id, item.content_type, 'item', 'feed');
    onClick();
  };
  
  const handleReadMoreClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    trackClick(item.id, item.content_type, 'read_more', 'feed');
    setIsExpanded(!isExpanded);
  };
  
  const handleSellerClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    trackClick(item.id, item.content_type, 'seller', 'feed');
    onSellerClick();
  };
  
  const handleImageClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    trackClick(item.id, item.content_type, 'image', 'feed');
    onClick();
  };
  const formatCount = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count > 0 ? count.toString() : '';
  };

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds}s`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const formatEventDate = (dateString?: string) => {
    if (!dateString) return 'Date TBD';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
  };

  const imageCount = item.images?.length || 0;
  
  const displayedText = item.description;

  return (
    <article 
      ref={viewRef}
      className="hover:bg-muted/30 transition-colors cursor-pointer"
      onClick={handleItemClick}
    >
      <div className="flex gap-2 sm:gap-3 px-[2px] sm:px-4 pt-3 pb-1">
        {/* Avatar */}
        <div className="flex-shrink-0">
          <Avatar
            className="w-10 h-10 cursor-pointer hover:opacity-90 transition-opacity"
            onClick={handleSellerClick}
          >
            <AvatarImage src={item.seller.business_logo_url} />
            <AvatarFallback className="bg-primary/10 text-primary font-semibold">
              {item.seller.business_name.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-center gap-1 flex-wrap">
            <span
              className="font-semibold text-[14px] text-foreground hover:underline cursor-pointer truncate"
              onClick={handleSellerClick}
            >
              {item.seller.business_name}
            </span>
            <UnifiedVerifiedBadge 
              isVerified={item.seller.is_verified} 
              badgeColor={item.seller.verification_badge_color}
              size="md" 
            />
            {/* Sponsored label */}
            {item.is_sponsored && (
              <span className="text-[10px] px-1.5 py-0.5 rounded-full font-medium bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">
                Sponsored
              </span>
            )}
            {/* Listing type label */}
            {item.content_type === 'ad' && item.listing_type && item.listing_type !== 'physical_products' && (
              <span className={cn(
                "text-[10px] px-1.5 py-0.5 rounded-full font-medium",
                item.listing_type === 'services' && "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
                item.listing_type === 'jobs' && "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
                item.listing_type === 'promotions' && "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400",
                item.listing_type === 'digital_products' && "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400"
              )}>
                {item.listing_type === 'services' ? 'Service' : 
                 item.listing_type === 'jobs' ? 'Job' :
                 item.listing_type === 'promotions' ? 'Promo' :
                 item.listing_type === 'digital_products' ? 'Digital' : ''}
              </span>
            )}
            {/* Service status badge for service providers */}
            {item.content_type === 'ad' && item.listing_type === 'services' && item.seller.current_service_status && (
              <ServiceStatusBadge status={item.seller.current_service_status} size="sm" />
            )}
            {/* Multiple Roles badge for bulk hiring jobs */}
            {item.content_type === 'ad' && item.listing_type === 'jobs' && item.job_details?.job_posting_type === 'multiple' && (
              <span className="text-[10px] px-1.5 py-0.5 rounded-full font-medium bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 flex items-center gap-0.5">
                <Users className="w-3 h-3" />
                Multiple Roles
              </span>
            )}
            {item.content_type === 'event' && (
              <span className="text-[10px] px-1.5 py-0.5 rounded-full font-medium bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400">
                Event
              </span>
            )}
            {item.content_type === 'post' && (
              <span className="text-[10px] px-1.5 py-0.5 rounded-full font-medium bg-gray-100 text-gray-700 dark:bg-gray-800/50 dark:text-gray-400">
                Update
              </span>
            )}
            <div className="ml-auto flex items-center gap-1 relative z-10">
              {/* Follow button - near the menu, only show if not the current user's post */}
              {user?.id !== item.seller.user_id && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleFollowClick}
                  disabled={followLoading}
                  className={cn(
                    "h-6 px-2 text-[11px] font-semibold rounded-full transition-all",
                    isFollowing 
                      ? "text-muted-foreground hover:text-destructive hover:bg-destructive/10" 
                      : "text-primary hover:bg-primary/10"
                  )}
                >
                  {followLoading ? '...' : isFollowing ? 'Following' : 'Follow'}
                </Button>
              )}
              <FeedCardMenu
                itemId={item.id}
                itemType={item.content_type}
                sellerId={item.seller.id}
                sellerUserId={item.seller.user_id}
                sellerName={item.seller.business_name}
                onSave={() => onSave(item.id)}
                isSaved={item.is_saved}
                isFollowing={isFollowing}
                onUnfollow={toggleFollow}
              />
            </div>
          </div>

          {/* Post content */}
          <div className="mt-0.5">
            {/* Title for ads/events */}
            {item.content_type !== 'post' && item.title && (
              <h3 className="text-[14px] font-semibold text-foreground mb-0.5">
                {item.title}
              </h3>
            )}
            
            {/* Description/Content with 3-line clamp */}
            {item.description && (
              <div className="text-[14px] text-foreground leading-[18px]">
                <div
                  ref={descriptionRef}
                  className={cn(
                    "whitespace-pre-wrap break-words",
                    !isExpanded && "line-clamp-3"
                  )}
                >
                  <RichText text={displayedText} />
                </div>
                {(isOverflowing || isExpanded) && (
                  <button
                    onClick={handleReadMoreClick}
                    className="inline-flex items-center gap-0.5 text-primary hover:text-primary/80 text-[13px] font-medium mt-1 transition-colors"
                  >
                    {isExpanded ? (
                      <>
                        Show less <ChevronUp className="w-3.5 h-3.5" />
                      </>
                    ) : (
                      <>
                        Show more <ChevronDown className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                )}
              </div>
            )}

            {/* Event specific info */}
            {item.content_type === 'event' && item.event_details && (
              <div className="mt-3 p-3 border border-border rounded-2xl bg-muted/20">
                <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
                  <Calendar className="w-4 h-4" />
                  <span>{formatEventDate(item.event_details.event_date)}</span>
                </div>
                {item.event_details.venue_name && (
                  <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
                    <MapPin className="w-4 h-4" />
                    <span>{item.event_details.venue_name}</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-sm">
                  <Ticket className="w-4 h-4 text-primary" />
                  {item.event_details.is_free ? (
                    <span className="text-green-500 font-medium">Free Entry</span>
                  ) : (
                    <span className="text-primary font-medium">
                      {formatPrice(item.event_details.ticket_price || 0)}
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Job specific info */}
            {item.content_type === 'ad' && item.listing_type === 'jobs' && item.job_details && (
              <div className="mt-3 p-3 border border-border rounded-2xl bg-muted/20">
                {/* Application deadline countdown */}
                {item.job_details.application_deadline && (
                  <div className="flex items-center justify-between mb-2">
                    <DeadlineCountdownBadge deadline={item.job_details.application_deadline} />
                  </div>
                )}
                
                {/* Single position job - show salary with currency conversion */}
                {item.job_details.job_posting_type !== 'multiple' && (
                  <div className="flex items-center gap-2 text-sm mb-2">
                    <DollarSign className="w-4 h-4 text-primary" />
                    {item.job_details.salary_min && item.job_details.salary_max ? (
                      <span className="text-primary font-medium">
                        {(() => {
                          const salCurrency = item.job_details?.salary_currency || 'UGX';
                          // If salary is in UGX, convert using user's currency setting
                          if (salCurrency === 'UGX') {
                            return `${formatPrice(item.job_details!.salary_min!)} - ${formatPrice(item.job_details!.salary_max!)}`;
                          }
                          // If salary is in another currency, show as-is
                          return `${salCurrency} ${item.job_details!.salary_min!.toLocaleString()} - ${item.job_details!.salary_max!.toLocaleString()}`;
                        })()}
                      </span>
                    ) : (
                      <span className="text-muted-foreground">Salary: Negotiable</span>
                    )}
                  </div>
                )}
                
                {/* Multi-position display - X.com style bullet list */}
                {item.job_details.job_posting_type === 'multiple' && item.job_details.positions && item.job_details.positions.length > 0 && (
                  <div className="mb-3">
                    <div className="flex items-center gap-1.5 mb-2">
                      <Users className="w-4 h-4 text-amber-500" />
                      <span className="text-[13px] font-semibold text-foreground">
                        Hiring {item.job_details.positions.reduce((sum, p) => sum + (p.quantity || 1), 0)} people for {item.job_details.positions.length} roles
                      </span>
                    </div>
                    <ul className="space-y-1.5 pl-1">
                      {item.job_details.positions.slice(0, 5).map((position, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <span className="text-[13px] text-foreground font-medium">
                              {position.role}
                            </span>
                            {position.quantity && position.quantity > 1 && (
                              <span className="text-[11px] text-muted-foreground ml-1">
                                ({position.quantity} openings)
                              </span>
                            )}
                            <div className="flex flex-wrap items-center gap-1.5 mt-0.5">
                              {position.job_type && (
                                <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                                  {position.job_type}
                                </span>
                              )}
                              {position.salary_negotiable ? (
                                <span className="text-[10px] text-muted-foreground">Negotiable</span>
                              ) : position.salary_min ? (
                                <span className="text-[10px] text-primary font-medium">
                                  {(() => {
                                    const salCurrency = item.job_details?.salary_currency || 'UGX';
                                    if (salCurrency === 'UGX') {
                                      return `${formatPrice(position.salary_min!)}${position.salary_max ? ` - ${formatPrice(position.salary_max)}` : ''}`;
                                    }
                                    return `${salCurrency} ${position.salary_min?.toLocaleString()}${position.salary_max ? ` - ${position.salary_max.toLocaleString()}` : ''}`;
                                  })()}
                                </span>
                              ) : null}
                            </div>
                          </div>
                        </li>
                      ))}
                      {item.job_details.positions.length > 5 && (
                        <li className="text-[12px] text-primary font-medium pl-3.5">
                          +{item.job_details.positions.length - 5} more roles
                        </li>
                      )}
                    </ul>
                  </div>
                )}
                
                <div className="flex flex-wrap gap-2">
                  {item.job_details.job_type && item.job_details.job_posting_type !== 'multiple' && (
                    <span className="text-[11px] px-2 py-1 rounded-full bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                      {item.job_details.job_type}
                    </span>
                  )}
                  {item.job_details.work_location && (
                    <span className="text-[11px] px-2 py-1 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400">
                      {item.job_details.work_location}
                    </span>
                  )}
                  {item.job_details.number_of_positions && item.job_details.number_of_positions > 1 && item.job_details.job_posting_type !== 'multiple' && (
                    <span className="text-[11px] px-2 py-1 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">
                      {item.job_details.number_of_positions} positions
                    </span>
                  )}
                  {item.job_details.apply_method && item.job_details.apply_method !== 'earlymarket' && (
                    <span className="text-[11px] px-2 py-1 rounded-full bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400">
                      {item.job_details.apply_method === 'phone' ? '📞 Call to Apply' : 
                       item.job_details.apply_method === 'email' ? '✉️ Email to Apply' : 
                       item.job_details.apply_method === 'website' ? '🌐 External Site' : ''}
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Price display - Highlighted */}
            {item.content_type === 'ad' && typeof item.price === 'number' && !isNaN(item.price) && item.price > 0 && item.listing_type !== 'jobs' && item.listing_type !== 'promotions' && (
              <div className="mt-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-xl font-extrabold text-primary bg-primary/10 px-2.5 py-1 rounded-lg inline-block">
                    {item.listing_type === 'services' && item.service_details?.accommodation_type && item.service_details?.price_period ? (
                      <>
                        {formatPrice(item.service_details?.starting_price || item.price)}
                        <span className="text-sm font-normal text-muted-foreground">/{item.service_details.price_period.replace('Per ', '').toLowerCase()}</span>
                      </>
                    ) : item.listing_type === 'services' && item.service_details?.pricing_type ? (
                      <>
                        {item.service_details.pricing_type === 'Custom Quote' ? 'Contact for Price' :
                         item.service_details.pricing_type === 'Free Consultation' ? 'Free Consultation' :
                         <>
                           {item.service_details.pricing_type === 'Per Project' ? 'From ' : ''}
                           {formatPrice(item.service_details?.starting_price || item.price)}
                           {item.service_details.pricing_type === 'Hourly Rate' ? '/hr' :
                            item.service_details.pricing_type === 'Per Session' ? '/session' :
                            item.service_details.pricing_type === 'Daily Rate' ? '/day' : ''}
                         </>
                        }
                      </>
                    ) : formatPrice(item.price)}
                  </p>
                  {/* Discount: strikethrough original price + badge */}
                  {item.has_discount && item.original_price && item.original_price > item.price && (
                    <>
                      <span className="text-sm text-muted-foreground line-through">
                        {formatPrice(item.original_price)}
                      </span>
                      <Badge className="bg-red-500 text-white text-[10px] px-1.5 py-0.5">
                        -{Math.round(((item.original_price - item.price) / item.original_price) * 100)}% OFF
                      </Badge>
                    </>
                  )}
                </div>
                {item.has_discount && item.original_price && item.original_price > item.price && (
                  <p className="text-[11px] text-green-600 dark:text-green-400 font-medium mt-0.5">
                    🏷️ This product has a discount
                  </p>
                )}
              </div>
            )}

            {/* Accommodation amenity chips */}
            {item.content_type === 'ad' && item.listing_type === 'services' && item.service_details?.amenities && item.service_details.amenities.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                {item.service_details.amenities.slice(0, 3).map(amenity => (
                  <span key={amenity} className="text-[10px] px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                    {amenity}
                  </span>
                ))}
                {item.service_details.amenities.length > 3 && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                    +{item.service_details.amenities.length - 3} more
                  </span>
                )}
              </div>
            )}

            {/* Promotion discount badge and info */}
            {item.content_type === 'ad' && item.listing_type === 'promotions' && (
              <div className="mt-2 flex flex-wrap items-center gap-2">
                {/* Check if promotion is expired */}
                {item.promotion_details?.valid_until && new Date(item.promotion_details.valid_until) < new Date() ? (
                  <Badge className="bg-muted text-muted-foreground text-sm px-3 py-1 font-bold">
                    <Clock className="w-3.5 h-3.5 mr-1" />
                    EXPIRED
                  </Badge>
                ) : (
                  <>
                    {item.promotion_details?.discount_percentage && item.promotion_details.discount_percentage > 0 ? (
                      <Badge className="bg-red-500 text-white text-sm px-3 py-1 font-bold">
                        <Percent className="w-3.5 h-3.5 mr-1" />
                        {item.promotion_details.discount_percentage}% OFF
                      </Badge>
                    ) : (
                      <Badge className="bg-gradient-to-r from-red-500 to-orange-500 text-white text-sm px-3 py-1 font-bold">
                        <Tag className="w-3.5 h-3.5 mr-1" />
                        Special Offer
                      </Badge>
                    )}
                    {item.promotion_details?.is_seller_wide && (
                      <Badge variant="secondary" className="text-xs">
                        Store-wide Sale
                      </Badge>
                    )}
                    {item.promotion_details?.promotion_type && item.promotion_details.promotion_type !== 'standard' && (
                      <Badge variant="outline" className="text-xs capitalize">
                        {item.promotion_details.promotion_type.replace('_', ' ')}
                      </Badge>
                    )}
                    {/* Countdown Timer */}
                    {item.promotion_details && (
                      <PromotionCountdownBadge 
                        startAt={item.promotion_details.start_at} 
                        validUntil={item.promotion_details.valid_until} 
                      />
                    )}
                  </>
                )}
              </div>
            )}

            {/* Combined media grid — images + inline b2 video */}
            {(() => {
              if (item.content_type === 'ad' && item.listing_type === 'promotions') return null;
              const imgs = (item.images || []).filter(Boolean);
              const hasB2Video = !!item.b2_video_url;
              type MediaItem =
                | { kind: 'image'; url: string; w?: number; h?: number }
                | { kind: 'video'; url: string; poster?: string | null; w?: number; h?: number };
              const mediaItems: MediaItem[] = [];
              if (hasB2Video) {
                mediaItems.push({
                  kind: 'video',
                  url: videoCdnUrl(item.b2_video_url!) || item.b2_video_url!,
                  poster: item.video_thumbnail_url || videoPlaceholder,
                  w: item.video_width || undefined,
                  h: item.video_height || undefined,
                });
              }
              imgs.forEach((img, idx) => {
                mediaItems.push({
                  kind: isVideoUrl(img) ? 'video' : 'image',
                  url: img,
                  poster: isVideoUrl(img) ? videoPlaceholder : undefined,
                  w: item.media_dimensions?.[idx]?.w,
                  h: item.media_dimensions?.[idx]?.h,
                } as MediaItem);
              });
              const total = mediaItems.length;
              if (total === 0) return null;

              // When Data Saver is active, only load the first image/video to avoid multi-file downloads
              const effectiveMediaItems = isDataSaverActive ? mediaItems.slice(0, 1) : mediaItems;
              const displayTotal = effectiveMediaItems.length;

              // Twitter-style layouts with adaptive aspect ratios
              const gridClass =
                displayTotal === 1
                  ? ''
                  : displayTotal === 2
                    ? 'grid grid-cols-2 gap-[2px]'
                    : displayTotal === 3
                      ? 'grid grid-cols-2 grid-rows-2 gap-[2px] aspect-[4/3]'
                      : 'grid grid-cols-2 grid-rows-2 gap-[2px] aspect-square';

              const cellAspect = (idx: number) => {
                if (displayTotal === 2) return 'aspect-[4/5] sm:aspect-square';
                return ''; // 3 & 4 fill row/col via parent aspect
              };
              const cellSpan = (idx: number) => {
                if (displayTotal === 3 && idx === 0) return 'row-span-2';
                return '';
              };

              const visible = effectiveMediaItems.slice(0, 4);

              return (
                <div className={cn('mt-2 rounded-xl sm:rounded-2xl overflow-hidden border border-border relative', gridClass)}>
                  {displayTotal === 1 ? (
                    <div className="relative">
                      {visible[0].kind === 'video' ? (
                        <AdaptiveMedia
                          url={visible[0].url}
                          type="video"
                          context="feed"
                          poster={visible[0].poster || videoPlaceholder}
                          originalWidth={visible[0].w}
                          originalHeight={visible[0].h}
                          onClick={(e) => { e.stopPropagation(); onVideoClick?.(visible[0].url); }}
                        />
                      ) : (
                        <AdaptiveMedia
                          url={visible[0].url}
                          type="image"
                          context="feed"
                          alt={item.title || 'Image'}
                          originalWidth={visible[0].w}
                          originalHeight={visible[0].h}
                        />
                      )}
                      {isDataSaverActive && total > 1 && (
                        <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-sm text-white text-[11px] font-medium border border-white/20 pointer-events-none">
                          +{total - 1} more
                        </div>
                      )}
                    </div>
                  ) : (
                    visible.map((m, idx) => (
                      <div key={idx} className={cn('relative overflow-hidden bg-muted', cellAspect(idx), cellSpan(idx))}>
                        <AdaptiveMedia
                          url={m.url}
                          type={m.kind}
                          context={m.kind === 'video' ? 'feed' : 'thumbnail'}
                          fill
                          poster={m.kind === 'video' ? (m.poster || videoPlaceholder) : undefined}
                          alt={`Media ${idx + 1}`}
                          originalWidth={m.w}
                          originalHeight={m.h}
                          onClick={m.kind === 'video' ? (e) => { e.stopPropagation(); onVideoClick?.(m.url); } : undefined}
                        />
                        {m.kind === 'video' && (
                          <div className="absolute top-2 right-2 pointer-events-none">
                            <div className="bg-black/60 rounded-full p-1.5"><Play className="w-3 h-3 text-white fill-white" /></div>
                          </div>
                        )}
                        {idx === 3 && total > 4 && (
                          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                            <span className="text-white text-2xl font-bold">+{total - 4}</span>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              );
            })()}

            {/* External video links (YouTube / TikTok) + website */}
            {(item.youtube_url || item.tiktok_url || item.website_url) && (
              <div className="mt-2 space-y-2">

                
                {/* YouTube and TikTok links - open in-app modal */}
                {(item.youtube_url || item.tiktok_url) && (
                  <div className="flex flex-col gap-2">
                    {item.youtube_url && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setEmbedVideoUrl(item.youtube_url!);
                          setEmbedVideoType('youtube');
                        }}
                        className="flex items-center gap-3 p-3 rounded-2xl border border-border bg-muted/50 hover:bg-muted transition-colors text-left"
                      >
                        <div className="w-10 h-10 rounded-full bg-red-600 flex items-center justify-center flex-shrink-0">
                          <YouTubeIcon className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[13px] font-medium text-foreground truncate">Watch on YouTube</p>
                          <p className="text-[11px] text-muted-foreground truncate">{item.youtube_url}</p>
                        </div>
                        <Play className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      </button>
                    )}
                    {item.tiktok_url && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setEmbedVideoUrl(item.tiktok_url!);
                          setEmbedVideoType('tiktok');
                        }}
                        className="flex items-center gap-3 p-3 rounded-2xl border border-border bg-muted/50 hover:bg-muted transition-colors text-left"
                      >
                        <div className="w-10 h-10 rounded-full bg-foreground flex items-center justify-center flex-shrink-0">
                          <TikTokIcon className="w-5 h-5 text-background" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[13px] font-medium text-foreground truncate">Watch on TikTok</p>
                          <p className="text-[11px] text-muted-foreground truncate">{item.tiktok_url}</p>
                        </div>
                        <Play className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      </button>
                    )}
                  </div>
                )}

                {/* Website Link */}
                {item.website_url && (
                  <a
                    href={item.website_url.startsWith('http') ? item.website_url : `https://${item.website_url}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="flex items-center gap-3 p-3 rounded-2xl border border-border bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                      <Globe className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[13px] font-medium text-foreground truncate">Visit Website</p>
                      <p className="text-[11px] text-muted-foreground truncate">{item.website_url}</p>
                    </div>
                    <ExternalLink className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  </a>
                )}
              </div>
            )}

            {/* Promotion Products Carousel - show discounted products for promotions */}
            {item.content_type === 'ad' && item.listing_type === 'promotions' && (
              <PromotionProductsCarousel
                adId={item.id}
                discountPercent={item.promotion_details?.discount_percentage || 0}
                sellerId={item.seller.id}
                isSellerWide={item.promotion_details?.is_seller_wide || false}
                maxItems={6}
                promotionImages={item.images || []}
                promotionTitle={item.title}
              />
            )}

            {/* Attached Services - for posts - styled like multi-position jobs */}
            {item.content_type === 'post' && item.attached_services && item.attached_services.length > 0 && (
              <div className="mt-3 p-3 border border-border rounded-2xl bg-muted/20">
                <AttachedServicesSection serviceIds={item.attached_services} />
              </div>
            )}

            {/* Attached Products carousel - for posts */}
            {item.content_type === 'post' && item.attached_products && item.attached_products.length > 0 && (
              <AttachedProductsCarousel productIds={item.attached_products} />
            )}
            
            {/* External links section for posts - styled like multi-position jobs */}
            {item.content_type === 'post' && (item.youtube_url || item.tiktok_url || item.website_url) && !item.b2_video_url && (
              <div className="mt-3 p-3 border border-border rounded-2xl bg-muted/20">
                <div className="flex items-center gap-1.5 mb-2">
                  <ExternalLink className="w-4 h-4 text-primary" />
                  <span className="text-[13px] font-semibold text-foreground">
                    Related Links
                  </span>
                </div>
                <ul className="space-y-1.5 pl-1">
                  {item.youtube_url && (
                    <li className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 flex-shrink-0" />
                      <a
                        href={item.youtube_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="text-[13px] text-primary hover:underline flex items-center gap-1"
                      >
                        Watch on YouTube
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </li>
                  )}
                  {item.tiktok_url && (
                    <li className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-foreground mt-1.5 flex-shrink-0" />
                      <a
                        href={item.tiktok_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="text-[13px] text-primary hover:underline flex items-center gap-1"
                      >
                        Watch on TikTok
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </li>
                  )}
                  {item.website_url && (
                    <li className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 flex-shrink-0" />
                      <a
                        href={item.website_url.startsWith('http') ? item.website_url : `https://${item.website_url}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="text-[13px] text-primary hover:underline flex items-center gap-1 truncate"
                      >
                        {item.website_url.replace(/^https?:\/\//, '').slice(0, 30)}
                        <ExternalLink className="w-3 h-3 flex-shrink-0" />
                      </a>
                    </li>
                  )}
                </ul>
              </div>
            )}
          </div>
          {/* Action buttons - X.com style with proper alignment */}
          <div className="relative z-30 flex items-center justify-between mt-2 mb-1.5 -ml-[46px] sm:-ml-2 pr-1 md:w-full md:max-w-none">
            {/* Comment */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                triggerInteractionView();
                onComment();
              }}
              className="flex items-center gap-0.5 group"
            >
              <div className="p-1.5 rounded-full group-hover:bg-primary/10 transition-colors">
                <MessageCircle className="w-4 h-4 text-muted-foreground group-hover:text-primary" />
              </div>
              
            </button>

            {/* Like/Interested - Thumbs up with confetti + sound */}
            <button
              ref={interestedBtnRef}
              onClick={handleLikeClick}
              disabled={interestedLoading}
              className="flex items-center gap-0.5 group"
              title="Like"
            >
              <motion.div 
                className="p-1.5 rounded-full group-hover:bg-primary/10 transition-colors"
                animate={likeAnimating ? { rotate: [0, -15, 15, -10, 10, 0], scale: [1, 1.2, 1] } : {}}
                transition={{ duration: 0.3 }}
              >
                <ThumbsUp className={cn(
                  "w-4 h-4 transition-colors",
                  isInterested ? "text-primary fill-primary" : "text-muted-foreground group-hover:text-primary"
                )} />
              </motion.div>
              {formatThresholdCount(interestedCount) && (
                <span className="text-[12px] text-muted-foreground group-hover:text-primary">
                  {formatThresholdCount(interestedCount)}
                </span>
              )}
            </button>

            {/* Apply button for jobs */}
            {item.content_type === 'ad' && item.listing_type === 'jobs' && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onClick();
                }}
                className="flex items-center gap-0.5 group"
                title="Apply"
              >
                <div className="p-1.5 rounded-full group-hover:bg-green-500/10 transition-colors">
                  <Briefcase className="w-4 h-4 text-muted-foreground group-hover:text-green-500" />
                </div>
                <span className="text-[12px] text-muted-foreground group-hover:text-green-500">
                  Apply
                </span>
              </button>
            )}

            {/* Book Now button for accommodation services */}
            {item.content_type === 'ad' && item.listing_type === 'services' && item.service_details?.accommodation_type && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (item.service_details?.booking_method === 'phone' && item.service_details?.booking_phone) {
                    window.open(`tel:${item.service_details.booking_phone}`, '_self');
                  } else if (item.service_details?.booking_method === 'website' && item.service_details?.booking_url) {
                    const url = item.service_details.booking_url.startsWith('http') ? item.service_details.booking_url : `https://${item.service_details.booking_url}`;
                    window.open(url, '_blank');
                  } else {
                    onClick();
                  }
                }}
                className="flex items-center gap-0.5 group"
                title="Book Now"
              >
                <div className="p-1.5 rounded-full group-hover:bg-blue-500/10 transition-colors">
                  <Home className="w-4 h-4 text-muted-foreground group-hover:text-blue-500" />
                </div>
                <span className="text-[12px] text-muted-foreground group-hover:text-blue-500">
                  Book Now
                </span>
              </button>
            )}

            {/* Views - threshold display */}
            {formatThresholdCount(realtimeViewCount) && (
              <button
                onClick={(e) => e.stopPropagation()}
                className="flex items-center gap-0.5 group"
              >
                <div className="p-1.5 rounded-full group-hover:bg-primary/10 transition-colors">
                  <BarChart3 className="w-4 h-4 text-muted-foreground group-hover:text-primary" />
                </div>
                <span className="text-[12px] text-muted-foreground group-hover:text-primary">
                  {formatThresholdCount(realtimeViewCount)} views
                </span>
              </button>
            )}

            {/* Bookmark & Share */}
            <div className="relative z-30 flex items-center">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  triggerInteractionView();
                  onSave(item.id);
                }}
                onPointerDown={(e) => e.stopPropagation()}
                aria-label="Bookmark"
                className="relative z-30 inline-flex items-center justify-center min-h-[44px] min-w-[44px] sm:h-9 sm:w-9 sm:min-h-0 sm:min-w-0 rounded-full hover:bg-primary/10 transition-colors touch-manipulation"
              >
                <Bookmark className={cn(
                  "w-4 h-4 transition-colors pointer-events-none",
                  item.is_saved ? "text-primary fill-primary" : "text-muted-foreground hover:text-primary"
                )} />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  triggerInteractionView();
                  onShare();
                }}
                onPointerDown={(e) => e.stopPropagation()}
                aria-label="Share"
                className="relative z-30 inline-flex items-center justify-center min-h-[44px] min-w-[44px] sm:h-9 sm:w-9 sm:min-h-0 sm:min-w-0 rounded-full hover:bg-primary/10 transition-colors touch-manipulation"
              >
                <Share2 className="w-4 h-4 text-muted-foreground hover:text-primary pointer-events-none" />
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Embed Video Modal */}
      {embedVideoUrl && (
        <EmbedVideoModal
          open={!!embedVideoUrl}
          onOpenChange={(open) => { if (!open) setEmbedVideoUrl(null); }}
          url={embedVideoUrl}
          type={embedVideoType}
        />
      )}
    </article>
  );
};

export default React.memo(XStyleFeedCard, (prev, next) =>
  prev.item?.id === next.item?.id &&
  prev.item?.is_liked === next.item?.is_liked &&
  prev.item?.is_saved === next.item?.is_saved &&
  prev.item?.like_count === next.item?.like_count &&
  prev.item?.comment_count === next.item?.comment_count &&
  prev.item?.view_count === next.item?.view_count
);

