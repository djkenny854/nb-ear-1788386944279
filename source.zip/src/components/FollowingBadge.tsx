import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { Badge } from '@/components/ui/badge';
import { UserCheck } from 'lucide-react';

interface FollowingBadgeProps {
  targetUserId: string;
  className?: string;
}

/**
 * Shows a "Following" badge if the current user follows the target user
 */
const FollowingBadge: React.FC<FollowingBadgeProps> = ({ targetUserId, className }) => {
  const { user } = useAuth();

  const { data: isFollowing } = useQuery({
    queryKey: ['is-following', user?.id, targetUserId],
    queryFn: async () => {
      if (!user?.id || !targetUserId || user.id === targetUserId) return false;
      
      const { data, error } = await supabase
        .from('follows')
        .select('id')
        .eq('follower_id', user.id)
        .eq('following_id', targetUserId)
        .maybeSingle();

      return !error && !!data;
    },
    enabled: !!user?.id && !!targetUserId && user?.id !== targetUserId,
    staleTime: 30000, // 30 seconds cache
  });

  if (!isFollowing) return null;

  return (
    <Badge 
      variant="secondary" 
      className={`bg-primary/10 text-primary border-0 text-xs gap-1 ${className || ''}`}
    >
      <UserCheck className="w-3 h-3" />
      Following
    </Badge>
  );
};

export default FollowingBadge;