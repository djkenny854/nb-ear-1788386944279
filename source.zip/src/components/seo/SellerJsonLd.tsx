import React from 'react';
import { Helmet } from 'react-helmet-async';

interface SellerJsonLdProps {
  seller: {
    id: string;
    business_name: string;
    description?: string;
    logo_url?: string;
    cover_image?: string;
    location?: string;
    district?: string;
    phone?: string;
    email?: string;
    website?: string;
    is_verified?: boolean;
    verification_badge_color?: string;
    rating?: number;
    review_count?: number;
    store_slug?: string;
    created_at?: string;
    working_hours?: Record<string, { open: string; close: string; closed?: boolean }>;
    social_links?: {
      facebook?: string;
      instagram?: string;
      twitter?: string;
      tiktok?: string;
      whatsapp?: string;
    };
    follower_count?: number;
    business_category?: string;
  };
  products?: Array<{
    id: string;
    title: string;
    price?: number;
    currency?: string;
    images?: string[];
    description?: string;
  }>;
}

const SellerJsonLd: React.FC<SellerJsonLdProps> = ({ seller, products }) => {
  const siteUrl = 'https://earlymarketug.com';
  
  // Generate SEO-friendly slug from business name if no store_slug
  const generateSlug = (name: string) => 
    name?.toLowerCase().trim().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
  
  const sellerSlug = seller.store_slug || generateSlug(seller.business_name);
  const sellerUrl = sellerSlug 
    ? `${siteUrl}/business/${sellerSlug}`
    : `${siteUrl}/seller/${seller.id}`;

  // Clean bio text by removing raw sparkle/fairy emojis and trimming excess whitespace
  const rawBio = seller.description || '';
  const cleanBio = rawBio
    .replace(/[✨🧚]/gu, '')
    .replace(/\s+/g, ' ')
    .trim();

  const locationText = seller.location || seller.district || 'Kampala, Uganda';
  const categoryText = seller.business_category || 'Business';

  // Build high-visibility Meta Description prioritizing the business's actual bio
  let metaDescription = '';
  if (cleanBio) {
    metaDescription = `${seller.business_name}${seller.is_verified ? ' ✓' : ''}: ${cleanBio}`;
    if (metaDescription.length > 155) {
      metaDescription = metaDescription.slice(0, 152).trim() + '...';
    }
  } else {
    metaDescription = `${seller.business_name}${seller.is_verified ? ' ✓' : ''} - Official profile on Earlymarket Uganda. Explore ${categoryText}, products, services, contact details, and location in ${locationText}.`;
  }

  // Build page title with Twitter/X style format: "Business Name (@slug) / Earlymarket"
  const handlePart = sellerSlug ? ` (@${sellerSlug})` : '';
  const pageTitle = `${seller.business_name}${handlePart}${seller.is_verified ? ' ✓' : ''} / Earlymarket`;

  // OG Image - prefer cover image, then logo
  const ogImage = seller.cover_image || seller.logo_url || `${siteUrl}/logo.png`;

  // Schema.org WebSite entity for Google Site Name resolution
  const websiteSchema = {
    "@type": "WebSite",
    "@id": `${siteUrl}/#website`,
    "url": `${siteUrl}/`,
    "name": "Earlymarket",
    "alternateName": ["Earlymarket Uganda", "EarlymarketUG"]
  };

  // Schema.org ProfilePage entity for social/business profile rich snippets with follower statistics
  const profilePageSchema: Record<string, any> = {
    "@type": "ProfilePage",
    "@id": `${sellerUrl}#profilepage`,
    "url": sellerUrl,
    "name": pageTitle,
    "isPartOf": {
      "@id": `${siteUrl}/#website`
    },
    "mainEntity": {
      "@id": `${sellerUrl}#business`
    }
  };

  if (seller.follower_count && seller.follower_count > 0) {
    profilePageSchema.interactionStatistic = [
      {
        "@type": "InteractionCounter",
        "interactionType": "https://schema.org/FollowAction",
        "userInteractionCount": seller.follower_count
      }
    ];
  }

  // Build LocalBusiness / Store entity schema with enhanced data
  const localBusinessSchema: Record<string, any> = {
    "@type": ["Store", "LocalBusiness", "Organization"],
    "@id": `${sellerUrl}#business`,
    "name": seller.business_name,
    "url": sellerUrl,
    "description": cleanBio || `${seller.business_name} on Earlymarket Uganda - Shop products and services in ${locationText}.`,
  };

  if (seller.follower_count && seller.follower_count > 0) {
    localBusinessSchema.interactionStatistic = [
      {
        "@type": "InteractionCounter",
        "interactionType": "https://schema.org/FollowAction",
        "userInteractionCount": seller.follower_count
      }
    ];
  }

  if (sellerSlug) {
    localBusinessSchema.alternateName = [`@${sellerSlug}`, `${seller.business_name} Uganda`];
  }

  // Add logo and images
  const imageList: string[] = [];
  if (seller.logo_url) imageList.push(seller.logo_url);
  if (seller.cover_image) imageList.push(seller.cover_image);
  if (imageList.length > 0) {
    localBusinessSchema.image = imageList;
    if (seller.logo_url) {
      localBusinessSchema.logo = seller.logo_url;
    }
  }

  // Add address
  if (seller.location || seller.district) {
    localBusinessSchema.address = {
      "@type": "PostalAddress",
      "addressLocality": seller.location || seller.district,
      "addressRegion": seller.district || "Central",
      "addressCountry": "UG"
    };
  }

  // Add contact info
  if (seller.phone) {
    localBusinessSchema.telephone = seller.phone;
  }
  if (seller.email) {
    localBusinessSchema.email = seller.email;
  }

  // Add social links
  const socialLinks: string[] = [];
  if (seller.website) socialLinks.push(seller.website);
  if (seller.social_links?.facebook) socialLinks.push(seller.social_links.facebook);
  if (seller.social_links?.instagram) socialLinks.push(seller.social_links.instagram);
  if (seller.social_links?.twitter) socialLinks.push(seller.social_links.twitter);
  if (seller.social_links?.tiktok) socialLinks.push(seller.social_links.tiktok);
  if (socialLinks.length > 0) {
    localBusinessSchema.sameAs = socialLinks;
  }

  // Add aggregate rating if available
  if (seller.rating && seller.rating > 0 && seller.review_count && seller.review_count > 0) {
    localBusinessSchema.aggregateRating = {
      "@type": "AggregateRating",
      "ratingValue": seller.rating.toFixed(1),
      "reviewCount": seller.review_count,
      "bestRating": 5,
      "worstRating": 1
    };
  }

  // Add opening hours if available
  if (seller.working_hours && Object.keys(seller.working_hours).length > 0) {
    const openingHoursSpec: any[] = [];
    const dayMap: Record<string, string> = {
      'monday': 'Monday', 'tuesday': 'Tuesday', 'wednesday': 'Wednesday',
      'thursday': 'Thursday', 'friday': 'Friday', 'saturday': 'Saturday', 'sunday': 'Sunday'
    };

    for (const [day, hours] of Object.entries(seller.working_hours)) {
      if (!hours.closed && hours.open && hours.close) {
        const dayOfWeek = dayMap[day.toLowerCase()];
        if (dayOfWeek) {
          openingHoursSpec.push({
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": dayOfWeek,
            "opens": hours.open,
            "closes": hours.close
          });
        }
      }
    }

    if (openingHoursSpec.length > 0) {
      localBusinessSchema.openingHoursSpecification = openingHoursSpec;
    }
  }

  // Add founding date
  if (seller.created_at) {
    localBusinessSchema.foundingDate = seller.created_at.split('T')[0];
  }

  // Add verified business status
  if (seller.is_verified) {
    localBusinessSchema.award = "Earlymarket Verified Business";
    localBusinessSchema.additionalProperty = [
      {
        "@type": "PropertyValue",
        "name": "Verification Status",
        "value": "Verified Business"
      },
      {
        "@type": "PropertyValue",
        "name": "Trust Badge",
        "value": "Earlymarket Verified"
      }
    ];
  }

  // Add business category
  if (seller.business_category) {
    localBusinessSchema.category = seller.business_category;
    localBusinessSchema.knowsAbout = [seller.business_category, "E-commerce", "Uganda Marketplace"];
  }

  // Add parent organization
  localBusinessSchema.parentOrganization = {
    "@type": "Organization",
    "name": "Earlymarket",
    "alternateName": "Earlymarket Uganda",
    "url": siteUrl,
    "logo": `${siteUrl}/logo.png`
  };

  // Build products schema if available - as OfferCatalog
  const productsSchema = products && products.length > 0 ? {
    "@type": "OfferCatalog",
    "@id": `${sellerUrl}#catalog`,
    "name": `Products by ${seller.business_name}`,
    "numberOfItems": products.length,
    "itemListElement": products.slice(0, 10).map((product, index) => ({
      "@type": "Offer",
      "position": index + 1,
      "itemOffered": {
        "@type": "Product",
        "@id": `${siteUrl}/ad/${product.id}`,
        "name": product.title,
        "description": product.description?.slice(0, 150),
        "url": `${siteUrl}/ad/${product.id}`,
        "image": product.images?.[0],
        "offers": product.price ? {
          "@type": "Offer",
          "price": product.price,
          "priceCurrency": product.currency || "UGX",
          "availability": "https://schema.org/InStock",
          "seller": {
            "@type": "Organization",
            "name": seller.business_name,
            "url": sellerUrl
          }
        } : undefined
      }
    }))
  } : null;

  // BreadcrumbList schema
  const breadcrumbSchema = {
    "@type": "BreadcrumbList",
    "@id": `${sellerUrl}#breadcrumb`,
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Earlymarket",
        "item": siteUrl
      },
      ...(seller.business_category ? [{
        "@type": "ListItem",
        "position": 2,
        "name": seller.business_category,
        "item": `${siteUrl}/search?category=${encodeURIComponent(seller.business_category)}`
      }] : []),
      {
        "@type": "ListItem",
        "position": seller.business_category ? 3 : 2,
        "name": seller.business_name,
        "item": sellerUrl
      }
    ]
  };

  // Combined Graph Schema
  const graphSchema = {
    "@context": "https://schema.org",
    "@graph": [
      websiteSchema,
      profilePageSchema,
      localBusinessSchema,
      breadcrumbSchema,
      ...(productsSchema ? [productsSchema] : [])
    ]
  };

  const keywords = [
    seller.business_name,
    sellerSlug ? `@${sellerSlug}` : '',
    seller.business_category,
    locationText,
    'Earlymarket',
    'Earlymarket Uganda',
    'buy in Uganda',
    'verified sellers Kampala',
    'online shop Uganda'
  ].filter(Boolean).join(', ');

  return (
    <>
      <Helmet>
        {/* Primary Meta Tags */}
        <title>{pageTitle}</title>
        <meta name="title" content={pageTitle} />
        <meta name="description" content={metaDescription} />
        <link rel="canonical" href={sellerUrl} />

        {/* Open Graph / Facebook */}
        <meta property="og:type" content="profile" />
        <meta property="og:url" content={sellerUrl} />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={metaDescription} />
        <meta property="og:image" content={ogImage} />
        <meta property="og:site_name" content="Earlymarket" />
        {seller.location && <meta property="business:contact_data:locality" content={seller.location} />}
        {seller.phone && <meta property="business:contact_data:phone_number" content={seller.phone} />}
        {seller.email && <meta property="business:contact_data:email" content={seller.email} />}

        {/* Twitter */}
        <meta property="twitter:card" content="summary_large_image" />
        <meta property="twitter:url" content={sellerUrl} />
        <meta property="twitter:title" content={pageTitle} />
        <meta property="twitter:description" content={metaDescription} />
        <meta property="twitter:image" content={ogImage} />
        <meta property="twitter:site" content="@earlymarketug" />

        {/* High Search Visibility Directives */}
        <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
        <meta name="googlebot" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
        <meta name="author" content={seller.business_name} />
        <meta name="keywords" content={keywords} />
      </Helmet>

      {/* JSON-LD Structured Graph Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(graphSchema) }}
      />
    </>
  );
};

export default SellerJsonLd;
