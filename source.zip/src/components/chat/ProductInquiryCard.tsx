import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ExternalLink, Sparkles, Send, Tag, MapPin, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { imageCdnUrl } from '@/utils/cdnUrl';
import { cn } from '@/lib/utils';

export interface ProductInquiryCardProps {
  adInfo: {
    id: string;
    title: string;
    price?: number;
    images?: string[];
    category?: string;
    listing_type?: string;
    location?: string;
  };
  onSendInquiry?: (message: string) => void;
  onPreFill?: (message: string) => void;
  isSending?: boolean;
  compact?: boolean;
  className?: string;
}

export const ProductInquiryCard: React.FC<ProductInquiryCardProps> = ({
  adInfo,
  onSendInquiry,
  onPreFill,
  isSending = false,
  compact = false,
  className,
}) => {
  const navigate = useNavigate();

  const rawImages = (adInfo.images && adInfo.images.length > 0) ? adInfo.images : [];
  const placeholder = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80';
  
  // Extract 3 images with graceful fallback
  const centerImage = rawImages[0] || placeholder;
  const leftImage = rawImages[1] || rawImages[0] || placeholder;
  const rightImage = rawImages[2] || rawImages[1] || rawImages[0] || placeholder;

  const routeByType: Record<string, string> = {
    services: 'service',
    jobs: 'job',
    events: 'event',
    promotions: 'promotion',
    digital_products: 'digital',
  };

  const productUrl = `/${routeByType[adInfo.listing_type || ''] || 'ad'}/${adInfo.id}`;

  const handlePrimaryInquiry = () => {
    const text = `Hi! I am interested in this product: ${adInfo.title}`;
    if (onSendInquiry) {
      onSendInquiry(text);
    } else if (onPreFill) {
      onPreFill(text);
    }
  };

  const handleQuickQuestion = (question: string) => {
    if (onSendInquiry) {
      onSendInquiry(`${question} regarding: ${adInfo.title}`);
    } else if (onPreFill) {
      onPreFill(question);
    }
  };

  // Compact version for pinned chat header banner or message thread card
  if (compact) {
    return (
      <div
        id={`product-inquiry-compact-${adInfo.id}`}
        className={cn(
          "bg-card/95 backdrop-blur-md border border-border/80 rounded-2xl p-3 shadow-sm flex items-center justify-between gap-3 transition-all",
          className
        )}
      >
        <div 
          className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer group"
          onClick={() => navigate(productUrl)}
        >
          {/* Small 3D angled thumbnail cluster */}
          <div className="relative w-14 h-14 flex-shrink-0 flex items-center justify-center [perspective:500px]">
            <img
              src={imageCdnUrl(leftImage, { width: 80, quality: 65 })}
              alt=""
              className="absolute w-10 h-10 object-cover rounded-md shadow -left-1 opacity-70 [transform:rotateY(45deg)_scale(0.85)] border border-border/50"
            />
            <img
              src={imageCdnUrl(centerImage, { width: 100, quality: 75 })}
              alt={adInfo.title}
              className="relative w-11 h-11 object-cover rounded-lg shadow-md z-10 border border-primary/30 group-hover:scale-105 transition-transform"
            />
            <img
              src={imageCdnUrl(rightImage, { width: 80, quality: 65 })}
              alt=""
              className="absolute w-10 h-10 object-cover rounded-md shadow -right-1 opacity-70 [transform:rotateY(-45deg)_scale(0.85)] border border-border/50"
            />
          </div>

          <div className="min-w-0 flex-1 text-left">
            <p className="font-semibold text-sm text-foreground truncate group-hover:text-primary transition-colors">
              {adInfo.title}
            </p>
            <div className="flex items-center gap-2 mt-0.5">
              {adInfo.price && adInfo.price > 0 && adInfo.listing_type !== 'promotions' ? (
                <span className="text-xs font-bold text-primary">
                  UGX {adInfo.price.toLocaleString()}
                </span>
              ) : (
                <span className="text-xs text-muted-foreground capitalize">
                  {adInfo.category || 'Product'}
                </span>
              )}
            </div>
          </div>
        </div>

        <Button
          id="btn-quick-inquiry-compact"
          size="sm"
          onClick={handlePrimaryInquiry}
          disabled={isSending}
          className="h-8 px-3 rounded-full text-xs font-medium gap-1.5 shadow-sm shrink-0"
        >
          <Sparkles className="w-3.5 h-3.5" />
          I'm interested
        </Button>
      </div>
    );
  }

  // Full 3D 3-image angled product showcase card
  return (
    <motion.div
      id={`product-inquiry-card-${adInfo.id}`}
      initial={{ opacity: 0, y: 12, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className={cn(
        "w-full max-w-md mx-auto bg-gradient-to-b from-card to-card/90 backdrop-blur-xl border border-border/80 rounded-3xl p-5 shadow-xl shadow-black/5 text-center relative overflow-hidden",
        className
      )}
    >
      {/* Background soft glow */}
      <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-48 h-48 bg-primary/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Tag */}
      <div className="flex items-center justify-between mb-3 px-1">
        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-primary uppercase tracking-wider bg-primary/10 px-2.5 py-0.5 rounded-full">
          <Tag className="w-3 h-3" />
          {adInfo.category || 'Product Inquiry'}
        </span>
        <button
          type="button"
          onClick={() => navigate(productUrl)}
          className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
        >
          <span>View item</span>
          <ExternalLink className="w-3 h-3" />
        </button>
      </div>

      {/* 3D 3-Image Angled Showcase (Middle front, Left at -60°, Right at +60°) */}
      <div className="relative my-4 h-36 sm:h-40 flex items-center justify-center [perspective:900px] select-none">
        {/* Left Image (Tilted 60 degrees looking outward to left) */}
        <div
          className="absolute z-10 w-24 h-28 sm:w-28 sm:h-32 rounded-2xl overflow-hidden border border-border/80 shadow-lg cursor-pointer transition-all duration-300 hover:opacity-100 hover:scale-95"
          style={{
            transform: 'translateX(-54px) perspective(600px) rotateY(55deg) rotateZ(-3deg) scale(0.88)',
            transformOrigin: 'right center',
            boxShadow: '-10px 10px 24px -4px rgba(0, 0, 0, 0.25)',
          }}
          onClick={() => navigate(productUrl)}
        >
          <img
            src={imageCdnUrl(leftImage, { width: 300, quality: 75 })}
            alt="Left view"
            className="w-full h-full object-cover brightness-95"
            onError={(e) => { (e.currentTarget as HTMLImageElement).src = placeholder; }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/20 to-transparent pointer-events-none" />
        </div>

        {/* Center Image (Front & elevated with high contrast) */}
        <div
          className="relative z-20 w-28 h-32 sm:w-32 sm:h-36 rounded-2xl overflow-hidden border-2 border-primary/40 shadow-2xl cursor-pointer group transition-all duration-300 hover:scale-105"
          style={{
            transform: 'scale(1.05) translateZ(30px)',
            boxShadow: '0 16px 36px -8px rgba(0, 0, 0, 0.35), 0 0 0 1px hsl(var(--primary)/0.2)',
          }}
          onClick={() => navigate(productUrl)}
        >
          <img
            src={imageCdnUrl(centerImage, { width: 400, quality: 85 })}
            alt={adInfo.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onError={(e) => { (e.currentTarget as HTMLImageElement).src = placeholder; }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent pointer-events-none" />
          <div className="absolute bottom-1.5 right-1.5 bg-black/60 backdrop-blur-sm text-[10px] text-white font-medium px-1.5 py-0.5 rounded-md flex items-center gap-1">
            <CheckCircle2 className="w-2.5 h-2.5 text-primary" />
            Verified
          </div>
        </div>

        {/* Right Image (Tilted 60 degrees looking outward to right) */}
        <div
          className="absolute z-10 w-24 h-28 sm:w-28 sm:h-32 rounded-2xl overflow-hidden border border-border/80 shadow-lg cursor-pointer transition-all duration-300 hover:opacity-100 hover:scale-95"
          style={{
            transform: 'translateX(54px) perspective(600px) rotateY(-55deg) rotateZ(3deg) scale(0.88)',
            transformOrigin: 'left center',
            boxShadow: '10px 10px 24px -4px rgba(0, 0, 0, 0.25)',
          }}
          onClick={() => navigate(productUrl)}
        >
          <img
            src={imageCdnUrl(rightImage, { width: 300, quality: 75 })}
            alt="Right view"
            className="w-full h-full object-cover brightness-95"
            onError={(e) => { (e.currentTarget as HTMLImageElement).src = placeholder; }}
          />
          <div className="absolute inset-0 bg-gradient-to-l from-black/20 to-transparent pointer-events-none" />
        </div>
      </div>

      {/* Title & Pricing */}
      <div className="space-y-1 my-3">
        <h3 
          className="font-bold text-base sm:text-lg text-foreground line-clamp-2 hover:text-primary transition-colors cursor-pointer"
          onClick={() => navigate(productUrl)}
        >
          {adInfo.title}
        </h3>

        {adInfo.price && adInfo.price > 0 && adInfo.listing_type !== 'promotions' && (
          <p className="text-lg sm:text-xl font-extrabold text-primary tracking-tight">
            UGX {adInfo.price.toLocaleString()}
          </p>
        )}

        {adInfo.location && (
          <p className="text-xs text-muted-foreground flex items-center justify-center gap-1">
            <MapPin className="w-3 h-3" />
            {adInfo.location}
          </p>
        )}
      </div>

      {/* Main Action Button requested by user */}
      <div className="mt-4 space-y-2">
        <Button
          id="btn-i-am-interested-in-this-product"
          onClick={handlePrimaryInquiry}
          disabled={isSending}
          size="lg"
          className="w-full h-12 rounded-2xl font-bold text-sm bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/25 gap-2 transition-all active:scale-[0.98]"
        >
          <Sparkles className="w-4 h-4 fill-current" />
          I am interested in this product
          <Send className="w-4 h-4 ml-auto" />
        </Button>

        {/* Quick follow-up chips */}
        <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1">
          <button
            type="button"
            onClick={() => handleQuickQuestion("Is this still available?")}
            className="text-xs px-3 py-1.5 rounded-full bg-muted/60 hover:bg-muted text-muted-foreground hover:text-foreground transition-colors border border-border/60"
          >
            Is this still available?
          </button>
          <button
            type="button"
            onClick={() => handleQuickQuestion("What's the best price you can offer?")}
            className="text-xs px-3 py-1.5 rounded-full bg-muted/60 hover:bg-muted text-muted-foreground hover:text-foreground transition-colors border border-border/60"
          >
            Negotiate price
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductInquiryCard;
