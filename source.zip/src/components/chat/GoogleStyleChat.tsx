import React, { useState, useEffect, useRef } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ArrowUp, ArrowLeft, X, MapPin, Image, Plus, MoreVertical, Info, Loader2, Flag, Trash2, AlertTriangle } from 'lucide-react';
import { formatDistanceToNow, format } from 'date-fns';
import { toast } from "@/components/ui/use-toast";
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { getPresence } from '@/lib/presence';
import MessageBubble from './MessageBubble';
import ChatAuthPrompt from './ChatAuthPrompt';
import VoiceRecorder from './VoiceRecorder';
import { useMessageSounds } from '@/hooks/useMessageSounds';
import { Spinner } from '@/components/ui/spinner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

// Context Card Component - shows what the chat is about
const ContextCard = ({ adId, contentType }: { adId: string; contentType?: string }) => {
  const [content, setContent] = useState<any>(null);

  useEffect(() => {
    const fetchContent = async () => {
      const { data } = await supabase
        .from('ads')
        .select('id, title, price, currency, images, listing_type, job_details(company_name, job_type)')
        .eq('id', adId)
        .single();
      if (data) {
        setContent({ ...data, type: contentType || data?.listing_type || 'product' });
      }
    };
    if (adId) fetchContent();
  }, [adId, contentType]);

  if (!content) return null;

  return (
    <div className="flex items-center gap-3 p-3 bg-muted/50 dark:bg-muted/20 rounded-xl mx-4 mt-2 border border-border/50">
      {content.images?.[0] && (
        <img
          src={content.images[0]}
          alt={content.title}
          className="w-12 h-12 rounded-lg object-cover"
        />
      )}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-foreground truncate">{content.title}</p>
        {(content.type === 'job' || content.type === 'jobs') ? (
          <p className="text-xs text-muted-foreground">
            {content.job_details?.[0]?.company_name} • {content.job_details?.[0]?.job_type}
          </p>
        ) : content.price && (
          <p className="text-sm font-bold text-primary">
            {content.currency || 'UGX'} {content.price?.toLocaleString()}
          </p>
        )}
      </div>
    </div>
  );
};

// AI-driven quick reply options with statement transformation
const QuickReplies = ({ 
  contentType, 
  onSelect,
  isOwner
}: { 
  contentType: string; 
  onSelect: (text: string) => void;
  isOwner: boolean;
}) => {
  if (isOwner) return null;

  const getOptions = () => {
    switch (contentType) {
      case 'job':
      case 'jobs':
        return [
          { label: "Is this position still available?", statement: "Hi, I'd like to know if this position is still open for applications." },
          { label: "What are the working hours?", statement: "Hello, could you please share more details about the working hours for this role?" },
          { label: "Can we schedule an interview?", statement: "I'm interested in this opportunity. Would it be possible to schedule an interview?" },
          { label: "What's the salary range?", statement: "I'd like to inquire about the salary range and benefits for this position." },
        ];
      case 'service':
      case 'services':
        return [
          { label: "How much do you charge?", statement: "Hi, I'm interested in your services. Could you share your pricing?" },
          { label: "Are you available this week?", statement: "Hello, I'd like to book your service. Are you available this week?" },
          { label: "Where are you located?", statement: "Could you please share your location or service area?" },
          { label: "Can I see your portfolio?", statement: "I'd love to see some of your previous work. Do you have a portfolio?" },
        ];
      case 'promotion':
      case 'promotions':
        return [
          { label: "Is this promotion still valid?", statement: "Hi, I wanted to confirm if this promotion is still active?" },
          { label: "How can I redeem this?", statement: "I'm interested in this offer. How can I redeem it?" },
          { label: "Any other discounts?", statement: "Are there any additional discounts or offers available?" },
          { label: "What are the terms?", statement: "Could you please share the terms and conditions for this promotion?" },
        ];
      case 'event':
      case 'events':
        return [
          { label: "Are tickets still available?", statement: "Hi, I'd like to attend this event. Are tickets still available?" },
          { label: "What's the venue address?", statement: "Could you please share the exact venue address and directions?" },
          { label: "Is parking available?", statement: "Will there be parking available at the venue?" },
          { label: "Can I pay at the door?", statement: "Is it possible to purchase tickets at the venue on the event day?" },
        ];
      default:
        return [
          { label: "Is this still available?", statement: "Hi, I'm interested in this item. Is it still available?" },
          { label: "What's your last price?", statement: "I'd like to purchase this. What's your best price?" },
          { label: "Can you deliver?", statement: "Do you offer delivery? What are the delivery charges?" },
          { label: "Can I see more photos?", statement: "Could you please share some additional photos of the item?" },
        ];
    }
  };

  const options = getOptions();

  return (
    <div className="px-4 py-3 border-t border-border/50 bg-background">
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
        {options.map((option, idx) => (
          <button
            key={idx}
            onClick={() => onSelect(option.statement)}
            className="flex-shrink-0 px-4 py-2 text-sm bg-primary/10 hover:bg-primary/20 text-primary rounded-full transition-colors whitespace-nowrap border border-primary/20"
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
};

// Character counter component
const CharacterCounter = ({ current, max }: { current: number; max: number }) => {
  const percentage = (current / max) * 100;
  const remaining = max - current;
  const isWarning = remaining < 50;
  const isDanger = remaining < 20;
  
  const strokeColor = isDanger ? 'hsl(var(--destructive))' : isWarning ? 'hsl(var(--warning, 45 93% 47%))' : 'hsl(var(--primary))';
  
  return (
    <div className="relative w-6 h-6 flex-shrink-0">
      <svg className="w-6 h-6 -rotate-90" viewBox="0 0 24 24">
        <circle
          cx="12"
          cy="12"
          r="10"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          className="text-muted/30"
        />
        <circle
          cx="12"
          cy="12"
          r="10"
          fill="none"
          stroke={strokeColor}
          strokeWidth="2"
          strokeDasharray={`${(percentage / 100) * 62.83} 62.83`}
          strokeLinecap="round"
        />
      </svg>
      {isDanger && (
        <span className="absolute inset-0 flex items-center justify-center text-[8px] font-medium text-destructive">
          {remaining}
        </span>
      )}
    </div>
  );
};

interface GoogleStyleChatProps {
  sellerId: string;
  adId?: string;
  contentType?: string;
  onBack: () => void;
}

interface Message {
  id: string;
  content: string;
  sender_id: string;
  created_at: string;
  is_read: boolean;
  is_voice_message?: boolean | null;
  voice_recording_url?: string | null;
  message_duration?: number | null;
  recipient_id: string;
  parent_message_id?: string | null;
  attachment_url?: string | null;
  attachment_type?: string | null;
  location_data?: any;
  deleted_at?: string | null;
  deleted_for?: string[];
}

const MAX_MESSAGE_LENGTH = 500;

const GoogleStyleChat: React.FC<GoogleStyleChatProps> = ({ sellerId, adId, contentType, onBack }) => {
  const [user, setUser] = useState<any>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [sellerInfo, setSellerInfo] = useState<{ name: string; avatar?: string; user_id?: string; is_online?: boolean; last_seen_at?: string; show_online_status?: boolean }>({ name: 'User' });
  const [showAuthPrompt, setShowAuthPrompt] = useState(false);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [gettingLocation, setGettingLocation] = useState(false);
  const [showInfoDialog, setShowInfoDialog] = useState(false);
  const isSelfChat = user?.id === sellerId;
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { playMessageSentSound, playMessageReceivedSound, playMessageDeliveredSound } = useMessageSounds();

  const isOwner = user?.id === sellerId;

  // Update user's online status
  useEffect(() => {
    const updateOnlineStatus = async () => {
      if (!user) return;
      await supabase
        .from('seller_profiles')
        .update({ is_online: true, last_seen_at: new Date().toISOString() })
        .eq('user_id', user.id);
    };

    updateOnlineStatus();
    const interval = setInterval(updateOnlineStatus, 30000); // Update every 30 seconds

    return () => {
      clearInterval(interval);
      // Set offline when leaving
      if (user) {
        supabase
          .from('seller_profiles')
          .update({ is_online: false, last_seen_at: new Date().toISOString() })
          .eq('user_id', user.id);
      }
    };
  }, [user]);

  useEffect(() => {
    const checkUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user);
      setLoading(false);
      if (!user) setShowAuthPrompt(true);
    };
    checkUser();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setUser(session?.user ?? null);
        if (session?.user) setShowAuthPrompt(false);
      }
    );
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      if (!sellerId || !user) return;

      try {
        const { data: messagesData } = await supabase
          .from('messages')
          .select('*')
          .or(`and(sender_id.eq.${user.id},recipient_id.eq.${sellerId}),and(sender_id.eq.${sellerId},recipient_id.eq.${user.id})`)
          .is('deleted_at', null)
          .order('created_at', { ascending: true });

        // Filter out messages deleted for current user
        const filteredMessages = (messagesData || []).filter(
          (msg: any) => !msg.deleted_for?.includes(user.id)
        );
        setMessages(filteredMessages);

        const { data: sellerData } = await supabase
          .from('seller_profiles')
          .select('business_name, business_logo_url, user_id, is_online, last_seen_at')
          .eq('user_id', sellerId)
          .single();

        if (sellerData) {
          // Fetch privacy settings
          const { data: privacyData } = await supabase
            .from('user_privacy_settings')
            .select('show_online_status')
            .eq('user_id', sellerId)
            .single();

          setSellerInfo({
            name: sellerData.business_name || 'User',
            avatar: sellerData.business_logo_url,
            user_id: sellerData.user_id,
            is_online: sellerData.is_online,
            last_seen_at: sellerData.last_seen_at,
            show_online_status: privacyData?.show_online_status ?? true,
          });
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, [sellerId, user]);

  // Real-time subscription for messages and online status
  useEffect(() => {
    if (!sellerId || !user) return;

    const channel = supabase
      .channel(`google-chat-messages-${sellerId}-${crypto.randomUUID()}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' },
        (payload) => {
          const newMsg = payload.new as Message;
          if ((newMsg.sender_id === sellerId && newMsg.recipient_id === user?.id) ||
              (newMsg.sender_id === user?.id && newMsg.recipient_id === sellerId)) {
            setMessages(prev => {
              if (prev.find(m => m.id === newMsg.id)) return prev;
              return [...prev, newMsg];
            });
            if (newMsg.sender_id !== user?.id) playMessageReceivedSound();
          }
        }
      )
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages' },
        (payload) => {
          const updated = payload.new as Message;
          // Handle deletions
          if (updated.deleted_at || updated.deleted_for?.includes(user?.id)) {
            setMessages(prev => prev.filter(msg => msg.id !== updated.id));
          } else {
            setMessages(prev => prev.map(msg => msg.id === updated.id ? updated : msg));
          }
          if (updated.is_read && updated.sender_id === user?.id) playMessageDeliveredSound();
        }
      )
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' },
        (payload) => {
          setMessages(prev => prev.filter(msg => msg.id !== payload.old.id));
        }
      )
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'seller_profiles', filter: `user_id=eq.${sellerId}` },
        (payload) => {
          const updated = payload.new as any;
          setSellerInfo(prev => ({
            ...prev,
            is_online: updated.is_online,
            last_seen_at: updated.last_seen_at,
          }));
        }
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [sellerId, user?.id]);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleDeleteMessage = async (messageId: string, deleteForEveryone: boolean) => {
    if (!user) return;

    try {
      if (deleteForEveryone) {
        // Delete for everyone - set deleted_at
        await supabase
          .from('messages')
          .update({ deleted_at: new Date().toISOString() })
          .eq('id', messageId);
      } else {
        // Delete for me only - add to deleted_for array
        const message = messages.find(m => m.id === messageId);
        const deletedFor = [...(message?.deleted_for || []), user.id];
        await supabase
          .from('messages')
          .update({ deleted_for: deletedFor })
          .eq('id', messageId);
      }
      toast({ title: "Message deleted" });
    } catch (error) {
      console.error('Error deleting message:', error);
      toast({ title: "Error", description: "Failed to delete message.", variant: "destructive" });
    }
  };

  const handleSendMessage = async (content: string, voiceRecordingUrl?: string, messageDuration?: number, attachmentUrl?: string, attachmentType?: string, locationData?: any) => {
    if (!user || !sellerId || user.id === sellerId) return;
    if ((!content.trim() && !voiceRecordingUrl && !attachmentUrl && !locationData) || sending) return;

    setSending(true);
    try {
      const { error } = await supabase.from('messages').insert([{
        sender_id: user.id,
        recipient_id: sellerId,
        content: content.trim() || (attachmentUrl ? '📎 Attachment' : locationData ? '📍 Location' : ''),
        ad_id: adId,
        is_voice_message: !!voiceRecordingUrl,
        voice_recording_url: voiceRecordingUrl,
        message_duration: messageDuration,
        parent_message_id: replyingTo?.id,
        attachment_url: attachmentUrl,
        attachment_type: attachmentType,
        location_data: locationData
      }]);

      if (error) throw error;
      playMessageSentSound();
      setReplyingTo(null);
    } catch (error) {
      console.error('Error sending message:', error);
      toast({ title: "Error", description: "Failed to send message.", variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(newMessage);
    setNewMessage('');
  };

  const handleQuickReply = (text: string) => {
    setNewMessage(text);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    setUploadingImage(true);
    setShowAttachMenu(false);

    try {
      const fileExt = file.name.split('.').pop();
      const filePath = `${user.id}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('chat-attachments')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('chat-attachments')
        .getPublicUrl(filePath);

      await handleSendMessage('', undefined, undefined, publicUrl, file.type);
      toast({ title: "Image sent!" });
    } catch (error) {
      console.error('Error uploading image:', error);
      toast({ title: "Error", description: "Failed to upload image.", variant: "destructive" });
    } finally {
      setUploadingImage(false);
    }
  };

  const handleShareLocation = async () => {
    if (!navigator.geolocation) {
      toast({ title: "Error", description: "Geolocation not supported.", variant: "destructive" });
      return;
    }

    setGettingLocation(true);
    setShowAttachMenu(false);

    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          resolve, 
          reject, 
          { 
            enableHighAccuracy: true,
            timeout: 15000,
            maximumAge: 0 // Force fresh location, don't use cached
          }
        );
      });

      const { latitude, longitude, accuracy } = position.coords;
      
      // Build detailed address using reverse geocoding
      let address = `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
      let detailedLocation = '';
      
      try {
        const res = await fetch(
          `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&addressdetails=1&zoom=18`,
          { headers: { 'User-Agent': 'EarlyMarket/1.0' } }
        );
        const data = await res.json();
        
        if (data.address) {
          const addr = data.address;
          // Build a more specific address
          const parts = [];
          if (addr.road) parts.push(addr.road);
          if (addr.suburb || addr.neighbourhood) parts.push(addr.suburb || addr.neighbourhood);
          if (addr.city || addr.town || addr.village) parts.push(addr.city || addr.town || addr.village);
          if (addr.county) parts.push(addr.county);
          if (addr.country) parts.push(addr.country);
          
          detailedLocation = parts.join(', ');
          address = detailedLocation || data.display_name || address;
        }
      } catch (e) {
        console.log('Geocoding failed, using coordinates');
      }

      await handleSendMessage(
        `📍 ${address}`, 
        undefined, 
        undefined, 
        undefined, 
        undefined, 
        { 
          lat: latitude, 
          lng: longitude, 
          address,
          accuracy: Math.round(accuracy)
        }
      );
      toast({ title: "Location shared!", description: `Accuracy: ~${Math.round(accuracy)}m` });
    } catch (error: any) {
      console.error('Error getting location:', error);
      let errorMessage = "Failed to get location.";
      if (error.code === 1) errorMessage = "Location access denied. Please enable location permissions.";
      else if (error.code === 2) errorMessage = "Location unavailable. Please try again.";
      else if (error.code === 3) errorMessage = "Location request timed out. Please try again.";
      toast({ title: "Error", description: errorMessage, variant: "destructive" });
    } finally {
      setGettingLocation(false);
    }
  };

  const groupMessagesByDate = (msgs: Message[]) => {
    const groups: { [key: string]: Message[] } = {};
    msgs.forEach(msg => {
      const date = format(new Date(msg.created_at), 'EEEE, d MMM');
      if (!groups[date]) groups[date] = [];
      groups[date].push(msg);
    });
    return groups;
  };

  const getOnlineStatus = () => {
    // Respect privacy settings
    if (sellerInfo.show_online_status === false) {
      return null;
    }
    const presence = getPresence(sellerInfo.is_online, sellerInfo.last_seen_at);
    if (presence.online) {
      return <span className="text-xs text-green-500 font-medium">● Online</span>;
    }
    if (presence.lastSeenLabel) {
      return (
        <span className="text-xs text-muted-foreground">{presence.lastSeenLabel}</span>
      );
    }
    return <span className="text-xs text-muted-foreground">Offline</span>;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <Spinner size="lg" className="text-primary" />
      </div>
    );
  }

  const groupedMessages = groupMessagesByDate(messages);

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Google Chat Style Header */}
      <div className="bg-background border-b border-border px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3 flex-1">
          <Button onClick={onBack} variant="ghost" size="icon" className="rounded-full">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="relative">
            <Avatar className="w-9 h-9">
              <AvatarImage src={sellerInfo?.avatar} />
              <AvatarFallback className="bg-primary/20 text-primary text-sm font-medium">
                {sellerInfo?.name?.charAt(0)?.toUpperCase() || 'U'}
              </AvatarFallback>
            </Avatar>
            {sellerInfo.show_online_status !== false && getPresence(sellerInfo.is_online, sellerInfo.last_seen_at).online && (
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-background rounded-full" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="font-medium text-sm text-foreground truncate">{sellerInfo?.name}</h2>
            {getOnlineStatus()}
          </div>
        </div>
        
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="rounded-full" onClick={() => setShowInfoDialog(true)}>
            <Info className="w-5 h-5 text-muted-foreground" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <MoreVertical className="w-5 h-5 text-muted-foreground" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem className="flex items-center gap-2">
                <Flag className="w-4 h-4" />
                Report User
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="w-4 h-4" />
                Block User
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Info Dialog */}
      <Dialog open={showInfoDialog} onOpenChange={setShowInfoDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Chat Information</DialogTitle>
            <DialogDescription>
              <div className="space-y-4 mt-4">
                <div className="flex items-center gap-4">
                  <Avatar className="w-16 h-16">
                    <AvatarImage src={sellerInfo?.avatar} />
                    <AvatarFallback className="bg-primary/20 text-primary text-xl font-medium">
                      {sellerInfo?.name?.charAt(0)?.toUpperCase() || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold text-foreground">{sellerInfo?.name}</h3>
                    {getOnlineStatus()}
                  </div>
                </div>
                <div className="bg-muted/50 rounded-lg p-3 text-sm">
                  <p className="text-muted-foreground">
                    🔒 Messages are encrypted and stored securely. They are automatically deleted after 90 days.
                  </p>
                </div>
              </div>
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>

      {/* Context Card */}
      {adId && <ContextCard adId={adId} contentType={contentType} />}

      {/* 90-day notice */}
      <div className="text-center py-2">
        <span className="text-[10px] text-muted-foreground bg-muted/50 px-3 py-1 rounded-full">
          Messages are kept for 90 days
        </span>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <Avatar className="w-20 h-20">
                <AvatarImage src={sellerInfo?.avatar} />
                <AvatarFallback className="bg-primary/20 text-primary text-2xl font-medium">
                  {sellerInfo?.name?.charAt(0)?.toUpperCase() || 'U'}
                </AvatarFallback>
              </Avatar>
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-1">{sellerInfo?.name}</h3>
            <p className="text-sm text-muted-foreground mb-6">Start a conversation</p>
          </div>
        ) : (
          Object.entries(groupedMessages).map(([date, msgs]) => (
            <div key={date}>
              <div className="flex justify-center my-4">
                <span className="text-xs text-muted-foreground bg-muted/50 px-3 py-1 rounded-full">
                  {date}
                </span>
              </div>
              {msgs.map((message) => (
                <MessageBubble
                  key={message.id}
                  message={message}
                  isCurrentUser={message.sender_id === user?.id}
                  senderInfo={sellerInfo}
                  onReply={setReplyingTo}
                  parentMessage={messages.find(m => m.id === message.parent_message_id)}
                  onDelete={handleDeleteMessage}
                />
              ))}
            </div>
          ))
        )}
        <div ref={chatBottomRef} />
      </div>

      {/* Quick Reply Options - only for non-owners */}
      {adId && messages.length === 0 && !isSelfChat && (
        <QuickReplies 
          contentType={contentType || 'product'} 
          onSelect={handleQuickReply}
          isOwner={isOwner}
        />
      )}

      {/* Self-messaging banner */}
      {isSelfChat && (
        <div className="border-t border-border bg-muted/50 p-4 text-center">
          <p className="text-sm text-muted-foreground">You cannot message yourself</p>
        </div>
      )}

      {/* Reply Bar */}
      {!isSelfChat && replyingTo && (
        <div className="bg-muted/50 border-l-4 border-primary px-4 py-2 flex items-center justify-between">
          <div className="flex-1 min-w-0">
            <p className="text-xs text-muted-foreground">Replying to</p>
            <p className="text-sm font-medium truncate">{replyingTo.content}</p>
          </div>
          <Button onClick={() => setReplyingTo(null)} variant="ghost" size="icon" className="h-8 w-8">
            <X className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* Input Area - Google Chat Style */}
      {!isSelfChat && (
      <div className="border-t border-border bg-background p-3">
        <div className="flex items-center gap-2">
          {/* Attach menu */}
          <div className="relative">
            <Button
              onClick={() => setShowAttachMenu(!showAttachMenu)}
              variant="ghost"
              size="icon"
              className="rounded-full h-10 w-10 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Plus className="w-5 h-5" />
            </Button>
            
            {showAttachMenu && (
              <div className="absolute bottom-12 left-0 bg-card rounded-xl shadow-lg border border-border p-2 min-w-[150px] z-50">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingImage}
                  className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-muted rounded-lg transition-colors"
                >
                  {uploadingImage ? <Loader2 className="w-4 h-4 animate-spin" /> : <Image className="w-4 h-4" />}
                  <span>Photo</span>
                </button>
                <button
                  onClick={handleShareLocation}
                  disabled={gettingLocation}
                  className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-muted rounded-lg transition-colors"
                >
                  {gettingLocation ? <Loader2 className="w-4 h-4 animate-spin" /> : <MapPin className="w-4 h-4" />}
                  <span>Location</span>
                </button>
              </div>
            )}
          </div>

          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageUpload}
            accept="image/*"
            className="hidden"
          />

          {/* Message input */}
          <form onSubmit={handleSubmit} className="flex-1 flex items-center gap-2">
            <div className="flex-1 relative">
              <Input
                type="text"
                placeholder="Message"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value.slice(0, MAX_MESSAGE_LENGTH))}
                className="flex-1 rounded-full bg-muted border-0 focus-visible:ring-1 focus-visible:ring-primary pr-10"
              />
            </div>
            
            {newMessage.length > 0 && (
              <CharacterCounter current={newMessage.length} max={MAX_MESSAGE_LENGTH} />
            )}
            
            <VoiceRecorder
              onSendVoiceMessage={(url, duration) => handleSendMessage('', url, duration)}
              disabled={sending}
            />
            
            <Button 
              type="submit" 
              disabled={!newMessage.trim() || sending}
              size="icon"
              className="rounded-full h-10 w-10 bg-primary hover:bg-primary/90"
            >
              <ArrowUp className="w-5 h-5" strokeWidth={2.5} />
            </Button>
          </form>
        </div>
      </div>
      )}

      {/* Auth Prompt */}
      <ChatAuthPrompt
        isOpen={showAuthPrompt}
        onClose={() => setShowAuthPrompt(false)}
        onAuthSuccess={() => setShowAuthPrompt(false)}
        sellerName={sellerInfo?.name}
        isSellerOnline={sellerInfo.is_online || false}
      />
    </div>
  );
};

export default GoogleStyleChat;