// Re-export the new Google Style Chat as WhatsAppChat for backward compatibility
import React from 'react';
import GoogleStyleChat from './GoogleStyleChat';

interface WhatsAppChatProps {
  sellerId: string;
  adId?: string;
  contentType?: string;
  onBack: () => void;
}

const WhatsAppChat: React.FC<WhatsAppChatProps> = (props) => {
  return <GoogleStyleChat {...props} />;
};

export default WhatsAppChat;
