import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { imageCdnUrl } from '@/utils/cdnUrl';
import { Spinner } from '@/components/ui/spinner';

interface ChatListingFanProps {
  adId: string;
  title?: string;
  price?: number | null;
  category?: string;
  listingType?: string;
  images?: string[];
  loading?: boolean;
  className?: string;
}

const routeByType: Record<string, string> = {
  services: 'service',
  jobs: 'job',
  events: 'event',
  promotions: 'promotion',
  digital_products: 'digital',
};

const FanImage: React.FC<{ src: string; alt: string; className?: string; style?: React.CSSProperties }> = ({
  src,
  alt,
  className,
  style,
}) => {
  const [loaded, setLoaded] = useState(false);
  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-xl border border-border bg-muted shadow-lg',
        className,
      )}
      style={style}
    >
      {!loaded && (
        <div className="absolute inset-0 flex items-center justify-center">
          <Spinner size="sm" className="text-primary" />
        </div>
      )}
      <img
        src={imageCdnUrl(src, { width: 320, quality: 70 })}
        alt={alt}
        loading="lazy"
        className={cn('w-full h-full object-cover transition-opacity duration-300', loaded ? 'opacity-100' : 'opacity-0')}
        onLoad={() => setLoaded(true)}
        onError={(event) => {
          if (event.currentTarget.dataset.originalRetried !== '1') {
            event.currentTarget.dataset.originalRetried = '1';
            event.currentTarget.src = src;
          } else {
            setLoaded(true);
          }
        }}
      />
    </div>
  );
};

/**
 * Listing header shown at the very top of a conversation: three cards fanned in
 * 3D — the side cards tilted, the middle one facing the reader. Hovering opens
 * the fan wider. It scrolls with the messages, so scrolling up always reveals
 * the item the conversation started from.
 */
const ChatListingFan: React.FC<ChatListingFanProps> = ({
  adId,
  title,
  price,
  category,
  listingType,
  images,
  loading,
  className,
}) => {
  const navigate = useNavigate();
  const [hovered, setHovered] = useState(false);

  const trio = useMemo(() => {
    const pool = (images || []).filter(Boolean);
    if (pool.length === 0) return [] as string[];
    return [pool[1] || pool[0], pool[0], pool[2] || pool[1] || pool[0]];
  }, [images]);

  const sideAngle = hovered ? 58 : 40;
  const sideShift = hovered ? 16 : 8;
  const sideScale = hovered ? 0.9 : 0.84;

  const open = () => navigate(`/${routeByType[listingType || ''] || 'ad'}/${adId}`);

  return (
    <div className={cn('w-full flex flex-col items-center pt-2 pb-5', className)}>
      <p className="text-[11px] uppercase tracking-wide text-muted-foreground mb-3">Chatting about</p>

      <div
        role="button"
        tabIndex={0}
        aria-label={title ? `Open ${title}` : 'Open listing'}
        onClick={open}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') open();
        }}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        className="cursor-pointer select-none"
        style={{ perspective: '900px' }}
      >
        {loading ? (
          <div className="h-[110px] flex items-center justify-center">
            <Spinner size="lg" className="text-primary" />
          </div>
        ) : trio.length === 0 ? (
          <div className="h-[110px] w-[92px] rounded-xl border border-border bg-muted flex items-center justify-center text-xs text-muted-foreground">
            No image
          </div>
        ) : (
          <div className="flex items-center justify-center" style={{ transformStyle: 'preserve-3d' }}>
            <FanImage
              src={trio[0]}
              alt={title ? `${title} preview 1` : 'Listing preview'}
              className="w-[76px] h-[96px] -mr-3"
              style={{
                transform: `rotateY(${sideAngle}deg) translateX(-${sideShift}px) scale(${sideScale})`,
                transition: 'transform 350ms cubic-bezier(0.22, 1, 0.36, 1)',
              }}
            />
            <FanImage
              src={trio[1]}
              alt={title ? `${title} preview 2` : 'Listing preview'}
              className="w-[104px] h-[124px] z-10"
              style={{
                transform: `rotateY(0deg) scale(${hovered ? 1.06 : 1})`,
                transition: 'transform 350ms cubic-bezier(0.22, 1, 0.36, 1)',
              }}
            />
            <FanImage
              src={trio[2]}
              alt={title ? `${title} preview 3` : 'Listing preview'}
              className="w-[76px] h-[96px] -ml-3"
              style={{
                transform: `rotateY(-${sideAngle}deg) translateX(${sideShift}px) scale(${sideScale})`,
                transition: 'transform 350ms cubic-bezier(0.22, 1, 0.36, 1)',
              }}
            />
          </div>
        )}
      </div>

      <div className="mt-3 text-center max-w-[280px]">
        <p className="text-sm font-semibold text-foreground truncate">{title || 'Listing'}</p>
        {typeof price === 'number' && price > 0 && listingType !== 'promotions' && (
          <p className="text-sm text-primary font-semibold">UGX {price.toLocaleString()}</p>
        )}
        {category && <p className="text-[11px] text-muted-foreground truncate">{category}</p>}
      </div>
    </div>
  );
};

export default ChatListingFan;
