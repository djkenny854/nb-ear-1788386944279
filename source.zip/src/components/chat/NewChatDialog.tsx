import React, { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Search, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import UnifiedVerifiedBadge from '@/components/UnifiedVerifiedBadge';

interface Recipient {
  user_id: string;
  name: string;
  avatar?: string | null;
  handle?: string | null;
  verified?: boolean;
}

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSelect: (r: Recipient) => void;
  currentUserId?: string;
}

const NewChatDialog: React.FC<Props> = ({ open, onOpenChange, onSelect, currentUserId }) => {
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<Recipient[]>([]);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    const run = async () => {
      setLoading(true);
      try {
        let query = supabase
          .from('seller_profiles')
          .select('user_id, business_name, business_logo_url, is_verified')
          .limit(20);
        if (q.trim()) query = query.ilike('business_name', `%${q.trim()}%`);
        const { data } = await query;
        if (cancelled) return;
        const list = (data || [])
          .filter((r: any) => r.user_id && r.user_id !== currentUserId)
          .map((r: any) => ({
            user_id: r.user_id,
            name: r.business_name || 'Seller',
            avatar: r.business_logo_url,
            verified: !!r.is_verified,
          }));
        setResults(list);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    const t = setTimeout(run, 200);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [q, open, currentUserId]);

  const initials = (n: string) => n.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md p-0 overflow-hidden">
        <DialogHeader className="px-4 pt-4 pb-2">
          <DialogTitle>New message</DialogTitle>
        </DialogHeader>
        <div className="px-4 pb-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              autoFocus
              placeholder="Search people"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              className="pl-9 rounded-full bg-muted/60 border-0"
            />
          </div>
        </div>
        <div className="max-h-[60vh] overflow-y-auto">
          {loading ? (
            <div className="flex justify-center py-8 text-muted-foreground">
              <Loader2 className="w-5 h-5 animate-spin" />
            </div>
          ) : results.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground py-8">No people found</p>
          ) : (
            results.map((r) => (
              <button
                key={r.user_id}
                onClick={() => {
                  onSelect(r);
                  onOpenChange(false);
                }}
                className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-muted/60 transition-colors text-left"
              >
                <Avatar className="w-10 h-10">
                  <AvatarImage src={r.avatar || undefined} />
                  <AvatarFallback className="text-sm">{initials(r.name)}</AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1">
                    <span className="font-semibold truncate text-[15px]">{r.name}</span>
                    {r.verified && <UnifiedVerifiedBadge isVerified size="xs" />}
                  </div>
                </div>
              </button>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default NewChatDialog;
