import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Mic, Square, X, ArrowUp, Play, Pause, Trash2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import DynamicWaveform from './DynamicWaveform';
import { audioExtensionFor, getMicrophoneStream, pickAudioMimeType } from '@/utils/audioRecording';

interface ModernVoiceRecorderProps {
  onSendVoiceMessage: (voiceUrl: string, duration: number) => void;
  disabled?: boolean;
}

const ModernVoiceRecorder: React.FC<ModernVoiceRecorderProps> = ({
  onSendVoiceMessage,
  disabled
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [analyserNode, setAnalyserNode] = useState<AnalyserNode | null>(null);

  // Preview/approve state
  const [previewBlob, setPreviewBlob] = useState<Blob | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewDuration, setPreviewDuration] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackTime, setPlaybackTime] = useState(0);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  const startRecording = async () => {
    try {
      const stream = await getMicrophoneStream();
      streamRef.current = stream;

      const audioContext = new AudioContext();
      audioContextRef.current = audioContext;
      const source = audioContext.createMediaStreamSource(stream);
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 64;
      source.connect(analyser);
      setAnalyserNode(analyser);

      const mimeType = pickAudioMimeType();
      const mediaRecorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, {
          type: mediaRecorder.mimeType || mimeType || 'audio/webm'
        });
        // Show preview instead of sending immediately
        const url = URL.createObjectURL(audioBlob);
        setPreviewBlob(audioBlob);
        setPreviewUrl(url);
        setPreviewDuration(recordingDuration);
        cleanup();
      };

      mediaRecorder.start(100);
      setIsRecording(true);
      setRecordingDuration(0);
      timerRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
    } catch (error: any) {
      console.error('Error starting recording:', error);
      toast.error(error?.message || 'Failed to start recording. Please check microphone permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  const cancelRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.ondataavailable = null;
      mediaRecorderRef.current.onstop = null;
      try { mediaRecorderRef.current.stop(); } catch {}
    }
    cleanup();
    setIsRecording(false);
    setRecordingDuration(0);
  };

  const cleanup = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    setAnalyserNode(null);
  };

  const discardPreview = () => {
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
      previewAudioRef.current = null;
    }
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewBlob(null);
    setPreviewUrl(null);
    setPreviewDuration(0);
    setIsPlaying(false);
    setPlaybackTime(0);
    setRecordingDuration(0);
  };

  const togglePlayback = () => {
    if (!previewUrl) return;
    if (!previewAudioRef.current) {
      const audio = new Audio(previewUrl);
      previewAudioRef.current = audio;
      audio.ontimeupdate = () => setPlaybackTime(audio.currentTime);
      audio.onended = () => {
        setIsPlaying(false);
        setPlaybackTime(0);
      };
    }
    if (isPlaying) {
      previewAudioRef.current.pause();
      setIsPlaying(false);
    } else {
      previewAudioRef.current.play();
      setIsPlaying(true);
    }
  };

  const confirmAndSend = async () => {
    if (!previewBlob) return;
    setIsUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const timestamp = Date.now();
      const randomId = Math.random().toString(36).substr(2, 9);
      const fileName = `voice-${timestamp}-${randomId}.${audioExtensionFor(previewBlob.type)}`;
      const filePath = `${user.id}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('voice-recordings')
        .upload(filePath, previewBlob, {
          contentType: previewBlob.type,
          upsert: false
        });
      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from('voice-recordings')
        .getPublicUrl(filePath);

      if (urlData?.publicUrl) {
        await onSendVoiceMessage(urlData.publicUrl, previewDuration);
        toast.success('Voice message sent!');
        discardPreview();
      } else {
        throw new Error('Failed to get public URL');
      }
    } catch (error: any) {
      console.error('Error sending voice message:', error);
      toast.error(`Failed to send voice message: ${error.message}`);
    } finally {
      setIsUploading(false);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    return () => {
      cleanup();
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      if (previewAudioRef.current) previewAudioRef.current.pause();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Uploading state
  if (isUploading) {
    return (
      <div className="flex items-center gap-2 px-4 py-2 bg-muted rounded-full">
        <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        <span className="text-xs text-muted-foreground">Sending...</span>
      </div>
    );
  }

  // Preview state — review before sending
  if (previewBlob) {
    return (
      <div className="flex items-center gap-2 px-3 py-2 bg-muted rounded-full border border-border">
        <Button
          variant="ghost"
          size="icon"
          className="w-8 h-8 rounded-full text-destructive hover:bg-destructive/10"
          onClick={discardPreview}
          aria-label="Discard recording"
        >
          <Trash2 className="w-4 h-4" />
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="w-9 h-9 rounded-full bg-foreground text-background hover:bg-foreground/90"
          onClick={togglePlayback}
          aria-label={isPlaying ? 'Pause' : 'Play'}
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
        </Button>

        <div className="flex-1 min-w-[80px] flex items-center">
          <div className="h-1 w-full bg-foreground/15 rounded-full overflow-hidden">
            <div
              className="h-full bg-foreground transition-all"
              style={{
                width: `${previewDuration ? Math.min(100, (playbackTime / previewDuration) * 100) : 0}%`
              }}
            />
          </div>
        </div>

        <span className="text-xs font-medium text-foreground min-w-[36px] text-right tabular-nums">
          {formatDuration(isPlaying ? playbackTime : previewDuration)}
        </span>

        <Button
          onClick={confirmAndSend}
          size="icon"
          className="w-9 h-9 rounded-full bg-primary text-primary-foreground hover:bg-primary/90"
          aria-label="Send voice message"
        >
          <ArrowUp className="w-4 h-4" />
        </Button>
      </div>
    );
  }

  // Recording state
  if (isRecording) {
    return (
      <div className="flex items-center gap-3 px-4 py-2 bg-pink-100 dark:bg-pink-900/30 rounded-full border border-pink-200 dark:border-pink-800">
        <Button
          variant="ghost"
          size="icon"
          className="w-8 h-8 rounded-full text-destructive hover:bg-destructive/10"
          onClick={cancelRecording}
          aria-label="Cancel recording"
        >
          <X className="w-4 h-4" />
        </Button>

        <DynamicWaveform
          analyserNode={analyserNode}
          isAnimating={true}
          barCount={20}
          className="flex-1 min-w-[80px]"
          barColor="bg-foreground/30"
          activeColor="bg-foreground"
        />

        <span className="text-sm font-medium text-foreground min-w-[40px] text-right tabular-nums">
          {formatDuration(recordingDuration)}
        </span>

        <Button
          onClick={stopRecording}
          size="icon"
          className="w-8 h-8 rounded-full bg-foreground text-background hover:bg-foreground/90"
          aria-label="Stop recording"
        >
          <Square className="w-3 h-3 fill-current" />
        </Button>
      </div>
    );
  }

  // Default - mic button
  return (
    <Button
      onClick={startRecording}
      disabled={disabled}
      variant="ghost"
      size="icon"
      className="w-10 h-10 rounded-full hover:bg-muted text-muted-foreground"
    >
      <Mic className="w-5 h-5" />
    </Button>
  );
};

export default ModernVoiceRecorder;
