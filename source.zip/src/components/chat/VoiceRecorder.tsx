
import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Mic, MicOff, Send, Trash2, Square } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { audioExtensionFor, getMicrophoneStream, pickAudioMimeType } from '@/utils/audioRecording';
import { toast } from 'sonner';

interface VoiceRecorderProps {
  onSendVoiceMessage: (voiceUrl: string, duration: number) => void;
  disabled?: boolean;
}

const VoiceRecorder: React.FC<VoiceRecorderProps> = ({ onSendVoiceMessage, disabled }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [hasRecording, setHasRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const startRecording = async () => {
    try {
      const stream = await getMicrophoneStream();
      
      streamRef.current = stream;
      
      const mimeType = pickAudioMimeType();
      const mediaRecorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };
      
      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { 
          type: mediaRecorder.mimeType || mimeType || 'audio/webm' 
        });
        
        // Auto-send the voice note immediately
        await autoSendVoiceNote(audioBlob);
        
        // Stop all tracks
        if (streamRef.current) {
          streamRef.current.getTracks().forEach(track => track.stop());
          streamRef.current = null;
        }
      };
      
      mediaRecorder.start(100); // Collect data every 100ms
      setIsRecording(true);
      setRecordingDuration(0);
      
      // Start timer
      timerRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
      
    } catch (error) {
      console.error('Error starting recording:', error);
      toast.error('Failed to start recording. Please check microphone permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  const cancelRecording = () => {
    if (isRecording) {
      stopRecording();
    }
    
    // Clean up
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
    }
    
    setHasRecording(false);
    setRecordingDuration(0);
    setAudioUrl(null);
    audioChunksRef.current = [];
  };

  const autoSendVoiceNote = async (audioBlob: Blob) => {
    setIsUploading(true);
    
    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('User not authenticated');
      }
      
      // Generate unique filename
      const timestamp = Date.now();
      const randomId = Math.random().toString(36).substr(2, 9);
      const fileName = `voice-${timestamp}-${randomId}.${audioExtensionFor(audioBlob.type)}`;
      const filePath = `${user.id}/${fileName}`;
      
      // Upload to Supabase Storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('voice-recordings')
        .upload(filePath, audioBlob, {
          contentType: audioBlob.type,
          upsert: false
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        throw uploadError;
      }

      // Get public URL
      const { data: urlData } = supabase.storage
        .from('voice-recordings')
        .getPublicUrl(filePath);

      if (urlData?.publicUrl) {
        await onSendVoiceMessage(urlData.publicUrl, recordingDuration);
        toast.success('Voice message sent!');
        
        // Reset state
        setRecordingDuration(0);
      } else {
        throw new Error('Failed to get public URL');
      }
      
    } catch (error) {
      console.error('Error sending voice message:', error);
      toast.error(`Failed to send voice message: ${error.message}`);
    } finally {
      setIsUploading(false);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, [audioUrl]);

  // If uploading, show a simple loading indicator
  if (isUploading) {
    return (
      <div className="flex items-center gap-2 px-3 py-2">
        <div className="w-4 h-4 border-2 border-green-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs text-gray-600">Sending...</span>
      </div>
    );
  }

  // Recording active state - Small compact canvas
  if (isRecording) {
    return (
      <div className="flex items-center gap-2 px-3 py-2 bg-red-50 rounded-full border border-red-200 shadow-sm">
        <div className="relative">
          <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
            <Mic className="w-4 h-4 text-red-600" />
          </div>
          <div className="absolute inset-0 rounded-full border-2 border-red-500 animate-ping opacity-50"></div>
        </div>
        
        {/* Small waveform */}
        <div className="flex items-center gap-0.5 h-4">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="w-0.5 bg-red-500 rounded-full animate-pulse"
              style={{
                height: `${8 + Math.sin((recordingDuration * 2 + i) * 0.5) * 6}px`,
                animationDelay: `${i * 0.1}s`,
              }}
            />
          ))}
        </div>
        
        <span className="text-xs font-mono text-red-600 min-w-[35px]">{formatDuration(recordingDuration)}</span>
        
        <Button
          onClick={stopRecording}
          size="sm"
          className="bg-red-600 hover:bg-red-700 text-white rounded-full w-6 h-6 p-0"
        >
          <Square className="w-3 h-3 fill-current" />
        </Button>
      </div>
    );
  }

  // Default state - record button
  return (
    <Button
      onClick={startRecording}
      disabled={disabled}
      size="sm"
      variant="outline"
      className="rounded-full w-12 h-12 p-0 border-2 border-green-200 hover:border-green-400 hover:bg-green-50 transition-all duration-200 hover:scale-110"
    >
      <Mic className="w-5 h-5 text-green-600" />
    </Button>
  );
};

export default VoiceRecorder;
