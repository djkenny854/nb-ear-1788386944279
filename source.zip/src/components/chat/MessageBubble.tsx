import React, { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Check, CheckCheck, Reply, Mic, MapPin, Trash2, Download, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import VoiceMessagePlayer from './VoiceMessagePlayer';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogTitle,
} from '@/components/ui/dialog';

interface MessageBubbleProps {
  message: {
    id: string;
    content: string;
    sender_id: string;
    created_at: string;
    is_read: boolean;
    is_voice_message?: boolean | null;
    voice_recording_url?: string | null;
    message_duration?: number | null;
    parent_message_id?: string | null;
    attachment_url?: string | null;
    attachment_type?: string | null;
    location_data?: any;
  };
  isCurrentUser: boolean;
  senderInfo?: {
    name: string;
    avatar?: string;
  };
  onReply?: (message: any) => void;
  parentMessage?: any;
  onDelete?: (messageId: string, deleteForEveryone: boolean) => void;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({
  message,
  isCurrentUser,
  senderInfo,
  onReply,
  parentMessage,
  onDelete
}) => {
  const [showDeleteMenu, setShowDeleteMenu] = useState(false);
  const [showImageDialog, setShowImageDialog] = useState(false);

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getInitials = (name?: string) => {
    return name?.split(' ').map(word => word.charAt(0)).join('').toUpperCase().slice(0, 2) || 'U';
  };
  
  const handleDownloadImage = async () => {
    if (!message.attachment_url) return;
    try {
      const response = await fetch(message.attachment_url);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `image-${Date.now()}.jpg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading image:', error);
    }
  };

  const isImageAttachment = message.attachment_type?.startsWith('image/');
  const hasLocation = message.location_data?.lat && message.location_data?.lng;

  // Build Google Maps URL with proper parameters
  const getGoogleMapsUrl = () => {
    const { lat, lng } = message.location_data;
    return `https://www.google.com/maps?q=${lat},${lng}&z=15`;
  };

  // Google Maps embed URL for iframe preview
  const getMapEmbedUrl = () => {
    const { lat, lng } = message.location_data;
    return `https://www.google.com/maps?q=${lat},${lng}&z=15&output=embed`;
  };

  // Action buttons component - shared between message types
  const ActionButtons = () => (
    <div className={cn(
      "absolute -top-9 opacity-0 group-hover:opacity-100 transition-opacity z-10 flex items-center gap-1 bg-card border border-border rounded-lg shadow-md px-1 py-0.5",
      isCurrentUser ? "right-0" : "left-0"
    )}>
      <Button
        onClick={() => onReply?.(message)}
        size="sm"
        variant="ghost"
        className="p-1.5 h-7 hover:bg-muted"
      >
        <Reply className="w-3.5 h-3.5" />
      </Button>
      
      {isImageAttachment && message.attachment_url && (
        <Button
          onClick={handleDownloadImage}
          size="sm"
          variant="ghost"
          className="p-1.5 h-7 hover:bg-muted"
        >
          <Download className="w-3.5 h-3.5" />
        </Button>
      )}
      
      {onDelete && (
        <DropdownMenu open={showDeleteMenu} onOpenChange={setShowDeleteMenu}>
          <DropdownMenuTrigger asChild>
            <Button
              size="sm"
              variant="ghost"
              className="p-1.5 h-7 hover:bg-muted"
            >
              <Trash2 className="w-3.5 h-3.5 text-destructive" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align={isCurrentUser ? "end" : "start"}>
            <DropdownMenuItem onClick={() => onDelete(message.id, false)}>
              Delete for me
            </DropdownMenuItem>
            {isCurrentUser && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={() => onDelete(message.id, true)}
                  className="text-destructive"
                >
                  Delete for everyone
                </DropdownMenuItem>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      )}
    </div>
  );

  return (
    <>
      {/* Image Expand Dialog */}
      <Dialog open={showImageDialog} onOpenChange={setShowImageDialog}>
        <DialogContent className="max-w-3xl p-0 bg-black/90 border-0">
          <DialogTitle className="sr-only">Image Preview</DialogTitle>
          <div className="relative">
            <Button
              onClick={() => setShowImageDialog(false)}
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 z-10 text-white hover:bg-white/20"
            >
              <X className="w-5 h-5" />
            </Button>
            <img
              src={message.attachment_url || ''}
              alt="Full size attachment"
              className="w-full max-h-[80vh] object-contain"
            />
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
              <Button
                onClick={handleDownloadImage}
                variant="secondary"
                className="gap-2"
              >
                <Download className="w-4 h-4" />
                Save Image
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    
      <div className={cn("flex mb-3", isCurrentUser ? "justify-end" : "justify-start")}>
        <div className={cn("flex gap-2.5 max-w-[85%] md:max-w-md", isCurrentUser ? "flex-row-reverse" : "flex-row")}>
          {!isCurrentUser && (
            <Avatar className="w-8 h-8 mt-1 flex-shrink-0">
              <AvatarImage src={senderInfo?.avatar} />
              <AvatarFallback className="bg-gradient-to-br from-primary to-orange-400 text-primary-foreground text-xs">
                {getInitials(senderInfo?.name)}
              </AvatarFallback>
            </Avatar>
          )}
          
          <div className="flex flex-col relative group">
            {/* Action buttons - outside the message bubble */}
            <ActionButtons />
            
            {/* Reply context */}
            {parentMessage && (
              <div className={cn(
                "text-xs p-2 mb-1 rounded-lg",
                isCurrentUser 
                  ? "bg-primary/10 border-r-2 border-primary" 
                  : "bg-muted border-l-2 border-muted-foreground/30"
              )}>
                <div className="flex items-center gap-1 mb-1">
                  <Reply className="w-3 h-3 text-muted-foreground" />
                  <span className="font-medium text-muted-foreground">
                    {parentMessage.sender_id === message.sender_id ? 'You' : senderInfo?.name}
                  </span>
                </div>
                {parentMessage.is_voice_message ? (
                  <div className="flex items-center gap-1">
                    <Mic className="w-3 h-3 text-muted-foreground" />
                    <span className="text-muted-foreground">Voice message</span>
                  </div>
                ) : (
                  <p className="text-muted-foreground truncate">{parentMessage.content}</p>
                )}
              </div>
            )}

            <div
              className={cn(
                "relative",
                message.is_voice_message 
                  ? "p-0"
                  : isImageAttachment || hasLocation
                  ? "rounded-2xl overflow-hidden"
                  : (isCurrentUser
                      ? "px-4 py-2.5 bg-primary text-primary-foreground rounded-2xl rounded-br-md"
                      : "px-4 py-2.5 bg-card text-foreground rounded-2xl rounded-bl-md shadow-sm border border-border")
              )}
            >
              {/* Image Attachment - Clickable to expand */}
              {isImageAttachment && message.attachment_url && (
                <div 
                  className={cn(
                    "rounded-2xl overflow-hidden cursor-pointer",
                    isCurrentUser ? "bg-primary" : "bg-card border border-border"
                  )}
                  onClick={() => setShowImageDialog(true)}
                >
                  <img 
                    src={message.attachment_url} 
                    alt="Attachment" 
                    className="max-w-full max-h-64 object-cover hover:opacity-90 transition-opacity"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/placeholder.svg';
                    }}
                  />
                  <div className={cn(
                    "px-3 py-1.5 flex items-center justify-end gap-1.5",
                    isCurrentUser ? "text-primary-foreground/70" : "text-muted-foreground"
                  )}>
                    <span className="text-[10px]">{formatTime(message.created_at)}</span>
                    {isCurrentUser && (
                      <div className="flex">
                        {message.is_read ? (
                          <CheckCheck className="w-3.5 h-3.5" />
                        ) : (
                          <Check className="w-3.5 h-3.5" />
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}

            {/* Location with Map Preview */}
            {hasLocation && (
              <a 
                href={getGoogleMapsUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="block"
              >
                <div className={cn(
                  "rounded-2xl overflow-hidden",
                  isCurrentUser ? "bg-primary" : "bg-card border border-border"
                )}>
                  {/* Map Preview using Google Maps iframe */}
                  <div className="relative w-[280px] h-[150px] overflow-hidden">
                    <iframe 
                      src={getMapEmbedUrl()}
                      width="280"
                      height="150"
                      style={{ border: 0 }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      className="w-full h-full"
                    />
                    {/* Fading edges overlay */}
                    <div className="absolute inset-0 pointer-events-none"
                      style={{
                        background: `linear-gradient(to bottom, transparent 85%, ${isCurrentUser ? 'hsl(var(--primary))' : 'hsl(var(--card))'} 100%)`
                      }}
                    />
                  </div>
                  
                  <div className={cn(
                    "p-3 flex items-start gap-2",
                    isCurrentUser ? "text-primary-foreground" : "text-foreground"
                  )}>
                    <MapPin className={cn("w-4 h-4 flex-shrink-0 mt-0.5", isCurrentUser ? "text-primary-foreground" : "text-primary")} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">Shared Location</p>
                      <p className={cn("text-xs line-clamp-2", isCurrentUser ? "text-primary-foreground/70" : "text-muted-foreground")}>
                        {message.location_data.address}
                      </p>
                    </div>
                  </div>
                  
                  <div className={cn(
                    "px-3 pb-2 flex items-center justify-end gap-1.5",
                    isCurrentUser ? "text-primary-foreground/70" : "text-muted-foreground"
                  )}>
                    <span className="text-[10px]">{formatTime(message.created_at)}</span>
                    {isCurrentUser && (
                      <div className="flex">
                        {message.is_read ? (
                          <CheckCheck className="w-3.5 h-3.5" />
                        ) : (
                          <Check className="w-3.5 h-3.5" />
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </a>
            )}

            {/* Voice Message */}
            {message.is_voice_message && message.voice_recording_url ? (
              <VoiceMessagePlayer
                audioUrl={message.voice_recording_url}
                duration={message.message_duration}
                isCurrentUser={isCurrentUser}
              />
            ) : !isImageAttachment && !hasLocation && (
              <>
                <p className="text-sm leading-relaxed">{message.content}</p>
                
                {/* Time and status */}
                <div className={cn(
                  "flex items-center justify-end gap-1.5 mt-1.5",
                  isCurrentUser ? "text-primary-foreground/70" : "text-muted-foreground"
                )}>
                  <span className="text-[10px]">{formatTime(message.created_at)}</span>
                  {isCurrentUser && (
                    <div className="flex">
                      {message.is_read ? (
                        <CheckCheck className="w-3.5 h-3.5" />
                      ) : (
                        <Check className="w-3.5 h-3.5" />
                      )}
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default MessageBubble;