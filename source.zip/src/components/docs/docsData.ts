import React from 'react';
import {
  Rocket, HelpCircle, UserPlus, FileText, ShieldCheck, Settings, AlertTriangle, CreditCard,
  Apple, Smartphone, QrCode, Store, Grid3X3, Star, Sparkles, TrendingUp,
  LayoutDashboard, PlusCircle, BarChart3, BadgeCheck, Phone, Lightbulb, Image
} from 'lucide-react';

export interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  category?: string;
}

export const navItems: NavItem[] = [
  // Getting Started
  { id: 'get-started', label: 'Get Started', icon: Rocket, category: 'Getting Started' },
  { id: 'how-it-works', label: 'How It Works', icon: HelpCircle },
  { id: 'create-account', label: 'Create Account', icon: UserPlus },
  { id: 'post-first-ad', label: 'Post Your First Ad', icon: FileText },
  { id: 'verification-guide', label: 'Verification Guide', icon: ShieldCheck },
  { id: 'account-setup', label: 'Account Setup', icon: Settings },
  { id: 'safety-tips', label: 'Safety Tips', icon: AlertTriangle },
  { id: 'payment-methods', label: 'Payment Methods', icon: CreditCard },
  // Downloads
  { id: 'download-ios', label: 'Download iOS', icon: Apple, category: 'Download App' },
  { id: 'download-android', label: 'Download Android', icon: Smartphone },
  { id: 'scan-qr', label: 'Scan QR Code', icon: QrCode },
  // Marketplace
  { id: 'all-categories', label: 'All Categories', icon: Grid3X3, category: 'Marketplace' },
  { id: 'featured-items', label: 'Featured Items', icon: Star },
  { id: 'new-arrivals', label: 'New Arrivals', icon: Sparkles },
  { id: 'best-sellers', label: 'Top Sellers', icon: TrendingUp },
  // Seller Dashboard
  { id: 'seller-dashboard', label: 'Seller Dashboard', icon: LayoutDashboard, category: 'For Businesses' },
  { id: 'post-an-ad', label: 'Post an Ad', icon: PlusCircle },
  { id: 'analytics', label: 'Performance', icon: BarChart3 },
  { id: 'become-seller', label: 'Create Business Account', icon: BadgeCheck },
  // Help Center
  { id: 'contact-us', label: 'Contact Us', icon: Phone, category: 'Help Center' },
  { id: 'trading-tips', label: 'Trading Tips', icon: Lightbulb },
  // Banners
  { id: 'banner-advertising', label: 'Banner Advertising', icon: Image, category: 'Advertising' },
];

export const sectionTOC: Record<string, { id: string; title: string }[]> = {
  'get-started': [
    { id: 'welcome', title: 'Welcome' },
    { id: 'quick-steps', title: 'Quick Steps' },
    { id: 'why-choose', title: 'Why Choose EarlyMarket?' },
  ],
  'how-it-works': [
    { id: 'browse', title: 'Browse or Search' },
    { id: 'connect', title: 'Connect with Sellers' },
    { id: 'complete', title: 'Complete Transaction' },
    { id: 'review', title: 'Leave a Review' },
  ],
  'create-account': [
    { id: 'registration', title: 'Registration Steps' },
    { id: 'phone-email', title: 'Phone or Email' },
    { id: 'verification', title: 'Verify Account' },
    { id: 'complete-profile', title: 'Complete Profile' },
  ],
  'post-first-ad': [
    { id: 'photos', title: 'Add Great Photos' },
    { id: 'descriptions', title: 'Write Clear Descriptions' },
    { id: 'pricing', title: 'Set the Right Price' },
    { id: 'category', title: 'Choose the Right Category' },
  ],
  'verification-guide': [
    { id: 'basic', title: 'Phone Verification' },
    { id: 'standard', title: 'ID Verification' },
    { id: 'premium', title: 'Business Verification' },
  ],
  'account-setup': [
    { id: 'profile-info', title: 'Profile Information' },
    { id: 'preferences', title: 'Notification Preferences' },
    { id: 'security', title: 'Security Settings' },
  ],
  'safety-tips': [
    { id: 'meet-safely', title: 'Meeting Safely' },
    { id: 'payment-safety', title: 'Payment Safety' },
    { id: 'report-issues', title: 'Report Issues' },
  ],
  'payment-methods': [
    { id: 'mobile-money', title: 'Mobile Money' },
    { id: 'bank-transfer', title: 'Bank Transfer' },
    { id: 'cash-delivery', title: 'Cash on Delivery' },
  ],
  'seller-dashboard': [
    { id: 'overview', title: 'Dashboard Overview' },
    { id: 'manage-listings', title: 'Manage Listings' },
    { id: 'orders', title: 'Orders & Messages' },
  ],
  'analytics': [
    { id: 'views', title: 'Views & Impressions' },
    { id: 'engagement', title: 'Engagement Metrics' },
    { id: 'performance', title: 'Performance Tips' },
  ],
  'become-seller': [
    { id: 'regular', title: 'Regular User' },
    { id: 'business', title: 'Business Account' },
    { id: 'organization', title: 'Organization Account' },
  ],
};

export const getCategory = (activeSection: string): string => {
  let currentCategory = 'Getting Started';
  for (const item of navItems) {
    if (item.category) currentCategory = item.category;
    if (item.id === activeSection) return currentCategory;
  }
  return currentCategory;
};
