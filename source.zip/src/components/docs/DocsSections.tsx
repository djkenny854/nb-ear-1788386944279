import React from 'react';
import {
  Rocket, HelpCircle, UserPlus, FileText, ShieldCheck, AlertTriangle,
  Star, Sparkles, CheckCircle2, ArrowRight, Users, Shield, Clock, Image,
  Smartphone, Apple, QrCode, Download, CreditCard, Lightbulb, PlusCircle,
  BarChart3, Phone, Mail, MapPin, Package, MessageSquare, Eye, Heart, MessageCircle, Bookmark, Zap, Crown, Cloud, AtSign, Video, Calendar, FileSignature
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { cn } from '@/lib/utils';
import { ChevronDown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import EMIIcon from '@/components/icons/EMIIcon';

interface CollapsibleSectionProps {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
  icon?: React.ReactNode;
}

const CollapsibleSection: React.FC<CollapsibleSectionProps> = ({
  title, children, defaultOpen = true, icon
}) => {
  const [isOpen, setIsOpen] = React.useState(defaultOpen);
  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen} className="border border-border rounded-lg overflow-hidden">
      <CollapsibleTrigger className="flex items-center justify-between w-full p-4 bg-muted/30 hover:bg-muted/50 transition-colors">
        <div className="flex items-center gap-2">
          {icon}
          <span className="font-semibold text-lg">{title}</span>
        </div>
        <ChevronDown className={cn("w-5 h-5 transition-transform duration-200", isOpen && "rotate-180")} />
      </CollapsibleTrigger>
      <CollapsibleContent className="p-4 bg-background">{children}</CollapsibleContent>
    </Collapsible>
  );
};

interface DocsSectionsProps {
  activeSection: string;
  onNavigate: (section: string) => void;
}

const DocsSections: React.FC<DocsSectionsProps> = ({ activeSection, onNavigate }) => {
  const navigate = useNavigate();

  // Fetch real category counts
  const { data: categories } = useQuery({
    queryKey: ['docs-categories'],
    queryFn: async () => {
      const systemCategories = ['Boosted Listings', 'Featured Ads', 'Reports / Violations', 'Sponsored Categories'];
      const { data: cats } = await supabase.from('categories').select('name, id').eq('is_active', true);
      const filtered = (cats || []).filter(c => !systemCategories.includes(c.name));

      // Get counts per category
      const withCounts = await Promise.all(filtered.map(async (cat) => {
        const { count } = await supabase.from('ads').select('*', { count: 'exact', head: true }).eq('category', cat.name).eq('status', 'active');
        return { name: cat.name, count: count || 0 };
      }));
      return withCounts;
    },
    staleTime: 5 * 60 * 1000,
  });

  const getCategoryIcon = (name: string): string => {
    const icons: Record<string, string> = {
      'Electronics': '📱', 'Vehicles': '🚗', 'Property': '🏠', 'Fashion': '👕',
      'Home, Furniture & Appliances': '🏡', 'Jobs & Services': '💼', 'Agriculture': '🌾',
      'Health & Beauty': '💄', 'Books, Sports & Hobbies': '📚', 'Animals & Pets': '🐕',
      'Computing': '💻', 'Babies & Kids': '👶', 'Beauty & Cosmetics': '💅',
      'Construction & Repair': '🔧', 'Education': '🎓', 'Energy & Utilities': '⚡',
      'Entertainment & Media': '🎬', 'Financial Services': '💰', 'Industrial Equipment': '🏭',
      'Art, Design & Photography': '🎨', 'Supermarket / Groceries': '🛒', 'Travel & Luggage': '✈️',
    };
    return icons[name] || '📦';
  };

  switch (activeSection) {
    case 'get-started':
      return (
        <div className="space-y-6">
          <div id="toc-welcome" className="scroll-mt-24">
            <Badge variant="secondary" className="mb-4">Quick Start</Badge>
            <h1 className="text-3xl font-bold mb-4">Welcome to EarlyMarket</h1>
            <p className="text-muted-foreground text-lg">
              EarlyMarket is Uganda's leading marketplace for buying and selling products, services, and more.
              Get started in just a few minutes — completely free!
            </p>
          </div>
          <CollapsibleSection title="Quick Steps to Get Started" icon={<Rocket className="w-5 h-5 text-primary" />}>
            <div id="toc-quick-steps" className="grid md:grid-cols-3 gap-4 scroll-mt-24">
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => onNavigate('create-account')}>
                <CardHeader>
                  <UserPlus className="w-10 h-10 text-primary mb-2" />
                  <CardTitle>1. Create Account</CardTitle>
                  <CardDescription>Sign up for free in under 2 minutes</CardDescription>
                </CardHeader>
              </Card>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => onNavigate('verification-guide')}>
                <CardHeader>
                  <ShieldCheck className="w-10 h-10 text-primary mb-2" />
                  <CardTitle>2. Get Verified</CardTitle>
                  <CardDescription>Build trust with verification badges</CardDescription>
                </CardHeader>
              </Card>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => onNavigate('post-first-ad')}>
                <CardHeader>
                  <FileText className="w-10 h-10 text-primary mb-2" />
                  <CardTitle>3. Start Listing</CardTitle>
                  <CardDescription>Post products, services, jobs & more</CardDescription>
                </CardHeader>
              </Card>
            </div>
          </CollapsibleSection>
          <CollapsibleSection title="Why Choose EarlyMarket?" icon={<Star className="w-5 h-5 text-primary" />}>
            <div id="toc-why-choose" className="scroll-mt-24">
              <ul className="space-y-3">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-green-500" /><span>Completely free to use — no hidden fees</span></li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-green-500" /><span>Verified sellers for safe transactions</span></li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-green-500" /><span>AI-powered features to help you buy and sell smarter</span></li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-green-500" /><span>Multiple listing types: Products, Services, Jobs, Events & Promotions</span></li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-green-500" /><span>Built-in messaging and direct communication</span></li>
              </ul>
            </div>
          </CollapsibleSection>
        </div>
      );

    case 'how-it-works':
      return (
        <div className="space-y-6">
          <div id="toc-browse" className="scroll-mt-24">
            <Badge variant="secondary" className="mb-4">Overview</Badge>
            <h1 className="text-3xl font-bold mb-4">How EarlyMarket Works</h1>
            <p className="text-muted-foreground text-lg">Understanding our platform is simple. Here's how buyers and sellers connect.</p>
          </div>
          <CollapsibleSection title="Step-by-Step Process" icon={<HelpCircle className="w-5 h-5 text-primary" />}>
            <div className="space-y-6">
              {[
                { id: 'browse', num: 1, title: 'Browse or Search', desc: 'Use our powerful search and category filters to find exactly what you\'re looking for. Browse listings from verified sellers.' },
                { id: 'connect', num: 2, title: 'Connect with Sellers', desc: 'Use our built-in chat system to communicate directly with sellers. Ask questions, negotiate prices, and arrange viewings.' },
                { id: 'complete', num: 3, title: 'Complete Transaction', desc: 'Choose from multiple payment options including Mobile Money, bank transfer, or cash on delivery.' },
                { id: 'review', num: 4, title: 'Leave a Review', desc: 'Help the community by leaving honest reviews. Your feedback helps maintain quality and trust.' },
              ].map(step => (
                <div key={step.id} id={`toc-${step.id}`} className="flex gap-4 scroll-mt-24">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-xl">{step.num}</div>
                  <div>
                    <h3 className="font-semibold text-xl mb-2">{step.title}</h3>
                    <p className="text-muted-foreground">{step.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </CollapsibleSection>
        </div>
      );

    case 'create-account':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Account</Badge>
            <h1 className="text-3xl font-bold mb-4">Create Your Account</h1>
            <p className="text-muted-foreground text-lg">Join EarlyMarket for free. Creating an account takes less than 2 minutes.</p>
          </div>
          <Card className="mt-6">
            <CardHeader><CardTitle>Registration Steps</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              {[
                { num: '1', title: 'Enter Your Phone Number or Email', desc: 'We\'ll send you a verification code to confirm your identity.' },
                { num: '2', title: 'Verify Your Account', desc: 'Enter the 6-digit code sent to your phone or email.' },
                { num: '3', title: 'Complete Your Profile', desc: 'Add your name, location, and profile picture to build trust.' },
              ].map((step, i) => (
                <React.Fragment key={step.num}>
                  {i > 0 && <Separator />}
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm font-medium">{step.num}</div>
                    <div><h4 className="font-medium">{step.title}</h4><p className="text-sm text-muted-foreground">{step.desc}</p></div>
                  </div>
                </React.Fragment>
              ))}
              <Separator />
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-green-500/10 text-green-500 flex items-center justify-center"><CheckCircle2 className="w-5 h-5" /></div>
                <div><h4 className="font-medium">Start Using EarlyMarket!</h4><p className="text-sm text-muted-foreground">Browse listings, save favorites, and start buying or selling.</p></div>
              </div>
            </CardContent>
          </Card>
          <Button size="lg" className="mt-4" onClick={() => navigate('/auth')}>Create Account Now <ArrowRight className="ml-2 w-4 h-4" /></Button>
        </div>
      );

    case 'post-first-ad':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Selling</Badge>
            <h1 className="text-3xl font-bold mb-4">Post Your First Ad</h1>
            <p className="text-muted-foreground text-lg">Learn how to create compelling listings that attract buyers.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-6 mt-8">
            {[
              { icon: <Image className="w-5 h-5" />, title: 'Add Great Photos', tips: ['Use natural lighting for clear photos', 'Include multiple angles of your item', 'Show any defects honestly', 'Upload at least 3-5 photos'] },
              { icon: <FileText className="w-5 h-5" />, title: 'Write Clear Descriptions', tips: ['Include brand, model, and condition', 'List key features and specifications', 'Mention what\'s included in the sale', 'Be honest about any issues'] },
              { icon: <CreditCard className="w-5 h-5" />, title: 'Set the Right Price', tips: ['Research similar listings for pricing', 'Consider the item\'s condition', 'Factor in negotiation room', 'Use "Negotiable" tag if flexible'] },
              { icon: <Grid3X3 className="w-5 h-5" />, title: 'Choose the Right Category', tips: ['Select the most relevant category', 'Use subcategories for better visibility', 'Add relevant tags and keywords', 'Review similar successful listings'] },
            ].map(card => (
              <Card key={card.title}>
                <CardHeader><CardTitle className="flex items-center gap-2">{card.icon}{card.title}</CardTitle></CardHeader>
                <CardContent><ul className="space-y-2 text-sm text-muted-foreground">{card.tips.map(t => <li key={t}>• {t}</li>)}</ul></CardContent>
              </Card>
            ))}
          </div>
        </div>
      );

    case 'verification-guide':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Trust & Safety</Badge>
            <h1 className="text-3xl font-bold mb-4">Verification Guide</h1>
            <p className="text-muted-foreground text-lg">Get verified to build trust with buyers and unlock premium features.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-4 mt-8">
            <Card className="border-blue-200 bg-blue-50/50 dark:border-blue-900 dark:bg-blue-950/20">
              <CardHeader><Badge className="w-fit bg-blue-500">Basic</Badge><CardTitle className="mt-2">Phone Verification</CardTitle></CardHeader>
              <CardContent><ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-blue-500" />Verify phone number</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-blue-500" />Basic trust badge</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-blue-500" />Post up to 5 ads</li>
              </ul></CardContent>
            </Card>
            <Card className="border-amber-200 bg-amber-50/50 dark:border-amber-900 dark:bg-amber-950/20">
              <CardHeader><Badge className="w-fit bg-amber-500">Standard</Badge><CardTitle className="mt-2">ID Verification</CardTitle></CardHeader>
              <CardContent><ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-amber-500" />Upload National ID</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-amber-500" />Verified seller badge</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-amber-500" />Post up to 20 ads</li>
              </ul></CardContent>
            </Card>
            <Card className="border-green-200 bg-green-50/50 dark:border-green-900 dark:bg-green-950/20">
              <CardHeader><Badge className="w-fit bg-green-500">Premium</Badge><CardTitle className="mt-2">Business Verification</CardTitle></CardHeader>
              <CardContent><ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-green-500" />Business registration</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-green-500" />Premium seller badge</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-green-500" />Unlimited ads</li>
              </ul></CardContent>
            </Card>
          </div>
          <Button size="lg" className="mt-6" onClick={() => navigate('/verification')}>Start Verification <ArrowRight className="ml-2 w-4 h-4" /></Button>
        </div>
      );

    case 'account-setup':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Settings</Badge>
            <h1 className="text-3xl font-bold mb-4">Account Setup</h1>
            <p className="text-muted-foreground text-lg">Configure your account for the best EarlyMarket experience.</p>
          </div>
          <div className="space-y-4 mt-8">
            <Card>
              <CardHeader><CardTitle>Profile Settings</CardTitle><CardDescription>Customize how others see you on the platform</CardDescription></CardHeader>
              <CardContent className="space-y-3">
                {[{ label: 'Profile Picture', badge: 'Recommended' }, { label: 'Display Name', badge: 'Required' }, { label: 'Bio', badge: 'Optional' }, { label: 'Location', badge: 'Recommended' }].map(i => (
                  <div key={i.label} className="flex justify-between items-center"><span>{i.label}</span><Badge variant="outline">{i.badge}</Badge></div>
                ))}
              </CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle>Notification Preferences</CardTitle><CardDescription>Control what notifications you receive</CardDescription></CardHeader>
              <CardContent className="space-y-3">
                {[{ label: 'New Messages', on: true }, { label: 'Price Drops', on: true }, { label: 'Promotions', on: false }].map(i => (
                  <div key={i.label} className="flex justify-between items-center"><span>{i.label}</span><Badge className={i.on ? "bg-green-500" : ""} variant={i.on ? "default" : "outline"}>{i.on ? 'Enabled' : 'Optional'}</Badge></div>
                ))}
              </CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle>Privacy & Security</CardTitle><CardDescription>Manage your security settings</CardDescription></CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center"><span>Two-Factor Authentication</span><Badge variant="outline">Recommended</Badge></div>
                <div className="flex justify-between items-center"><span>Login Alerts</span><Badge className="bg-green-500">Enabled</Badge></div>
                <div className="flex justify-between items-center"><span>Show Followers & Following</span><Badge variant="outline">Configurable</Badge></div>
              </CardContent>
            </Card>
          </div>
        </div>
      );

    case 'safety-tips':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="destructive" className="mb-4">Important</Badge>
            <h1 className="text-3xl font-bold mb-4">Safety Tips</h1>
            <p className="text-muted-foreground text-lg">Stay safe while buying and selling on EarlyMarket.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-6 mt-8">
            <Card className="border-red-200 dark:border-red-900">
              <CardHeader><CardTitle className="flex items-center gap-2 text-red-600 dark:text-red-400"><AlertTriangle className="w-5 h-5" />Things to Avoid</CardTitle></CardHeader>
              <CardContent><ul className="space-y-3 text-sm">
                {['Never send money before receiving the item', 'Don\'t share personal banking details', 'Avoid deals that seem too good to be true', 'Never meet in private or unsafe locations', 'Don\'t click on suspicious external links'].map(t => (
                  <li key={t} className="flex items-start gap-2"><span className="text-red-500 mt-1">✗</span>{t}</li>
                ))}
              </ul></CardContent>
            </Card>
            <Card className="border-green-200 dark:border-green-900">
              <CardHeader><CardTitle className="flex items-center gap-2 text-green-600 dark:text-green-400"><Shield className="w-5 h-5" />Best Practices</CardTitle></CardHeader>
              <CardContent><ul className="space-y-3 text-sm">
                {['Meet in public places during daylight', 'Use EarlyMarket\'s secure chat system', 'Check seller verification badges', 'Read reviews before transacting', 'Use Mobile Money for secure payments'].map(t => (
                  <li key={t} className="flex items-start gap-2"><span className="text-green-500 mt-1">✓</span>{t}</li>
                ))}
              </ul></CardContent>
            </Card>
          </div>
          <Card className="bg-amber-50 border-amber-200 dark:bg-amber-950/20 dark:border-amber-900">
            <CardContent className="p-6">
              <h3 className="font-semibold text-amber-800 dark:text-amber-200 mb-2">Report Suspicious Activity</h3>
              <p className="text-sm text-amber-700 dark:text-amber-300">If you encounter any suspicious behavior, report it immediately through our Help Center or contact our support team.</p>
              <Button variant="outline" className="mt-4 border-amber-500 text-amber-700 hover:bg-amber-100 dark:text-amber-300 dark:hover:bg-amber-900" onClick={() => navigate('/report')}>Report an Issue</Button>
            </CardContent>
          </Card>
        </div>
      );

    case 'payment-methods':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Payments</Badge>
            <h1 className="text-3xl font-bold mb-4">Payment Methods</h1>
            <p className="text-muted-foreground text-lg">EarlyMarket supports multiple payment options for your convenience.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-6 mt-8">
            {[
              { icon: <Smartphone className="w-5 h-5 text-yellow-500" />, title: 'Mobile Money', badge: 'Recommended', desc: 'The most popular payment method in Uganda.', items: ['MTN Mobile Money', 'Airtel Money', 'Instant transfers', 'Transaction records for disputes'] },
              { icon: <CreditCard className="w-5 h-5 text-blue-500" />, title: 'Bank Transfer', desc: 'Secure bank-to-bank transfers for larger transactions.', items: ['All major Ugandan banks', 'RTGS for same-day transfers', 'Visa/Mastercard debit cards', 'International transfers available'] },
              { icon: <Clock className="w-5 h-5 text-purple-500" />, title: 'Cash on Delivery', desc: 'Pay when you receive your item.', items: ['Available within Kampala', 'Inspect before paying', 'Delivery fees may apply', 'Selected sellers only'] },
              { icon: <Users className="w-5 h-5 text-orange-500" />, title: 'In-Person Payment', desc: 'Meet the seller and pay directly.', items: ['Cash payments accepted', 'Mobile Money on the spot', 'Meet in safe locations', 'Verify item before paying'] },
            ].map(method => (
              <Card key={method.title}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">{method.icon}{method.title}</CardTitle>
                  {method.badge && <Badge className="w-fit bg-green-500">{method.badge}</Badge>}
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">{method.desc}</p>
                  <ul className="space-y-2 text-sm">{method.items.map(i => <li key={i}>• {i}</li>)}</ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      );

    case 'download-ios':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Mobile App</Badge>
            <h1 className="text-3xl font-bold mb-4">Download for iOS</h1>
            <p className="text-muted-foreground text-lg">The EarlyMarket iOS app is currently under development.</p>
          </div>
          <Card className="max-w-md mt-8 border-amber-200 dark:border-amber-800">
            <CardContent className="p-8 text-center">
              <Apple className="w-20 h-20 mx-auto mb-6 text-foreground" />
              <h3 className="text-xl font-semibold mb-2">EarlyMarket for iOS</h3>
              <Badge variant="outline" className="mb-4 text-amber-600 border-amber-400">Coming Soon</Badge>
              <p className="text-muted-foreground mb-6">The iOS app is currently in development. In the meantime, you can use EarlyMarket on your mobile browser for the full experience.</p>
              <Button size="lg" className="w-full" variant="outline" disabled>
                <Download className="mr-2 w-5 h-5" />
                Not Yet Available
              </Button>
              <p className="text-xs text-muted-foreground mt-4">We'll announce the launch on our social media channels</p>
            </CardContent>
          </Card>
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-6">
              <h3 className="font-semibold mb-2">Use the Web App</h3>
              <p className="text-sm text-muted-foreground mb-4">While we build the native app, you can add EarlyMarket to your home screen for a native-like experience:</p>
              <ol className="space-y-2 text-sm text-muted-foreground">
                <li>1. Open EarlyMarket in Safari on your iPhone</li>
                <li>2. Tap the Share button (square with arrow)</li>
                <li>3. Scroll down and tap "Add to Home Screen"</li>
                <li>4. Tap "Add" to confirm</li>
              </ol>
            </CardContent>
          </Card>
        </div>
      );

    case 'download-android':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Mobile App</Badge>
            <h1 className="text-3xl font-bold mb-4">Download for Android</h1>
            <p className="text-muted-foreground text-lg">The EarlyMarket Android app is currently under development.</p>
          </div>
          <Card className="max-w-md mt-8 border-amber-200 dark:border-amber-800">
            <CardContent className="p-8 text-center">
              <Smartphone className="w-20 h-20 mx-auto mb-6 text-green-500" />
              <h3 className="text-xl font-semibold mb-2">EarlyMarket for Android</h3>
              <Badge variant="outline" className="mb-4 text-amber-600 border-amber-400">Coming Soon</Badge>
              <p className="text-muted-foreground mb-6">The Android app is in active development. Use EarlyMarket on your mobile browser for now.</p>
              <Button size="lg" className="w-full" variant="outline" disabled>
                <Download className="mr-2 w-5 h-5" />
                Not Yet Available
              </Button>
              <p className="text-xs text-muted-foreground mt-4">We'll announce the launch on our social media channels</p>
            </CardContent>
          </Card>
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-6">
              <h3 className="font-semibold mb-2">Use the Web App</h3>
              <p className="text-sm text-muted-foreground mb-4">Add EarlyMarket to your home screen for a native-like experience:</p>
              <ol className="space-y-2 text-sm text-muted-foreground">
                <li>1. Open EarlyMarket in Chrome on your Android device</li>
                <li>2. Tap the three-dot menu (⋮)</li>
                <li>3. Tap "Add to Home screen"</li>
                <li>4. Tap "Add" to confirm</li>
              </ol>
            </CardContent>
          </Card>
        </div>
      );

    case 'scan-qr':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Quick Access</Badge>
            <h1 className="text-3xl font-bold mb-4">Scan QR Code</h1>
            <p className="text-muted-foreground text-lg">Scan the QR code below to open EarlyMarket on your mobile device.</p>
          </div>
          <Card className="max-w-sm mx-auto mt-8">
            <CardContent className="p-8 text-center">
              <div className="w-48 h-48 mx-auto mb-6 bg-muted rounded-lg flex items-center justify-center">
                <QrCode className="w-32 h-32 text-foreground" />
              </div>
              <h3 className="font-semibold mb-2">Scan to Open</h3>
              <p className="text-sm text-muted-foreground">Point your phone camera at this QR code to open EarlyMarket in your browser</p>
              <Badge variant="outline" className="mt-4 text-amber-600 border-amber-400">Native apps coming soon</Badge>
            </CardContent>
          </Card>
        </div>
      );

    case 'all-categories':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Marketplace</Badge>
            <h1 className="text-3xl font-bold mb-4">All Categories</h1>
            <p className="text-muted-foreground text-lg">
              Browse our {categories?.length || 0} active categories to find what you're looking for.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            {(categories || []).map((cat) => (
              <Card key={cat.name} className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => navigate(`/search?category=${encodeURIComponent(cat.name)}`)}>
                <CardContent className="p-4 text-center">
                  <span className="text-3xl mb-2 block">{getCategoryIcon(cat.name)}</span>
                  <h3 className="font-medium text-sm">{cat.name}</h3>
                  <p className="text-xs text-muted-foreground">{cat.count.toLocaleString()} listings</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      );

    case 'featured-items':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Marketplace</Badge>
            <h1 className="text-3xl font-bold mb-4">Featured Items</h1>
            <p className="text-muted-foreground text-lg">Hand-picked premium listings from our top verified sellers.</p>
          </div>
          <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-4"><Star className="w-5 h-5 text-yellow-500 fill-yellow-500" /><span className="font-semibold">What Makes Items Featured?</span></div>
              <ul className="grid md:grid-cols-2 gap-2 text-sm">
                {['Listed by verified sellers', 'High-quality photos', 'Competitive pricing', 'Excellent seller ratings'].map(t => (
                  <li key={t} className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-green-500" />{t}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
          <div className="mt-6">
            <h3 className="font-semibold mb-4">How to Get Featured</h3>
            <ol className="space-y-3">
              {['Complete your seller verification', 'Maintain a high seller rating', 'Use high-quality images in your listings', 'Boost your ad for guaranteed featuring'].map((t, i) => (
                <li key={t} className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm">{i + 1}</span>
                  <span>{t}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      );

    case 'new-arrivals':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Marketplace</Badge>
            <h1 className="text-3xl font-bold mb-4">New Arrivals</h1>
            <p className="text-muted-foreground text-lg">Fresh listings posted recently. Be the first to discover great deals!</p>
          </div>
          <Card className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-green-500/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-2"><Sparkles className="w-5 h-5 text-green-500" /><span className="font-semibold">New Arrivals Benefits</span></div>
              <p className="text-sm text-muted-foreground">Items in New Arrivals get up to 5x more views in their first 24 hours. Browse the latest listings to find the best deals before anyone else.</p>
            </CardContent>
          </Card>
          <div className="mt-6">
            <h3 className="font-semibold mb-4">Stay Updated</h3>
            <p className="text-muted-foreground mb-4">Check the EarlyMarket social feed regularly to see the latest posts from sellers you follow and discover new arrivals in your favorite categories.</p>
            <Button onClick={() => navigate('/search?sortBy=newest')}>Browse New Arrivals <ArrowRight className="ml-2 w-4 h-4" /></Button>
          </div>
        </div>
      );

    case 'best-sellers':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Marketplace</Badge>
            <h1 className="text-3xl font-bold mb-4">Top Sellers</h1>
            <p className="text-muted-foreground text-lg">Discover highly-rated sellers with great track records on EarlyMarket.</p>
          </div>
          <Card className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-amber-500/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-4"><Star className="w-5 h-5 text-amber-500 fill-amber-500" /><span className="font-semibold">What Makes a Top Seller?</span></div>
              <p className="text-sm text-muted-foreground mb-4">Top sellers are recognized based on their overall engagement, responsiveness, and community trust — not tier rankings.</p>
              <ul className="grid md:grid-cols-2 gap-2 text-sm">
                {['Verified business account', 'Consistent positive reviews', 'Fast response times', 'High-quality listings', 'Active community engagement', 'Trusted by the community'].map(t => (
                  <li key={t} className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-amber-500" />{t}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
          <div className="mt-6">
            <h3 className="font-semibold mb-4">How to Become a Top Seller</h3>
            <div className="grid md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-primary/10 mx-auto mb-4 flex items-center justify-center"><ShieldCheck className="w-6 h-6 text-primary" /></div>
                  <h4 className="font-medium mb-2">Get Verified</h4>
                  <p className="text-sm text-muted-foreground">Complete verification to earn your trust badge</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-primary/10 mx-auto mb-4 flex items-center justify-center"><MessageSquare className="w-6 h-6 text-primary" /></div>
                  <h4 className="font-medium mb-2">Be Responsive</h4>
                  <p className="text-sm text-muted-foreground">Reply to messages quickly and professionally</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-primary/10 mx-auto mb-4 flex items-center justify-center"><Star className="w-6 h-6 text-primary" /></div>
                  <h4 className="font-medium mb-2">Earn Reviews</h4>
                  <p className="text-sm text-muted-foreground">Deliver great service and collect positive reviews</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      );

    case 'seller-dashboard':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">For Businesses</Badge>
            <h1 className="text-3xl font-bold mb-4">Seller Dashboard</h1>
            <p className="text-muted-foreground text-lg">Your command center for managing listings, messages, and performance.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-6 mt-8">
            {[
              { icon: <Package className="w-5 h-5" />, title: 'Active Listings', desc: 'View and manage all your active listings. Edit prices, update descriptions, mark items as sold, or remove listings.' },
              { icon: <BarChart3 className="w-5 h-5" />, title: 'Performance Analytics', desc: 'Track views, clicks, bookmarks, and comments. Understand what\'s working and optimize your listings.' },
              { icon: <MessageSquare className="w-5 h-5" />, title: 'Messages', desc: 'Respond to buyer inquiries quickly. Fast response times lead to more engagement and better ratings.' },
              { icon: <Star className="w-5 h-5" />, title: 'Reviews & Ratings', desc: 'Monitor your seller rating and respond to customer reviews. Build your reputation on the platform.' },
            ].map(card => (
              <Card key={card.title}>
                <CardHeader><CardTitle className="flex items-center gap-2">{card.icon}{card.title}</CardTitle></CardHeader>
                <CardContent><p className="text-sm text-muted-foreground">{card.desc}</p></CardContent>
              </Card>
            ))}
          </div>
        </div>
      );

    case 'post-an-ad':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">For Businesses</Badge>
            <h1 className="text-3xl font-bold mb-4">Post an Ad</h1>
            <p className="text-muted-foreground text-lg">Create compelling listings to reach buyers on EarlyMarket.</p>
          </div>
          <Card className="mt-8">
            <CardHeader><CardTitle>Listing Types Available</CardTitle></CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-4">
              {[
                { title: 'Product', desc: 'Sell electronics, vehicles, fashion, and more', emoji: '📦' },
                { title: 'Service', desc: 'Offer repairs, tutoring, photography, etc.', emoji: '🔧' },
                { title: 'Job', desc: 'Post job openings and find talent', emoji: '💼' },
                { title: 'Event', desc: 'Create and promote events', emoji: '🎉' },
                { title: 'Promotion', desc: 'Run discount campaigns for your products', emoji: '🏷️' },
              ].map(type => (
                <div key={type.title} className="p-4 rounded-lg border hover:border-primary transition-colors cursor-pointer">
                  <div className="flex items-center gap-2 mb-1">
                    <span>{type.emoji}</span>
                    <h4 className="font-medium">{type.title}</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">{type.desc}</p>
                </div>
              ))}
            </CardContent>
          </Card>
          <Button size="lg" className="w-full md:w-auto" onClick={() => navigate('/publish')}>
            <PlusCircle className="mr-2 w-5 h-5" />
            Create New Listing
          </Button>
        </div>
      );

    case 'analytics':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">For Businesses</Badge>
            <h1 className="text-3xl font-bold mb-4">Performance & Analytics</h1>
            <p className="text-muted-foreground text-lg">Track your engagement and make data-driven decisions to grow.</p>
          </div>
          <div className="grid md:grid-cols-4 gap-4 mt-8">
            {[
              { icon: <Eye className="w-5 h-5" />, label: 'Views', desc: 'How many people saw your listings', color: 'text-primary' },
              { icon: <Heart className="w-5 h-5" />, label: 'Clicks', desc: 'Engagement with your listings', color: 'text-red-500' },
              { icon: <Bookmark className="w-5 h-5" />, label: 'Bookmarks', desc: 'People who saved your listings', color: 'text-blue-500' },
              { icon: <MessageCircle className="w-5 h-5" />, label: 'Comments', desc: 'Discussions on your listings', color: 'text-green-500' },
            ].map(metric => (
              <Card key={metric.label}>
                <CardContent className="p-6 text-center">
                  <div className={cn("mx-auto mb-2", metric.color)}>{metric.icon}</div>
                  <p className="font-semibold">{metric.label}</p>
                  <p className="text-xs text-muted-foreground mt-1">{metric.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          <Card className="mt-6">
            <CardHeader><CardTitle>What You Can Track</CardTitle></CardHeader>
            <CardContent>
              <ul className="grid md:grid-cols-2 gap-3 text-sm">
                {[
                  'Listing views over time',
                  'Click-through rates',
                  'Bookmark count per listing',
                  'Comments and engagement',
                  'Best performing listings',
                  'AI-driven performance insights',
                ].map(t => (
                  <li key={t} className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-green-500" />{t}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-2"><Lightbulb className="w-5 h-5 text-amber-500" /><span className="font-semibold">Performance Tips</span></div>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• Use high-quality photos to increase click-through rates</li>
                <li>• Write detailed descriptions with relevant keywords</li>
                <li>• Respond to messages quickly to boost your ranking</li>
                <li>• Boost your best listings to reach a wider audience</li>
                <li>• Run promotions and discounts to drive engagement</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      );

    case 'become-seller':
      return (
        <div className="space-y-6">
          <div id="toc-regular" className="scroll-mt-24">
            <Badge variant="secondary" className="mb-4">Account Types</Badge>
            <h1 className="text-3xl font-bold mb-4">Create a Business Account</h1>
            <p className="text-muted-foreground text-lg">
              Choose the right account type for your needs. All accounts are <strong>completely free</strong> right now — premium pricing will be introduced in the future.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6 mt-8">
            {/* Regular User */}
            <Card className="border-border">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xl">👤</span>
                  <Badge variant="outline">Free Forever</Badge>
                </div>
                <CardTitle className="mt-2">Regular User</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2"><Cloud className="w-4 h-4 text-muted-foreground" />Up to 5 active listings</li>
                  <li className="flex items-center gap-2"><AtSign className="w-4 h-4 text-muted-foreground" />Basic profile page</li>
                  <li className="flex items-center gap-2"><Video className="w-4 h-4 text-muted-foreground" />Direct messaging with buyers</li>
                  <li className="flex items-center gap-2"><Calendar className="w-4 h-4 text-muted-foreground" />Listings expire after 30 days</li>
                  <li className="flex items-center gap-2"><Sparkles className="w-4 h-4 text-primary" />Basic AI-powered suggestions</li>
                </ul>
                <Button className="w-full mt-4" variant="outline" onClick={() => navigate('/auth')}>Continue as Regular User</Button>
              </CardContent>
            </Card>

            {/* Business Account */}
            <Card id="toc-business" className="border-primary relative scroll-mt-24">
              <Badge className="absolute -top-3 right-4 bg-primary">Recommended</Badge>
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xl">🏢</span>
                  <div className="flex items-baseline gap-2">
                    <Badge className="bg-green-500">Free</Badge>
                    <span className="text-sm text-muted-foreground line-through">$4/month</span>
                  </div>
                </div>
                <CardTitle className="mt-2">Business Account</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2"><Cloud className="w-4 h-4 text-muted-foreground" />Unlimited product, job & service listings</li>
                  <li className="flex items-center gap-2"><AtSign className="w-4 h-4 text-muted-foreground" />Custom store page with unique URL</li>
                  <li className="flex items-center gap-2"><Video className="w-4 h-4 text-muted-foreground" />Analytics dashboard & performance insights</li>
                  <li className="flex items-center gap-2"><Calendar className="w-4 h-4 text-muted-foreground" />Easier appointment bookings</li>
                  <li className="flex items-center gap-2"><FileSignature className="w-4 h-4 text-muted-foreground" />Priority support & verification eligibility</li>
                  <li className="flex items-center gap-2"><Crown className="w-4 h-4 text-muted-foreground" />Premium features throughout EarlyMarket</li>
                  <li className="flex items-center gap-2"><Sparkles className="w-4 h-4 text-primary" />Expanded AI models and features</li>
                  <li className="flex items-center gap-2"><EMIIcon className="w-4 h-4" />EMI · Early Market Intelligence in listings, chat, analytics</li>
                </ul>
                <Button className="w-full mt-4" onClick={() => navigate('/create-business-account')}>Create Business Account</Button>
              </CardContent>
            </Card>

            {/* Organization */}
            <Card id="toc-organization" className="border-border scroll-mt-24">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xl">🏛️</span>
                  <div className="flex items-baseline gap-2">
                    <Badge className="bg-green-500">Free</Badge>
                    <span className="text-sm text-muted-foreground line-through">$10/month</span>
                  </div>
                </div>
                <CardTitle className="mt-2">Organization Account</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2"><Cloud className="w-4 h-4 text-muted-foreground" />Everything in Business Account, plus:</li>
                  <li className="flex items-center gap-2"><AtSign className="w-4 h-4 text-muted-foreground" />Instant orange verification badge</li>
                  <li className="flex items-center gap-2"><Video className="w-4 h-4 text-muted-foreground" />Official organization profile page</li>
                  <li className="flex items-center gap-2"><Calendar className="w-4 h-4 text-muted-foreground" />Multiple team members access</li>
                  <li className="flex items-center gap-2"><FileSignature className="w-4 h-4 text-muted-foreground" />Event hosting & tender posting</li>
                  <li className="flex items-center gap-2"><Crown className="w-4 h-4 text-muted-foreground" />Job posting with application management</li>
                  <li className="flex items-center gap-2"><Sparkles className="w-4 h-4 text-primary" />Full access to all AI models and features</li>
                </ul>
                <Button className="w-full mt-4" variant="outline" onClick={() => navigate('/create-business-account')}>Register Organization</Button>
              </CardContent>
            </Card>
          </div>
          <p className="text-center text-sm text-muted-foreground mt-4">
            All account types are currently free. Premium pricing will be introduced in the future. You can upgrade or change your account type anytime from settings.
          </p>
        </div>
      );

    case 'contact-us':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Support</Badge>
            <h1 className="text-3xl font-bold mb-4">Contact Us</h1>
            <p className="text-muted-foreground text-lg">We're here to help! Reach out through any of these channels.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-6 mt-8">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Mail className="w-5 h-5" />Email Support</CardTitle></CardHeader>
              <CardContent>
                <p className="text-lg font-semibold mb-2">support@earlymarket.ug</p>
                <p className="text-sm text-muted-foreground">We aim to respond within 24 hours</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><MessageSquare className="w-5 h-5" />In-App Feedback</CardTitle></CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">Use our built-in feedback system for the fastest response</p>
                <Button variant="outline" onClick={() => navigate('/feedback')}>Send Feedback</Button>
              </CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Phone className="w-5 h-5" />Report Issues</CardTitle></CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">Found a problem? Report it directly through the platform</p>
                <Button variant="outline" onClick={() => navigate('/report')}>Report an Issue</Button>
              </CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><MapPin className="w-5 h-5" />About Us</CardTitle></CardHeader>
              <CardContent>
                <p className="font-semibold mb-2">EarlyMarket</p>
                <p className="text-sm text-muted-foreground">Uganda's leading digital marketplace</p>
                <Button variant="outline" className="mt-4" onClick={() => navigate('/about')}>Learn More</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      );

    case 'trading-tips':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Tips</Badge>
            <h1 className="text-3xl font-bold mb-4">Trading Tips</h1>
            <p className="text-muted-foreground text-lg">Expert advice to help you buy and sell successfully on EarlyMarket.</p>
          </div>
          <div className="space-y-6 mt-8">
            <Card>
              <CardHeader><CardTitle>For Buyers</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                {[
                  { title: 'Research Before Buying', desc: 'Compare prices across multiple sellers. Use search filters to find the best deals in your area.' },
                  { title: 'Check Seller Profiles', desc: 'Review the seller\'s verification status, ratings, and past activity before making a purchase.' },
                  { title: 'Ask Questions', desc: 'Don\'t hesitate to message sellers for more photos, videos, or details about the item\'s condition.' },
                  { title: 'Use Safe Payment Methods', desc: 'Prefer Mobile Money or bank transfers over cash when possible. Always get a receipt or confirmation.' },
                ].map(tip => (
                  <div key={tip.title} className="flex gap-3">
                    <Lightbulb className="w-5 h-5 text-amber-500 flex-shrink-0 mt-1" />
                    <div><h4 className="font-medium">{tip.title}</h4><p className="text-sm text-muted-foreground">{tip.desc}</p></div>
                  </div>
                ))}
              </CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle>For Sellers</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                {[
                  { title: 'Respond Quickly', desc: 'Fast response times lead to higher conversion rates. Aim to reply within 1 hour during business hours.' },
                  { title: 'Price Competitively', desc: 'Research similar listings and price your items competitively. Use the "Negotiable" tag if you\'re flexible.' },
                  { title: 'Use High-Quality Photos', desc: 'Listings with clear, well-lit photos get significantly more views and inquiries.' },
                  { title: 'Run Promotions', desc: 'Use the Promotions wizard to create discount campaigns for your products and attract more buyers.' },
                  { title: 'Boost Your Best Listings', desc: 'Invest in boosting your top-performing listings to reach an even wider audience.' },
                ].map(tip => (
                  <div key={tip.title} className="flex gap-3">
                    <Lightbulb className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                    <div><h4 className="font-medium">{tip.title}</h4><p className="text-sm text-muted-foreground">{tip.desc}</p></div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      );

    case 'banner-advertising':
      return (
        <div className="space-y-6">
          <div>
            <Badge variant="secondary" className="mb-4">Advertising</Badge>
            <h1 className="text-3xl font-bold mb-4">Banner Advertising</h1>
            <p className="text-muted-foreground text-lg">Promote your business with banner placements across EarlyMarket.</p>
          </div>
          <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-4"><Zap className="w-5 h-5 text-primary" /><span className="font-semibold">Want a Banner on EarlyMarket?</span></div>
              <p className="text-sm text-muted-foreground mb-4">
                Banner advertising is available for businesses who want to promote their products or services to the EarlyMarket audience. We create custom banners for you based on your brand and goals.
              </p>
            </CardContent>
          </Card>
          <Card className="mt-4">
            <CardHeader><CardTitle>How It Works</CardTitle></CardHeader>
            <CardContent>
              <ol className="space-y-4">
                {[
                  { title: 'Contact Us', desc: 'Reach out to our advertising team via the feedback form or email at support@earlymarket.ug with your business details.' },
                  { title: 'We Design Your Banner', desc: 'Our team will create a professional banner that matches your brand and the EarlyMarket aesthetic.' },
                  { title: 'Review & Approve', desc: 'You\'ll review the banner design before it goes live. We\'ll make adjustments until you\'re satisfied.' },
                  { title: 'Banner Goes Live', desc: 'Once approved, your banner will appear across EarlyMarket, reaching thousands of users daily.' },
                ].map((step, i) => (
                  <li key={step.title} className="flex gap-3">
                    <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-medium">{i + 1}</span>
                    <div><h4 className="font-medium">{step.title}</h4><p className="text-sm text-muted-foreground">{step.desc}</p></div>
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle>Banner Specifications</CardTitle></CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-2">Supported Dimensions</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Desktop: 1200 × 300 pixels</li>
                    <li>• Mobile: 640 × 200 pixels</li>
                    <li>• Format: JPG, PNG, or WebP</li>
                    <li>• Max file size: 500KB</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Placements Available</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Homepage hero banner</li>
                    <li>• Social feed in-stream banners</li>
                    <li>• Category page banners</li>
                    <li>• Search results page</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
          <div className="flex gap-4">
            <Button onClick={() => navigate('/feedback')}>Request a Banner</Button>
            <Button variant="outline" onClick={() => navigate('/contact')}>Contact Sales</Button>
          </div>
        </div>
      );

    default:
      return (
        <div className="text-center py-12">
          <FileText className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-xl font-semibold mb-2">Content Coming Soon</h2>
          <p className="text-muted-foreground">This section is being updated. Check back soon!</p>
        </div>
      );
  }
};

export default DocsSections;

// Re-export icons needed by parent
import { Grid3X3 } from 'lucide-react';
