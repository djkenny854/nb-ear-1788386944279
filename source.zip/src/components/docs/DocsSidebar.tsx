import React, { useMemo } from 'react';
import { Search, X, BookOpen } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { navItems, NavItem } from './docsData';

interface DocsSidebarProps {
  activeSection: string;
  onSelectSection: (id: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

const DocsSidebar: React.FC<DocsSidebarProps> = ({
  activeSection,
  onSelectSection,
  searchQuery,
  onSearchChange,
}) => {
  const filteredNavItems = useMemo(() => {
    if (!searchQuery.trim()) return navItems;
    return navItems.filter(item =>
      item.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.category && item.category.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  }, [searchQuery]);

  const groupedItems = filteredNavItems.reduce((acc, item) => {
    if (item.category && !acc.some(i => i.type === 'category' && i.label === item.category)) {
      acc.push({ type: 'category' as const, label: item.category });
    }
    acc.push({ type: 'item' as const, ...item });
    return acc;
  }, [] as ({ type: 'category'; label: string } | (NavItem & { type: 'item' }))[]);

  return (
    <>
      <div className="p-4 border-b border-border space-y-3">
        <h2 className="font-bold text-lg flex items-center gap-2">
          <BookOpen className="w-5 h-5" />
          Documentation
        </h2>
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search docs..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-8 pr-8 h-9 text-sm"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
      <ScrollArea className="h-[calc(100vh-130px)]">
        <nav className="p-2">
          {groupedItems.map((item, index) => {
            if (item.type === 'category') {
              return (
                <div key={`cat-${index}`} className="mt-4 mb-2 px-3">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    {item.label}
                  </p>
                </div>
              );
            }
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => onSelectSection(item.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors text-left",
                  activeSection === item.id
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-accent text-foreground"
                )}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </ScrollArea>
    </>
  );
};

export default DocsSidebar;
