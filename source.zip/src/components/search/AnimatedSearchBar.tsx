import React, { useState, useEffect, useRef } from 'react';
import { MagnifyingGlass } from '@phosphor-icons/react';
import { Mic, X, Loader2, Search } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';

interface AnimatedSearchBarProps {
  isExpanded: boolean;
  onExpandChange: (expanded: boolean) => void;
  className?: string;
}

const placeholders = [
  "Search for phones, laptops...",
  "Find jobs near you",
  "Discover local services",
  "Browse promotions & deals",
  "Search for cars, vehicles...",
  "Find fashion & clothing",
  "Explore events nearby",
];

const AnimatedSearchBar: React.FC<AnimatedSearchBarProps> = ({
  isExpanded,
  onExpandChange,
  className,
}) => {
  const [query, setQuery] = useState('');
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const [isListening, setIsListening] = useState(false);
  const [rotation, setRotation] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  // Rotate placeholder text
  useEffect(() => {
    const interval = setInterval(() => {
      setPlaceholderIndex((prev) => (prev + 1) % placeholders.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // Animate gradient rotation
  useEffect(() => {
    if (!isExpanded) return;
    const interval = setInterval(() => {
      setRotation((prev) => (prev + 1) % 360);
    }, 20);
    return () => clearInterval(interval);
  }, [isExpanded]);

  // Focus input when expanded
  useEffect(() => {
    if (isExpanded && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isExpanded]);

  const handleSearch = () => {
    if (!query.trim()) return;
    // Navigate to search page with query
    navigate(`/search?q=${encodeURIComponent(query)}&contentType=products`);
    onExpandChange(false);
    setQuery('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    } else if (e.key === 'Escape') {
      onExpandChange(false);
      setQuery('');
    }
  };

  const handleVoiceSearch = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Voice search is not supported in your browser');
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    setIsListening(true);

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setQuery(transcript);
      setIsListening(false);
    };

    recognition.onerror = () => {
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  if (!isExpanded) {
    return (
      <button
        onClick={() => onExpandChange(true)}
        className={cn(
          "flex items-center justify-center h-10 w-10 rounded-full",
          "bg-muted/60 hover:bg-muted transition-colors",
          className
        )}
        aria-label="Search"
      >
        <MagnifyingGlass weight="bold" className="h-5 w-5 text-foreground" />
      </button>
    );
  }

  return (
    <div className="fixed inset-x-0 top-0 z-50 px-4 pt-3 pb-3 bg-background/95 backdrop-blur-md border-b border-border animate-in slide-in-from-top duration-200">
      <div
        className="relative rounded-xl p-[2px] overflow-hidden"
        style={{
          background: `linear-gradient(${rotation}deg, 
            hsl(var(--primary)), 
            #4285f4, 
            #ea4335, 
            #fbbc05, 
            #34a853, 
            hsl(var(--primary))
          )`,
        }}
      >
        <div className="relative flex items-center bg-background rounded-[10px] h-12">
          <Search className="absolute left-4 h-5 w-5 text-muted-foreground" />
          
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={placeholders[placeholderIndex]}
            className="flex-1 h-full bg-transparent pl-12 pr-24 text-base outline-none placeholder:text-muted-foreground/60 transition-all"
          />

          <div className="absolute right-2 flex items-center gap-1">
            {/* Voice search button */}
            <button
              onClick={handleVoiceSearch}
              disabled={isListening}
              className={cn(
                "h-8 w-8 rounded-full flex items-center justify-center transition-all",
                isListening 
                  ? "bg-destructive text-destructive-foreground animate-pulse" 
                  : "hover:bg-muted text-muted-foreground hover:text-foreground"
              )}
            >
              {isListening ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Mic className="h-4 w-4" />
              )}
            </button>

            {/* Close button */}
            <button
              onClick={() => {
                onExpandChange(false);
                setQuery('');
              }}
              className="h-8 w-8 rounded-full flex items-center justify-center hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Quick suggestions */}
      {!query && (
        <div className="mt-3 flex flex-wrap gap-2">
          {['Phones', 'Jobs', 'Cars', 'Fashion', 'Services'].map((tag) => (
            <button
              key={tag}
              onClick={() => {
                setQuery(tag);
                navigate(`/search?q=${encodeURIComponent(tag)}&contentType=products`);
                onExpandChange(false);
              }}
              className="px-3 py-1.5 text-xs rounded-full bg-muted hover:bg-primary/10 hover:text-primary transition-colors"
            >
              {tag}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default AnimatedSearchBar;
