import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  ChevronDown, Package, Briefcase, Code, Megaphone, Calendar,
  Star, Verified, Clock, Truck, CreditCard, Tag, Grid3X3,
  Building2, GraduationCap, DollarSign, MapPin, Image, Video,
  Shield, Award, Sparkles, Filter, User, Store
} from 'lucide-react';

interface FilterSectionsProps {
  filters: any;
  onFiltersChange: (filters: any) => void;
  activeSection?: string;
}

const listingTypes = [
  { id: 'product', name: 'Products', icon: Package, color: 'bg-blue-500/10 text-blue-600' },
  { id: 'service', name: 'Services', icon: Briefcase, color: 'bg-purple-500/10 text-purple-600' },
  { id: 'job', name: 'Jobs', icon: Briefcase, color: 'bg-green-500/10 text-green-600' },
  { id: 'digital', name: 'Digital', icon: Code, color: 'bg-orange-500/10 text-orange-600' },
  { id: 'promotion', name: 'Promotions', icon: Megaphone, color: 'bg-pink-500/10 text-pink-600' },
  { id: 'event', name: 'Events', icon: Calendar, color: 'bg-cyan-500/10 text-cyan-600' },
];

// Condition options that map to actual database values
const conditions = [
  { label: 'Brand New', dbValue: 'New' },
  { label: 'Like New', dbValue: 'like_new' },
  { label: 'Used', dbValue: 'Used' },
  { label: 'For Parts', dbValue: 'for_parts' },
];
const deliveryOptions = ['Express Delivery', 'Standard Shipping', 'Pickup Only', 'Nationwide'];
const paymentMethods = ['Cash', 'Mobile Money', 'Bank Transfer', 'Card Payment', 'Crypto'];
const dateOptions = [
  { label: 'Any time', value: '' },
  { label: 'Last 24 hours', value: '1' },
  { label: 'Last 7 days', value: '7' },
  { label: 'Last 30 days', value: '30' },
  { label: 'Last 3 months', value: '90' },
];

// Seller type options: regular (no business account) and business (registered)
const sellerTypeOptions = [
  { id: 'all', label: 'All Sellers', icon: User, description: 'Show all listings' },
  { id: 'regular', label: 'Regular Sellers', icon: User, description: 'Sellers without a business account (limited to 3 listings)' },
  { id: 'registered_business', label: 'Business Sellers', icon: Store, description: 'Registered business accounts' },
];

const jobTypes = ['Full-time', 'Part-time', 'Contract', 'Internship', 'Remote', 'Freelance'];
const experienceLevels = ['Entry Level', 'Mid Level', 'Senior', 'Executive', 'No Experience'];
const educationLevels = ['Any', 'High School', 'Diploma', 'Bachelor\'s', 'Master\'s', 'PhD'];
const salaryRanges = [
  { label: 'Under 500K', range: [0, 500000] },
  { label: '500K-1M', range: [500000, 1000000] },
  { label: '1M-2M', range: [1000000, 2000000] },
  { label: '2M-5M', range: [2000000, 5000000] },
  { label: '5M+', range: [5000000, 50000000] },
];

const pricePresets = [
  { label: 'Under 100K', range: [0, 100000] },
  { label: '100K-500K', range: [100000, 500000] },
  { label: '500K-1M', range: [500000, 1000000] },
  { label: '1M-5M', range: [1000000, 5000000] },
  { label: '5M+', range: [5000000, 10000000] },
];

const FilterSections: React.FC<FilterSectionsProps> = ({ filters, onFiltersChange, activeSection }) => {
  const [openSections, setOpenSections] = useState({
    listingType: true,
    price: true,
    condition: true,
    seller: true,
    features: true,
    date: true,
    delivery: true,
    brands: true,
    jobFilters: true,
    digitalFilters: true,
  });

  // Map activeSection to which blocks to show
  const sectionMapping: { [key: string]: string[] } = {
    'price': ['price', 'condition'],
    'seller': ['seller'],
    'features': ['features'],
    'date': ['date'],
    'delivery': ['delivery'],
    'brands': ['brands'],
    'ratings': ['ratings'],
    'deals': ['deals'],
    'more': ['more'],
  };

  const visibleSections = activeSection ? sectionMapping[activeSection] || [] : null;

  const [brandSearch, setBrandSearch] = useState('');

  // Fetch brands from database
  const { data: dbBrands = [], isLoading: brandsLoading } = useQuery({
    queryKey: ['filter-brands', brandSearch],
    queryFn: async () => {
      let query = supabase
        .from('brands')
        .select('id, name, logo_url, category, is_popular')
        .order('is_popular', { ascending: false })
        .order('name');
      
      if (brandSearch) {
        query = query.ilike('name', `%${brandSearch}%`);
      }
      
      const { data, error } = await query.limit(50);
      if (error) throw error;
      return data || [];
    },
    staleTime: 1000 * 60 * 5,
  });

  const toggleSection = (section: string) => {
    setOpenSections(prev => ({ ...prev, [section]: !prev[section as keyof typeof prev] }));
  };

  const handleFilterChange = (key: string, value: any) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const toggleArrayItem = (key: string, item: string) => {
    const current = filters[key] || [];
    const updated = current.includes(item)
      ? current.filter((i: string) => i !== item)
      : [...current, item];
    handleFilterChange(key, updated);
  };

  // Filter brands based on search - use database brands
  const filteredBrands = dbBrands.filter(brand =>
    brand.name.toLowerCase().includes(brandSearch.toLowerCase())
  );

  const showJobFilters = filters.listingTypes?.includes('job');
  const showDigitalFilters = filters.listingTypes?.includes('digital');

  const SectionBlock = ({ 
    id, 
    title, 
    icon: Icon, 
    iconColor,
    count,
    children 
  }: { 
    id: string; 
    title: string; 
    icon: any; 
    iconColor: string;
    count?: number;
    children: React.ReactNode;
  }) => (
    <Collapsible
      open={openSections[id as keyof typeof openSections]}
      onOpenChange={() => toggleSection(id)}
      className="border border-border rounded-xl overflow-hidden bg-card/50"
    >
      <CollapsibleTrigger className="flex items-center justify-between w-full p-3 hover:bg-muted/50 transition-colors">
        <div className="flex items-center gap-2.5">
          <div className={`p-1.5 rounded-lg ${iconColor}`}>
            <Icon className="w-4 h-4" />
          </div>
          <span className="font-medium text-sm text-foreground">{title}</span>
          {count !== undefined && count > 0 && (
            <Badge variant="secondary" className="text-xs h-5 px-1.5 bg-primary/10 text-primary">
              {count}
            </Badge>
          )}
        </div>
        <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform duration-200 ${
          openSections[id as keyof typeof openSections] ? 'rotate-180' : ''
        }`} />
      </CollapsibleTrigger>
      <CollapsibleContent className="p-3 pt-0 border-t border-border">
        <div className="pt-3 space-y-3">
          {children}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );

  const shouldShowSection = (sectionId: string) => {
    if (!visibleSections) return true; // Show all if no activeSection
    return visibleSections.includes(sectionId);
  };

  return (
    <div className="space-y-3">
      {/* Listing Type */}
      {shouldShowSection('listingType') && (
        <SectionBlock
          id="listingType"
          title="Listing Type"
          icon={Grid3X3}
          iconColor="bg-primary/10 text-primary"
          count={filters.listingTypes?.length}
        >
          <div className="grid grid-cols-2 gap-2">
            {listingTypes.map(({ id, name, icon: Icon, color }) => (
              <button
                key={id}
                onClick={() => toggleArrayItem('listingTypes', id)}
                className={`flex items-center gap-2 p-2.5 rounded-xl border transition-all duration-200 ${
                  filters.listingTypes?.includes(id)
                    ? 'bg-primary/10 border-primary/30 ring-1 ring-primary/20'
                    : 'bg-muted/30 border-border hover:bg-muted/50'
                }`}
              >
                <div className={`p-1.5 rounded-lg ${color}`}>
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <span className="text-xs font-medium">{name}</span>
              </button>
            ))}
          </div>
        </SectionBlock>
      )}

      {/* Price Range */}
      {shouldShowSection('price') && (
        <SectionBlock
          id="price"
          title="Price Range"
          icon={Tag}
          iconColor="bg-green-500/10 text-green-600"
        >
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2">
              {pricePresets.map((preset) => (
                <Button
                  key={preset.label}
                  variant={
                    filters.priceRange?.[0] === preset.range[0] &&
                    filters.priceRange?.[1] === preset.range[1]
                      ? "default"
                      : "outline"
                  }
                  size="sm"
                  onClick={() => handleFilterChange('priceRange', preset.range)}
                  className="h-7 text-xs"
                >
                  {preset.label}
                </Button>
              ))}
            </div>

            <div className="px-1 py-2">
              <Slider
                value={filters.priceRange || [0, 10000000]}
                onValueChange={(value) => handleFilterChange('priceRange', value)}
                max={10000000}
                step={50000}
                className="w-full"
              />
            </div>

            {/* Manual Min/Max Input Fields */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">Minimum (UGX)</Label>
                <Input
                  type="number"
                  inputMode="numeric"
                  placeholder="0"
                  value={filters.priceRange?.[0] || ''}
                  onChange={(e) => {
                    const min = parseInt(e.target.value) || 0;
                    const max = filters.priceRange?.[1] || 10000000;
                    handleFilterChange('priceRange', [min, max]);
                  }}
                  onFocus={(e) => e.target.setAttribute('data-focused', 'true')}
                  className="h-9"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">Maximum (UGX)</Label>
                <Input
                  type="number"
                  inputMode="numeric"
                  placeholder="10,000,000"
                  value={filters.priceRange?.[1] === 10000000 ? '' : filters.priceRange?.[1] || ''}
                  onChange={(e) => {
                    const max = parseInt(e.target.value) || 10000000;
                    const min = filters.priceRange?.[0] || 0;
                    handleFilterChange('priceRange', [min, max]);
                  }}
                  onFocus={(e) => e.target.setAttribute('data-focused', 'true')}
                  className="h-9"
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="negotiable"
                checked={filters.negotiable || false}
                onCheckedChange={(checked) => handleFilterChange('negotiable', checked)}
              />
              <label htmlFor="negotiable" className="text-sm cursor-pointer">
                Negotiable prices only
              </label>
            </div>
          </div>
        </SectionBlock>
      )}

      {/* Condition */}
      {shouldShowSection('condition') && (
        <SectionBlock
          id="condition"
          title="Condition"
          icon={Award}
          iconColor="bg-amber-500/10 text-amber-600"
        >
          <div className="flex flex-wrap gap-2">
            {conditions.map((cond) => (
              <button
                key={cond.label}
                onClick={() => handleFilterChange('condition', filters.condition === cond.label ? '' : cond.label)}
                className={`px-3 py-1.5 text-xs rounded-full border transition-all ${
                  filters.condition === cond.label
                    ? 'bg-primary/10 border-primary/30 text-primary'
                    : 'bg-muted/30 border-border hover:bg-muted/50'
                }`}
              >
                {cond.label}
              </button>
            ))}
          </div>
        </SectionBlock>
      )}

      {/* Seller Options */}
      {shouldShowSection('seller') && (
        <SectionBlock
          id="seller"
          title="Seller Options"
          icon={Verified}
          iconColor="bg-blue-500/10 text-blue-600"
        >
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="verified-sellers"
                checked={filters.verifiedOnly || false}
                onCheckedChange={(checked) => handleFilterChange('verifiedOnly', checked)}
              />
              <label htmlFor="verified-sellers" className="text-sm cursor-pointer flex items-center gap-2">
                <Shield className="w-4 h-4 text-primary" />
                Verified sellers only
              </label>
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Seller Type</Label>
              <div className="grid grid-cols-2 gap-2">
                {sellerTypeOptions.map((option) => {
                  const Icon = option.icon;
                  const isActive = filters.sellerType === option.id || (!filters.sellerType && option.id === 'all');
                  return (
                    <button
                      key={option.id}
                      onClick={() => handleFilterChange('sellerType', option.id === 'all' ? '' : option.id)}
                      className={`flex items-center gap-2 p-2.5 rounded-xl border transition-all duration-200 ${
                        isActive
                          ? 'bg-primary/10 border-primary/30 ring-1 ring-primary/20'
                          : 'bg-muted/30 border-border hover:bg-muted/50'
                      }`}
                    >
                      <div className={`p-1.5 rounded-lg ${isActive ? 'bg-primary/20' : 'bg-muted'}`}>
                        <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-primary' : 'text-muted-foreground'}`} />
                      </div>
                      <div className="text-left">
                        <span className={`text-xs font-medium block ${isActive ? 'text-primary' : 'text-foreground'}`}>
                          {option.label}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Minimum Rating</Label>
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <Button
                    key={rating}
                    variant={filters.minRating === rating ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleFilterChange('minRating', filters.minRating === rating ? null : rating)}
                    className="h-8 w-10 p-0"
                  >
                    {rating}<Star className="w-3 h-3 ml-0.5 fill-current" />
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </SectionBlock>
      )}

      {/* Item Features */}
      {shouldShowSection('features') && (
        <SectionBlock
          id="features"
          title="Item Features"
          icon={Sparkles}
          iconColor="bg-purple-500/10 text-purple-600"
        >
          <div className="space-y-2">
            {[
              { id: 'hasImages', label: 'Has Images', icon: Image },
              { id: 'hasVideo', label: 'Has Video', icon: Video },
              { id: 'featured', label: 'Featured/Boosted', icon: Award },
            ].map(({ id, label, icon: Icon }) => (
              <div key={id} className="flex items-center space-x-2">
                <Checkbox
                  id={id}
                  checked={filters[id] || false}
                  onCheckedChange={(checked) => handleFilterChange(id, checked)}
                />
                <label htmlFor={id} className="text-sm cursor-pointer flex items-center gap-2">
                  <Icon className="w-4 h-4 text-muted-foreground" />
                  {label}
                </label>
              </div>
            ))}
          </div>
        </SectionBlock>
      )}

      {/* Date Posted */}
      {shouldShowSection('date') && (
        <SectionBlock
          id="date"
          title="Date Posted"
          icon={Clock}
          iconColor="bg-cyan-500/10 text-cyan-600"
        >
          <RadioGroup
            value={filters.datePosted || ''}
            onValueChange={(value) => handleFilterChange('datePosted', value)}
            className="space-y-2"
          >
            {dateOptions.map(({ label, value }) => (
              <div key={value} className="flex items-center space-x-2">
                <RadioGroupItem value={value} id={`date-${value}`} />
                <label htmlFor={`date-${value}`} className="text-sm cursor-pointer">{label}</label>
              </div>
            ))}
          </RadioGroup>
        </SectionBlock>
      )}

      {/* Delivery & Payment */}
      {shouldShowSection('delivery') && (
        <SectionBlock
          id="delivery"
          title="Delivery & Payment"
          icon={Truck}
          iconColor="bg-indigo-500/10 text-indigo-600"
        >
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label className="text-xs text-muted-foreground">Delivery Options</Label>
                <Badge variant="outline" className="text-[10px] bg-amber-500/10 text-amber-600 border-amber-500/30">Coming Soon</Badge>
              </div>
              <div className="flex flex-wrap gap-2 opacity-50 pointer-events-none">
                {deliveryOptions.map((option) => (
                  <button
                    key={option}
                    className="px-3 py-1.5 text-xs rounded-full border bg-muted/30 border-border"
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label className="text-xs text-muted-foreground">Payment Methods</Label>
                <Badge variant="outline" className="text-[10px] bg-amber-500/10 text-amber-600 border-amber-500/30">Coming Soon</Badge>
              </div>
              <div className="flex flex-wrap gap-2 opacity-50 pointer-events-none">
                {paymentMethods.map((method) => (
                  <button
                    key={method}
                    className="px-3 py-1.5 text-xs rounded-full border bg-muted/30 border-border"
                  >
                    {method}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </SectionBlock>
      )}

      {/* Brands */}
      {shouldShowSection('brands') && (
        <SectionBlock
          id="brands"
          title="Brands"
          icon={Tag}
          iconColor="bg-rose-500/10 text-rose-600"
          count={filters.brands?.length}
        >
          <div className="space-y-3">
            <Input
              placeholder="Search brands..."
              value={brandSearch}
              onChange={(e) => setBrandSearch(e.target.value)}
              className="h-9"
            />
            {brandsLoading ? (
              <div className="flex flex-wrap gap-2">
                {Array.from({ length: 8 }).map((_, i) => (
                  <Skeleton key={i} className="h-8 w-20 rounded-full" />
                ))}
              </div>
            ) : (
              <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto">
                {filteredBrands.map((brand) => (
                  <button
                    key={brand.id}
                    onClick={() => toggleArrayItem('brands', brand.name)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-full border transition-all ${
                      filters.brands?.includes(brand.name)
                        ? 'bg-primary/10 border-primary/30 text-primary'
                        : 'bg-muted/30 border-border hover:bg-muted/50'
                    }`}
                  >
                    {brand.logo_url && (
                      <Avatar className="h-4 w-4">
                        <AvatarImage src={brand.logo_url} alt={brand.name} />
                        <AvatarFallback className="text-[8px]">{brand.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                    )}
                    {brand.name}
                    {brand.is_popular && <Sparkles className="w-3 h-3 text-amber-500" />}
                  </button>
                ))}
                {filteredBrands.length === 0 && (
                  <p className="text-sm text-muted-foreground py-2">No brands found</p>
                )}
              </div>
            )}
          </div>
        </SectionBlock>
      )}

      {/* Ratings Filter */}
      {shouldShowSection('ratings') && (
        <SectionBlock
          id="ratings"
          title="Ratings & Reviews"
          icon={Star}
          iconColor="bg-yellow-500/10 text-yellow-600"
        >
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Minimum Rating</Label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <Button
                    key={rating}
                    variant={filters.minRating === rating ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleFilterChange('minRating', filters.minRating === rating ? null : rating)}
                    className="flex-1 h-9 p-0"
                  >
                    {rating}
                    <Star className="w-3 h-3 ml-0.5 fill-current" />
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label className="text-xs text-muted-foreground">Review Count</Label>
                <Badge variant="outline" className="text-[10px] bg-amber-500/10 text-amber-600 border-amber-500/30">Coming Soon</Badge>
              </div>
              <div className="flex flex-wrap gap-2 opacity-50 pointer-events-none">
                {[
                  { label: 'Any', value: '' },
                  { label: '10+', value: '10' },
                  { label: '50+', value: '50' },
                  { label: '100+', value: '100' },
                  { label: '500+', value: '500' },
                ].map((option) => (
                  <button
                    key={option.value}
                    className="px-3 py-1.5 text-xs rounded-full border bg-muted/30 border-border"
                  >
                    {option.label} reviews
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center space-x-2 opacity-50 pointer-events-none">
              <Checkbox
                id="hasReviews"
                checked={false}
                disabled
              />
              <label htmlFor="hasReviews" className="text-sm cursor-pointer flex items-center gap-2">
                Only items with reviews
                <Badge variant="outline" className="text-[10px] bg-amber-500/10 text-amber-600 border-amber-500/30">Coming Soon</Badge>
              </label>
            </div>
          </div>
        </SectionBlock>
      )}

      {/* Deals & Discounts */}
      {shouldShowSection('deals') && (
        <SectionBlock
          id="deals"
          title="Deals & Discounts"
          icon={Tag}
          iconColor="bg-red-500/10 text-red-600"
        >
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Discount Level</Label>
              <div className="flex flex-wrap gap-2">
                {[
                  { label: 'Any Discount', value: '1' },
                  { label: '10%+ off', value: '10' },
                  { label: '25%+ off', value: '25' },
                  { label: '50%+ off', value: '50' },
                  { label: '70%+ off', value: '70' },
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => {
                      if (option.value && !filters.onSale) {
                        // Set both minDiscount and onSale together
                        onFiltersChange({ ...filters, minDiscount: option.value, onSale: true });
                      } else {
                        handleFilterChange('minDiscount', option.value);
                      }
                    }}
                    className={`px-3 py-1.5 text-xs rounded-full border transition-all ${
                      filters.minDiscount === option.value
                        ? 'bg-red-500/10 border-red-500/30 text-red-600'
                        : 'bg-muted/30 border-border hover:bg-muted/50'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              {[
                { id: 'onSale', label: 'On Sale', icon: Tag, comingSoon: false },
                { id: 'clearance', label: 'Clearance Items', icon: DollarSign, comingSoon: true },
                { id: 'bundleDeals', label: 'Bundle Deals', icon: Package, comingSoon: true },
                { id: 'flashSale', label: 'Flash Sales', icon: Clock, comingSoon: true },
              ].map(({ id, label, icon: Icon, comingSoon }) => (
                <div key={id} className={`flex items-center space-x-2 ${comingSoon ? 'opacity-50 pointer-events-none' : ''}`}>
                  <Checkbox
                    id={id}
                    checked={comingSoon ? false : (filters[id] || false)}
                    onCheckedChange={comingSoon ? undefined : (checked) => handleFilterChange(id, checked)}
                    disabled={comingSoon}
                  />
                  <label htmlFor={id} className="text-sm cursor-pointer flex items-center gap-2">
                    <Icon className="w-4 h-4 text-muted-foreground" />
                    {label}
                    {comingSoon && <Badge variant="outline" className="text-[10px] bg-amber-500/10 text-amber-600 border-amber-500/30">Coming Soon</Badge>}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </SectionBlock>
      )}

      {/* More Options */}
      {shouldShowSection('more') && (
        <SectionBlock
          id="more"
          title="More Options"
          icon={Filter}
          iconColor="bg-gray-500/10 text-gray-600"
        >
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label className="text-xs text-muted-foreground">Language</Label>
                <Badge variant="outline" className="text-[10px] bg-amber-500/10 text-amber-600 border-amber-500/30">Coming Soon</Badge>
              </div>
              <div className="flex flex-wrap gap-2 opacity-50 pointer-events-none">
                {['English', 'Luganda', 'Swahili', 'French', 'Arabic'].map((lang) => (
                  <button
                    key={lang}
                    className="px-3 py-1.5 text-xs rounded-full border bg-muted/30 border-border"
                  >
                    {lang}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label className="text-xs text-muted-foreground">Return Policy</Label>
                <Badge variant="outline" className="text-[10px] bg-amber-500/10 text-amber-600 border-amber-500/30">Coming Soon</Badge>
              </div>
              <div className="flex flex-wrap gap-2 opacity-50 pointer-events-none">
                {[
                  { label: 'Any', value: '' },
                  { label: '7-day Returns', value: '7' },
                  { label: '14-day Returns', value: '14' },
                  { label: '30-day Returns', value: '30' },
                  { label: 'No Returns', value: 'none' },
                ].map((option) => (
                  <button
                    key={option.value}
                    className="px-3 py-1.5 text-xs rounded-full border bg-muted/30 border-border"
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              {[
                { id: 'warranty', label: 'Has Warranty', comingSoon: true },
                { id: 'authentic', label: 'Authentic/Genuine Only', comingSoon: true },
                { id: 'localSeller', label: 'Local Sellers Only', comingSoon: true },
                { id: 'acceptsOffers', label: 'Accepts Offers', comingSoon: false },
                { id: 'urgentSale', label: 'Urgent Sale', comingSoon: true },
              ].map(({ id, label, comingSoon }) => (
                <div key={id} className={`flex items-center space-x-2 ${comingSoon ? 'opacity-50 pointer-events-none' : ''}`}>
                  <Checkbox
                    id={id}
                    checked={comingSoon ? false : (filters[id] || false)}
                    onCheckedChange={comingSoon ? undefined : (checked) => handleFilterChange(id, checked)}
                    disabled={comingSoon}
                  />
                  <label htmlFor={id} className="text-sm cursor-pointer flex items-center gap-2">
                    {label}
                    {comingSoon && <Badge variant="outline" className="text-[10px] bg-amber-500/10 text-amber-600 border-amber-500/30">Coming Soon</Badge>}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </SectionBlock>
      )}

      {/* Job-specific Filters */}
      {showJobFilters && (
        <SectionBlock
          id="jobFilters"
          title="Job Filters"
          icon={Briefcase}
          iconColor="bg-emerald-500/10 text-emerald-600"
        >
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Job Type</Label>
              <div className="flex flex-wrap gap-2">
                {jobTypes.map((type) => (
                  <button
                    key={type}
                    onClick={() => toggleArrayItem('jobTypes', type)}
                    className={`px-3 py-1.5 text-xs rounded-full border transition-all ${
                      filters.jobTypes?.includes(type)
                        ? 'bg-primary/10 border-primary/30 text-primary'
                        : 'bg-muted/30 border-border hover:bg-muted/50'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Experience Level</Label>
              <Select
                value={filters.experienceLevel || ''}
                onValueChange={(value) => handleFilterChange('experienceLevel', value)}
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Select experience" />
                </SelectTrigger>
                <SelectContent>
                  {experienceLevels.map((level) => (
                    <SelectItem key={level} value={level}>{level}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Salary Range</Label>
              <div className="flex flex-wrap gap-2">
                {salaryRanges.map((preset) => (
                  <Button
                    key={preset.label}
                    variant={
                      filters.salaryRange?.[0] === preset.range[0] &&
                      filters.salaryRange?.[1] === preset.range[1]
                        ? "default"
                        : "outline"
                    }
                    size="sm"
                    onClick={() => handleFilterChange('salaryRange', preset.range)}
                    className="h-7 text-xs"
                  >
                    {preset.label}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </SectionBlock>
      )}

      {/* Digital Products Filters */}
      {showDigitalFilters && (
        <SectionBlock
          id="digitalFilters"
          title="Digital Filters"
          icon={Code}
          iconColor="bg-violet-500/10 text-violet-600"
        >
          <div className="space-y-3">
            {[
              { id: 'instantDownload', label: 'Instant Download', comingSoon: true },
              { id: 'hasPreview', label: 'Has Preview', comingSoon: true },
              { id: 'hasSupport', label: 'Includes Support', comingSoon: true },
              { id: 'hasUpdates', label: 'Free Updates', comingSoon: true },
            ].map(({ id, label, comingSoon }) => (
              <div key={id} className={`flex items-center space-x-2 ${comingSoon ? 'opacity-50 pointer-events-none' : ''}`}>
                <Checkbox
                  id={id}
                  checked={false}
                  disabled={comingSoon}
                />
                <label htmlFor={id} className="text-sm cursor-pointer flex items-center gap-2">
                  {label}
                  {comingSoon && <Badge variant="outline" className="text-[10px] bg-amber-500/10 text-amber-600 border-amber-500/30">Coming Soon</Badge>}
                </label>
              </div>
            ))}
          </div>
        </SectionBlock>
      )}
    </div>
  );
};

export default FilterSections;
