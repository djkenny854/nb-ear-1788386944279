import React, { useState, useRef } from 'react';
import { MapPin, Layers, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface UgandaMapVisualizationProps {
  onLocationSelect: (district: string) => void;
  selectedDistrict?: string;
  listingCounts?: { [key: string]: number };
}

// Uganda regions with accurate SVG positions matching actual geography
const ugandaRegions = [
  { 
    id: 'northern', 
    name: 'Northern', 
    // Northern region - top area including West Nile
    path: 'M 45,8 L 55,5 L 70,8 L 82,12 L 88,18 L 90,28 L 85,35 L 75,38 L 65,40 L 55,42 L 45,40 L 38,35 L 35,28 L 38,18 Z',
    centerX: 62,
    centerY: 22,
    districts: ['Gulu', 'Lira', 'Arua', 'Kitgum', 'Moroto', 'Adjumani', 'Moyo', 'Nebbi', 'Apac', 'Kotido'], 
    count: 980,
    color: 'hsl(var(--primary) / 0.25)'
  },
  { 
    id: 'eastern', 
    name: 'Eastern', 
    // Eastern region - right side along Kenya border
    path: 'M 75,38 L 85,35 L 90,40 L 92,50 L 90,60 L 85,68 L 78,72 L 70,70 L 65,65 L 62,55 L 65,45 L 70,40 Z',
    centerX: 78,
    centerY: 52,
    districts: ['Jinja', 'Mbale', 'Tororo', 'Soroti', 'Iganga', 'Busia', 'Bugiri', 'Kapchorwa', 'Pallisa', 'Kumi'], 
    count: 2180,
    color: 'hsl(var(--primary) / 0.5)'
  },
  { 
    id: 'central', 
    name: 'Central', 
    // Central region - around Lake Victoria
    path: 'M 45,40 L 55,42 L 65,45 L 62,55 L 65,65 L 60,72 L 50,75 L 42,70 L 38,60 L 40,50 L 42,45 Z',
    centerX: 52,
    centerY: 58,
    districts: ['Kampala', 'Wakiso', 'Mukono', 'Mpigi', 'Masaka', 'Entebbe', 'Luwero', 'Mityana', 'Kayunga', 'Nakasongola'], 
    count: 5420,
    color: 'hsl(var(--primary) / 0.85)'
  },
  { 
    id: 'western', 
    name: 'Western', 
    // Western region - along DRC border and includes southwest
    path: 'M 8,35 L 20,30 L 35,28 L 38,35 L 45,40 L 42,45 L 40,50 L 38,60 L 42,70 L 35,78 L 25,82 L 15,78 L 8,70 L 5,58 L 5,45 Z',
    centerX: 25,
    centerY: 55,
    districts: ['Mbarara', 'Kabale', 'Fort Portal', 'Kasese', 'Hoima', 'Masindi', 'Bushenyi', 'Rukungiri', 'Ibanda', 'Bundibugyo'], 
    count: 1890,
    color: 'hsl(var(--primary) / 0.4)'
  },
];

// Lake Victoria approximate shape
const lakeVictoriaPath = 'M 55,72 Q 60,68 65,70 Q 72,75 68,82 Q 60,88 52,85 Q 48,80 52,75 Z';

// Major water bodies
const lakesAndRivers = [
  { name: 'Lake Victoria', path: lakeVictoriaPath, x: 58, y: 78 },
  { name: 'Lake Albert', path: 'M 12,40 Q 15,35 18,40 Q 18,48 14,50 Q 10,48 12,40 Z', x: 14, y: 44 },
  { name: 'Lake Kyoga', path: 'M 55,45 Q 62,42 68,45 Q 70,48 65,50 Q 58,52 55,48 Z', x: 62, y: 46 },
];

const popularDistricts = [
  { name: 'Kampala', region: 'Central', listings: 3240, growth: '+12%' },
  { name: 'Wakiso', region: 'Central', listings: 1580, growth: '+8%' },
  { name: 'Jinja', region: 'Eastern', listings: 720, growth: '+15%' },
  { name: 'Mbarara', region: 'Western', listings: 650, growth: '+6%' },
  { name: 'Gulu', region: 'Northern', listings: 420, growth: '+22%' },
  { name: 'Mbale', region: 'Eastern', listings: 380, growth: '+10%' },
];

const UgandaMapVisualization: React.FC<UgandaMapVisualizationProps> = ({
  onLocationSelect,
  selectedDistrict,
  listingCounts = {}
}) => {
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const [is3D, setIs3D] = useState(true);
  const [rotation, setRotation] = useState({ x: 15, z: -5 });
  const mapRef = useRef<SVGSVGElement>(null);

  const getRegionOpacity = (count: number) => {
    if (count > 3000) return 1;
    if (count > 1500) return 0.7;
    if (count > 500) return 0.5;
    return 0.3;
  };

  const handleReset = () => {
    setZoom(1);
    setRotation({ x: 15, z: -5 });
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-emerald-500/10 rounded-lg">
            <MapPin className="w-4 h-4 text-emerald-500" />
          </div>
          <h3 className="font-medium text-sm text-foreground">Uganda Regions</h3>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => setIs3D(!is3D)}
            title={is3D ? 'Switch to 2D' : 'Switch to 3D'}
          >
            <Layers className={`w-3.5 h-3.5 ${is3D ? 'text-primary' : ''}`} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => setZoom(Math.min(zoom + 0.15, 1.5))}
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => setZoom(Math.max(zoom - 0.15, 0.8))}
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={handleReset}
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* 3D Map Container */}
      <div 
        className="relative bg-gradient-to-br from-muted/50 via-background to-muted/30 rounded-2xl border border-border overflow-hidden"
        style={{ height: '280px', perspective: is3D ? '800px' : 'none' }}
      >
        {/* Background Grid */}
        <div className="absolute inset-0 opacity-5">
          <svg className="w-full h-full">
            <defs>
              <pattern id="map-grid" width="15" height="15" patternUnits="userSpaceOnUse">
                <path d="M 15 0 L 0 0 0 15" fill="none" stroke="currentColor" strokeWidth="0.5"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#map-grid)" />
          </svg>
        </div>

        {/* Uganda Map SVG */}
        <div 
          className="absolute inset-0 flex items-center justify-center transition-transform duration-500"
          style={{ 
            transform: is3D 
              ? `scale(${zoom}) rotateX(${rotation.x}deg) rotateZ(${rotation.z}deg)` 
              : `scale(${zoom})`,
            transformStyle: 'preserve-3d'
          }}
        >
          <TooltipProvider>
            <svg 
              ref={mapRef}
              viewBox="0 0 100 95" 
              className="w-64 h-64"
              style={{ 
                filter: is3D ? 'drop-shadow(0 8px 16px rgba(0,0,0,0.2))' : 'drop-shadow(0 2px 4px rgba(0,0,0,0.1))'
              }}
            >
              <defs>
                {/* Gradient for regions */}
                <linearGradient id="regionGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.4" />
                </linearGradient>
                
                {/* Water gradient */}
                <linearGradient id="waterGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.6" />
                  <stop offset="100%" stopColor="#1d4ed8" stopOpacity="0.4" />
                </linearGradient>

                {/* Shadow filter */}
                <filter id="regionShadow" x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="0" dy="2" stdDeviation="2" floodOpacity="0.3"/>
                </filter>
              </defs>

              {/* Uganda Outline Base */}
              <path
                d="M 8,35 L 20,30 L 35,28 L 38,18 L 45,8 L 55,5 L 70,8 L 82,12 L 88,18 L 90,28 L 92,50 L 90,60 L 85,68 L 78,72 L 68,82 Q 60,88 52,85 L 42,78 L 35,78 L 25,82 L 15,78 L 8,70 L 5,58 L 5,45 Z"
                className="fill-muted/50 stroke-border"
                strokeWidth="0.5"
              />

              {/* Regions */}
              {ugandaRegions.map((region) => {
                const isHovered = hoveredRegion === region.id;
                const isSelected = selectedDistrict && region.districts.includes(selectedDistrict);
                
                return (
                  <Tooltip key={region.id}>
                    <TooltipTrigger asChild>
                      <g
                        className="cursor-pointer transition-all duration-300"
                        onMouseEnter={() => setHoveredRegion(region.id)}
                        onMouseLeave={() => setHoveredRegion(null)}
                        onClick={() => onLocationSelect(region.districts[0])}
                        style={{
                          transform: isHovered && is3D ? 'translateZ(8px)' : 'translateZ(0)',
                          transformStyle: 'preserve-3d'
                        }}
                      >
                        <path
                          d={region.path}
                          fill={region.color}
                          className={`transition-all duration-300 ${
                            isHovered ? 'opacity-100' : 'opacity-80'
                          } ${isSelected ? 'stroke-primary stroke-2' : 'stroke-border/50 stroke-[0.5]'}`}
                          filter={isHovered ? 'url(#regionShadow)' : undefined}
                        />
                        
                        {/* Region label */}
                        <text
                          x={region.centerX}
                          y={region.centerY}
                          textAnchor="middle"
                          className="fill-foreground text-[5px] font-semibold pointer-events-none"
                          style={{ textShadow: '0 1px 2px rgba(255,255,255,0.8)' }}
                        >
                          {region.name}
                        </text>
                        <text
                          x={region.centerX}
                          y={region.centerY + 6}
                          textAnchor="middle"
                          className="fill-muted-foreground text-[3.5px] pointer-events-none"
                        >
                          {region.count.toLocaleString()} listings
                        </text>

                        {/* Pulse effect for selected */}
                        {isSelected && (
                          <circle
                            cx={region.centerX}
                            cy={region.centerY}
                            r="8"
                            className="fill-none stroke-primary animate-ping opacity-50"
                            strokeWidth="0.5"
                          />
                        )}
                      </g>
                    </TooltipTrigger>
                    <TooltipContent side="top" className="bg-background border shadow-lg">
                      <div className="text-center space-y-1">
                        <p className="font-semibold">{region.name} Region</p>
                        <p className="text-xs text-muted-foreground">{region.count.toLocaleString()} listings</p>
                        <div className="flex flex-wrap gap-1 max-w-[150px]">
                          {region.districts.slice(0, 4).map(d => (
                            <Badge key={d} variant="secondary" className="text-[10px] px-1.5 py-0">
                              {d}
                            </Badge>
                          ))}
                          {region.districts.length > 4 && (
                            <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                              +{region.districts.length - 4}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                );
              })}

              {/* Lakes */}
              {lakesAndRivers.map((lake) => (
                <Tooltip key={lake.name}>
                  <TooltipTrigger asChild>
                    <path
                      d={lake.path}
                      fill="url(#waterGradient)"
                      className="stroke-blue-400/50 cursor-pointer hover:opacity-80 transition-opacity"
                      strokeWidth="0.3"
                    />
                  </TooltipTrigger>
                  <TooltipContent side="top" className="bg-background border">
                    <p className="text-xs font-medium">{lake.name}</p>
                  </TooltipContent>
                </Tooltip>
              ))}

              {/* Kampala marker */}
              <g className="cursor-pointer" onClick={() => onLocationSelect('Kampala')}>
                <circle cx="52" cy="62" r="2" className="fill-destructive animate-pulse" />
                <circle cx="52" cy="62" r="3.5" className="fill-none stroke-destructive/50" strokeWidth="0.5" />
              </g>
            </svg>
          </TooltipProvider>
        </div>

        {/* Legend */}
        <div className="absolute bottom-3 left-3 flex items-center gap-3 bg-background/90 backdrop-blur-sm rounded-lg px-3 py-2 border border-border/50">
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-primary" />
            <span className="text-[10px] text-muted-foreground">High</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-primary/50" />
            <span className="text-[10px] text-muted-foreground">Medium</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-primary/25" />
            <span className="text-[10px] text-muted-foreground">Low</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-blue-500/60" />
            <span className="text-[10px] text-muted-foreground">Water</span>
          </div>
        </div>

        {/* Capital indicator */}
        <div className="absolute bottom-3 right-3 flex items-center gap-1.5 bg-background/90 backdrop-blur-sm rounded-lg px-2 py-1.5 border border-border/50">
          <div className="w-2 h-2 rounded-full bg-destructive animate-pulse" />
          <span className="text-[10px] text-muted-foreground">Kampala</span>
        </div>
      </div>

      {/* Popular Districts */}
      <div className="space-y-2">
        <p className="text-xs text-muted-foreground font-medium">Top Districts</p>
        <div className="grid grid-cols-2 gap-2">
          {popularDistricts.slice(0, 6).map((district, index) => (
            <button
              key={index}
              onClick={() => onLocationSelect(district.name)}
              className={`flex items-center justify-between p-2.5 rounded-xl border transition-all duration-200 hover:scale-[1.02] ${
                selectedDistrict === district.name
                  ? 'bg-primary/10 border-primary/30'
                  : 'bg-muted/30 border-border hover:bg-muted/50'
              }`}
            >
              <div className="flex items-center gap-2">
                <MapPin className={`w-3.5 h-3.5 ${selectedDistrict === district.name ? 'text-primary' : 'text-muted-foreground'}`} />
                <div className="text-left">
                  <p className="text-xs font-medium text-foreground">{district.name}</p>
                  <p className="text-[10px] text-muted-foreground">{district.region}</p>
                </div>
              </div>
              <div className="text-right">
                <Badge variant="secondary" className="text-[10px] bg-background">
                  {district.listings.toLocaleString()}
                </Badge>
                <p className="text-[9px] text-emerald-500 mt-0.5">{district.growth}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default UgandaMapVisualization;
