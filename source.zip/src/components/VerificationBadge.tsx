import React from 'react';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';
import { cn } from '@/lib/utils';

interface VerificationBadgeProps {
  isVerified?: boolean;
  badgeColor?: BadgeColor;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  className?: string;
}

const VerificationBadge: React.FC<VerificationBadgeProps> = ({
  isVerified = false,
  badgeColor = 'blue',
  size = 'sm',
  showText = true,
  className
}) => {
  if (!isVerified) return null;

  const sizeMap = {
    sm: 'xs' as const,
    md: 'sm' as const,
    lg: 'md' as const
  };

  return (
    <div className={cn('flex items-center gap-1', className)}>
      <UnifiedVerifiedBadge 
        isVerified={isVerified} 
        badgeColor={badgeColor}
        size={sizeMap[size]} 
      />
      {showText && <span className="text-xs font-medium">Verified</span>}
    </div>
  );
};

export default VerificationBadge;