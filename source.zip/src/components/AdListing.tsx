import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useQuery, useInfiniteQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import AdCard from '@/components/AdCard';
import ProductSkeleton from '@/components/LoadingSkeleton';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { useAuth } from '@/components/auth/AuthContext';
import { useGeolocation } from '@/hooks/useGeolocation';
import { rankMarketplaceItems } from '@/lib/feedRanking';
import { saveToCache, loadFromCache, CACHE_KEYS } from '@/utils/offlineCache';

interface Seller {
  id: string;
  business_name?: string;
  business_logo_url?: string;
  is_verified?: boolean;
  is_featured?: boolean;
  rating?: number;
  total_sales?: number;
  user_id?: string;
}

interface Ad {
  id: string;
  title: string;
  price: number;
  location: string;
  images: string[];
  is_boosted: boolean;
  engagement_score?: number;
  created_at: string;
  category: string;
  seller?: Seller | null;
  seller_id: string;
  currency?: string;
  is_price_negotiable?: boolean;
  condition?: string;
  youtube_url?: string;
  tiktok_url?: string;
  listing_type?: string;
}

const ITEMS_PER_PAGE = 50;

const AdListing = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { locationName } = useGeolocation();
  const [likedAds, setLikedAds] = useState<Set<string>>(new Set());
  const [savedAds, setSavedAds] = useState<Set<string>>(new Set());
  const loadMoreRef = useRef<HTMLDivElement>(null);

  const { data: followedUserIds = [] } = useQuery({
    queryKey: ['followed-user-ids', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const { data } = await supabase
        .from('follows')
        .select('following_id')
        .eq('follower_id', user.id);
      return data?.map(f => f.following_id) || [];
    },
    enabled: !!user?.id,
    staleTime: 1000 * 60 * 5,
  });

  const { 
    data, 
    isLoading, 
    error, 
    refetch, 
    fetchNextPage, 
    hasNextPage, 
    isFetchingNextPage 
  } = useInfiniteQuery({
    queryKey: ['ads-marketplace', locationName, followedUserIds],
    queryFn: async ({ pageParam = 0 }) => {
      const offset = pageParam * ITEMS_PER_PAGE;
      
      const { data: adsData, error: adsError } = await supabase
        .from('ads')
        .select(`
          id, title, price, location, images, is_boosted, engagement_score,
          created_at, seller_id, category, currency, is_price_negotiable,
          condition, youtube_url, tiktok_url, listing_type,
          is_sponsored, sponsored_until,
          seller_profiles (
            id, user_id, business_name, business_logo_url, is_verified, is_featured,
            verification_score, district, sub_county
          )
        `)
        .eq('status', 'active')
        .in('listing_type', ['physical_products', 'digital_products', 'services'])
        .order('created_at', { ascending: false })
        .range(offset, offset + ITEMS_PER_PAGE - 1);
      
      if (adsError) throw adsError;
      
      const mapped = (adsData || []).map(ad => ({
        id: ad.id,
        title: ad.title,
        price: ad.price,
        location: ad.location || 'Location not specified',
        images: ad.images || [],
        is_boosted: ad.is_boosted,
        engagement_score: ad.engagement_score,
        created_at: ad.created_at,
        category: ad.category,
        seller_id: ad.seller_id,
        currency: ad.currency,
        is_price_negotiable: ad.is_price_negotiable,
        condition: ad.condition,
        listing_type: ad.listing_type,
        youtube_url: ad.youtube_url,
        tiktok_url: ad.tiktok_url,
        seller: ad.seller_profiles ? { ...(ad.seller_profiles as any) } : null
      } as Ad));

      // Apply marketplace ranking
      const ranked = rankMarketplaceItems(
        mapped.map(ad => ({
          ...ad,
          content_type: 'ad' as const,
          listing_type: ad.listing_type || 'physical_products',
          is_sponsored: (ad as any).is_sponsored || false,
          sponsored_until: (ad as any).sponsored_until || null,
          seller: {
            is_verified: ad.seller?.is_verified || false,
            is_featured: ad.seller?.is_featured || false,
            user_id: ad.seller?.user_id || '',
          },
        })),
        followedUserIds,
        locationName
      );
      
      const rankedAds = ranked.map(r => mapped.find(m => m.id === r.id)!);
      
      // Cache first page for offline use
      if (pageParam === 0) {
        saveToCache(CACHE_KEYS.MARKETPLACE, rankedAds);
      }
      
      return {
        items: rankedAds,
        nextPage: adsData && adsData.length === ITEMS_PER_PAGE ? pageParam + 1 : undefined,
      };
    },
    getNextPageParam: (lastPage) => lastPage.nextPage,
    initialPageParam: 0,
    staleTime: 1000 * 60 * 2,
    refetchOnWindowFocus: true,
  });

  // Offline cache fallback
  const { data: cachedAds } = useQuery({
    queryKey: ['ads-marketplace-cache'],
    queryFn: () => loadFromCache<Ad[]>(CACHE_KEYS.MARKETPLACE, 60 * 60 * 1000),
    staleTime: Infinity,
  });

  const ads = data?.pages.flatMap(p => p.items) || cachedAds || [];

  // Infinite scroll observer
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage) {
          fetchNextPage();
        }
      },
      { rootMargin: '800px 0px', threshold: 0 }
    );

    if (loadMoreRef.current) {
      observer.observe(loadMoreRef.current);
    }

    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  const handleAdClick = (id: string) => {
    navigate(`/ad/${id}`);
  };

  const handleLike = (id: string) => {
    setLikedAds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
        toast.success('Removed from liked items');
      } else {
        newSet.add(id);
        toast.success('Added to liked items');
      }
      return newSet;
    });
  };

  const handleSave = (id: string) => {
    setSavedAds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
        toast.success('Removed from saved items');
      } else {
        newSet.add(id);
        toast.success('Added to saved items');
      }
      return newSet;
    });
  };

  const handleCall = (id: string) => {
    const ad = ads.find(a => a.id === id);
    if (ad?.seller?.business_name) {
      console.log('Calling seller for ad:', id);
      toast.info('Opening phone dialer...');
    }
  };

  if (error) {
    return (
      <div className="py-4 px-2 md:px-4 text-center">
        <p className="text-destructive mb-4 text-sm md:text-base">Error loading ads. Please try again later.</p>
        <Button onClick={() => refetch()} size="sm">Retry</Button>
      </div>
    );
  }

  return (
    <div className="py-2 md:py-4 px-2 md:px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-3 md:mb-4">
          <div>
            <h2 className="text-lg md:text-xl font-bold text-foreground mb-1">Latest Items</h2>
            <p className="text-muted-foreground text-xs md:text-sm">Fresh listings from verified sellers across Uganda</p>
          </div>
          <Button 
            variant="outline" 
            onClick={() => navigate('/search')}
            className="text-primary border-primary hover:bg-primary hover:text-white text-xs md:text-sm"
            size="sm"
          >
            View All Items
          </Button>
        </div>

        {isLoading ? (
          <ProductSkeleton count={10} layout="grid" />
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2 md:gap-3">
            {ads.map((ad) => (
              <AdCard 
                key={ad.id} 
                ad={ad} 
                onClick={handleAdClick}
              />
            ))}
          </div>
        )}

        {/* Infinite scroll trigger */}
        <div ref={loadMoreRef} className="py-4">
          {isFetchingNextPage && <ProductSkeleton count={6} layout="grid" />}
          {!isFetchingNextPage && ads.length > 0 && (
            <div className="text-center py-4">
              <Button 
                onClick={() => navigate('/marketplace')}
                variant="outline"
                className="text-primary border-primary hover:bg-primary hover:text-white"
              >
                Show More on Marketplace
              </Button>
            </div>
          )}
        </div>
        {!isLoading && ads.length === 0 && (
          <div className="text-center py-8 md:py-12">
            <div className="max-w-md mx-auto px-4">
              <div className="w-16 h-16 md:w-24 md:h-24 bg-secondary rounded-full flex items-center justify-center mx-auto mb-3 md:mb-4">
                <span className="text-2xl md:text-4xl">📦</span>
              </div>
              <h3 className="text-base md:text-lg font-medium text-foreground mb-2">No items found</h3>
              <p className="text-sm md:text-base text-muted-foreground mb-4">Be the first to post an item in your area!</p>
              <Button onClick={() => navigate('/post-ad')} className="bg-primary text-white hover:bg-primary/90" size="sm">
                Post Your First Item
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdListing;
