import React from 'react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Shield, BadgeCheck, Award } from 'lucide-react';

interface SellerBadgeDisplayProps {
  badgeLevel: 'basic' | 'verified' | 'trusted';
  showPreview?: boolean;
  sellerName?: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const SellerBadgeDisplay: React.FC<SellerBadgeDisplayProps> = ({
  badgeLevel,
  showPreview = false,
  sellerName,
  size = 'sm',
  className
}) => {
  const badgeConfig = {
    basic: {
      label: 'Basic Seller',
      icon: Shield,
      bgClass: 'bg-slate-500/10 border-slate-500/20',
      textClass: 'text-slate-600 dark:text-slate-400',
      iconClass: 'text-slate-500'
    },
    verified: {
      label: 'Verified',
      icon: BadgeCheck,
      bgClass: 'bg-blue-500/10 border-blue-500/20',
      textClass: 'text-blue-600 dark:text-blue-400',
      iconClass: 'text-blue-500'
    },
    trusted: {
      label: 'Trusted',
      icon: Award,
      bgClass: 'bg-gradient-to-r from-amber-500/10 to-yellow-500/10 border-amber-500/20',
      textClass: 'text-amber-600 dark:text-amber-400',
      iconClass: 'text-amber-500'
    }
  };

  const config = badgeConfig[badgeLevel];
  const IconComponent = config.icon;
  
  const sizes = {
    sm: { badge: 'text-xs px-2 py-0.5', icon: 'w-3 h-3' },
    md: { badge: 'text-sm px-3 py-1', icon: 'w-4 h-4' },
    lg: { badge: 'text-base px-4 py-1.5', icon: 'w-5 h-5' }
  };

  if (showPreview && sellerName) {
    return (
      <div className={cn('flex items-center gap-2', className)}>
        <span className="font-medium">{sellerName}</span>
        <Badge 
          variant="outline" 
          className={cn(
            'gap-1 font-medium border',
            config.bgClass,
            config.textClass,
            sizes[size].badge
          )}
        >
          <IconComponent className={cn(sizes[size].icon, config.iconClass)} />
          {config.label}
        </Badge>
      </div>
    );
  }

  return (
    <Badge 
      variant="outline" 
      className={cn(
        'gap-1 font-medium border',
        config.bgClass,
        config.textClass,
        sizes[size].badge,
        className
      )}
    >
      <IconComponent className={cn(sizes[size].icon, config.iconClass)} />
      {config.label}
    </Badge>
  );
};

export default SellerBadgeDisplay;