import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { 
  Phone, 
  CheckCircle2, 
  Loader2, 
  Send,
  RefreshCw
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface PhoneVerificationStepProps {
  verificationData: any;
  onComplete: () => void;
}

const PhoneVerificationStep: React.FC<PhoneVerificationStepProps> = ({
  verificationData,
  onComplete
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [phoneNumber, setPhoneNumber] = useState(verificationData?.phone_number || '');
  const [otp, setOtp] = useState('');
  const [sending, setSending] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [mockOtp, setMockOtp] = useState('');

  const isVerified = verificationData?.phone_verified;

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const handleSendOTP = async () => {
    if (!phoneNumber || phoneNumber.length < 10) {
      toast({
        title: 'Invalid Phone Number',
        description: 'Please enter a valid phone number.',
        variant: 'destructive',
      });
      return;
    }
    
    setSending(true);
    try {
      // Generate mock OTP (in production, this would be sent via SMS gateway)
      const generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
      setMockOtp(generatedOtp);

      // Update verification record
      await supabase
        .from('seller_verifications')
        .update({
          phone_number: phoneNumber,
          phone_otp_code: generatedOtp,
          phone_otp_sent_at: new Date().toISOString(),
          phone_otp_attempts: 0
        })
        .eq('user_id', user?.id);

      setOtpSent(true);
      setCountdown(60);
      toast({
        title: 'OTP Sent',
        description: `A 6-digit code has been sent to ${phoneNumber}. For demo: ${generatedOtp}`,
      });
    } catch (error: any) {
      toast({
        title: 'Failed to Send OTP',
        description: error.message || 'Could not send OTP.',
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (otp.length !== 6) {
      toast({
        title: 'Invalid OTP',
        description: 'Please enter the 6-digit code.',
        variant: 'destructive',
      });
      return;
    }
    
    setVerifying(true);
    try {
      // Verify OTP (check against stored value)
      const { data, error } = await supabase
        .from('seller_verifications')
        .select('phone_otp_code, phone_otp_attempts')
        .eq('user_id', user?.id)
        .single();

      if (error) throw error;

      if (data.phone_otp_attempts >= 3) {
        toast({
          title: 'Too Many Attempts',
          description: 'Please request a new OTP.',
          variant: 'destructive',
        });
        return;
      }

      if (data.phone_otp_code === otp) {
        // Update verification record
        await supabase
          .from('seller_verifications')
          .update({
            phone_verified: true,
            phone_verified_at: new Date().toISOString(),
            phone_otp_code: null
          })
          .eq('user_id', user?.id);

        toast({
          title: 'Phone Verified!',
          description: 'Your phone number has been successfully verified.',
        });
        onComplete();
      } else {
        // Increment attempts
        await supabase
          .from('seller_verifications')
          .update({
            phone_otp_attempts: (data.phone_otp_attempts || 0) + 1
          })
          .eq('user_id', user?.id);

        toast({
          title: 'Invalid OTP',
          description: 'The code you entered is incorrect. Please try again.',
          variant: 'destructive',
        });
      }
    } catch (error: any) {
      toast({
        title: 'Verification Failed',
        description: error.message || 'Could not verify OTP.',
        variant: 'destructive',
      });
    } finally {
      setVerifying(false);
    }
  };

  if (isVerified) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-full bg-green-500/10">
            <Phone className="w-8 h-8 text-green-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Phone Verification</h2>
            <p className="text-muted-foreground">Your phone is verified</p>
          </div>
        </div>

        <div className="p-6 rounded-xl bg-green-50 dark:bg-green-950/20 border border-green-200">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-green-600" />
            <div>
              <p className="font-semibold text-green-900 dark:text-green-100">Phone Verified</p>
              <p className="text-sm text-green-700 dark:text-green-300">{verificationData?.phone_number}</p>
            </div>
          </div>
        </div>

        <Button onClick={onComplete} className="w-full">
          Continue to Government ID
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-3 rounded-full bg-primary/10">
          <Phone className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-bold">Phone Verification</h2>
          <p className="text-muted-foreground">Verify your phone number with OTP</p>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <Label>Phone Number</Label>
          <div className="flex gap-2 mt-2">
            <Input 
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder="+256 XXX XXX XXX"
              disabled={otpSent}
            />
            {!otpSent && (
              <Button 
                onClick={handleSendOTP} 
                disabled={sending || !phoneNumber}
              >
                {sending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            )}
          </div>
        </div>

        {otpSent && (
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-950/20 border border-blue-200">
              <p className="text-sm text-blue-900 dark:text-blue-100">
                Enter the 6-digit code sent to <strong>{phoneNumber}</strong>
              </p>
              {mockOtp && (
                <p className="text-xs text-blue-600 mt-1">
                  Demo OTP: <code className="bg-blue-100 px-2 py-0.5 rounded">{mockOtp}</code>
                </p>
              )}
            </div>

            <div className="flex justify-center">
              <InputOTP
                value={otp}
                onChange={setOtp}
                maxLength={6}
              >
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
            </div>

            <div className="flex gap-3">
              <Button 
                variant="outline"
                onClick={handleSendOTP}
                disabled={countdown > 0 || sending}
                className="flex-1"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                {countdown > 0 ? `Resend in ${countdown}s` : 'Resend OTP'}
              </Button>
              <Button 
                onClick={handleVerifyOTP}
                disabled={verifying || otp.length !== 6}
                className="flex-1"
              >
                {verifying ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Verifying...
                  </>
                ) : (
                  'Verify OTP'
                )}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PhoneVerificationStep;