import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Share2, 
  CheckCircle2, 
  XCircle,
  Facebook,
  Instagram,
  Twitter,
  Loader2,
  Link2,
  Unlink
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface SocialMediaStepProps {
  userId: string;
  onComplete: () => void;
}

const SocialMediaStep: React.FC<SocialMediaStepProps> = ({
  userId,
  onComplete
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: connections, isLoading } = useQuery({
    queryKey: ['social-connections', userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('seller_social_connections')
        .select('*')
        .eq('user_id', userId);
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!userId
  });

  const connectMutation = useMutation({
    mutationFn: async (platform: string) => {
      // In production, this would redirect to OAuth flow
      // For demo, we mock a successful connection
      const { error } = await supabase
        .from('seller_social_connections')
        .upsert({
          user_id: userId,
          platform,
          is_connected: true,
          connected_at: new Date().toISOString(),
          platform_username: `@demo_user_${platform}`
        });
      
      if (error) throw error;
    },
    onSuccess: (_, platform) => {
      queryClient.invalidateQueries({ queryKey: ['social-connections'] });
      toast({
        title: 'Account Connected',
        description: `Your ${platform} account has been linked.`,
      });
    },
    onError: () => {
      toast({
        title: 'Connection Failed',
        description: 'Could not connect account.',
        variant: 'destructive',
      });
    }
  });

  const disconnectMutation = useMutation({
    mutationFn: async (platform: string) => {
      const { error } = await supabase
        .from('seller_social_connections')
        .update({
          is_connected: false,
          disconnected_at: new Date().toISOString()
        })
        .eq('user_id', userId)
        .eq('platform', platform);
      
      if (error) throw error;
    },
    onSuccess: (_, platform) => {
      queryClient.invalidateQueries({ queryKey: ['social-connections'] });
      toast({
        title: 'Account Disconnected',
        description: `Your ${platform} account has been unlinked.`,
      });
    }
  });

  const platforms = [
    { id: 'facebook', name: 'Facebook', icon: Facebook, color: 'text-blue-600' },
    { id: 'instagram', name: 'Instagram', icon: Instagram, color: 'text-pink-600' },
    { id: 'twitter', name: 'X (Twitter)', icon: Twitter, color: 'text-sky-500' },
  ];

  const getConnectionStatus = (platformId: string) => {
    const connection = connections?.find(c => c.platform === platformId);
    return connection?.is_connected ? connection : null;
  };

  const hasAnyConnection = connections?.some(c => c.is_connected);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-3 rounded-full bg-primary/10">
          <Share2 className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-bold">Social Media Linking</h2>
          <p className="text-muted-foreground">Connect your social accounts (optional)</p>
        </div>
      </div>

      <div className="p-4 rounded-lg bg-muted/50 border">
        <p className="text-sm text-muted-foreground">
          Linking your social media accounts helps build trust with buyers and shows you're a real person. 
          This step is optional but recommended.
        </p>
      </div>

      <div className="space-y-3">
        {platforms.map((platform) => {
          const connection = getConnectionStatus(platform.id);
          const isConnecting = connectMutation.isPending && connectMutation.variables === platform.id;
          const isDisconnecting = disconnectMutation.isPending && disconnectMutation.variables === platform.id;
          
          return (
            <div
              key={platform.id}
              className={cn(
                'flex items-center justify-between p-4 rounded-xl border transition-colors',
                connection ? 'bg-green-50/50 dark:bg-green-950/20 border-green-200' : 'bg-card'
              )}
            >
              <div className="flex items-center gap-3">
                <platform.icon className={cn('w-6 h-6', platform.color)} />
                <div>
                  <p className="font-medium">{platform.name}</p>
                  {connection && (
                    <p className="text-xs text-muted-foreground">
                      {connection.platform_username}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                {connection ? (
                  <>
                    <Badge className="bg-green-500/10 text-green-600 border-green-500/20">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Connected
                    </Badge>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => disconnectMutation.mutate(platform.id)}
                      disabled={isDisconnecting}
                    >
                      {isDisconnecting ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Unlink className="w-4 h-4" />
                      )}
                    </Button>
                  </>
                ) : (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => connectMutation.mutate(platform.id)}
                    disabled={isConnecting}
                  >
                    {isConnecting ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Link2 className="w-4 h-4 mr-2" />
                    )}
                    Connect
                  </Button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {hasAnyConnection && (
        <div className="p-4 rounded-lg bg-green-50 dark:bg-green-950/20 border border-green-200">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-green-600" />
            <span className="text-sm font-medium text-green-900 dark:text-green-100">
              Social accounts linked! This helps build buyer trust.
            </span>
          </div>
        </div>
      )}

      <Button onClick={onComplete} className="w-full" size="lg">
        {hasAnyConnection ? 'Continue to KYC Form' : 'Skip for Now'}
      </Button>
    </div>
  );
};

export default SocialMediaStep;