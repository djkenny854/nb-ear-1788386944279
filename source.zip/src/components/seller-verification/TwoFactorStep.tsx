import React, { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { 
  Shield, 
  CheckCircle2, 
  Loader2,
  Smartphone,
  Mail,
  Lock
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface TwoFactorStepProps {
  verificationData: any;
  onComplete: () => void;
}

const TwoFactorStep: React.FC<TwoFactorStepProps> = ({
  verificationData,
  onComplete
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [enabling, setEnabling] = useState(false);
  const [method, setMethod] = useState<'sms' | 'email'>(verificationData?.two_fa_method || 'sms');
  const [isEnabled, setIsEnabled] = useState(verificationData?.two_fa_enabled || false);

  const handleToggle2FA = async (enabled: boolean) => {
    setEnabling(true);
    try {
      await supabase
        .from('seller_verifications')
        .update({
          two_fa_enabled: enabled,
          two_fa_method: enabled ? method : null,
          two_fa_enabled_at: enabled ? new Date().toISOString() : null
        })
        .eq('user_id', user?.id);

      setIsEnabled(enabled);
      toast({
        title: enabled ? '2FA Enabled' : '2FA Disabled',
        description: enabled 
          ? `Two-factor authentication via ${method.toUpperCase()} is now active.`
          : 'Two-factor authentication has been disabled.',
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Could not update 2FA settings.',
        variant: 'destructive',
      });
    } finally {
      setEnabling(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-3 rounded-full bg-primary/10">
          <Shield className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-bold">Two-Factor Authentication</h2>
          <p className="text-muted-foreground">Add an extra layer of security (optional)</p>
        </div>
      </div>

      <div className="p-4 rounded-lg bg-muted/50 border">
        <div className="flex items-start gap-3">
          <Lock className="w-5 h-5 text-primary mt-0.5" />
          <div>
            <h4 className="font-medium">Why enable 2FA?</h4>
            <p className="text-sm text-muted-foreground mt-1">
              Two-factor authentication adds an extra layer of security by requiring a verification code 
              in addition to your password when logging in.
            </p>
          </div>
        </div>
      </div>

      {/* 2FA Toggle */}
      <div className="flex items-center justify-between p-4 rounded-xl border">
        <div className="flex items-center gap-3">
          <Shield className={cn(
            'w-6 h-6',
            isEnabled ? 'text-green-600' : 'text-muted-foreground'
          )} />
          <div>
            <p className="font-medium">Enable Two-Factor Authentication</p>
            <p className="text-sm text-muted-foreground">
              {isEnabled ? 'Currently enabled' : 'Not enabled'}
            </p>
          </div>
        </div>
        <Switch
          checked={isEnabled}
          onCheckedChange={handleToggle2FA}
          disabled={enabling}
        />
      </div>

      {/* Method Selection */}
      {!isEnabled && (
        <div className="space-y-4">
          <Label className="text-base font-medium">Select verification method:</Label>
          <RadioGroup
            value={method}
            onValueChange={(value) => setMethod(value as 'sms' | 'email')}
            className="grid sm:grid-cols-2 gap-4"
          >
            <div className={cn(
              'flex items-center space-x-3 p-4 rounded-xl border cursor-pointer transition-colors',
              method === 'sms' && 'border-primary bg-primary/5'
            )}>
              <RadioGroupItem value="sms" id="sms" />
              <Label htmlFor="sms" className="flex items-center gap-2 cursor-pointer flex-1">
                <Smartphone className="w-5 h-5 text-primary" />
                <div>
                  <p className="font-medium">SMS OTP</p>
                  <p className="text-xs text-muted-foreground">Receive codes via SMS</p>
                </div>
              </Label>
            </div>

            <div className={cn(
              'flex items-center space-x-3 p-4 rounded-xl border cursor-pointer transition-colors',
              method === 'email' && 'border-primary bg-primary/5'
            )}>
              <RadioGroupItem value="email" id="email" />
              <Label htmlFor="email" className="flex items-center gap-2 cursor-pointer flex-1">
                <Mail className="w-5 h-5 text-primary" />
                <div>
                  <p className="font-medium">Email OTP</p>
                  <p className="text-xs text-muted-foreground">Receive codes via email</p>
                </div>
              </Label>
            </div>
          </RadioGroup>
        </div>
      )}

      {isEnabled && (
        <div className="p-6 rounded-xl bg-green-50 dark:bg-green-950/20 border border-green-200">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-green-600" />
            <div>
              <p className="font-semibold text-green-900 dark:text-green-100">2FA Active</p>
              <p className="text-sm text-green-700 dark:text-green-300">
                Method: {verificationData?.two_fa_method?.toUpperCase() || method.toUpperCase()}
              </p>
            </div>
          </div>
        </div>
      )}

      <Button onClick={onComplete} className="w-full" size="lg">
        {isEnabled ? 'Continue to Login Security' : 'Skip for Now'}
      </Button>
    </div>
  );
};

export default TwoFactorStep;