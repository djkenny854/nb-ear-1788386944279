import React from 'react';
import { Sparkles, Wand2, ImageIcon, Search } from 'lucide-react';
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';
import earlymarketMono from '@/assets/earlymarket-mono.svg';

const AIFeaturesScreen: React.FC = () => {
  return (
    <div className="flex flex-col h-full px-6 overflow-y-auto">
      <div className="flex items-center gap-2 pt-4 mb-4">
        <img src={earlymarketLogo} alt="" className="w-6 h-6 object-contain" />
        <span className="text-sm font-medium text-foreground/80">Earlymarket</span>
      </div>

      <h1 className="text-[40px] leading-[1.05] tracking-tight font-light text-foreground mb-3">
        Meet<br />Earlymarket AI
      </h1>
      <p className="text-[15px] leading-relaxed text-muted-foreground mb-6">
        Built-in AI helps you post faster, look sharper and find exactly what you need.
      </p>

      {/* Hero AI badge */}
      <div className="flex-1 flex items-center justify-center min-h-[180px]">
        <div className="relative">
          <span className="absolute -top-3 -left-4 w-2.5 h-2.5 rounded-full bg-[#FC9D3F]" />
          <span className="absolute -top-2 right-2 w-2 h-2 rounded-full bg-[#DC63CC]" />
          <span className="absolute -bottom-3 -right-4 w-3 h-3 rounded-full bg-[#3076F8]" />
          <div className="w-32 h-32 rounded-3xl bg-gradient-to-br from-[#3076F8] via-[#6366f1] to-[#DC63CC] p-5 shadow-xl shadow-[#3076F8]/25 flex items-center justify-center">
            <img src={earlymarketMono} alt="Earlymarket AI" className="w-full h-full object-contain brightness-0 invert" />
          </div>
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 flex items-center gap-1 px-2.5 py-1 rounded-full bg-foreground text-background text-[11px] font-semibold shadow-md">
            <Sparkles className="w-3 h-3" />
            AI
          </div>
        </div>
      </div>

      <ul className="space-y-3 pt-6 pb-2">
        <Feature Icon={Wand2} title="Smart listing assistant" desc="Auto-write titles, descriptions and tags from a photo." />
        <Feature Icon={ImageIcon} title="AI image generation" desc="Create polished promo posters and product visuals." />
        <Feature Icon={Search} title="Visual & semantic search" desc="Snap or type — find items even without exact words." />
      </ul>
    </div>
  );
};

const Feature: React.FC<{ Icon: React.ComponentType<{ className?: string }>; title: string; desc: string }> = ({ Icon, title, desc }) => (
  <li className="flex items-start gap-3">
    <span className="w-10 h-10 rounded-xl bg-[#3076F8]/10 flex items-center justify-center shrink-0">
      <Icon className="w-5 h-5 text-[#3076F8]" />
    </span>
    <div className="flex-1 min-w-0">
      <div className="text-[15px] font-semibold text-foreground leading-tight">{title}</div>
      <div className="text-[13px] text-muted-foreground leading-snug">{desc}</div>
    </div>
  </li>
);

export default AIFeaturesScreen;
