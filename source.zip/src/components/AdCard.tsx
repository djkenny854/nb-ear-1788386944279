import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Star, Heart, MessageCircle, User } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import VerificationBadge from './VerificationBadge';
import ChatAuthPrompt from './chat/ChatAuthPrompt';
import VideoEmbed from './VideoEmbed';
import AnimatedText from './AnimatedText';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { getSellerProfileUrl } from '@/lib/sellerUrl';
interface AdCardProps {
  ad: {
    id: string;
    title: string;
    price: number;
    location: string;
    images: string[];
    is_boosted: boolean;
    created_at: string;
    category: string;
    currency?: string;
    seller_id: string;
    youtube_url?: string;
    tiktok_url?: string;
    has_discount?: boolean;
    original_price?: number;
    seller?: {
      id?: string;
      business_name?: string;
      business_logo_url?: string;
      is_verified?: boolean;
      district?: string;
      sub_county?: string;
      store_slug?: string;
    };
  };
  onClick: (id: string) => void;
  onChatClick?: (sellerId: string, adId: string) => void;
  currentUserId?: string | null;
}
const AdCard: React.FC<AdCardProps> = ({
  ad,
  onClick,
  onChatClick,
  currentUserId
}) => {
  const [isLiked, setIsLiked] = useState(false);
  const [showAuthPrompt, setShowAuthPrompt] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const navigate = useNavigate();

  // Auto-change images every 2 seconds with multiple images
  useEffect(() => {
    if (ad.images.length > 1) {
      const interval = setInterval(() => {
        setCurrentImageIndex(prev => (prev + 1) % ad.images.length);
      }, 2000);
      return () => clearInterval(interval);
    }
  }, [ad.images.length]);
  const getCategoryIcon = (category: string) => {
    const icons: {
      [key: string]: string;
    } = {
      'Cars': '🚗',
      'Electronics': '📱',
      'Fashion': '👔',
      'Home': '🏠',
      'Sports': '⚽',
      'Books': '📚'
    };
    return icons[category] || '📦';
  };
  const getInitials = (name: string) => {
    return name.split(' ').map(word => word.charAt(0)).join('').toUpperCase().slice(0, 2);
  };
  const getDisplayLocation = () => {
    if (ad.seller?.district && ad.seller?.sub_county) {
      return `${ad.seller.sub_county}, ${ad.seller.district}`;
    }
    if (ad.seller?.district) {
      return ad.seller.district;
    }
    return ad.location || 'Location not specified';
  };
  const toggleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsLiked(!isLiked);
  };
  const handleChatClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    
    // Check authentication
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      setShowAuthPrompt(true);
      return;
    }
    
    onChatClick?.(ad.seller_id, ad.id);
  };
  const handleSellerClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const sellerData = { id: ad.seller_id, ...ad.seller };
    navigate(getSellerProfileUrl(sellerData));
  };
  const handleAuthSuccess = () => {
    setShowAuthPrompt(false);
    window.location.reload();
  };
  return <>
      <div className="bg-card/60 backdrop-blur-sm rounded-md shadow-sm hover:shadow-lg transition-all duration-300 cursor-pointer group overflow-hidden border border-border hover:border-primary/40" onClick={() => onClick(ad.id)}>
        {/* Image Container - More compact */}
        <div className="relative aspect-square overflow-hidden bg-secondary">
          {/* Auto-changing images with fade transition */}
          <div className="relative w-full h-full">
            {ad.images.length > 0 ? ad.images.map((image, index) => <img key={index} src={image || "/placeholder.svg"} alt={ad.title} className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${index === currentImageIndex ? 'opacity-100' : 'opacity-0'}`} />) : <img src="/placeholder.svg" alt={ad.title} className="w-full h-full object-cover" />}
          </div>
          
          {/* Boost Badge */}
          {ad.is_boosted && <Badge className="absolute top-1 left-1 bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-xs px-1 py-0.5">
              <Star className="w-2 h-2 mr-0.5" />
              <span className="hidden sm:inline text-xs">Featured</span>
            </Badge>}

          {/* Category Tag */}
          

          {/* Image indicators for multiple images */}
          {ad.images.length > 1 && <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 flex gap-0.5">
              {ad.images.map((_, index) => <div key={index} className={`w-1 h-1 rounded-full transition-all duration-300 ${index === currentImageIndex ? 'bg-white' : 'bg-white/50'}`} />)}
            </div>}

          {/* Action Buttons - Overlay on image */}
          <div className="absolute bottom-1 right-1 flex items-center gap-1">
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0 bg-black/30 hover:bg-black/50 text-white hover:text-blue-400 rounded-full" onClick={handleChatClick}>
              <MessageCircle className="w-3 h-3" />
            </Button>
          </div>
        </div>

        {/* Content - Very compact */}
        <div className="p-2">
          {/* Seller Info - Ultra compact */}
          <div className="flex items-center gap-1 mb-1" onClick={handleSellerClick}>
            {ad.seller?.business_logo_url ? <img src={ad.seller.business_logo_url} alt={ad.seller.business_name || 'Seller'} className="w-3 h-3 rounded-full object-cover" /> : <div className="w-3 h-3 rounded-full bg-gradient-to-r from-primary to-orange-600 flex items-center justify-center">
                {ad.seller?.business_name ? <span className="text-white text-xs font-medium">
                    {getInitials(ad.seller.business_name)}
                  </span> : <User className="w-2 h-2 text-white" />}
              </div>}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-0.5">
                <span className="text-xs font-medium text-foreground truncate">
                  {ad.seller?.business_name || 'Seller'}
                </span>
                <VerificationBadge isVerified={ad.seller?.is_verified} size="sm" showText={false} />
              </div>
              <div className="text-xs text-muted-foreground">
                <AnimatedText texts={['Trusted Seller', 'Quality Products', 'Fast Response', 'Secure Payment']} className="text-xs" duration={2500} delay={300} />
              </div>
            </div>
          </div>

          {/* Title - Very compact */}
          <h3 className="font-semibold text-foreground mb-1 text-xs leading-tight line-clamp-2 group-hover:text-primary transition-colors">
            {ad.title}
          </h3>
          
          {/* Price */}
          <div className="mb-1">
            <p className="text-sm font-bold text-primary">
              {ad.currency || 'UGX'} {ad.price?.toLocaleString() || '0'}
            </p>
            {ad.has_discount && ad.original_price && (
              <div className="flex items-center gap-1">
                <p className="text-xs text-muted-foreground line-through">
                  {ad.currency || 'UGX'} {ad.original_price.toLocaleString()}
                </p>
                <Badge variant="destructive" className="text-xs px-1 py-0 h-4">
                  -{Math.round(((ad.original_price - ad.price) / ad.original_price) * 100)}%
                </Badge>
              </div>
            )}
          </div>
          
          {/* Location and Time - Ultra compact */}
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center min-w-0 flex-1">
              <MapPin className="w-2 h-2 mr-0.5 flex-shrink-0" />
              <span className="truncate text-xs">{getDisplayLocation()}</span>
            </div>
            <span className="ml-1 flex-shrink-0 text-xs">{formatDistanceToNow(new Date(ad.created_at), {
              addSuffix: true
            })}</span>
          </div>
        </div>
      </div>

      <ChatAuthPrompt isOpen={showAuthPrompt} onClose={() => setShowAuthPrompt(false)} onAuthSuccess={handleAuthSuccess} sellerName={ad.seller?.business_name || 'Seller'} isSellerOnline={Math.random() > 0.5} />
    </>;
};
export default AdCard;