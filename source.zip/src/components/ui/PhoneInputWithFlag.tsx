import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';

interface Country {
  code: string;
  name: string;
  dial: string;
  flag: string;
}

const countries: Country[] = [
  { code: 'UG', name: 'Uganda', dial: '+256', flag: '🇺🇬' },
  { code: 'KE', name: 'Kenya', dial: '+254', flag: '🇰🇪' },
  { code: 'TZ', name: 'Tanzania', dial: '+255', flag: '🇹🇿' },
  { code: 'RW', name: 'Rwanda', dial: '+250', flag: '🇷🇼' },
  { code: 'CD', name: 'DR Congo', dial: '+243', flag: '🇨🇩' },
  { code: 'SS', name: 'South Sudan', dial: '+211', flag: '🇸🇸' },
  { code: 'BI', name: 'Burundi', dial: '+257', flag: '🇧🇮' },
  { code: 'ET', name: 'Ethiopia', dial: '+251', flag: '🇪🇹' },
  { code: 'NG', name: 'Nigeria', dial: '+234', flag: '🇳🇬' },
  { code: 'ZA', name: 'South Africa', dial: '+27', flag: '🇿🇦' },
  { code: 'GH', name: 'Ghana', dial: '+233', flag: '🇬🇭' },
  { code: 'US', name: 'United States', dial: '+1', flag: '🇺🇸' },
  { code: 'GB', name: 'United Kingdom', dial: '+44', flag: '🇬🇧' },
];

interface PhoneInputWithFlagProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
  id?: string;
}

export const PhoneInputWithFlag: React.FC<PhoneInputWithFlagProps> = ({
  value,
  onChange,
  placeholder = '700 000 000',
  required,
  id,
}) => {
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState<Country>(countries[0]);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Parse existing value to detect country code
  useEffect(() => {
    if (value) {
      const match = countries.find(c => value.startsWith(c.dial));
      if (match) setSelected(match);
    }
  }, []);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSelect = (country: Country) => {
    setSelected(country);
    setOpen(false);
    // Replace old dial code with new one
    const numberPart = value.replace(/^\+\d+\s?/, '');
    onChange(`${country.dial} ${numberPart}`);
  };

  // Max digits allowed for the local number part (without country code)
  const MAX_LOCAL_DIGITS = 9;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    // Only allow digits and spaces in the number part
    const cleaned = raw.replace(/[^\d\s]/g, '');
    // Enforce max digit limit (count only digits, not spaces)
    const digitsOnly = cleaned.replace(/\s/g, '');
    if (digitsOnly.length > MAX_LOCAL_DIGITS) return; // block further input
    onChange(`${selected.dial} ${cleaned}`);
  };

  // Extract number part without dial code
  const numberPart = value.replace(/^\+\d+\s?/, '');

  return (
    <div className="flex items-center border border-border rounded-xl bg-background overflow-hidden focus-within:ring-2 focus-within:ring-ring">
      <div className="relative" ref={dropdownRef}>
        <button
          type="button"
          onClick={() => setOpen(!open)}
          className="flex items-center gap-1 px-3 py-2.5 hover:bg-muted/50 transition-colors border-r border-border h-full"
        >
          <span className="text-lg">{selected.flag}</span>
          <span className="text-xs text-muted-foreground">{selected.dial}</span>
          <ChevronDown className="w-3 h-3 text-muted-foreground" />
        </button>
        {open && (
          <div className="absolute top-full left-0 z-50 mt-1 w-56 bg-popover border border-border rounded-xl shadow-lg max-h-60 overflow-y-auto">
            {countries.map(c => (
              <button
                key={c.code}
                type="button"
                onClick={() => handleSelect(c)}
                className={`w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-muted/50 transition-colors ${
                  c.code === selected.code ? 'bg-muted' : ''
                }`}
              >
                <span className="text-lg">{c.flag}</span>
                <span className="flex-1 text-left text-foreground">{c.name}</span>
                <span className="text-muted-foreground text-xs">{c.dial}</span>
              </button>
            ))}
          </div>
        )}
      </div>
      <input
        id={id}
        type="tel"
        value={numberPart}
        onChange={handleInputChange}
        placeholder={placeholder}
        required={required}
        className="flex-1 px-3 py-2.5 bg-transparent text-foreground placeholder:text-muted-foreground text-sm outline-none"
      />
    </div>
  );
};
