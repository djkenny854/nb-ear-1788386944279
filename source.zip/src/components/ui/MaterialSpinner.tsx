import React from 'react';
import { cn } from '@/lib/utils';

interface MaterialSpinnerProps {
  /** Diameter in pixels */
  size?: number;
  /** Stroke width in px relative to a 50x50 viewBox */
  strokeWidth?: number;
  className?: string;
}

/**
 * Classic Google "Material" indeterminate circular spinner — the same
 * rotating-arc spinner that X (Twitter) uses. Pure CSS/SVG, GPU friendly.
 */
const MaterialSpinner: React.FC<MaterialSpinnerProps> = ({
  size = 36,
  strokeWidth = 4,
  className,
}) => {
  return (
    <svg
      className={cn('mat-spinner', className)}
      width={size}
      height={size}
      viewBox="0 0 50 50"
      role="status"
      aria-label="Loading"
    >
      <circle
        className="mat-spinner-path"
        cx="25"
        cy="25"
        r="20"
        fill="none"
        strokeWidth={strokeWidth}
      />
    </svg>
  );
};

export default MaterialSpinner;