import React from 'react';

const CategorySkeleton = () => {
  return (
    <div className="py-4">
      <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4">
        {[...Array(8)].map((_, index) => (
          <div 
            key={index} 
            className="flex items-center justify-center min-w-[56px] animate-fade-in"
            style={{ animationDelay: `${index * 0.05}s` }}
          >
            <div className="w-14 h-14 rounded-2xl bg-muted animate-pulse" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategorySkeleton;
