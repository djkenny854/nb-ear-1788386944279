import React, { useEffect, useState } from 'react';
import { Joyride, EVENTS, STATUS, type EventData, type Step } from 'react-joyride';
import { isCapacitorNative } from '@/hooks/useCapacitor';
import { House, Compass, Storefront, Bell, ChatCircle, UserCircle, Plus, Sparkle } from '@phosphor-icons/react';

const TOUR_KEY = 'em_app_tour_completed_v2';

const TourStep = ({ Icon, title, body, color }: { Icon: any; title: string; body: string; color: string }) => (
  <div className="flex flex-col items-start gap-3">
    <div
      className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-md"
      style={{ background: color }}
    >
      <Icon size={26} weight="fill" color="#fff" />
    </div>
    <div>
      <h3 className="text-base font-bold leading-tight" style={{ color: 'hsl(var(--foreground))' }}>
        {title}
      </h3>
      <p className="text-sm leading-relaxed mt-1" style={{ color: 'hsl(var(--muted-foreground))' }}>
        {body}
      </p>
    </div>
  </div>
);

const steps: Step[] = [
  {
    target: 'body',
    placement: 'center',
    skipBeacon: true,
    content: (
      <TourStep
        Icon={Storefront}
        title="Welcome to EarlyMarket"
        body="Your social marketplace platform — products, jobs, services, events and more in one place. Let’s take a quick tour."
        color="linear-gradient(135deg, #10B981, #059669)"
      />
    ),
  },
  {
    target: '[data-tour="nav-home"]',
    content: (
      <TourStep
        Icon={House}
        title="Your feed"
        body="Personalized listings, fresh posts and updates from sellers you follow."
        color="linear-gradient(135deg, #3B82F6, #1D4ED8)"
      />
    ),
    placement: 'top',
    skipBeacon: true,
  },
  {
    target: '[data-tour="nav-discover"]',
    content: (
      <TourStep
        Icon={Compass}
        title="Discover"
        body="Find new sellers, trending categories and accounts to follow."
        color="linear-gradient(135deg, #8B5CF6, #6D28D9)"
      />
    ),
    placement: 'top',
    skipBeacon: true,
  },
  {
    target: '[data-tour="nav-marketplace"]',
    content: (
      <TourStep
        Icon={Storefront}
        title="Marketplace"
        body="Browse, filter and search every listing — products, services and more."
        color="linear-gradient(135deg, #F59E0B, #D97706)"
      />
    ),
    placement: 'top',
    skipBeacon: true,
  },
  {
    target: '[data-tour="nav-notifications"]',
    content: (
      <TourStep
        Icon={Bell}
        title="Notifications"
        body="Real-time updates on offers, comments, follows and order status."
        color="linear-gradient(135deg, #EF4444, #B91C1C)"
      />
    ),
    placement: 'top',
    skipBeacon: true,
  },
  {
    target: '[data-tour="nav-messages"]',
    content: (
      <TourStep
        Icon={ChatCircle}
        title="Messages"
        body="Chat directly with buyers and sellers. Tap a conversation to reply instantly."
        color="linear-gradient(135deg, #06B6D4, #0891B2)"
      />
    ),
    placement: 'top',
    skipBeacon: true,
  },
  {
    target: '[data-tour="nav-profile"]',
    content: (
      <TourStep
        Icon={UserCircle}
        title="Your account"
        body="Open your profile, drafts, bookmarks, payments, verification and settings — all in one drawer."
        color="linear-gradient(135deg, #EC4899, #BE185D)"
      />
    ),
    placement: 'top-end',
    skipBeacon: true,
  },
  {
    target: '[data-tour="plus-button"]',
    content: (
      <TourStep
        Icon={Plus}
        title="Create anything"
        body="Tap the + button to publish a product, service, job, promotion, event or post — all from one place."
        color="linear-gradient(135deg, #10B981, #059669)"
      />
    ),
    placement: 'top-end',
    skipBeacon: true,
  },
  {
    target: '[data-tour="ai-button"]',
    content: (
      <TourStep
        Icon={Sparkle}
        title="EarlyMarket AI"
        body="Ask anything — find products, get help writing listings, discover deals and more, powered by AI."
        color="linear-gradient(135deg, #0F172A, #334155)"
      />
    ),
    placement: 'top-end',
    skipBeacon: true,
  },
];

export const AppTour: React.FC = () => {
  const [run, setRun] = useState(false);

  useEffect(() => {
    if (!isCapacitorNative()) return;
    if (typeof window === 'undefined') return;
    if (localStorage.getItem(TOUR_KEY)) return;

    const id = setTimeout(() => {
      if (document.querySelector('[data-tour="plus-button"]')) {
        setRun(true);
      }
    }, 1500);
    return () => clearTimeout(id);
  }, []);

  // Toggle a body class while tour is running so other components
  // (e.g. the plus button auto-fade) can opt out of conflicting effects.
  useEffect(() => {
    if (run) document.body.classList.add('app-tour-running');
    else document.body.classList.remove('app-tour-running');
    return () => document.body.classList.remove('app-tour-running');
  }, [run]);

  const handleEvent = (data: EventData) => {
    const { status, type } = data;
    const finished: string[] = [STATUS.FINISHED, STATUS.SKIPPED];
    if (finished.includes(status) || type === EVENTS.TOUR_END) {
      localStorage.setItem(TOUR_KEY, '1');
      setRun(false);
    }
  };

  if (!isCapacitorNative()) return null;

  return (
    <Joyride
      steps={steps}
      run={run}
      continuous
      scrollToFirstStep
      onEvent={handleEvent}
      options={{
        primaryColor: 'hsl(var(--primary))',
        backgroundColor: 'hsl(var(--background))',
        textColor: 'hsl(var(--foreground))',
        arrowColor: 'hsl(var(--background))',
        overlayColor: 'rgba(0, 0, 0, 0.85)',
        zIndex: 10000,
        showProgress: true,
        skipScroll: true,
        overlayClickAction: false,
        spotlightRadius: 24,
        buttons: ['back', 'skip', 'primary'],
      }}
      styles={{
        spotlight: {
          rx: 20,
          ry: 20,
        },
        tooltip: {
          borderRadius: 20,
          padding: 18,
          boxShadow: '0 24px 70px -12px rgba(0,0,0,0.55), 0 0 0 1px hsl(var(--border))',
          maxWidth: 340,
          backgroundColor: 'hsl(var(--background))',
        },
        tooltipTitle: {
          fontSize: 16,
          fontWeight: 700,
          marginBottom: 6,
        },
        tooltipContent: {
          fontSize: 14,
          lineHeight: 1.5,
          padding: '4px 0 8px',
          textAlign: 'left',
        },
        buttonPrimary: {
          borderRadius: 999,
          padding: '8px 18px',
          fontWeight: 600,
          background: 'hsl(var(--primary))',
          color: 'hsl(var(--primary-foreground))',
        },
        buttonBack: {
          color: 'hsl(var(--muted-foreground))',
          marginRight: 8,
        },
        buttonSkip: {
          color: 'hsl(var(--muted-foreground))',
          fontSize: 13,
        },
      }}
      locale={{
        back: 'Back',
        close: 'Close',
        last: 'Got it',
        next: 'Next',
        skip: 'Skip tour',
      }}
    />
  );
};

export default AppTour;
