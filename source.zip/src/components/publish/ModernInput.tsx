import { cn } from '@/lib/utils';
import FloatingBorderInput from './FloatingBorderInput';

interface ModernInputProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
  required?: boolean;
  id?: string;
  className?: string;
}

export default function ModernInput({
  label,
  value,
  onChange,
  type = 'text',
  required = false,
  id,
  className,
}: ModernInputProps) {
  return (
    <FloatingBorderInput
      label={label}
      value={value ?? ''}
      onChange={onChange}
      type={type}
      required={required}
      id={id}
      className={cn(className)}
    />
  );
}
