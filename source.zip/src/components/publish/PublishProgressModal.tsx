import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { VisuallyHidden } from '@radix-ui/react-visually-hidden';
import { Loader2 } from 'lucide-react';

type WizardType = 'product' | 'service' | 'job' | 'event' | 'promotion';

const getAssuranceTexts = (wizardType: WizardType): string[] => {
  const steps: Record<WizardType, string[]> = {
    product: [
      'Checking content for quality...',
      'Optimizing your images...',
      'Saving product details...',
      'Setting up your listing...',
      'Making it discoverable...',
      'Almost there...',
    ],
    service: [
      'Reviewing your service info...',
      'Processing your images...',
      'Saving service details...',
      'Configuring your offerings...',
      'Publishing your service...',
      'Almost there...',
    ],
    job: [
      'Validating job details...',
      'Processing attachments...',
      'Saving job posting...',
      'Setting up applications...',
      'Publishing your vacancy...',
      'Almost there...',
    ],
    event: [
      'Checking event details...',
      'Processing event media...',
      'Saving event information...',
      'Setting up registration...',
      'Publishing your event...',
      'Almost there...',
    ],
    promotion: [
      'Validating promotion details...',
      'Processing promotional media...',
      'Applying discounts to products...',
      'Scheduling your promotion...',
      'Publishing your deal...',
      'Almost there...',
    ],
  };
  return steps[wizardType] || steps.product;
};

interface PublishProgressModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  currentStep: number;
  totalSteps?: number;
  progress: number;
  steps?: any[];
  title?: string;
  uploadSpeed?: number;
  wizardType?: WizardType;
  hasImages?: boolean;
  hasVideo?: boolean;
}

export default function PublishProgressModal({
  open,
  onOpenChange,
  progress,
  wizardType = 'product',
}: PublishProgressModalProps) {
  const assuranceTexts = getAssuranceTexts(wizardType);
  const [textIndex, setTextIndex] = useState(0);

  // Advance text based on progress
  useEffect(() => {
    if (!open) return;
    const idx = Math.min(
      Math.floor((progress / 100) * assuranceTexts.length),
      assuranceTexts.length - 1
    );
    setTextIndex(idx);
  }, [progress, open, assuranceTexts.length]);

  useEffect(() => {
    if (open) setTextIndex(0);
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent
        className="sm:max-w-[340px] max-w-[calc(100%-3rem)] mx-auto border-border/40 bg-card/98 backdrop-blur-2xl pointer-events-auto rounded-3xl shadow-2xl"
        hideCloseButton
        onPointerDownOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => e.preventDefault()}
      >
        <VisuallyHidden>
          <DialogTitle>Publishing</DialogTitle>
          <DialogDescription>Your content is being published. Please wait.</DialogDescription>
        </VisuallyHidden>
        <div className="py-8 px-2 flex flex-col items-center">
          {/* Spinner with percentage */}
          <div className="relative w-24 h-24 mb-8">
            {/* Outer rotating ring */}
            <motion.div
              className="absolute inset-0 rounded-full"
              style={{
                background: 'conic-gradient(from 0deg, hsl(var(--primary)), hsl(var(--primary) / 0.3), hsl(var(--primary)))',
                mask: 'radial-gradient(farthest-side, transparent calc(100% - 3px), #fff calc(100% - 3px))',
                WebkitMask: 'radial-gradient(farthest-side, transparent calc(100% - 3px), #fff calc(100% - 3px))',
              }}
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
            />
            {/* Inner circle with percentage */}
            <div className="absolute inset-[6px] rounded-full bg-card flex items-center justify-center">
              <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                {Math.round(progress)}%
              </span>
            </div>
          </div>

          {/* Assurance text in normal theme color, with shimmer line accent */}
          <div className="h-16 flex flex-col items-center justify-center w-full gap-2">
            <AnimatePresence mode="wait">
              <motion.p
                key={textIndex}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.3, ease: 'easeOut' }}
                className="text-base font-semibold text-center px-4 text-foreground"
              >
                {assuranceTexts[textIndex]}
              </motion.p>
            </AnimatePresence>
            {/* Shimmer line that moves under the text */}
            <div className="w-16 h-0.5 rounded-full overflow-hidden bg-muted">
              <div className="h-full w-1/2 bg-gradient-to-r from-transparent via-primary to-transparent animate-shimmer" />
            </div>
          </div>

          {/* Subtle loading indicator */}
          <div className="flex items-center gap-2 mt-4 text-muted-foreground">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span className="text-xs">Please don't close this page</span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
