import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import EMIIcon from '@/components/icons/EMIIcon';
import { useAIFeatureFlags } from '@/hooks/useAIFeatureFlags';
import { useAuth } from '@/components/auth/AuthContext';

interface AIAssistButtonProps {
  type: 'title' | 'description' | 'tags' | 'skills' | 'job_description' | 'promotion_description' | 'requirements';
  context: {
    postType: string;
    category?: string;
    title?: string;
    company?: string;
    promotionType?: string;
    positions?: Array<{ role: string; quantity: number }>;
  };
  onResult: (result: string) => void;
  label?: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  currentValue?: string;
  placeholder?: string;
  multiline?: boolean;
}

export default function AIAssistButton({
  type,
  context,
  onResult,
  label = 'AI Assist',
  variant = 'outline',
  size = 'sm',
  currentValue = '',
  placeholder = '',
  multiline = false,
}: AIAssistButtonProps) {
  const [loading, setLoading] = useState(false);
  const [showManualReview, setShowManualReview] = useState(false);
  const isListType = type === 'tags' || type === 'skills';
  const [generatedText, setGeneratedText] = useState('');
  const [typingIndex, setTypingIndex] = useState(0);
  const { aiAssistEnabled, loading: flagsLoading } = useAIFeatureFlags();
  const { user } = useAuth();

  useEffect(() => {
    if (isListType) return;

    if (generatedText && typingIndex < generatedText.length) {
      const timer = setTimeout(() => {
        onResult(generatedText.slice(0, typingIndex + 1));
        setTypingIndex(typingIndex + 1);
      }, 20);
      return () => clearTimeout(timer);
    } else if (generatedText && typingIndex >= generatedText.length) {
      setLoading(false);
      setGeneratedText('');
      setTypingIndex(0);
    }
  }, [generatedText, typingIndex, onResult, isListType]);

  // Don't render if AI assist is disabled
  if (!flagsLoading && !aiAssistEnabled) return null;

  const handleAIAssist = async () => {
    setLoading(true);
    setShowManualReview(false);
    setTypingIndex(0);
    
    try {
      const { data, error } = await supabase.functions.invoke('ai-assist', {
        body: { type, context, userId: user?.id }
      });

      if (error) {
        console.error('AI assist error:', error);
        setLoading(false);
        toast({
          title: 'AI is busy',
          description: 'High traffic or quota reached. Please wait ~1 minute and try again.',
          variant: 'destructive',
        });
        return;
      }

      if (data?.result) {
        if (isListType) {
          onResult(data.result);
          setShowManualReview(true);
          setLoading(false);
          toast({
            title: '✨ AI Generated',
            description: 'Added 5 suggestions. Review and edit if needed.',
          });
          return;
        }

        setGeneratedText(data.result);
        setShowManualReview(true);
        toast({
          title: '✨ AI Generated',
          description: 'Review and edit the suggestion. AI can make mistakes.',
        });
      } else if (data?.error) {
        setLoading(false);
        toast({
          title: 'AI is busy',
          description: data?.userMessage || 'High traffic or quota reached. Please try again shortly.',
          variant: 'destructive',
        });
        return;
      } else {
        throw new Error('No result received');
      }
    } catch (error: any) {
      console.error('AI assist error:', error);
      setLoading(false);
      
      const errorMessage = error?.message || '';
      const errorContext = error?.context || {};
      
      if (errorMessage.includes('quota') || errorContext.error === 'quota_exceeded') {
        toast({
          title: '⏱️ EMI Quota Exceeded',
          description: errorContext.userMessage || 'AI generation limit reached. Please wait a minute and try again.',
          variant: 'destructive',
        });
      } else if (errorContext.userMessage) {
        toast({
          title: 'Generation Failed',
          description: errorContext.userMessage,
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'Generation Failed',
          description: 'Could not generate content. Please try again.',
          variant: 'destructive',
        });
      }
    }
  };

  return (
    <Button
      type="button"
      variant={variant}
      size={size}
      onClick={handleAIAssist}
      disabled={loading}
      className="gap-2 relative"
    >
      <div className={loading ? 'animate-spin' : ''}>
        <EMIIcon className="w-4 h-4" />
      </div>
      <span>{loading ? 'Generating...' : label}</span>
      <Badge variant="secondary" className="ml-1 text-xs">Beta</Badge>
      {showManualReview && <Badge className="ml-1 text-xs bg-destructive/10 text-destructive border-destructive/30">Needs manual edit</Badge>}
    </Button>
  );
}
