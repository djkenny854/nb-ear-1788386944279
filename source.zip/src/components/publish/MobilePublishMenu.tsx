import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Package, Briefcase, Megaphone, Wrench, Calendar, FileText, X, Clock } from 'lucide-react';
import { usePublishToggles, PublishTogglesMap } from '@/hooks/usePublishToggles';
import { cn } from '@/lib/utils';

interface MobilePublishMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const publishOptions: Array<{
  id: keyof PublishTogglesMap;
  icon: React.ElementType;
  label: string;
  route: string;
}> = [
  { id: 'product', icon: Package, label: 'Product', route: '/publish/product' },
  { id: 'service', icon: Wrench, label: 'Service', route: '/publish/service' },
  { id: 'job', icon: Briefcase, label: 'Job', route: '/publish/job' },
  { id: 'promotion', icon: Megaphone, label: 'Promotion', route: '/publish/promotion' },
  { id: 'event', icon: Calendar, label: 'Event', route: '/publish/event' },
  { id: 'post', icon: FileText, label: 'Post', route: '/publish/post' },
];

export const MobilePublishMenu: React.FC<MobilePublishMenuProps> = ({ isOpen, onClose }) => {
  const navigate = useNavigate();
  const { isEnabled, isLoading } = usePublishToggles();

  const handleOptionClick = (option: typeof publishOptions[0]) => {
    if (!isEnabled(option.id)) return;
    onClose();
    navigate(option.route);
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Blurred overlay backdrop */}
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-md z-[95] md:hidden"
        onClick={onClose}
      />

      {/* Menu container */}
      <div data-publish-menu className="fixed bottom-20 right-4 z-[100] md:hidden flex flex-col gap-2">
        {publishOptions.map((option) => {
          const Icon = option.icon;
          const enabled = isEnabled(option.id);

          return (
            <button
              key={option.id}
              onClick={() => handleOptionClick(option)}
              disabled={!enabled || isLoading}
              className={cn(
                "flex items-center justify-between gap-3 px-4 py-3 rounded-full bg-background min-w-[140px]",
                enabled 
                  ? "active:bg-muted" 
                  : "opacity-50"
              )}
            >
              <span className={cn(
                "text-sm",
                enabled ? "text-foreground" : "text-muted-foreground"
              )}>
                {option.label}
              </span>

              {!enabled ? (
                <Clock className="w-5 h-5 text-muted-foreground" />
              ) : (
                <Icon className="w-5 h-5 text-foreground" />
              )}
            </button>
          );
        })}

        {/* Close button - properly centered X icon */}
        <button
          onClick={onClose}
          className="flex items-center justify-center w-12 h-12 rounded-full bg-foreground text-background ml-auto mt-2"
        >
          <X className="w-5 h-5 shrink-0" />
        </button>
      </div>
    </>
  );
};

export default MobilePublishMenu;
