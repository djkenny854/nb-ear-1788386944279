import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Sparkles, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useAuth } from '@/components/auth/AuthContext';
import { addWatermarkToImage } from '@/utils/watermark';
import { saveAiImage } from '@/utils/saveAiImage';

interface FormDataLike {
  title: string;
  description: string;
  category?: string;
  location?: string;
}

interface GeneratedImage {
  id: string;
  file: File;
  url: string;
  isHighQuality: boolean;
  qualityScore: number;
  type?: 'image' | 'video';
}

interface Props {
  formData: FormDataLike;
  onGenerated: (img: GeneratedImage) => void;
  disabled?: boolean;
}

async function dataUrlToFile(dataUrl: string, filename: string): Promise<File> {
  const res = await fetch(dataUrl);
  const blob = await res.blob();
  return new File([blob], filename, { type: blob.type || 'image/png' });
}

export default function AIServiceImageButton({ formData, onGenerated, disabled }: Props) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [businessName, setBusinessName] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const cooldownUntilRef = useRef(0);

  useEffect(() => {
    if (!user) return;
    (async () => {
      try {
        const { data } = await supabase
          .from('seller_profiles')
          .select('business_name, business_logo_url')
          .eq('user_id', user.id)
          .maybeSingle();
        if (data) {
          setBusinessName((data as any).business_name || '');
          setLogoUrl((data as any).business_logo_url || '');
        }
      } catch { /* ignore */ }
    })();
  }, [user]);

  const handleClick = async () => {
    if (loading) return;
    const now = Date.now();
    if (now < cooldownUntilRef.current) {
      const secs = Math.ceil((cooldownUntilRef.current - now) / 1000);
      toast({ title: 'Please wait', description: `Try again in ${secs}s.`, variant: 'destructive' });
      return;
    }
    if (!formData.title?.trim()) {
      toast({ title: 'Add a title first', description: 'AI needs your service title to generate a poster.', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-promotion-image', {
        body: {
          context: 'service',
          title: formData.title,
          description: formData.description,
          businessName,
          location: formData.location || '',
          serviceCategory: formData.category || '',
          logoUrl,
        },
      });

      if (error) {
        const ctx: any = (error as any).context;
        const status = ctx?.status;
        let msg = error.message || 'Failed to generate image';
        try { const body = ctx ? await ctx.json() : null; if (body?.error) msg = body.error; if (body?.reason) msg = body.reason; } catch { /* ignore */ }
        if (status === 429) cooldownUntilRef.current = Date.now() + 60_000;
        toast({ title: 'AI generation blocked', description: msg, variant: 'destructive' });
        return;
      }
      if (data?.flagged) {
        cooldownUntilRef.current = Date.now() + 30_000;
        toast({ title: 'Content blocked', description: data.reason || 'Try different wording.', variant: 'destructive' });
        return;
      }
      if (!data?.imageDataUrl) {
        toast({ title: 'No image returned', description: 'Please try again.', variant: 'destructive' });
        return;
      }

      const rawFile = await dataUrlToFile(data.imageDataUrl, `service-${Date.now()}.png`);
      let file = rawFile;
      try { file = await addWatermarkToImage(rawFile); } catch (e) { console.warn('Watermark failed', e); }
      // Persist to Storage + user_generated_media so it appears in Profile › Media.
      saveAiImage({
        file,
        source: 'service',
        prompt: formData.title,
        context: { category: formData.category, location: formData.location },
      }).catch((e) => console.warn('saveAiImage', e));
      const objectUrl = URL.createObjectURL(file);
      onGenerated({
        id: crypto.randomUUID(),
        file,
        url: objectUrl,
        isHighQuality: true,
        qualityScore: 90,
        type: 'image',
      });
      toast({ title: '✨ Image generated', description: 'AI-generated service poster is ready. Saved to your Media tab.' });
    } catch (e: any) {
      toast({ title: 'Generation failed', description: e?.message || 'Please try again.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      type="button"
      variant="outline"
      onClick={handleClick}
      disabled={disabled || loading}
      className="w-full gap-2 border-yellow-400/60 bg-gradient-to-r from-yellow-50 to-amber-50 hover:from-yellow-100 hover:to-amber-100 dark:from-yellow-950/30 dark:to-amber-950/30"
    >
      {loading ? (
        <>
          <Loader2 className="h-4 w-4 animate-spin" />
          Generating with EarlyMarket AI…
        </>
      ) : (
        <>
          <Sparkles className="h-4 w-4 text-amber-500" />
          Generate image with EarlyMarket AI
        </>
      )}
    </Button>
  );
}