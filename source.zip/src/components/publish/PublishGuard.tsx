import React from 'react';
import { Navigate } from 'react-router-dom';
import { usePublishToggles, PublishTogglesMap } from '@/hooks/usePublishToggles';
import { Skeleton } from '@/components/ui/skeleton';
import { Clock, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

interface PublishGuardProps {
  type: keyof PublishTogglesMap;
  children: React.ReactNode;
}

/**
 * Guards publish wizard routes - redirects or shows message if feature is disabled
 */
export const PublishGuard: React.FC<PublishGuardProps> = ({ type, children }) => {
  const navigate = useNavigate();
  const { isEnabled, getMessage, isLoading } = usePublishToggles();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="max-w-md w-full space-y-4">
          <Skeleton className="h-8 w-3/4 mx-auto" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-2/3 mx-auto" />
          <Skeleton className="h-12 w-40 mx-auto mt-6" />
        </div>
      </div>
    );
  }

  if (!isEnabled(type)) {
    const message = getMessage(type);

    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center">
          {/* Icon */}
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-amber-500/20 flex items-center justify-center">
            <Clock className="w-10 h-10 text-amber-500" />
          </div>

          {/* Title */}
          <h1 className="text-2xl font-bold text-foreground mb-3">
            Feature Coming Soon
          </h1>

          {/* Message */}
          <p className="text-muted-foreground mb-8">
            {message}
          </p>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button
              variant="outline"
              onClick={() => navigate(-1)}
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Go Back
            </Button>
            <Button
              onClick={() => navigate('/post-ad')}
            >
              View Available Options
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default PublishGuard;
