import { ReactNode, useEffect, useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, Check, Save, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import WizardStepSidebar from './WizardStepSidebar';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface WizardLayoutProps {
  children: ReactNode;
  steps: string[];
  currentStep: number;
  onNext: () => void;
  onBack: () => void;
  onSubmit?: () => void;
  isLastStep: boolean;
  canProceed: boolean;
  title: string;
  onSaveDraft?: () => Promise<boolean>;
  savingDraft?: boolean;
  pendingDraft?: { formData: Record<string, any>; step: number } | null;
  onApplyDraft?: () => void;
  onDismissDraft?: () => void;
}

export default function WizardLayout({
  children,
  steps,
  currentStep,
  onNext,
  onBack,
  onSubmit,
  isLastStep,
  canProceed,
  title,
  onSaveDraft,
  savingDraft,
  pendingDraft,
  onApplyDraft,
  onDismissDraft,
}: WizardLayoutProps) {
  const navigate = useNavigate();
  const [showLeaveDialog, setShowLeaveDialog] = useState(false);
  const pendingNavigationRef = useRef<string | null>(null);

  // Block browser close/refresh
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      if (onSaveDraft) {
        onSaveDraft();
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [onSaveDraft]);

  const handleConfirmLeave = async () => {
    if (onSaveDraft) {
      await onSaveDraft();
    }
    setShowLeaveDialog(false);
    if (pendingNavigationRef.current) {
      navigate(pendingNavigationRef.current);
      pendingNavigationRef.current = null;
    }
  };

  const handleCancelLeave = () => {
    setShowLeaveDialog(false);
    pendingNavigationRef.current = null;
  };

  const sidebarSteps = steps.map(label => ({ label }));

  return (
    <>
      <div className="min-h-screen bg-background flex">
        {/* Sidebar */}
        <WizardStepSidebar
          steps={sidebarSteps}
          currentStep={currentStep}
          title={title}
        />

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto lg:ml-64">
          <div className="max-w-4xl mx-auto p-4 sm:p-6 md:p-12">
            {/* Mobile Header - handled by WizardStepSidebar */}

            {/* Content */}
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.2 }}
            >
              {children}
            </motion.div>

            {/* Navigation Buttons */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="flex items-center justify-between mt-6 gap-4"
            >
              <Button variant="outline" onClick={onBack} disabled={currentStep === 0} className="gap-2" size="lg">
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline">Back</span>
              </Button>

              <div className="flex gap-3">
                {onSaveDraft && (
                  <Button
                    variant="outline"
                    className="gap-2"
                    size="lg"
                    onClick={onSaveDraft}
                    disabled={savingDraft}
                  >
                    <Save className="w-4 h-4" />
                    <span className="hidden md:inline">{savingDraft ? 'Saving...' : 'Save Draft'}</span>
                  </Button>
                )}
                
                {isLastStep ? (
                  <Button onClick={onSubmit} disabled={!canProceed} className="gap-2" size="lg">
                    <span className="hidden sm:inline">Publish Now</span>
                    <span className="sm:hidden">Publish</span>
                    <Check className="w-4 h-4" />
                  </Button>
                ) : (
                  <Button onClick={onNext} disabled={!canProceed} className="gap-2" size="lg">
                    <span className="hidden sm:inline">Continue</span>
                    <span className="sm:hidden">Next</span>
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Leave Confirmation Dialog */}
      <AlertDialog open={showLeaveDialog} onOpenChange={setShowLeaveDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Leave without completing?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to leave? Your progress will be saved as a draft so you can continue later.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={handleCancelLeave}>Stay</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmLeave}>
              Save Draft & Leave
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Draft Restoration Dialog */}
      <AlertDialog open={!!pendingDraft} onOpenChange={(open) => { if (!open && onDismissDraft) onDismissDraft(); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              Draft Found
            </AlertDialogTitle>
            <AlertDialogDescription>
              You have a saved draft from a previous session. Would you like to restore it and continue where you left off?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={onDismissDraft}>Start Fresh</AlertDialogCancel>
            <AlertDialogAction onClick={onApplyDraft}>
              Restore Draft
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
