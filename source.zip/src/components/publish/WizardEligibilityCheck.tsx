import { useState } from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Lock, Crown, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { PaywallModal } from '@/components/subscription/PaywallModal';

interface WizardEligibilityCheckProps {
  loading: boolean;
  isEligible: boolean;
  title: string;
  description: string;
  children: React.ReactNode;
  // New props for subscription checks
  requiresSubscription?: boolean;
  isSubscribed?: boolean;
  feature?: 'posting' | 'analytics' | 'boosting' | 'jobs' | 'events' | 'promotions' | 'services';
}

export const WizardEligibilityCheck: React.FC<WizardEligibilityCheckProps> = ({
  loading,
  isEligible,
  title,
  description,
  children,
  requiresSubscription = false,
  isSubscribed = true,
  feature = 'posting',
}) => {
  const navigate = useNavigate();
  const [showPaywall, setShowPaywall] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-background py-8 px-4">
        <div className="max-w-3xl mx-auto space-y-6">
          {/* Header skeleton */}
          <div className="flex items-center gap-3 mb-8">
            <Skeleton className="h-10 w-10 rounded-lg" />
            <div className="space-y-2">
              <Skeleton className="h-6 w-48" />
              <Skeleton className="h-4 w-64" />
            </div>
          </div>

          {/* Step indicator skeleton */}
          <div className="flex items-center gap-2 mb-6">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex items-center gap-2">
                <Skeleton className="h-8 w-8 rounded-full" />
                <Skeleton className="h-3 w-16 hidden md:block" />
                {i < 5 && <Skeleton className="h-0.5 w-8" />}
              </div>
            ))}
          </div>

          {/* Card skeleton */}
          <div className="border border-border rounded-xl p-6 space-y-6">
            <div className="space-y-2">
              <Skeleton className="h-5 w-32" />
              <Skeleton className="h-12 w-full" />
            </div>
            <div className="space-y-2">
              <Skeleton className="h-5 w-24" />
              <Skeleton className="h-12 w-full" />
            </div>
            <div className="space-y-2">
              <Skeleton className="h-5 w-36" />
              <Skeleton className="h-12 w-full" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Skeleton className="h-5 w-20" />
                <Skeleton className="h-12 w-full" />
              </div>
              <div className="space-y-2">
                <Skeleton className="h-5 w-16" />
                <Skeleton className="h-12 w-full" />
              </div>
            </div>
          </div>

          {/* Loading message */}
          <div className="text-center py-4">
            <p className="text-sm text-muted-foreground animate-pulse">
              Checking your account eligibility...
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Check subscription status first (if subscriptions are required)
  if (requiresSubscription && !isSubscribed) {
    return (
      <>
        <div className="min-h-screen bg-background flex items-center justify-center py-8 px-4">
          <div className="max-w-md w-full space-y-6">
            <Button
              variant="ghost"
              onClick={() => navigate('/post-ad')}
              className="mb-4"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>

            <Alert className="border-primary/50 bg-primary/5">
              <Crown className="h-5 w-5 text-primary" />
              <AlertTitle className="text-primary font-semibold text-lg">
                Subscription Required
              </AlertTitle>
              <AlertDescription className="space-y-4 mt-3">
                <p className="text-muted-foreground">
                  Your subscription has expired or is not active. Please renew to continue posting.
                </p>
                <Button
                  onClick={() => setShowPaywall(true)}
                  className="w-full"
                >
                  <Crown className="mr-2 h-4 w-4" />
                  View Subscription Options
                </Button>
              </AlertDescription>
            </Alert>
          </div>
        </div>
        <PaywallModal 
          isOpen={showPaywall} 
          onClose={() => setShowPaywall(false)} 
          feature={feature}
        />
      </>
    );
  }

  if (!isEligible) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center py-8 px-4">
        <div className="max-w-md w-full space-y-6">
          <Button
            variant="ghost"
            onClick={() => navigate('/post-ad')}
            className="mb-4"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>

          <Alert className="border-orange-500/50 bg-orange-500/5">
            <Lock className="h-5 w-5 text-orange-500" />
            <AlertTitle className="text-orange-500 font-semibold text-lg">
              {title}
            </AlertTitle>
            <AlertDescription className="space-y-4 mt-3">
              <p className="text-muted-foreground">
                {description}
              </p>
              <div className="space-y-2 text-sm text-muted-foreground">
                <p>With a business account, you can:</p>
                <ul className="list-disc list-inside space-y-1 ml-2">
                  <li>Post unlimited listings</li>
                  <li>Create services, jobs, promotions & events</li>
                  <li>Get a verified seller badge</li>
                  <li>Access analytics & insights</li>
                </ul>
              </div>
              <Button
                onClick={() => navigate('/create-business-account', { replace: true })}
                className="w-full bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600"
              >
                <Crown className="mr-2 h-4 w-4" />
                Create a Business Account
              </Button>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
