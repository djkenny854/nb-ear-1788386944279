import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, Grid3X3 } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import SubcategorySkeleton from '@/components/ui/subcategory-skeleton';
import { icons } from 'lucide-react';

interface Category {
  id: string;
  name: string;
  icon: string;
}
interface Subcategory {
  id: string;
  name: string;
  category_id: string;
  icon: string;
}
interface SubNavbarProps {
  onCategorySelect?: (category: string, subcategory?: string) => void;
}

const CLOSE_DELAY = 120;

const SubNavbar: React.FC<SubNavbarProps> = ({ onCategorySelect }) => {
  const [openCategoryId, setOpenCategoryId] = useState<string | null>(null);
  const [panelTop, setPanelTop] = useState<number>(0);
  // Hover-open only on real hover-capable devices. Touch devices toggle on tap
  // so we don't get double open/close from hover-simulated mouse events.
  const [supportsHover, setSupportsHover] = useState(false);
  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mq = window.matchMedia('(hover: hover) and (pointer: fine)');
    const update = () => setSupportsHover(mq.matches);
    update();
    mq.addEventListener?.('change', update);
    return () => mq.removeEventListener?.('change', update);
  }, []);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const stripRef = useRef<HTMLDivElement>(null);
  const closeTimerRef = useRef<number | null>(null);
  const navigate = useNavigate();

  const { data: categories = [], isLoading } = useQuery({
    queryKey: ['navbar-categories'],
    queryFn: async () => {
      const { data, error } = await supabase.from('categories').select('*').eq('is_active', true).order('name');
      if (error) throw error;
      return data as Category[];
    },
  });

  const { data: subcategories = [] } = useQuery({
    queryKey: ['navbar-subcategories'],
    queryFn: async () => {
      const { data, error } = await supabase.from('subcategories').select('*').eq('is_active', true).order('name');
      if (error) throw error;
      return data as Subcategory[];
    },
  });

  const { data: adCounts = {} } = useQuery({
    queryKey: ['ad-counts'],
    queryFn: async () => {
      const { data, error } = await supabase.from('ads').select('category').eq('status', 'active');
      if (error) throw error;
      const counts: Record<string, number> = {};
      data.forEach((ad: any) => {
        counts[ad.category] = (counts[ad.category] || 0) + 1;
      });
      return counts;
    },
  });

  const { data: subcategoryCounts = {} } = useQuery({
    queryKey: ['subcategory-ad-counts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('ads')
        .select('subcategory')
        .eq('status', 'active')
        .not('subcategory', 'is', null);
      if (error) throw error;
      const counts: Record<string, number> = {};
      data.forEach((ad: any) => {
        if (ad.subcategory) counts[ad.subcategory] = (counts[ad.subcategory] || 0) + 1;
      });
      return counts;
    },
  });

  const isOpen = !!openCategoryId;

  // Auto-swipe pause when open
  useEffect(() => {
    if (!scrollContainerRef.current || categories.length === 0 || isOpen) return;
    const interval = setInterval(() => {
      const container = scrollContainerRef.current;
      if (!container) return;
      const maxScroll = container.scrollWidth - container.clientWidth;
      if (container.scrollLeft >= maxScroll - 10) {
        container.scrollTo({ left: 0, behavior: 'smooth' });
      } else {
        container.scrollBy({ left: 200, behavior: 'smooth' });
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [categories.length, isOpen]);

  // NOTE: Body scroll is intentionally NOT locked while the dropdown is open.
  // Locking scroll toggles the page scrollbar, which shifts the layout, moves
  // the strip out from under the cursor, and causes the dropdown to flicker
  // open/closed rapidly.


  // Measure strip position for portal panel
  const recalcPanelTop = () => {
    if (!stripRef.current) return;
    const rect = stripRef.current.getBoundingClientRect();
    setPanelTop(rect.bottom);
  };

  useEffect(() => {
    if (!isOpen) return;
    recalcPanelTop();
    window.addEventListener('scroll', recalcPanelTop, true);
    window.addEventListener('resize', recalcPanelTop);
    return () => {
      window.removeEventListener('scroll', recalcPanelTop, true);
      window.removeEventListener('resize', recalcPanelTop);
    };
  }, [isOpen]);

  const sortedCategories = useMemo(() => {
    return [...categories].sort((a, b) => {
      const aCount = (adCounts as any)[a.name] || 0;
      const bCount = (adCounts as any)[b.name] || 0;
      if (bCount !== aCount) return bCount - aCount;
      return a.name.localeCompare(b.name);
    });
  }, [categories, adCounts]);

  const getIconComponent = (iconName: string) => {
    if (!iconName) return icons.Package;
    const pascalCaseIcon = iconName
      .split(/[-_\s]/)
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join('');
    return (icons as any)[pascalCaseIcon] || icons.Package;
  };

  const getCategorySubcategories = (categoryId: string) =>
    subcategories.filter((s) => s.category_id === categoryId);

  const clearCloseTimer = () => {
    if (closeTimerRef.current) {
      window.clearTimeout(closeTimerRef.current);
      closeTimerRef.current = null;
    }
  };
  const scheduleClose = () => {
    clearCloseTimer();
    closeTimerRef.current = window.setTimeout(() => setOpenCategoryId(null), CLOSE_DELAY);
  };
  const openCategory = (id: string) => {
    clearCloseTimer();
    setOpenCategoryId(id);
    // measure on next frame after render
    requestAnimationFrame(recalcPanelTop);
  };

  const handleSubcategoryClick = (category: string, subcategory: string) => {
    onCategorySelect?.(category, subcategory);
    setOpenCategoryId(null);
    navigate(`/search?category=${encodeURIComponent(category)}&subcategory=${encodeURIComponent(subcategory)}&contentType=products`);
  };

  if (isLoading) {
    return (
      <div className="bg-transparent">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between py-3 overflow-x-auto scrollbar-hide">
            {Array.from({ length: 8 }).map((_, index) => (
              <Skeleton key={index} className="h-8 w-20 flex-shrink-0" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  const activeCategory = sortedCategories.find((c) => c.id === openCategoryId);
  const activeSubs = activeCategory ? getCategorySubcategories(activeCategory.id) : [];
  const ActiveIcon = activeCategory ? getIconComponent(activeCategory.icon) : null;
  const activeCount = activeCategory ? ((adCounts as any)[activeCategory.name] || 0) : 0;

  return (
    <>
      <div ref={stripRef} className={`bg-background/95 backdrop-blur-md border-b border-border/50 relative ${isOpen ? 'z-[9999]' : 'z-[50]'}`}>
        <div className="absolute left-0 top-0 bottom-0 w-8 md:w-12 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-8 md:w-12 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />

        <div className="px-2 md:px-4">
          <div
            ref={scrollContainerRef}
            className="flex items-center gap-1 py-2 md:py-3 overflow-x-auto scrollbar-hide scroll-smooth"
            onMouseLeave={scheduleClose}
          >
            <Button
              variant="ghost"
              className="flex items-center gap-1.5 md:gap-2 px-2 md:px-4 py-1.5 md:py-2 rounded-lg hover:bg-primary/10 hover:text-primary text-foreground font-medium whitespace-nowrap flex-shrink-0 text-xs md:text-sm"
              onClick={() => {
                onCategorySelect?.('');
                setOpenCategoryId(null);
              }}
              onMouseEnter={() => {
                if (!supportsHover) return;
                clearCloseTimer();
                setOpenCategoryId(null);
              }}
            >
              <Grid3X3 className="w-3 h-3 md:w-4 md:h-4" />
              <span className="hidden sm:inline">All Categories</span>
              <span className="sm:hidden">All</span>
            </Button>

            {sortedCategories.map((category) => {
              const categorySubcategories = getCategorySubcategories(category.id);
              const hasSubcategories = categorySubcategories.length > 0;
              const CategoryIcon = getIconComponent(category.icon);
              const categoryAdCount = (adCounts as any)[category.name] || 0;
              const isDisabled = categoryAdCount === 0;
              const isActive = openCategoryId === category.id;

              return (
                <button
                  key={category.id}
                  type="button"
                  disabled={isDisabled}
                  onMouseEnter={() => supportsHover && hasSubcategories && !isDisabled && openCategory(category.id)}
                  onFocus={() => supportsHover && hasSubcategories && !isDisabled && openCategory(category.id)}
                  onClick={() => {
                    if (isDisabled) return;
                    if (hasSubcategories) {
                      isActive ? setOpenCategoryId(null) : openCategory(category.id);
                    } else {
                      onCategorySelect?.(category.name);
                    }
                  }}
                  className={`flex items-center gap-1.5 md:gap-2 px-2 md:px-3 py-1.5 md:py-2 rounded-md font-medium whitespace-nowrap flex-shrink-0 text-xs md:text-sm transition-colors ${
                    isDisabled
                      ? 'text-muted-foreground/50 cursor-not-allowed opacity-50'
                      : isActive
                        ? 'bg-accent/60 text-foreground'
                        : 'text-foreground hover:bg-muted/50'
                  }`}
                >
                  <CategoryIcon className="w-3 h-3 md:w-4 md:h-4" />
                  <span>{category.name}</span>
                  {categoryAdCount > 0 && (
                    <Badge
                      variant="secondary"
                      className="text-[10px] md:text-xs px-1 md:px-1.5 py-0 md:py-0.5 h-4 md:h-5"
                    >
                      {categoryAdCount}
                    </Badge>
                  )}
                  {hasSubcategories && !isDisabled && (
                    <ChevronDown
                      className={`w-3 h-3 transition-transform ${isActive ? 'rotate-180' : ''}`}
                      aria-hidden
                    />
                  )}
                </button>
              );
            })}

            <div className="flex-shrink-0 w-32" />
          </div>
        </div>
      </div>

      {/* Portal-based dropdown panel */}
      {isOpen && activeCategory && ActiveIcon &&
        createPortal(
          <>
            {/* Overlay starts BELOW the strip so it doesn't cover the category
                buttons (which was causing mouse-enter/leave flicker). */}
            <div
              className="fixed left-0 right-0 bottom-0 bg-background/60 backdrop-blur-sm z-[9998]"
              style={{ top: panelTop }}
              onClick={() => setOpenCategoryId(null)}
            />
            <div
              className="fixed left-0 right-0 z-[9999] px-3 md:px-6 flex justify-center pointer-events-none"
              style={{ top: panelTop }}
            >
              <div
                className="pointer-events-auto w-full max-w-[1100px] max-h-[70vh] overflow-y-auto bg-popover text-popover-foreground border border-border rounded-xl shadow-2xl p-6 mt-1"
                onMouseEnter={clearCloseTimer}
                onMouseLeave={scheduleClose}
              >
                <div className="mb-4">
                  <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
                    <ActiveIcon className="w-6 h-6 text-primary" />
                    {activeCategory.name}
                    {activeCount > 0 && (
                      <Badge variant="outline" className="text-xs border-border text-muted-foreground">
                        {activeCount} listings
                      </Badge>
                    )}
                  </h2>
                </div>

                {activeSubs.length === 0 ? (
                  <SubcategorySkeleton />
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                    {activeSubs.map((subcategory) => {
                      const SubcategoryIcon = getIconComponent(subcategory.icon);
                      const subCount = (subcategoryCounts as any)[subcategory.name] || 0;
                      const isSubDisabled = subCount === 0;
                      return (
                        <button
                          key={subcategory.id}
                          onClick={() =>
                            !isSubDisabled && handleSubcategoryClick(activeCategory.name, subcategory.name)
                          }
                          disabled={isSubDisabled}
                          className={`group text-left p-3 rounded-lg transition-all duration-200 border border-transparent ${
                            isSubDisabled
                              ? 'opacity-40 cursor-not-allowed'
                              : 'hover:bg-accent hover:shadow-sm hover:border-border cursor-pointer'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <div className="p-2 bg-muted rounded-lg group-hover:bg-accent transition-colors">
                              <SubcategoryIcon className="w-4 h-4 text-primary" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h3 className="font-medium text-sm text-foreground group-hover:text-primary transition-colors truncate">
                                {subcategory.name}
                              </h3>
                              <div className="text-xs text-muted-foreground mt-1">
                                {isSubDisabled ? 'No listings' : `${subCount} listing${subCount !== 1 ? 's' : ''}`}
                              </div>
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}

                <div className="border-t border-border mt-4 pt-4 text-center">
                  <button
                    onClick={() => {
                      onCategorySelect?.(activeCategory.name);
                      setOpenCategoryId(null);
                      navigate(`/search?category=${encodeURIComponent(activeCategory.name)}`);
                    }}
                    className="inline-flex items-center gap-2 text-primary hover:text-primary/80 font-medium transition-colors duration-200 text-sm"
                  >
                    View All in {activeCategory.name} →
                  </button>
                </div>
              </div>
            </div>
          </>,
          document.body
        )}
    </>
  );
};

export default SubNavbar;
