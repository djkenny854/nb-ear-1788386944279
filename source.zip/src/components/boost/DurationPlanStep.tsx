import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Zap, TrendingUp, Rocket, Check } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import AnimatedLabel from '@/components/publish/AnimatedLabel';
import { Slider } from '@/components/ui/slider';

interface DurationPlanStepProps {
  duration: number;
  boostType: string;
  onDurationChange: (duration: number) => void;
  onBoostTypeChange: (type: string) => void;
  onTotalAmountChange: (amount: number) => void;
}

const BOOST_PLANS = [
  {
    id: 'standard',
    name: 'Standard Boost',
    icon: Zap,
    basePrice: 5000,
    multiplier: 1,
    features: ['3x visibility', 'Appear in top results', 'Basic analytics'],
    color: 'from-blue-500 to-blue-600'
  },
  {
    id: 'premium',
    name: 'Premium Boost',
    icon: TrendingUp,
    basePrice: 10000,
    multiplier: 1.5,
    features: ['5x visibility', 'Featured placement', 'Advanced analytics', 'Priority support'],
    color: 'from-purple-500 to-purple-600',
    popular: true
  },
  {
    id: 'ultimate',
    name: 'Ultimate Boost',
    icon: Rocket,
    basePrice: 20000,
    multiplier: 2,
    features: ['10x visibility', 'Homepage banner', 'Full analytics suite', '24/7 support', 'Guaranteed results'],
    color: 'from-orange-500 to-red-600'
  }
];

export default function DurationPlanStep({
  duration,
  boostType,
  onDurationChange,
  onBoostTypeChange,
  onTotalAmountChange
}: DurationPlanStepProps) {
  const [loading, setLoading] = useState(true);
  const [calculatedPrice, setCalculatedPrice] = useState(0);

  useEffect(() => {
    // Simulate loading
    setTimeout(() => setLoading(false), 800);
  }, []);

  useEffect(() => {
    const plan = BOOST_PLANS.find(p => p.id === boostType);
    if (plan) {
      const price = plan.basePrice * duration * plan.multiplier;
      setCalculatedPrice(price);
      onTotalAmountChange(price);
    }
  }, [duration, boostType, onTotalAmountChange]);

  if (loading) {
    return (
      <div className="space-y-8">
        <div className="space-y-3">
          <AnimatedLabel showSkeleton>Choose Boost Plan</AnimatedLabel>
          <Skeleton className="h-4 w-2/3 rounded bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-80 rounded-xl bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
          ))}
        </div>

        <div className="space-y-4">
          <AnimatedLabel showSkeleton>Boost Duration</AnimatedLabel>
          <Skeleton className="h-12 w-full rounded-lg bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="space-y-3">
        <h2 className="text-3xl font-bold text-foreground">Select Your Plan</h2>
        <p className="text-muted-foreground text-lg">
          Choose the perfect boost plan to maximize your ad's reach
        </p>
      </div>

      {/* Boost Plans */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {BOOST_PLANS.map((plan, index) => {
          const Icon = plan.icon;
          const isSelected = boostType === plan.id;

          return (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              onClick={() => onBoostTypeChange(plan.id)}
              className={`
                relative p-6 rounded-xl cursor-pointer transition-all duration-300
                border-2 hover:shadow-xl
                ${isSelected 
                  ? 'border-primary bg-primary/5 shadow-lg scale-105' 
                  : 'border-border hover:border-primary/50 bg-card'
                }
              `}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-primary text-primary-foreground text-xs font-semibold rounded-full">
                  POPULAR
                </div>
              )}

              {isSelected && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-primary flex items-center justify-center shadow-lg"
                >
                  <Check className="w-5 h-5 text-primary-foreground" />
                </motion.div>
              )}

              <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-4`}>
                <Icon className="w-8 h-8 text-white" />
              </div>

              <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
              <div className="text-3xl font-bold mb-4 text-primary">
                {plan.basePrice.toLocaleString()} 
                <span className="text-sm text-muted-foreground font-normal"> UGX/day</span>
              </div>

              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-primary flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          );
        })}
      </div>

      {/* Duration Slider */}
      <div className="space-y-6 bg-card p-8 rounded-xl border border-border">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <AnimatedLabel>Boost Duration</AnimatedLabel>
            <p className="text-sm text-muted-foreground">
              Choose how long you want your ad to be boosted
            </p>
          </div>
          <div className="text-right">
            <div className="text-4xl font-bold text-primary">{duration}</div>
            <div className="text-sm text-muted-foreground">days</div>
          </div>
        </div>

        <Slider
          value={[duration]}
          onValueChange={(value) => onDurationChange(value[0])}
          min={1}
          max={30}
          step={1}
          className="w-full"
        />

        <div className="flex justify-between text-xs text-muted-foreground">
          <span>1 day</span>
          <span>15 days</span>
          <span>30 days</span>
        </div>
      </div>

      {/* Price Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-primary/10 to-primary/5 p-8 rounded-xl border border-primary/20"
      >
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm text-muted-foreground mb-1">Total Cost</div>
            <div className="text-4xl font-bold text-primary">
              {calculatedPrice.toLocaleString()} 
              <span className="text-lg text-muted-foreground font-normal ml-2">UGX</span>
            </div>
          </div>
          <div className="text-right text-sm text-muted-foreground">
            <div>{duration} days</div>
            <div>× {BOOST_PLANS.find(p => p.id === boostType)?.basePrice.toLocaleString()} UGX/day</div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
