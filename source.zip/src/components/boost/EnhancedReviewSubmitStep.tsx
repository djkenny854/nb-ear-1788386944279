import { motion } from 'framer-motion';
import { Check, Clock, Zap, Calendar, DollarSign, TrendingUp, MapPin, Target, Users, Crown } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';

interface EnhancedReviewSubmitStepProps {
  selectedAd: any;
  duration: number;
  boostType: string;
  placementType: string;
  targetRegion: string;
  targetDistricts: string[];
  totalAmount: number;
  estimatedReach: number;
}

export default function EnhancedReviewSubmitStep({
  selectedAd,
  duration,
  boostType,
  placementType,
  targetRegion,
  targetDistricts,
  totalAmount,
  estimatedReach
}: EnhancedReviewSubmitStepProps) {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => setLoading(false), 500);
  }, []);

  if (loading) {
    return (
      <div className="space-y-12 py-8">
        <Skeleton className="h-12 w-2/3 mx-auto rounded bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
        
        <div className="space-y-6">
          <Skeleton className="h-64 rounded-2xl bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Skeleton key={i} className="h-40 rounded-xl bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
            ))}
          </div>

          <Skeleton className="h-48 rounded-2xl bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12 py-8">
      {/* Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold text-foreground"
        >
          Review Your Campaign
        </motion.h2>
        <motion.p 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-muted-foreground text-lg"
        >
          Everything looks good? Submit for approval and get ready to boost!
        </motion.p>
      </div>

      {/* Ad Preview - Full Width */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-8 rounded-2xl bg-gradient-to-br from-primary/10 to-primary/5 border-2 border-primary/20"
      >
        <div className="flex items-start gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center">
            <Zap className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h3 className="font-bold text-2xl">Selected Ad</h3>
            <p className="text-muted-foreground">This listing will be boosted</p>
          </div>
        </div>

        {selectedAd && (
          <div className="flex flex-col md:flex-row items-start gap-6 p-6 bg-card rounded-xl border border-border">
            {selectedAd.images?.[0] && (
              <img 
                src={selectedAd.images[0]} 
                alt={selectedAd.title}
                className="w-full md:w-48 h-48 rounded-xl object-cover"
              />
            )}
            <div className="flex-1 space-y-3">
              <div className="flex items-start justify-between gap-4">
                <h4 className="font-bold text-2xl text-foreground">{selectedAd.title}</h4>
                {selectedAd.price && (
                  <div className="text-right">
                    <div className="text-2xl font-bold text-primary">
                      {selectedAd.price.toLocaleString()}
                    </div>
                    <div className="text-sm text-muted-foreground">{selectedAd.currency}</div>
                  </div>
                )}
              </div>
              
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary" className="capitalize">
                  {selectedAd.listing_type?.replace('_', ' ')}
                </Badge>
                <Badge variant="outline" className="flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {selectedAd.location}
                </Badge>
                <Badge variant="outline" className="flex items-center gap-1">
                  👁️ {selectedAd.view_count || 0} views
                </Badge>
              </div>

              {selectedAd.description && (
                <p className="text-muted-foreground line-clamp-2 text-sm">
                  {selectedAd.description}
                </p>
              )}
            </div>
          </div>
        )}
      </motion.div>

      {/* Boost Configuration Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="p-6 rounded-xl bg-card border border-border hover:shadow-lg transition-shadow"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">Boost Plan</h3>
              <p className="text-xs text-muted-foreground">Selected package</p>
            </div>
          </div>
          <div className="text-2xl font-bold text-primary capitalize">{boostType}</div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.15 }}
          className="p-6 rounded-xl bg-card border border-border hover:shadow-lg transition-shadow"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center">
              <Target className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">Placement</h3>
              <p className="text-xs text-muted-foreground">Ad position</p>
            </div>
          </div>
          <div className="text-2xl font-bold text-primary capitalize flex items-center gap-2">
            {placementType}
            {placementType === 'banner' && <Crown className="w-5 h-5" />}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="p-6 rounded-xl bg-card border border-border hover:shadow-lg transition-shadow"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <Calendar className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">Duration</h3>
              <p className="text-xs text-muted-foreground">Campaign length</p>
            </div>
          </div>
          <div className="text-2xl font-bold text-primary">{duration} Days</div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.25 }}
          className="p-6 rounded-xl bg-card border border-border hover:shadow-lg transition-shadow"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">Target Region</h3>
              <p className="text-xs text-muted-foreground">Geographic area</p>
            </div>
          </div>
          <div className="text-xl font-bold text-primary">{targetRegion}</div>
          {targetDistricts.length > 0 && (
            <p className="text-xs text-muted-foreground mt-2">
              + {targetDistricts.length} specific {targetDistricts.length === 1 ? 'district' : 'districts'}
            </p>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="p-6 rounded-xl bg-card border border-border hover:shadow-lg transition-shadow"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-yellow-500 to-orange-500 flex items-center justify-center">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">Est. Reach</h3>
              <p className="text-xs text-muted-foreground">Potential viewers</p>
            </div>
          </div>
          <div className="text-2xl font-bold text-primary">
            {estimatedReach ? estimatedReach.toLocaleString() : '50,000+'}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.35 }}
          className="p-6 rounded-xl bg-card border border-border hover:shadow-lg transition-shadow"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">Review Time</h3>
              <p className="text-xs text-muted-foreground">Expected wait</p>
            </div>
          </div>
          <div className="text-2xl font-bold text-primary">1-2 Hours</div>
        </motion.div>
      </div>

      {/* Total Cost - Large Highlight */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="p-8 md:p-12 rounded-2xl bg-gradient-to-br from-primary/20 via-primary/10 to-transparent border-2 border-primary/30 shadow-2xl"
      >
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="text-center md:text-left space-y-2">
            <div className="flex items-center gap-3 mb-2">
              <DollarSign className="w-8 h-8 text-primary" />
              <h3 className="text-xl font-semibold text-muted-foreground">Total Investment</h3>
            </div>
            <div className="text-6xl md:text-7xl font-bold bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent">
              {totalAmount.toLocaleString()}
            </div>
            <div className="text-2xl text-muted-foreground font-semibold">UGX</div>
          </div>
          
          <div className="text-center md:text-right space-y-3">
            <div className="text-3xl font-bold text-primary">
              {(totalAmount / duration).toLocaleString()} UGX
            </div>
            <div className="text-sm text-muted-foreground">per day</div>
            
            <div className="pt-3 border-t border-border">
              <div className="text-sm text-muted-foreground mb-1">Cost per 1000 views</div>
              <div className="text-xl font-bold text-primary">
                {estimatedReach ? Math.round((totalAmount / estimatedReach) * 1000).toLocaleString() : '100'} UGX
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* What Happens Next */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="p-8 rounded-2xl bg-gradient-to-r from-green-500/10 to-emerald-500/5 border border-green-500/20"
      >
        <div className="flex items-start gap-4 mb-6">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center flex-shrink-0">
            <Check className="w-8 h-8 text-white" />
          </div>
          <div>
            <h4 className="font-bold text-2xl mb-2">What happens next?</h4>
            <p className="text-muted-foreground">Your boost journey in 4 simple steps</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { step: '1', title: 'Review', desc: 'We review your boost request within 1-2 hours' },
            { step: '2', title: 'Payment', desc: 'Receive payment instructions via email/SMS' },
            { step: '3', title: 'Activation', desc: 'Your ad goes live immediately after payment' },
            { step: '4', title: 'Analytics', desc: 'Track performance in real-time dashboard' }
          ].map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 + index * 0.1 }}
              className="flex items-start gap-3 p-4 rounded-xl bg-card/50 border border-border"
            >
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center flex-shrink-0 font-bold text-primary-foreground">
                {item.step}
              </div>
              <div className="space-y-1">
                <div className="font-semibold text-foreground">{item.title}</div>
                <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
