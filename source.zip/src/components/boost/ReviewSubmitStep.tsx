import { motion } from 'framer-motion';
import { Check, Clock, Zap, Calendar, DollarSign, TrendingUp } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useState, useEffect } from 'react';

interface ReviewSubmitStepProps {
  selectedAd: any;
  duration: number;
  boostType: string;
  totalAmount: number;
}

export default function ReviewSubmitStep({
  selectedAd,
  duration,
  boostType,
  totalAmount
}: ReviewSubmitStepProps) {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => setLoading(false), 600);
  }, []);

  if (loading) {
    return (
      <div className="space-y-8">
        <Skeleton className="h-8 w-1/2 rounded bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
        
        <div className="space-y-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32 rounded-xl bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-3">
        <h2 className="text-3xl font-bold text-foreground">Review Your Boost</h2>
        <p className="text-muted-foreground text-lg">
          Double-check everything before submitting for review
        </p>
      </div>

      {/* Ad Preview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-card p-6 rounded-xl border border-border"
      >
        <div className="flex items-start gap-2 mb-4">
          <Zap className="w-5 h-5 text-primary mt-1" />
          <div>
            <h3 className="font-semibold text-lg">Selected Ad</h3>
            <p className="text-sm text-muted-foreground">The ad that will be boosted</p>
          </div>
        </div>

        {selectedAd && (
          <div className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
            {selectedAd.images?.[0] && (
              <img 
                src={selectedAd.images[0]} 
                alt={selectedAd.title}
                className="w-20 h-20 rounded-lg object-cover"
              />
            )}
            <div className="flex-1">
              <h4 className="font-semibold">{selectedAd.title}</h4>
              <p className="text-sm text-muted-foreground capitalize">
                {selectedAd.listing_type?.replace('_', ' ')} • {selectedAd.location}
              </p>
              {selectedAd.price && (
                <p className="text-sm font-semibold text-primary mt-1">
                  {selectedAd.price.toLocaleString()} {selectedAd.currency}
                </p>
              )}
            </div>
          </div>
        )}
      </motion.div>

      {/* Boost Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card p-6 rounded-xl border border-border"
        >
          <div className="flex items-start gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-primary mt-1" />
            <div>
              <h3 className="font-semibold text-lg">Boost Type</h3>
              <p className="text-sm text-muted-foreground">Your selected plan</p>
            </div>
          </div>
          <div className="text-2xl font-bold text-primary capitalize">
            {boostType} Boost
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card p-6 rounded-xl border border-border"
        >
          <div className="flex items-start gap-2 mb-4">
            <Calendar className="w-5 h-5 text-primary mt-1" />
            <div>
              <h3 className="font-semibold text-lg">Duration</h3>
              <p className="text-sm text-muted-foreground">Boost period</p>
            </div>
          </div>
          <div className="text-2xl font-bold text-primary">
            {duration} Days
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card p-6 rounded-xl border border-border"
        >
          <div className="flex items-start gap-2 mb-4">
            <DollarSign className="w-5 h-5 text-primary mt-1" />
            <div>
              <h3 className="font-semibold text-lg">Total Cost</h3>
              <p className="text-sm text-muted-foreground">Amount to pay</p>
            </div>
          </div>
          <div className="text-2xl font-bold text-primary">
            {totalAmount.toLocaleString()} UGX
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-card p-6 rounded-xl border border-border"
        >
          <div className="flex items-start gap-2 mb-4">
            <Clock className="w-5 h-5 text-primary mt-1" />
            <div>
              <h3 className="font-semibold text-lg">Review Time</h3>
              <p className="text-sm text-muted-foreground">Expected wait</p>
            </div>
          </div>
          <div className="text-2xl font-bold text-primary">
            1-2 Hours
          </div>
        </motion.div>
      </div>

      {/* Info Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-gradient-to-r from-primary/10 to-primary/5 p-6 rounded-xl border border-primary/20"
      >
        <div className="flex gap-4">
          <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
            <Check className="w-6 h-6 text-primary" />
          </div>
          <div className="space-y-2">
            <h4 className="font-semibold text-lg">What happens next?</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                Your boost request will be reviewed by our team
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                Once approved, you'll receive payment instructions
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                After payment, your ad will be boosted immediately
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                Track your boost performance in the analytics dashboard
              </li>
            </ul>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
