import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { motion } from 'framer-motion';
import { Check, Package, Briefcase, Megaphone, FileCode } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import AnimatedLabel from '@/components/publish/AnimatedLabel';

interface SelectAdStepProps {
  selectedAd: any;
  onSelectAd: (ad: any) => void;
}

export default function SelectAdStep({ selectedAd, onSelectAd }: SelectAdStepProps) {
  const [ads, setAds] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUserAds();
  }, []);

  const fetchUserAds = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: sellerProfile } = await supabase
        .from('seller_profiles')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (!sellerProfile) return;

      const { data, error } = await supabase
        .from('ads')
        .select('*')
        .eq('seller_id', sellerProfile.id)
        .eq('status', 'active')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setAds(data || []);
    } catch (error) {
      console.error('Error fetching ads:', error);
    } finally {
      setLoading(false);
    }
  };

  const getListingIcon = (type: string) => {
    switch (type) {
      case 'physical_products': return Package;
      case 'jobs': return Briefcase;
      case 'promotions': return Megaphone;
      case 'digital_products': return FileCode;
      default: return Package;
    }
  };

  if (loading) {
    return (
      <div className="space-y-12 py-8">
        <div className="text-center space-y-4">
          <AnimatedLabel showSkeleton className="text-3xl">Select Your Ad</AnimatedLabel>
          <Skeleton className="h-6 w-2/3 mx-auto rounded bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="space-y-4">
              <Skeleton className="aspect-video rounded-2xl bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
              <Skeleton className="h-6 w-3/4 rounded bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
              <Skeleton className="h-4 w-1/2 rounded bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12 py-8">
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <h2 className="text-4xl font-bold text-foreground">Choose Your Ad</h2>
        <p className="text-muted-foreground text-lg">
          Select the ad you want to boost and reach thousands of potential customers
        </p>
      </div>

      {ads.length === 0 ? (
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center py-20 px-4"
        >
          <div className="mx-auto w-24 h-24 rounded-full bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center mb-6 shadow-lg">
            <Package className="w-12 h-12 text-muted-foreground" />
          </div>
          <h3 className="text-2xl font-bold mb-3">No Active Ads</h3>
          <p className="text-muted-foreground text-lg max-w-md mx-auto">
            You need to create an ad before you can boost it. Start by posting your first listing.
          </p>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
          {ads.map((ad, index) => {
            const Icon = getListingIcon(ad.listing_type);
            const isSelected = selectedAd?.id === ad.id;

            return (
              <motion.div
                key={ad.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => onSelectAd(ad)}
                className={`
                  relative group cursor-pointer transition-all duration-300
                  ${isSelected ? 'scale-105' : 'hover:scale-105'}
                `}
              >
                {/* Selection Badge */}
                {isSelected && (
                  <motion.div
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    className="absolute -top-3 -right-3 z-10 w-12 h-12 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-xl"
                  >
                    <Check className="w-6 h-6 text-primary-foreground" />
                  </motion.div>
                )}

                {/* Image Container */}
                <div className={`
                  relative overflow-hidden rounded-2xl mb-4 aspect-video
                  border-2 transition-all duration-300
                  ${isSelected 
                    ? 'border-primary shadow-xl' 
                    : 'border-border group-hover:border-primary/50 group-hover:shadow-lg'
                  }
                `}>
                  {ad.images && ad.images.length > 0 ? (
                    <img 
                      src={ad.images[0]} 
                      alt={ad.title}
                      className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center">
                      <Icon className="w-16 h-16 text-muted-foreground" />
                    </div>
                  )}

                  {/* Category Badge */}
                  <div className="absolute top-3 left-3 px-3 py-1.5 rounded-full bg-background/90 backdrop-blur-sm border border-border flex items-center gap-2">
                    <Icon className="w-4 h-4 text-primary" />
                    <span className="text-xs font-medium capitalize">
                      {ad.listing_type?.replace('_', ' ')}
                    </span>
                  </div>

                  {/* Views Badge */}
                  <div className="absolute bottom-3 right-3 px-3 py-1.5 rounded-full bg-background/90 backdrop-blur-sm border border-border">
                    <span className="text-xs font-medium">
                      👁️ {ad.view_count || 0}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="space-y-3">
                  <h3 className="font-bold text-xl line-clamp-2 text-foreground">
                    {ad.title}
                  </h3>
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground flex items-center gap-1">
                      📍 {ad.location}
                    </span>
                    {ad.price && (
                      <span className="font-bold text-primary text-lg">
                        {ad.price.toLocaleString()} {ad.currency}
                      </span>
                    )}
                  </div>

                  {/* Engagement Bar */}
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min((ad.view_count || 0) % 100, 100)}%` }}
                        transition={{ delay: index * 0.05 + 0.3, duration: 0.8 }}
                        className="h-full bg-gradient-to-r from-primary to-primary/50" 
                      />
                    </div>
                    <span className="text-xs text-muted-foreground font-medium">
                      {Math.min((ad.view_count || 0) % 100, 100)}%
                    </span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
