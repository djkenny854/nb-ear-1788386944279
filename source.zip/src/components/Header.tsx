import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Search, ShoppingBag, User, Plus, Menu, X, Store, BarChart3, MessageSquare, Package, Settings, TrendingUp, Cog } from 'lucide-react';
import { useAuth } from '@/components/auth/AuthContext';
import AuthModal from '@/components/auth/AuthModal';
import NotificationBell from '@/components/notifications/NotificationBell';
import { useState } from 'react';
import ChatInterface from '@/components/chat/ChatInterface';
import logoUrl from '@/assets/earlymarket-logo-new.png';

const Header = () => {
  const [showChat, setShowChat] = useState(false);
  const [selectedSellerId, setSelectedSellerId] = useState<string | null>(null);
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleChatOpen = (sellerId: string) => {
    setSelectedSellerId(sellerId);
    setShowChat(true);
  };

  const handleChatClose = () => {
    setShowChat(false);
    setSelectedSellerId(null);
  };

  if (showChat && selectedSellerId) {
    return (
      <ChatInterface
        sellerId={selectedSellerId}
        onBack={handleChatClose}
      />
    );
  }

  return (
    <header className="bg-background shadow-sm border-b border-border sticky top-0 z-50">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo (Left Side) with 2026 badge */}
          <Link to="/" className="flex-shrink-0 flex items-center gap-3" aria-label="Early Market home">
            <img src={logoUrl} alt="Early Market" className="h-10 md:h-12 w-auto object-contain" />
          </Link>

          {/* Mobile Actions (Right Side - Visible on small screens) */}
          <div className="flex md:hidden items-center gap-1">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => navigate('/marketplace')}
              className="h-9 w-9"
            >
              <Search className="w-5 h-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => navigate('/account-settings')}
              className="h-9 w-9"
            >
              <Cog className="w-5 h-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleMobileMenu}
              className="h-9 w-9"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>

          {/* Desktop Search Bar */}
          <div className="hidden md:flex items-center bg-secondary rounded-full px-4 py-2 flex-1 max-w-xl mx-4">
            <Search className="w-5 h-5 text-muted-foreground mr-2" />
            <Input
              type="search"
              placeholder="Search for anything..."
              className="bg-transparent border-none shadow-none focus:ring-0 focus:outline-none"
            />
          </div>

          {/* Navigation and Auth (Right Side - Hidden on small screens) */}
          <div className="hidden md:flex items-center space-x-4">
            <NotificationBell onChatOpen={handleChatOpen} />
            {user ? (
              <>
                <Link to="/post-ad">
                  <Button size="sm" variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Post Ad
                  </Button>
                </Link>
                <Link to="/profile">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src="https://github.com/shadcn.png" alt="@shadcn" />
                    <AvatarFallback>CN</AvatarFallback>
                  </Avatar>
                </Link>
                <Button size="sm" onClick={handleSignOut}>
                  Sign Out
                </Button>
              </>
            ) : (
              <AuthModal>
                <Button size="sm">
                  Sign In
                </Button>
              </AuthModal>
            )}
          </div>
        </div>

        {/* Mobile Menu (Collapsible) */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-3 border-t border-border bg-background">
            <div className="flex flex-col space-y-1">
              {user ? (
                <>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-left"
                    onClick={() => {
                      navigate('/post-ad');
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    <Plus className="w-5 h-5 mr-3" />
                    <span>Add Product / Service</span>
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-left"
                    onClick={() => {
                      navigate('/sales-analytics');
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    <BarChart3 className="w-5 h-5 mr-3" />
                    <span>My Store Analytics</span>
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-left"
                    onClick={() => {
                      navigate('/messages');
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    <MessageSquare className="w-5 h-5 mr-3" />
                    <span>Customer Chats</span>
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-left"
                    onClick={() => {
                      navigate('/my-products');
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    <Package className="w-5 h-5 mr-3" />
                    <span>Orders & Deliveries</span>
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-left"
                    onClick={() => {
                      navigate('/account-settings');
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    <Settings className="w-5 h-5 mr-3" />
                    <span>Store Settings</span>
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-left"
                    onClick={() => {
                      navigate('/boost-ad');
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    <TrendingUp className="w-5 h-5 mr-3" />
                    <span>Boost Ads / Promote Post</span>
                  </Button>
                  <div className="pt-2 border-t border-border mt-2">
                    <Button 
                      variant="ghost" 
                      className="w-full justify-start text-left text-destructive"
                      onClick={() => {
                        handleSignOut();
                        setIsMobileMenuOpen(false);
                      }}
                    >
                      Sign Out
                    </Button>
                  </div>
                </>
              ) : (
                <AuthModal>
                  <Button className="w-full">
                    Sign In
                  </Button>
                </AuthModal>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
