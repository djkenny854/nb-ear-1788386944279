import React from 'react';
import { useFeatureGate } from '@/hooks/useFeatureGate';
import { Shield, Lock, ArrowUpCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CURRENT_APP_VERSION } from '@/hooks/useAppVersion';

interface FeatureGateProps {
  feature: string;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

const FeatureGate: React.FC<FeatureGateProps> = ({ feature, children, fallback }) => {
  const gate = useFeatureGate(feature);

  if (gate.isLoading) return null;

  if (gate.isAllowed) return <>{children}</>;

  if (fallback) return <>{fallback}</>;

  return (
    <Card className="border-amber-500/30 bg-gradient-to-br from-amber-500/5 to-orange-500/5">
      <CardContent className="flex flex-col items-center justify-center py-12 text-center gap-4">
        {gate.reason === 'version_too_low' ? (
          <>
            <div className="p-3 rounded-full bg-amber-500/10">
              <ArrowUpCircle className="h-8 w-8 text-amber-600" />
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Update Required</h3>
              <p className="text-sm text-muted-foreground max-w-md">
                <strong>{gate.displayName || feature}</strong> requires version{' '}
                <Badge variant="outline" className="font-mono">{gate.minVersion}</Badge>.
                You're on <Badge variant="secondary" className="font-mono">{CURRENT_APP_VERSION}</Badge>.
              </p>
              {gate.description && (
                <p className="text-xs text-muted-foreground">{gate.description}</p>
              )}
            </div>
          </>
        ) : gate.reason === 'premium_required' ? (
          <>
            <div className="p-3 rounded-full bg-primary/10">
              <Shield className="h-8 w-8 text-primary" />
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Premium Feature</h3>
              <p className="text-sm text-muted-foreground max-w-md">
                <strong>{gate.displayName || feature}</strong> is available on the Premium plan.
              </p>
            </div>
          </>
        ) : (
          <>
            <div className="p-3 rounded-full bg-muted">
              <Lock className="h-8 w-8 text-muted-foreground" />
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Feature Unavailable</h3>
              <p className="text-sm text-muted-foreground">
                This feature is currently disabled.
              </p>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default FeatureGate;
