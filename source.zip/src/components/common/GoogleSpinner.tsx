import React from 'react';
import { cn } from '@/lib/utils';

interface GoogleSpinnerProps {
  size?: number;
  className?: string;
}

/** Material-style indeterminate spinner (uses .animate-spin-google / .animate-dash). */
const GoogleSpinner: React.FC<GoogleSpinnerProps> = ({ size = 24, className }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 50 50"
    className={cn('animate-spin-google text-primary', className)}
    aria-hidden="true"
  >
    <circle
      cx="25"
      cy="25"
      r="20"
      fill="none"
      stroke="currentColor"
      strokeWidth="4"
      strokeLinecap="round"
      className="animate-dash"
    />
  </svg>
);

export default GoogleSpinner;
