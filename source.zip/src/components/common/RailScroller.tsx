import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface RailScrollerProps {
  children: React.ReactNode;
  className?: string;
  /** CSS selector for the scrollable element inside children. */
  railSelector?: string;
}

/**
 * Wraps a horizontally scrolling rail and adds left/right arrow buttons for
 * pointer (mouse) devices. Buttons are hidden on touch-only devices and when
 * the rail is already at its start/end.
 */
const RailScroller: React.FC<RailScrollerProps> = ({
  children,
  className,
  railSelector = '.overflow-x-auto',
}) => {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [canPrev, setCanPrev] = useState(false);
  const [canNext, setCanNext] = useState(false);
  const [hasPointer, setHasPointer] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mq = window.matchMedia('(hover: hover) and (pointer: fine)');
    const apply = () => setHasPointer(mq.matches);
    apply();
    mq.addEventListener?.('change', apply);
    return () => mq.removeEventListener?.('change', apply);
  }, []);

  const getRail = useCallback(
    () => wrapRef.current?.querySelector<HTMLElement>(railSelector) || null,
    [railSelector],
  );

  const update = useCallback(() => {
    const rail = getRail();
    if (!rail) return;
    const max = rail.scrollWidth - rail.clientWidth;
    setCanPrev(rail.scrollLeft > 8);
    setCanNext(max > 8 && rail.scrollLeft < max - 8);
  }, [getRail]);

  useEffect(() => {
    if (!hasPointer) return;
    const rail = getRail();
    if (!rail) return;
    update();
    rail.addEventListener('scroll', update, { passive: true });
    const ro = new ResizeObserver(update);
    ro.observe(rail);
    return () => {
      rail.removeEventListener('scroll', update);
      ro.disconnect();
    };
  }, [hasPointer, getRail, update]);

  const scrollBy = (dir: 1 | -1) => {
    const rail = getRail();
    if (!rail) return;
    rail.scrollBy({ left: dir * rail.clientWidth * 0.85, behavior: 'smooth' });
  };

  const btn =
    'absolute top-1/2 -translate-y-1/2 z-20 hidden md:inline-flex items-center justify-center h-9 w-9 rounded-full bg-background/95 border border-border shadow-md text-foreground hover:bg-muted transition-opacity';

  return (
    <div ref={wrapRef} className={cn('relative group/rail', className)}>
      {children}
      {hasPointer && canPrev && (
        <button
          type="button"
          aria-label="Scroll left"
          onClick={() => scrollBy(-1)}
          className={cn(btn, 'left-0 -translate-x-1')}
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
      )}
      {hasPointer && canNext && (
        <button
          type="button"
          aria-label="Scroll right"
          onClick={() => scrollBy(1)}
          className={cn(btn, 'right-0 translate-x-1')}
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      )}
    </div>
  );
};

export default RailScroller;