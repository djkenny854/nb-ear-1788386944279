import React, { useState, useEffect } from 'react';
import { Download, Zap, Bell, WifiOff, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Drawer,
  DrawerContent,
} from '@/components/ui/drawer';
import {
  Dialog,
  DialogContent,
} from '@/components/ui/dialog';
import { isCapacitorNative } from '@/hooks/useCapacitor';
import { useIsMobile } from '@/hooks/use-mobile';
import earlyMarketLogo from '@/assets/earlymarket-logo-new.png';

const PLAY_STORE_URL = 'https://play.google.com/store/apps/details?id=com.earlymarketug.app';
const DISMISS_KEY = 'app-promo-drawer-dismissed';

const PromoContent: React.FC<{ onClose: () => void }> = ({ onClose }) => (
  <div className="px-6 pt-2 pb-6 max-w-md mx-auto w-full">
    {/* Header row */}
    <div className="flex items-center gap-4 mb-5">
      <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-primary/10 border border-primary/20 overflow-hidden">
        <img src={earlyMarketLogo} alt="EarlyMarket" className="h-10 w-10 object-contain" />
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="text-base font-bold text-foreground leading-tight">
          Better on the App
        </h3>
        <p className="text-sm text-muted-foreground leading-snug mt-0.5">
          Get a faster, richer experience with the EarlyMarket mobile app.
        </p>
      </div>
    </div>

    {/* Feature chips */}
    <div className="flex flex-wrap gap-2 mb-5">
      {[
        { icon: Zap, text: 'Faster' },
        { icon: Bell, text: 'Notifications' },
        { icon: WifiOff, text: 'Offline' },
      ].map(({ icon: Icon, text }) => (
        <div key={text} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-muted text-sm font-medium text-foreground">
          <Icon className="w-3.5 h-3.5 text-primary" />
          {text}
        </div>
      ))}
    </div>

    {/* Actions */}
    <div className="flex flex-col gap-2">
      <Button
        size="lg"
        onClick={() => {
          const intentUrl = `intent://app#Intent;scheme=earlymarket;package=com.earlymarketug.app;S.browser_fallback_url=${encodeURIComponent(PLAY_STORE_URL)};end`;
          window.location.href = intentUrl;
        }}
        className="w-full gap-2 font-bold h-12 rounded-xl"
      >
        <Download className="h-5 w-5" />
        Get the App
      </Button>
      <Button
        variant="ghost"
        size="sm"
        onClick={onClose}
        className="text-muted-foreground text-sm hover:text-foreground"
      >
        Stay on Web
      </Button>
    </div>
  </div>
);

const AppPromoBanner: React.FC = () => {
  const [open, setOpen] = useState(false);
  const isMobile = useIsMobile();

  useEffect(() => {
    if (isCapacitorNative()) return;
    const wasDismissed = sessionStorage.getItem(DISMISS_KEY);
    if (wasDismissed) return;

    const timer = setTimeout(() => {
      setOpen(true);
    }, 30000);

    return () => clearTimeout(timer);
  }, []);

  const handleClose = () => {
    setOpen(false);
    sessionStorage.setItem(DISMISS_KEY, 'true');
  };

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={(v) => { if (!v) handleClose(); }}>
        <DrawerContent className="max-h-[50vh]">
          <PromoContent onClose={handleClose} />
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) handleClose(); }}>
      <DialogContent className="max-w-sm p-0 border-none overflow-hidden">
        <PromoContent onClose={handleClose} />
      </DialogContent>
    </Dialog>
  );
};

export default AppPromoBanner;

