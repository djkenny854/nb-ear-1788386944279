import React, { useState, useRef, useCallback } from 'react';
import { ArrowDown, Loader2 } from 'lucide-react';
import { motion, useMotionValue, useTransform } from 'framer-motion';
import { cn } from '@/lib/utils';

interface PullToRefreshProps {
  onRefresh: () => Promise<void> | void;
  children: React.ReactNode;
  className?: string;
}

const THRESHOLD = 80;

const PullToRefresh: React.FC<PullToRefreshProps> = ({ onRefresh, children, className }) => {
  const [refreshing, setRefreshing] = useState(false);
  const [reachedThreshold, setReachedThreshold] = useState(false);
  const pullDistance = useMotionValue(0);
  const opacity = useTransform(pullDistance, [0, 40, THRESHOLD], [0, 0.5, 1]);
  const scale = useTransform(pullDistance, [0, THRESHOLD], [0.5, 1]);

  const touchStartY = useRef(0);
  const isPulling = useRef(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    // Only enable if scrolled to the absolute top of both container and window
    const el = containerRef.current;
    if (!el || el.scrollTop > 2 || window.scrollY > 2) return;
    touchStartY.current = e.touches[0].clientY;
    isPulling.current = true;
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isPulling.current || refreshing) return;
    const el = containerRef.current;
    if ((el && el.scrollTop > 0) || window.scrollY > 0) {
      isPulling.current = false;
      pullDistance.set(0);
      return;
    }
    const diff = e.touches[0].clientY - touchStartY.current;
    if (diff > 8) {
      const next = Math.min(diff * 0.45, THRESHOLD + 20);
      pullDistance.set(next);
      setReachedThreshold(next >= THRESHOLD);
    }
  }, [refreshing, pullDistance]);

  const handleTouchEnd = useCallback(async () => {
    if (!isPulling.current) return;
    isPulling.current = false;

    if (pullDistance.get() >= THRESHOLD && !refreshing) {
      setRefreshing(true);
      pullDistance.set(THRESHOLD * 0.6);
      try {
        await onRefresh();
      } catch {}
      setRefreshing(false);
    }
    pullDistance.set(0);
    setReachedThreshold(false);
  }, [onRefresh, refreshing, pullDistance]);

  return (
    <div
      ref={containerRef}
      className={cn('relative overflow-y-auto', className)}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Pull indicator */}
      <motion.div
        className="flex items-center justify-center pointer-events-none"
        style={{
          height: pullDistance,
          opacity,
          willChange: 'height, opacity',
        }}
      >
        <motion.div style={{ scale }} className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10">
          {refreshing ? (
            <Loader2 className="w-5 h-5 text-primary animate-spin" />
          ) : (
            <ArrowDown
              className="w-5 h-5 text-primary transition-transform duration-200 ease-out"
              style={{ transform: reachedThreshold ? 'rotate(180deg)' : 'rotate(0deg)' }}
            />
          )}
        </motion.div>
      </motion.div>

      {children}
    </div>
  );
};

export default PullToRefresh;
