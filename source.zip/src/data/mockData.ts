// Mock data for EarlyMarket homepage sections

export interface Listing {
  id: string;
  title: string;
  price: number;
  originalPrice?: number;
  image: string;
  images?: string[];
  category: string;
  location: string;
  isNew?: boolean;
  isHot?: boolean;
  discount?: number;
  seller: {
    name: string;
    avatar: string;
    isVerified: boolean;
  };
  views: number;
  createdAt: string;
}

export interface Job {
  id: string;
  title: string;
  company: string;
  companyLogo: string;
  location: string;
  salary: string;
  type: 'full-time' | 'part-time' | 'contract' | 'remote';
  isNew?: boolean;
  isUrgent?: boolean;
  postedAt: string;
  description?: string;
  images?: string[];
}

export interface DigitalProduct {
  id: string;
  title: string;
  price: number;
  originalPrice?: number;
  images: string[];
  type: 'ebook' | 'software' | 'music' | 'video' | 'graphics' | 'template';
  format: string;
  fileSize: string;
  downloads: number;
  rating: number;
  seller: {
    name: string;
    avatar: string;
    isVerified: boolean;
  };
}

export interface Promotion {
  id: string;
  title: string;
  description: string;
  images: string[];
  type: 'discount' | 'flash-sale' | 'bundle' | 'coupon';
  discountPercent: number;
  startsAt: string;
  endsAt: string;
  brand: {
    name: string;
    logo: string;
  };
  claimsCount: number;
  maxClaims?: number;
}

export interface Seller {
  id: string;
  name: string;
  avatar: string;
  category: string;
  isVerified: boolean;
  rating: number;
  followers: number;
  productsCount: number;
}

export interface SocialPost {
  id: string;
  author: {
    name: string;
    avatar: string;
    isVerified: boolean;
  };
  content: string;
  image?: string;
  likes: number;
  comments: number;
  shares: number;
  createdAt: string;
}

export interface Collection {
  id: string;
  title: string;
  description: string;
  image: string;
  itemCount: number;
  color: string;
}

export const mockListings: Listing[] = [
  {
    id: '1',
    title: 'iPhone 14 Pro Max 256GB',
    price: 3500000,
    originalPrice: 4000000,
    image: 'https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=400',
    images: [
      'https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=400',
      'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400',
      'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?w=400',
    ],
    category: 'Electronics',
    location: 'Kampala',
    isNew: true,
    discount: 12,
    seller: { name: 'TechHub UG', avatar: 'https://i.pravatar.cc/150?img=1', isVerified: true },
    views: 1250,
    createdAt: '2024-01-15'
  },
  {
    id: '2',
    title: 'Samsung Galaxy S24 Ultra',
    price: 4200000,
    image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400',
    images: [
      'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400',
      'https://images.unsplash.com/photo-1585060544812-6b45742d762f?w=400',
    ],
    category: 'Electronics',
    location: 'Entebbe',
    isHot: true,
    seller: { name: 'Mobile World', avatar: 'https://i.pravatar.cc/150?img=2', isVerified: true },
    views: 890,
    createdAt: '2024-01-14'
  },
  {
    id: '3',
    title: 'MacBook Pro M3 14"',
    price: 8500000,
    originalPrice: 9200000,
    image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400',
    images: [
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400',
      'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=400',
      'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400',
    ],
    category: 'Electronics',
    location: 'Kampala',
    discount: 8,
    seller: { name: 'Apple Store UG', avatar: 'https://i.pravatar.cc/150?img=3', isVerified: true },
    views: 2100,
    createdAt: '2024-01-13'
  },
  {
    id: '4',
    title: 'Nike Air Jordan 1 Retro',
    price: 450000,
    image: 'https://images.unsplash.com/photo-1556906781-9a412961c28c?w=400',
    images: [
      'https://images.unsplash.com/photo-1556906781-9a412961c28c?w=400',
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400',
      'https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?w=400',
    ],
    category: 'Fashion',
    location: 'Jinja',
    isNew: true,
    seller: { name: 'Sneaker Zone', avatar: 'https://i.pravatar.cc/150?img=4', isVerified: false },
    views: 567,
    createdAt: '2024-01-12'
  },
  {
    id: '5',
    title: 'Sony PlayStation 5',
    price: 2800000,
    originalPrice: 3200000,
    image: 'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=400',
    images: [
      'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=400',
      'https://images.unsplash.com/photo-1607853202273-797f1c22a38e?w=400',
    ],
    category: 'Gaming',
    location: 'Kampala',
    isHot: true,
    discount: 12,
    seller: { name: 'Game Masters', avatar: 'https://i.pravatar.cc/150?img=5', isVerified: true },
    views: 3400,
    createdAt: '2024-01-11'
  },
  {
    id: '6',
    title: 'Toyota Land Cruiser V8',
    price: 185000000,
    image: 'https://images.unsplash.com/photo-1559416523-140ddc3d238c?w=400',
    category: 'Vehicles',
    location: 'Kampala',
    seller: { name: 'AutoMart Uganda', avatar: 'https://i.pravatar.cc/150?img=6', isVerified: true },
    views: 5600,
    createdAt: '2024-01-10'
  },
  {
    id: '7',
    title: 'Modern 3BR Apartment',
    price: 1500000,
    image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=400',
    category: 'Properties',
    location: 'Kololo',
    isNew: true,
    seller: { name: 'Prime Properties', avatar: 'https://i.pravatar.cc/150?img=7', isVerified: true },
    views: 1890,
    createdAt: '2024-01-09'
  },
  {
    id: '8',
    title: 'Designer Handbag Collection',
    price: 750000,
    originalPrice: 950000,
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400',
    category: 'Fashion',
    location: 'Kampala',
    discount: 21,
    seller: { name: 'Luxury Lane', avatar: 'https://i.pravatar.cc/150?img=8', isVerified: true },
    views: 456,
    createdAt: '2024-01-08'
  }
];

export const mockJobs: Job[] = [
  {
    id: '1',
    title: 'Senior Software Engineer',
    company: 'SafeBoda',
    companyLogo: 'https://i.pravatar.cc/150?img=10',
    location: 'Kampala',
    salary: 'UGX 5M - 8M',
    type: 'full-time',
    isNew: true,
    postedAt: '2 days ago'
  },
  {
    id: '2',
    title: 'Marketing Manager',
    company: 'MTN Uganda',
    companyLogo: 'https://i.pravatar.cc/150?img=11',
    location: 'Kampala',
    salary: 'UGX 4M - 6M',
    type: 'full-time',
    isUrgent: true,
    postedAt: '1 day ago'
  },
  {
    id: '3',
    title: 'UI/UX Designer',
    company: 'Xente',
    companyLogo: 'https://i.pravatar.cc/150?img=12',
    location: 'Remote',
    salary: 'UGX 3M - 5M',
    type: 'remote',
    isNew: true,
    postedAt: '3 days ago'
  },
  {
    id: '4',
    title: 'Sales Representative',
    company: 'Jumia Uganda',
    companyLogo: 'https://i.pravatar.cc/150?img=13',
    location: 'Kampala',
    salary: 'UGX 1.5M + Commission',
    type: 'full-time',
    postedAt: '5 days ago'
  },
  {
    id: '5',
    title: 'Data Analyst',
    company: 'Stanbic Bank',
    companyLogo: 'https://i.pravatar.cc/150?img=14',
    location: 'Kampala',
    salary: 'UGX 4M - 7M',
    type: 'full-time',
    isNew: true,
    postedAt: '1 day ago'
  },
  {
    id: '6',
    title: 'Content Creator',
    company: 'EarlyMarket',
    companyLogo: 'https://i.pravatar.cc/150?img=15',
    location: 'Hybrid',
    salary: 'UGX 2M - 3M',
    type: 'contract',
    postedAt: '4 days ago'
  }
];

export const mockSellers: Seller[] = [
  {
    id: '1',
    name: 'TechHub Uganda',
    avatar: 'https://i.pravatar.cc/150?img=20',
    category: 'Electronics',
    isVerified: true,
    rating: 4.9,
    followers: 12500,
    productsCount: 156
  },
  {
    id: '2',
    name: 'Fashion Forward',
    avatar: 'https://i.pravatar.cc/150?img=21',
    category: 'Fashion',
    isVerified: true,
    rating: 4.7,
    followers: 8900,
    productsCount: 234
  },
  {
    id: '3',
    name: 'AutoMart Uganda',
    avatar: 'https://i.pravatar.cc/150?img=22',
    category: 'Vehicles',
    isVerified: true,
    rating: 4.8,
    followers: 15600,
    productsCount: 89
  },
  {
    id: '4',
    name: 'Home & Living',
    avatar: 'https://i.pravatar.cc/150?img=23',
    category: 'Home',
    isVerified: true,
    rating: 4.6,
    followers: 5400,
    productsCount: 312
  },
  {
    id: '5',
    name: 'Sneaker Culture',
    avatar: 'https://i.pravatar.cc/150?img=24',
    category: 'Fashion',
    isVerified: false,
    rating: 4.5,
    followers: 3200,
    productsCount: 78
  },
  {
    id: '6',
    name: 'Prime Properties',
    avatar: 'https://i.pravatar.cc/150?img=25',
    category: 'Real Estate',
    isVerified: true,
    rating: 4.9,
    followers: 22000,
    productsCount: 45
  }
];

export const mockPosts: SocialPost[] = [
  {
    id: '1',
    author: { name: 'Sarah Nakamya', avatar: 'https://i.pravatar.cc/150?img=30', isVerified: true },
    content: 'Just got my new iPhone from TechHub! Amazing service and genuine products 📱✨',
    image: 'https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=600',
    likes: 234,
    comments: 45,
    shares: 12,
    createdAt: '2 hours ago'
  },
  {
    id: '2',
    author: { name: 'John Mukasa', avatar: 'https://i.pravatar.cc/150?img=31', isVerified: false },
    content: 'Best deals in Kampala! Found this amazing vintage collection at Fashion Forward 🔥',
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600',
    likes: 156,
    comments: 23,
    shares: 8,
    createdAt: '5 hours ago'
  },
  {
    id: '3',
    author: { name: 'Grace Auma', avatar: 'https://i.pravatar.cc/150?img=32', isVerified: true },
    content: 'My new apartment in Kololo is absolutely stunning! Thanks Prime Properties 🏠❤️',
    image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=600',
    likes: 567,
    comments: 89,
    shares: 34,
    createdAt: '1 day ago'
  },
  {
    id: '4',
    author: { name: 'David Okello', avatar: 'https://i.pravatar.cc/150?img=33', isVerified: false },
    content: 'Gaming setup complete! PS5 + new TV = perfect weekend 🎮',
    image: 'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=600',
    likes: 890,
    comments: 123,
    shares: 56,
    createdAt: '2 days ago'
  }
];

export const mockCollections: Collection[] = [
  {
    id: '1',
    title: 'Deals Under 50K',
    description: 'Amazing finds for budget shoppers',
    image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=400',
    itemCount: 245,
    color: 'from-emerald-500 to-teal-600'
  },
  {
    id: '2',
    title: 'Back to School',
    description: 'Everything for the new term',
    image: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400',
    itemCount: 189,
    color: 'from-blue-500 to-indigo-600'
  },
  {
    id: '3',
    title: 'Tech Essentials',
    description: 'Must-have gadgets',
    image: 'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=400',
    itemCount: 156,
    color: 'from-purple-500 to-pink-600'
  },
  {
    id: '4',
    title: 'Home Makeover',
    description: 'Transform your space',
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400',
    itemCount: 312,
    color: 'from-orange-500 to-red-600'
  }
];

export const mockDigitalProducts: DigitalProduct[] = [
  {
    id: 'd1',
    title: 'Business Plan Template Bundle',
    price: 75000,
    originalPrice: 150000,
    images: [
      'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=400',
      'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=400',
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400',
    ],
    type: 'template',
    format: 'PDF/DOCX',
    fileSize: '25 MB',
    downloads: 1250,
    rating: 4.8,
    seller: { name: 'Business Pro', avatar: 'https://i.pravatar.cc/150?img=40', isVerified: true },
  },
  {
    id: 'd2',
    title: 'Learn React - Complete Course',
    price: 250000,
    images: [
      'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400',
      'https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=400',
    ],
    type: 'video',
    format: 'MP4/HD',
    fileSize: '8.5 GB',
    downloads: 3400,
    rating: 4.9,
    seller: { name: 'CodeMaster UG', avatar: 'https://i.pravatar.cc/150?img=41', isVerified: true },
  },
  {
    id: 'd3',
    title: 'Afrobeats Sample Pack Vol. 2',
    price: 120000,
    images: [
      'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400',
      'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=400',
    ],
    type: 'music',
    format: 'WAV/MP3',
    fileSize: '2.1 GB',
    downloads: 890,
    rating: 4.7,
    seller: { name: 'BeatLab Africa', avatar: 'https://i.pravatar.cc/150?img=42', isVerified: true },
  },
  {
    id: 'd4',
    title: 'Social Media Graphics Kit',
    price: 0,
    images: [
      'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=400',
      'https://images.unsplash.com/photo-1626785774625-ddcddc3445e9?w=400',
      'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=400',
    ],
    type: 'graphics',
    format: 'PSD/PNG',
    fileSize: '450 MB',
    downloads: 5600,
    rating: 4.5,
    seller: { name: 'DesignHub', avatar: 'https://i.pravatar.cc/150?img=43', isVerified: false },
  },
  {
    id: 'd5',
    title: 'E-Commerce WordPress Theme',
    price: 180000,
    originalPrice: 300000,
    images: [
      'https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=400',
      'https://images.unsplash.com/photo-1522542550221-31fd8575f4c4?w=400',
    ],
    type: 'software',
    format: 'ZIP',
    fileSize: '85 MB',
    downloads: 2100,
    rating: 4.6,
    seller: { name: 'ThemeForest UG', avatar: 'https://i.pravatar.cc/150?img=44', isVerified: true },
  },
  {
    id: 'd6',
    title: 'Financial Freedom eBook',
    price: 35000,
    images: [
      'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400',
      'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=400',
    ],
    type: 'ebook',
    format: 'PDF/EPUB',
    fileSize: '15 MB',
    downloads: 4500,
    rating: 4.4,
    seller: { name: 'WealthBooks', avatar: 'https://i.pravatar.cc/150?img=45', isVerified: true },
  },
];

export const mockPromotions: Promotion[] = [
  {
    id: 'p1',
    title: 'Black Friday Mega Sale',
    description: 'Up to 70% off on all electronics. Limited time offer - grab yours now!',
    images: [
      'https://images.unsplash.com/photo-1607082349566-187342175e2f?w=400',
      'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400',
      'https://images.unsplash.com/photo-1607082350899-7e105aa886ae?w=400',
    ],
    type: 'flash-sale',
    discountPercent: 70,
    startsAt: '2024-11-20T00:00:00Z',
    endsAt: '2024-12-31T23:59:59Z',
    brand: { name: 'TechHub Uganda', logo: 'https://i.pravatar.cc/150?img=50' },
    claimsCount: 1250,
    maxClaims: 2000,
  },
  {
    id: 'p2',
    title: 'Fashion Bundle Deal',
    description: 'Buy 2 get 1 free on all clothing items. Mix and match your style!',
    images: [
      'https://images.unsplash.com/photo-1445205170230-053b83016050?w=400',
      'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=400',
    ],
    type: 'bundle',
    discountPercent: 33,
    startsAt: '2024-11-01T00:00:00Z',
    endsAt: '2024-12-25T23:59:59Z',
    brand: { name: 'Fashion Forward', logo: 'https://i.pravatar.cc/150?img=51' },
    claimsCount: 890,
  },
  {
    id: 'p3',
    title: 'New User Discount',
    description: 'Get 25% off your first purchase with code WELCOME25',
    images: [
      'https://images.unsplash.com/photo-1556742111-a301076d9d18?w=400',
      'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=400',
    ],
    type: 'coupon',
    discountPercent: 25,
    startsAt: '2024-01-01T00:00:00Z',
    endsAt: '2024-12-31T23:59:59Z',
    brand: { name: 'EarlyMarket', logo: 'https://i.pravatar.cc/150?img=52' },
    claimsCount: 5600,
  },
  {
    id: 'p4',
    title: 'Weekend Special',
    description: 'Flash sale every weekend! 40% off selected items.',
    images: [
      'https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?w=400',
      'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400',
    ],
    type: 'discount',
    discountPercent: 40,
    startsAt: '2024-11-15T00:00:00Z',
    endsAt: '2024-12-20T23:59:59Z',
    brand: { name: 'Home & Living', logo: 'https://i.pravatar.cc/150?img=53' },
    claimsCount: 320,
  },
  {
    id: 'p5',
    title: 'Gaming Week',
    description: 'Massive discounts on gaming gear, consoles, and accessories!',
    images: [
      'https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?w=400',
      'https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=400',
      'https://images.unsplash.com/photo-1600861194942-f883de0dfe96?w=400',
    ],
    type: 'flash-sale',
    discountPercent: 50,
    startsAt: '2024-11-25T00:00:00Z',
    endsAt: '2024-12-15T23:59:59Z',
    brand: { name: 'Game Masters', logo: 'https://i.pravatar.cc/150?img=54' },
    claimsCount: 780,
    maxClaims: 1000,
  },
];

// Mock services for search
export interface MockSearchService {
  id: string;
  title: string;
  description: string;
  price: number;
  priceType: 'hourly' | 'fixed' | 'starting_from';
  images: string[];
  provider: {
    name: string;
    avatar: string;
    isVerified: boolean;
    rating: number;
    reviewCount: number;
  };
  location: string;
  category: string;
  availability: string;
  responseTime: string;
}

export const mockSearchServices: MockSearchService[] = [
  {
    id: 's1',
    title: 'Professional Photography & Videography',
    description: 'High-quality event coverage, portraits, product photography, and video production with professional equipment.',
    price: 350000,
    priceType: 'starting_from',
    images: ['https://images.unsplash.com/photo-1554048612-b6a482bc67e5?w=600'],
    provider: { name: 'Creative Studios', avatar: 'https://i.pravatar.cc/150?img=60', isVerified: true, rating: 4.9, reviewCount: 127 },
    location: 'Kampala',
    category: 'Photography',
    availability: 'Mon-Sat',
    responseTime: '< 1 hour',
  },
  {
    id: 's2',
    title: 'Home Cleaning & Maintenance Services',
    description: 'Deep cleaning, regular maintenance, and organizing services for homes and offices.',
    price: 80000,
    priceType: 'fixed',
    images: ['https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=600'],
    provider: { name: 'CleanPro UG', avatar: 'https://i.pravatar.cc/150?img=61', isVerified: true, rating: 4.7, reviewCount: 89 },
    location: 'Entebbe',
    category: 'Cleaning',
    availability: 'Daily',
    responseTime: '< 30 min',
  },
  {
    id: 's3',
    title: 'Web & Mobile App Development',
    description: 'Custom software solutions, websites, mobile apps, and digital transformation services.',
    price: 150000,
    priceType: 'hourly',
    images: ['https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=600'],
    provider: { name: 'TechWave Solutions', avatar: 'https://i.pravatar.cc/150?img=62', isVerified: true, rating: 4.8, reviewCount: 56 },
    location: 'Remote',
    category: 'Technology',
    availability: 'Flexible',
    responseTime: '< 2 hours',
  },
];

// Mock events for search
export interface MockSearchEvent {
  id: string;
  title: string;
  description: string;
  images: string[];
  eventDate: string;
  endDate?: string;
  location: string;
  venue: string;
  isFree: boolean;
  ticketPrice?: number;
  currency?: string;
  category: string;
  currentAttendees: number;
  maxAttendees?: number;
  organizer: {
    name: string;
    logo: string;
  };
}

export const mockSearchEvents: MockSearchEvent[] = [
  {
    id: 'e1',
    title: 'Uganda Tech Summit 2025',
    description: 'Join the biggest tech conference in East Africa. Network with industry leaders and discover the latest innovations.',
    images: ['https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600'],
    eventDate: '2025-02-15T09:00:00Z',
    endDate: '2025-02-16T18:00:00Z',
    location: 'Kampala',
    venue: 'Serena Conference Center',
    isFree: false,
    ticketPrice: 150000,
    currency: 'UGX',
    category: 'Technology',
    currentAttendees: 456,
    maxAttendees: 1000,
    organizer: { name: 'Tech Uganda', logo: 'https://i.pravatar.cc/150?img=70' },
  },
  {
    id: 'e2',
    title: 'Afrobeats Festival Kampala',
    description: 'A celebration of African music featuring top artists from Uganda, Nigeria, and beyond.',
    images: ['https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=600'],
    eventDate: '2025-01-20T16:00:00Z',
    location: 'Kampala',
    venue: 'Lugogo Cricket Oval',
    isFree: false,
    ticketPrice: 50000,
    currency: 'UGX',
    category: 'Music',
    currentAttendees: 2340,
    maxAttendees: 5000,
    organizer: { name: 'Beats Africa', logo: 'https://i.pravatar.cc/150?img=71' },
  },
  {
    id: 'e3',
    title: 'Startup Weekend Kampala',
    description: 'Build a startup in 54 hours! Pitch your idea, form a team, and launch your MVP.',
    images: ['https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=600'],
    eventDate: '2025-01-10T18:00:00Z',
    endDate: '2025-01-12T21:00:00Z',
    location: 'Kampala',
    venue: 'Innovation Village',
    isFree: true,
    category: 'Business',
    currentAttendees: 78,
    maxAttendees: 100,
    organizer: { name: 'Startup Uganda', logo: 'https://i.pravatar.cc/150?img=72' },
  },
];

// Mock promotions for search cards
export interface MockSearchPromotion {
  id: string;
  title: string;
  description: string;
  images: string[];
  discountPercent: number;
  originalPrice?: number;
  discountedPrice?: number;
  promoCode?: string;
  type: 'discount' | 'flash-sale' | 'bundle' | 'coupon';
  validUntil: string;
  claimsCount: number;
  maxClaims?: number;
  brand: {
    name: string;
    logo: string;
  };
  termsConditions?: string;
}

export const mockSearchPromotions: MockSearchPromotion[] = [
  {
    id: 'sp1',
    title: 'New Year Mega Electronics Sale',
    description: 'Start 2025 with amazing deals on phones, laptops, and accessories. Up to 60% off!',
    images: ['https://images.unsplash.com/photo-1607082349566-187342175e2f?w=600'],
    discountPercent: 60,
    promoCode: 'NEWYEAR60',
    type: 'flash-sale',
    validUntil: '2025-01-31T23:59:59Z',
    claimsCount: 1890,
    maxClaims: 3000,
    brand: { name: 'TechHub Uganda', logo: 'https://i.pravatar.cc/150?img=80' },
  },
  {
    id: 'sp2',
    title: 'Fashion Week Bundle Deals',
    description: 'Buy any 3 items and get 40% off. Mix designer bags, shoes, and clothing!',
    images: ['https://images.unsplash.com/photo-1445205170230-053b83016050?w=600'],
    discountPercent: 40,
    type: 'bundle',
    validUntil: '2025-01-15T23:59:59Z',
    claimsCount: 567,
    brand: { name: 'Fashion Forward', logo: 'https://i.pravatar.cc/150?img=81' },
  },
  {
    id: 'sp3',
    title: 'First Order Discount',
    description: 'Welcome to EarlyMarket! Get 30% off your first purchase with us.',
    images: ['https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=600'],
    discountPercent: 30,
    promoCode: 'WELCOME30',
    type: 'coupon',
    validUntil: '2025-12-31T23:59:59Z',
    claimsCount: 12500,
    brand: { name: 'EarlyMarket', logo: 'https://i.pravatar.cc/150?img=82' },
  },
];

export const categories = [
  { id: '1', name: 'Phones', icon: 'Smartphone', color: 'bg-blue-500' },
  { id: '2', name: 'Fashion', icon: 'Shirt', color: 'bg-pink-500' },
  { id: '3', name: 'Electronics', icon: 'Laptop', color: 'bg-purple-500' },
  { id: '4', name: 'Services', icon: 'Wrench', color: 'bg-orange-500' },
  { id: '5', name: 'Jobs', icon: 'Briefcase', color: 'bg-green-500' },
  { id: '6', name: 'Properties', icon: 'Home', color: 'bg-teal-500' },
  { id: '7', name: 'Vehicles', icon: 'Car', color: 'bg-red-500' },
  { id: '8', name: 'Gaming', icon: 'Gamepad2', color: 'bg-indigo-500' },
  { id: '9', name: 'Digital', icon: 'Download', color: 'bg-violet-500' },
];
