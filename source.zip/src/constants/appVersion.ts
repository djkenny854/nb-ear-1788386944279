// Bump ONBOARDING_VERSION to re-show post-auth onboarding to all users.
export const ONBOARDING_VERSION = 'v2';