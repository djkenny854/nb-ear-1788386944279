package com.earlymarketug.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
