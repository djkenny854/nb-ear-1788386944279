import{r as i}from"./index-BH4s7x6C.js";const t=i("PushNotifications",{});export{t as PushNotifications};
