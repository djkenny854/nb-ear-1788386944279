const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B5_v9FZM.js","assets/index-BH4s7x6C.js","assets/index-DFOWlNhU.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-BH4s7x6C.js";const _=e("Browser",{web:()=>o(()=>import("./web-B5_v9FZM.js"),__vite__mapDeps([0,1,2])).then(r=>new r.BrowserWeb)});export{_ as Browser};
