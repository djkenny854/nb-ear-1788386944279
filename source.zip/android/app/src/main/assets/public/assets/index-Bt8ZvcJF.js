const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-lSZRQla-.js","assets/index-BH4s7x6C.js","assets/index-DFOWlNhU.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BH4s7x6C.js";const _=p("App",{web:()=>r(()=>import("./web-lSZRQla-.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
