# Antigravity Master Prompt — EarlyMarket Native (Android)

Copy and paste the prompt below into Antigravity after pulling this project locally.
It tells Antigravity exactly what to do to finish the native Android build.

---

## 📋 Master Prompt (paste into Antigravity)

> You are working on the EarlyMarket Capacitor Android app. The web side of the project is already prepared. Your job is to finalize everything that can only be done in a local checkout (Android folder, native plugins, Supabase + Google Cloud config, store metadata). Follow every step below in order. Don't skip any. After each major step, run `npx cap sync android` and verify with a real device or emulator.
>
> ### 1. Package rename → `com.earlymarketug.app`
> The web code already references `com.earlymarketug.app`. The Android folder still uses the old `com.earlymarket.app`. Do the following:
> 1. Rename the folder `android/app/src/main/java/com/earlymarket/app` to `android/app/src/main/java/com/earlymarketug/app`.
> 2. Update the `package` declaration in `MainActivity.java` (or `.kt`) to `com.earlymarketug.app`.
> 3. In `android/app/build.gradle`, set:
>    ```
>    namespace "com.earlymarketug.app"
>    defaultConfig { applicationId "com.earlymarketug.app" }
>    ```
> 4. In `android/app/src/main/AndroidManifest.xml`, replace any `com.earlymarket.app` reference with `com.earlymarketug.app`.
> 5. Update `android/app/src/main/res/values/strings.xml` `package_name` and `custom_url_scheme` if present.
> 6. Run `cd android && ./gradlew clean && cd .. && npx cap sync android`.
>
> ### 2. Native Google Sign-In (no browser redirect)
> The app uses `@capawesome/capacitor-google-sign-in`. The web side calls `GoogleSignIn.signIn()` then `supabase.auth.signInWithIdToken({ provider: 'google', token })`. Make it actually open the **native Google account picker** (not Chrome Custom Tabs):
> 1. Ensure `.env` has `VITE_GOOGLE_WEB_CLIENT_ID=<the Web client ID from Google Cloud>` (NOT the Android client ID — the plugin needs the Web one to mint an ID token Supabase accepts).
> 2. In Google Cloud Console → APIs & Services → Credentials, create an **Android OAuth client**:
>    - Package name: `com.earlymarketug.app`
>    - SHA-1: get it via `cd android && ./gradlew signingReport` (use the `debug` SHA-1 for development; add the release SHA-1 once you sign for Play Store).
> 3. In Supabase Dashboard → Authentication → URL Configuration:
>    - Add `com.earlymarketug.app://login-callback` to **Redirect URLs**.
>    - Also add `com.earlymarketug.app://**` as a wildcard fallback.
> 4. Verify `capacitor.config.ts` has `appId: 'com.earlymarketug.app'` (already set).
> 5. Test on device: tap "Continue with Google" → native Google chooser appears → after picking an account, app navigates to `/` (home), NOT staying on the auth page. The fallback `window.location.replace('/')` is already wired in `useNativeAuth.ts` and `Auth.tsx`.
>
> ### 3. Status bar — pure black/white, non-overlay
> The web layer (`useStatusBar.ts`) already sets:
> - `StatusBar.setOverlaysWebView({ overlay: false })`
> - `#000000` in dark mode, `#ffffff` in light mode
> - Re-applied on theme change and app resume
>
> In `android/app/src/main/res/values/styles.xml`, ensure `AppTheme.NoActionBarLaunch` has:
> ```xml
> <item name="android:windowDrawsSystemBarBackgrounds">true</item>
> <item name="android:statusBarColor">@android:color/white</item>
> <item name="android:windowLightStatusBar">true</item>
> ```
> And in `MainActivity` set edge-to-edge OFF: `WindowCompat.setDecorFitsSystemWindows(window, true)`.
>
> ### 4. Theme follows system in native mode
> Web side already forces `defaultTheme="system"` when `NATIVE_MODE_ENABLED` is true. Nothing to do natively beyond confirming the device's dark-mode toggle visibly flips the app theme on next foreground.
>
> ### 5. Permissions — DO NOT auto-request notifications
> The app no longer prompts for push/local notification permission at launch (it was crashing Android). Only request the following on demand inside the relevant feature:
> - **Camera** + **Microphone** — for video recording / voice messages
> - **Photos / Files** — for image picker & uploads
> - **Location (foreground only)** — for "near me" search and location picker
>
> Make sure `AndroidManifest.xml` only declares permissions actually used:
> ```xml
> <uses-permission android:name="android.permission.INTERNET" />
> <uses-permission android:name="android.permission.CAMERA" />
> <uses-permission android:name="android.permission.RECORD_AUDIO" />
> <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
> <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
> <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
> <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
> ```
> Remove `POST_NOTIFICATIONS` if present, and remove any `android.permission.RECEIVE_BOOT_COMPLETED` from the local-notifications plugin manifest merging if it triggers crashes.
>
> ### 6. Safe-area handling — bottom navigation must clear gesture/3-button bar
> Install:
> ```bash
> npm i capacitor-plugin-safe-area
> npx cap sync android
> ```
> Then in `src/hooks/useStatusBar.ts` (or a new bootstrap effect), wire the plugin to update CSS variables:
> ```ts
> import { SafeArea } from 'capacitor-plugin-safe-area';
> const { insets } = await SafeArea.getSafeAreaInsets();
> document.documentElement.style.setProperty('--safe-area-top', `${insets.top}px`);
> document.documentElement.style.setProperty('--safe-area-bottom', `${insets.bottom}px`);
> ```
> Subscribe to `safeAreaChanged` to re-apply when the user toggles gesture nav.
> Ensure `BottomNavigation.tsx` uses `padding-bottom: max(env(safe-area-inset-bottom), var(--safe-area-bottom), 16px)`.
>
> ### 7. Splash screen — fix KitKat → Android 11 + handle Android 12+
> - For Android <12: use `android:windowBackground` pointing to a 9-patch or `CENTER_CROP` drawable. Already configured via `androidScaleType: 'CENTER_CROP'` in `capacitor.config.ts`.
> - For Android 12+: the system uses the adaptive icon defined in `android/app/src/main/res/values-v31/styles.xml` via `android:windowSplashScreenAnimatedIcon`. Keep the icon within the safe zone (inner 2/3 of the 288dp circle) to avoid clipping.
> - Verify `android/app/src/main/res/drawable/splash.png` is present and 2732×2732 px.
>
> ### 8. Deep links
> Add this intent filter to the main activity in `AndroidManifest.xml`:
> ```xml
> <intent-filter android:autoVerify="true">
>   <action android:name="android.intent.action.VIEW" />
>   <category android:name="android.intent.category.DEFAULT" />
>   <category android:name="android.intent.category.BROWSABLE" />
>   <data android:scheme="com.earlymarketug.app" />
>   <data android:scheme="https" android:host="earlymarketug.com" />
> </intent-filter>
> ```
> Host `assetlinks.json` at `https://earlymarketug.com/.well-known/assetlinks.json` with the SHA-256 fingerprint of your signing key.
>
> ### 9. Build & verify
> ```bash
> npm install
> npm run build
> npx cap sync android
> npx cap run android
> ```
>
> ### ✅ Verification checklist
> - [ ] App launches without any permission popup (no notification crash).
> - [ ] Status bar background is pure white in light mode and pure black in dark mode; icons readable in both.
> - [ ] App content starts BELOW the status bar (no overlap).
> - [ ] Bottom navigation clears the device 3-button / gesture bar (no overlap).
> - [ ] System dark/light theme toggle flips app theme on resume.
> - [ ] "Continue with Google" opens the native account chooser (NOT Chrome).
> - [ ] After picking an account, app lands on `/` (home), not the auth screen.
> - [ ] Notifications screen does NOT show "X sent you a message" entries.
> - [ ] Splash screen looks correct on Android KitKat, 8, 11, 12, 13, 14.
> - [ ] Deep link `com.earlymarketug.app://login-callback` opens the app and completes the session.

---

## 📦 What's already done in this web project

- `capacitor.config.ts` `appId` = `com.earlymarketug.app`.
- `useStatusBar.ts` uses pure `#000000` / `#ffffff`, non-overlay.
- `NativePermissionsGate.tsx` no longer auto-requests notification permission.
- `useNativeAuth.ts` + `Auth.tsx` force-redirect to `/` after Google sign-in success.
- `Notifications.tsx` filters out `new_message` notifications.
- `index.html`, `AppPromoBanner`, `UpdateRequired` reference the new package ID.
- Native mode forces `defaultTheme="system"`.

## 🛑 What can ONLY be done in the local checkout (Antigravity's job)

- Folder rename `android/app/src/main/java/com/earlymarket/app` → `.../com/earlymarketug/app`.
- `applicationId` + `namespace` updates in `android/app/build.gradle`.
- New SHA-1 / Android client ID in Google Cloud OAuth.
- New redirect URI in Supabase Auth settings.
- Install + wire `capacitor-plugin-safe-area`.
- Splash screen drawable adjustments for older Android versions.
- Final `npx cap sync android` and on-device verification.

---

## 🆕 Play Console Compliance & Android App Links

### Play Console URLs (paste exactly)
- **Privacy Policy URL**: `https://earlymarketug.com/privacy`
- **Account / Data Deletion URL**: `https://earlymarketug.com/delete-account`

Both pages are public (no login required) and live in the web project.

### Android App Links — fix the host

The current `android/app/src/main/AndroidManifest.xml` has the wrong HTTPS deep-link host
(`earlymarket.app`). Replace the `<intent-filter android:autoVerify="true">` block that
declares `android:scheme="https"` so it matches the live domain:

```xml
<intent-filter android:autoVerify="true">
    <action android:name="android.intent.action.VIEW" />
    <category android:name="android.intent.category.DEFAULT" />
    <category android:name="android.intent.category.BROWSABLE" />
    <data android:scheme="https" android:host="earlymarketug.com" />
    <data android:scheme="https" android:host="www.earlymarketug.com" />
</intent-filter>
```

Keep the existing custom-scheme filter for `com.earlymarketug.app://` (OAuth callback).

### Digital Asset Links (`assetlinks.json`)

The web project ships `public/.well-known/assetlinks.json`. Once deployed, the file is
served at `https://earlymarketug.com/.well-known/assetlinks.json` (Vercel rewrite is
already in `vercel.json`).

Before publishing:
1. Get the SHA-256 of every signing certificate (debug, upload, **and** Play App Signing key).
   ```bash
   keytool -list -v -keystore /path/to/release.jks -alias your-alias | grep "SHA256:"
   ```
   Or in **Play Console → Setup → App integrity → App signing key certificate**.
2. Replace the placeholders in `public/.well-known/assetlinks.json` with the real
   colon-separated fingerprints.
3. Redeploy the web project.
4. Verify:
   ```bash
   curl -s "https://digitalassetlinks.googleapis.com/v1/statements:list?source.web.site=https://earlymarketug.com&relation=delegate_permission/common.handle_all_urls" | jq
   ```
5. On a device, force re-verification:
   ```bash
   adb shell pm verify-app-links --re-verify com.earlymarketug.app
   adb shell pm get-app-links com.earlymarketug.app
   ```
   The output should show `earlymarketug.com: verified`.

Full reference: `docs/ANDROID_APP_LINKS.md`.
