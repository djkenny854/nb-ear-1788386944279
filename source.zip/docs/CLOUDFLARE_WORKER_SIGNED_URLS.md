# Cloudflare Worker — signed URLs for B2 video playback

This is **phase 2** of the CDN setup (see `CLOUDFLARE_B2_CDN.md` first). It
makes B2 video URLs short-lived and tied to a logged-in EarlyMarket user, so
casual scraping of `cdn.earlymarketug.com/file/...` URLs stops working after
~1 hour.

## How it works

1. Set the B2 bucket to **Private**.
2. The Worker sits at `cdn.earlymarketug.com` and intercepts every request.
3. The Worker checks for a query param `?token=...&exp=...` signed with a
   shared secret (HMAC-SHA256). If the signature is valid and `exp > now()`,
   the Worker fetches the object from B2 (using a B2 application key stored as
   a Worker secret) and streams it back. Otherwise: 403.
4. The EarlyMarket app generates these signed URLs on the server (in an edge
   function) when a user opens a listing.

## Worker code

Save as `worker.js` and deploy via `wrangler deploy`:

```js
const SECRET = globalThis.CDN_SIGNING_SECRET; // Worker secret
const B2_KEY_ID = globalThis.B2_KEY_ID;
const B2_APP_KEY = globalThis.B2_APP_KEY;

async function hmacSha256(key, msg) {
  const k = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(key),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(msg));
  return [...new Uint8Array(sig)].map(b => b.toString(16).padStart(2, "0")).join("");
}

export default {
  async fetch(req) {
    const url = new URL(req.url);
    const token = url.searchParams.get("token");
    const exp = parseInt(url.searchParams.get("exp") || "0", 10);

    if (!token || !exp || exp < Math.floor(Date.now() / 1000)) {
      return new Response("Forbidden", { status: 403 });
    }
    const expected = await hmacSha256(SECRET, `${url.pathname}|${exp}`);
    if (token !== expected) {
      return new Response("Forbidden", { status: 403 });
    }

    // Fetch from B2 with a fresh authorization token (cached for 1h)
    const b2 = await getB2Auth();
    const upstream = `${b2.downloadUrl}${url.pathname}`;
    return fetch(upstream, {
      headers: { Authorization: b2.authToken },
      cf: { cacheTtl: 3600, cacheEverything: true },
    });
  },
};

let cachedAuth = null;
let cachedAt = 0;
async function getB2Auth() {
  if (cachedAuth && Date.now() - cachedAt < 50 * 60 * 1000) return cachedAuth;
  const r = await fetch("https://api.backblazeb2.com/b2api/v2/b2_authorize_account", {
    headers: { Authorization: "Basic " + btoa(`${B2_KEY_ID}:${B2_APP_KEY}`) },
  });
  const j = await r.json();
  cachedAuth = { downloadUrl: j.downloadUrl, authToken: j.authorizationToken };
  cachedAt = Date.now();
  return cachedAuth;
}
```

## Server-side URL signing (in EarlyMarket)

Add this helper to `supabase/functions/_shared/signCdnUrl.ts`:

```ts
export async function signCdnUrl(path: string, ttlSeconds = 3600) {
  const secret = Deno.env.get("CDN_SIGNING_SECRET")!;
  const exp = Math.floor(Date.now() / 1000) + ttlSeconds;
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw", enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(`${path}|${exp}`));
  const token = [...new Uint8Array(sig)].map(b => b.toString(16).padStart(2, "0")).join("");
  return `https://cdn.earlymarketug.com${path}?token=${token}&exp=${exp}`;
}
```

Use it from any edge function that returns a video URL to a logged-in user.

## Honest limits

- A user can still open DevTools, copy the signed URL, and download once
  within the TTL window. After expiry it's dead.
- Signed URLs prevent **embedding on other sites** and **mass scraping**, not
  one-off downloads.
- For real DRM you would need Widevine/FairPlay, which is a different league
  (Cloudflare Stream supports it, B2 alone does not).

## When to deploy this

Only after the basic CDN (`CLOUDFLARE_B2_CDN.md`) is live and confirmed
working. Signing adds complexity — don't bother until you actually see
abusive traffic.