# EarlyMarket Lite — Technical Specification

Target: a separate, standalone Android app (built in another environment) that runs
smoothly on **Android 5.0 (API 21) and later**, installs at **≤ 5 MB**, uses little
RAM, feels instant, and caches aggressively.

This document is the hand-off brief: what to build with, what to include, what to
drop, and exactly which backend endpoints to call.

---

## 1. Language and stack recommendation

**Recommendation: native Android in Kotlin. Do not reuse the React/Capacitor code.**

The current app is a React + Vite SPA in a WebView. A WebView shell can never hit
5 MB with acceptable performance on low-end Android 5 devices: the JS bundle,
WebView memory (~120–200 MB working set) and layout cost are the bottleneck, not
the app size.

| Option | Verdict |
| --- | --- |
| **Kotlin + Views (XML layouts)** | **Chosen.** minSdk 21 works, APK 3–5 MB with R8 + resource shrinking, lowest RAM, no Compose runtime overhead. |
| Kotlin + Jetpack Compose | Works on API 21 but adds ~2.5–3.5 MB and higher memory/first-frame cost. Only if the team strongly prefers it. |
| Java | Possible, but more code, no coroutines/Flow ergonomics, no size advantage. Not recommended. |
| Flutter | ~7–9 MB minimum, extra engine RAM. Fails the 5 MB target. |
| React Native / Capacitor / PWA (TWA) | Fails the size, RAM and API-21 goals. A TWA is < 1 MB but still runs this same heavy SPA. |

**Concrete stack**

- Kotlin, minSdk 21, targetSdk current, `ViewBinding`, XML layouts, single-Activity
  + Navigation component (or plain fragment stack to save size).
- Networking: **Ktor client OkHttp engine** or plain **OkHttp + kotlinx.serialization**
  (avoid Retrofit + Gson + Moshi stacking; one JSON lib only).
- Images: **Coil** (Kotlin-first, small) with a 64 MB disk cache and a memory cache
  capped at 15% of heap. No Glide + Picasso duplication.
- Persistence/cache: **Room** (SQLite) for offline lists + `DataStore` for prefs.
- Video: `MediaPlayer`/`VideoView` on API 21–23, **ExoPlayer core-only artifact**
  (`media3-exoplayer` + `media3-ui`, no DASH/HLS/IMA modules) on API 24+.
  Ship one player behind an interface so the light path stays light.
- Async: coroutines + Flow. No RxJava.
- DI: manual constructor injection or `koin-core` (skip Hilt — annotation processing
  and extra methods).
- Build: R8 full mode, `shrinkResources true`, `resConfigs("en","sw")`,
  ABI splits (`arm64-v8a`, `armeabi-v7a`), **Android App Bundle** so Play delivers
  ~3–4 MB per device. WebP/vector drawables only; no bundled fonts (use system
  Roboto) — this alone saves ~1.5 MB versus the current Google Sans files.

**Hard budgets**

| Budget | Limit |
| --- | --- |
| Download size (per-ABI, AAB) | ≤ 5 MB |
| Method count | ≤ 45k after R8 (no multidex on API 21) |
| Cold start on 1 GB RAM device | ≤ 1.5 s to first content |
| Steady-state RAM | ≤ 90 MB |
| Feed scroll | 60 fps, no jank frames > 16 ms |

---

## 2. Feature scope

### Included (the "buy, sell, talk" core)

1. **Auth** — email + password, Google sign-in optional (adds ~700 KB; make it a
   later flavor), password reset, session persistence.
2. **Marketplace browse** — products and services list, category filter, sort,
   location filter, pagination (20 per page).
3. **Search** — keyword search with debounce + server pagination. History stored
   locally.
4. **Listing detail** — images (swipeable, downscaled), price, seller card,
   description, contact / WhatsApp / call buttons, bookmark, share.
5. **Publishing (light)** — product and service only, single-screen form:
   title, category, price, description, up to 5 images. Client-side JPEG
   re-compression to ≤ 1280 px / 200 KB before upload.
6. **Messaging** — 1:1 chat, text + one image, realtime via polling on API 21–22
   and WebSocket elsewhere. Local Room mirror so threads open instantly offline.
7. **Notifications** — FCM push, notification list, deep links into listing/chat.
8. **Profile / my listings** — edit profile, my ads with status (active, in review,
   expired), mark sold, delete.
9. **Bookmarks** — local-first, synced.
10. **Offline mode** — last feed page, last viewed listings, chat history, and
    bookmarks all readable with no network.

### Excluded from Lite (stay in the full app; deep-link out to the web app)

- Social feed / posts / reels / video playback in feed (biggest RAM + size cost).
- Video upload, trimming, compression, B2 pipeline.
- Service workspaces, updates, portfolios, testimonials, FAQ, catalogs.
- Jobs, tenders, volunteering, events, announcements, digital products.
- All AI features: AI assist, image analysis, semantic/visual/voice search,
  knowledge base chat, AI algorithm summaries.
- Verification and KYC wizards, organization dashboards, analytics/performance
  charts, boosting/promotions checkout, subscriptions, bulk upload.
- Maps SDK (show a static map image + "Open in Maps" intent instead — the Maps SDK
  alone is ~2 MB).
- Multi-currency live conversion (show the listing currency as stored; a single
  cached daily rates blob if needed), animations/motion library, dark-mode
  theming beyond the system `DayNight` theme.

Anything excluded gets an entry point that opens the full web app in a Custom Tab:
`https://earlymarketug.com/<path>` — the user is never dead-ended.

---

## 3. Backend endpoints

Base: `https://<SUPABASE_PROJECT_REF>.supabase.co`
Always send: `apikey: <anon key>` and `Authorization: Bearer <user JWT or anon key>`.
Always send `Accept-Profile: public` for reads. Everything below is plain HTTPS +
JSON — **no Supabase SDK needed**, which is why the app stays small.

### 3.1 Auth (GoTrue)

| Purpose | Method + path |
| --- | --- |
| Sign up | `POST /auth/v1/signup` `{email, password}` |
| Sign in | `POST /auth/v1/token?grant_type=password` `{email, password}` |
| Refresh | `POST /auth/v1/token?grant_type=refresh_token` `{refresh_token}` |
| Current user | `GET /auth/v1/user` |
| Reset password | `POST /auth/v1/recover` `{email}` |
| Sign out | `POST /auth/v1/logout` |

Store `access_token` / `refresh_token` in `EncryptedSharedPreferences`; refresh
proactively 60 s before `expires_at`.

### 3.2 Data (PostgREST)

Path prefix `/rest/v1/`. Use `select=` to request **only** the columns Lite renders —
this is the single biggest bandwidth win.

| Purpose | Request |
| --- | --- |
| Feed / marketplace list | `GET /rest/v1/ads?select=id,title,price,currency,images,location,category,listing_type,created_at,seller_id&is_active=eq.true&status=eq.active&order=created_at.desc&limit=20&offset=<n>` |
| Category filter | add `&category=eq.<slug>` |
| Type filter | add `&listing_type=eq.product` (or `service`) |
| Price / location filters | `&price=gte.<min>&price=lte.<max>&location=ilike.*<q>*` |
| Keyword search | `&or=(title.ilike.*<q>*,description.ilike.*<q>*)` |
| Listing detail | `GET /rest/v1/ads?select=*,seller_profiles(business_name,business_logo_url,is_verified,phone)&id=eq.<id>` |
| Create listing | `POST /rest/v1/ads` with `Prefer: return=representation` |
| Update / mark sold | `PATCH /rest/v1/ads?id=eq.<id>` |
| Delete | `DELETE /rest/v1/ads?id=eq.<id>` |
| My listings | `GET /rest/v1/ads?seller_id=eq.<uid>&order=created_at.desc` |
| Profile | `GET /rest/v1/profiles?id=eq.<uid>` / `PATCH` |
| Seller profile | `GET /rest/v1/seller_profiles?user_id=eq.<uid>` |
| Categories | `GET /rest/v1/categories?select=id,name,slug,icon&order=name` (cache 24 h) |
| Bookmarks | `GET/POST/DELETE /rest/v1/bookmarks` |
| Conversations | `GET /rest/v1/conversations?select=id,participant_ids,last_message,updated_at&order=updated_at.desc` |
| Messages | `GET /rest/v1/messages?conversation_id=eq.<id>&order=created_at.asc&limit=50` |
| Send message | `POST /rest/v1/messages` |
| Notifications | `GET /rest/v1/notifications?user_id=eq.<uid>&order=created_at.desc&limit=30` |
| Mark read | `PATCH /rest/v1/notifications?id=eq.<id>` `{is_read:true}` |
| Register push token | `POST /rest/v1/device_tokens` with `Prefer: resolution=merge-duplicates`, body `{user_id, token, platform:"android_lite", app_version}` |

Pagination: prefer `Range: 0-19` headers + `Prefer: count=exact` to get totals
without a second query.

### 3.3 Storage and media

- Upload images: `POST /storage/v1/object/<bucket>/<path>` (multipart, JWT auth).
- Read images **always through the transform endpoint** so Lite never downloads a
  full-resolution photo:
  `/storage/v1/render/image/public/<bucket>/<path>?width=320&quality=60&resize=cover`
  - list thumbnails: `width=320`
  - detail: `width=720`
  - avatars: `width=96`
- Videos are out of scope for Lite; if a listing has one, show the poster with a
  "Watch on web" button.

### 3.4 Edge functions (only these three)

| Function | Use |
| --- | --- |
| `POST /functions/v1/moderate-content` | Called after publishing so listings follow the same review rules. |
| `POST /functions/v1/send-push` | Server-side only; Lite just registers its token. |
| `POST /functions/v1/check-payment-status` | Only if paid boosting is ever added to Lite. Skip in v1. |

All AI functions (`ai-assist`, `semantic-search`, `image-search`,
`analyze-product-images`, `knowledge-rag`, …) are **not** called by Lite.

### 3.5 Realtime

WebSocket `wss://<ref>.supabase.co/realtime/v1/websocket?apikey=<anon>&vsn=1.0.0`,
subscribed to `postgres_changes` on `messages` and `notifications` filtered by the
user id. On API 21–22 (weak TLS/WebSocket support) fall back to a 15 s poll while
a chat screen is open, and rely on FCM otherwise.

---

## 4. Caching strategy

Three layers, all mandatory:

1. **HTTP cache** — OkHttp `Cache` (20 MB). Send
   `Cache-Control: max-age=60, stale-while-revalidate=600` handling client-side:
   render cached instantly, revalidate in the background, diff into the list.
2. **Room database** — tables `ads_cache`, `categories_cache`, `messages`,
   `conversations`, `notifications`, `bookmarks`, each with `fetched_at`.
   Screens read Room first (Flow), then the network updates Room and the UI
   re-emits. Nothing ever shows a blank screen twice.
3. **Coil disk cache** — 64 MB, keyed on the transform URL so the 320 px and 720 px
   variants coexist.

TTLs: categories 24 h, feed page 5 min, listing detail 10 min, profile 1 h,
messages never expire (append-only), images 30 days.

Also: prefetch the next feed page when the user is 5 items from the end; warm the
detail request on list-item long-press/scroll-stop; WorkManager job refreshes page 1
of the feed and unread counts every 6 h on unmetered networks.

---

## 5. Performance rules

- `RecyclerView` with stable ids, `DiffUtil`, fixed item size, view-type reuse; no
  nested scrolling lists.
- Fixed aspect-ratio image containers (4:3 for products) so there is zero layout
  shift while images decode.
- Load `RGB_565` bitmaps on devices with < 1.5 GB RAM (`ActivityManager.isLowRamDevice`).
- No animation library; only `MotionLayout`-free simple transitions, disabled on
  low-RAM devices.
- One thread pool; images and network share OkHttp's dispatcher.
- StrictMode in debug; Baseline Profile generated for API 24+.
- Startup: no work on the main thread before first frame; categories and session
  restore happen asynchronously behind cached content.

---

## 6. Push notifications

- `firebase-messaging` only (`~1 MB`; still fits the budget with R8). If even that
  is too big, use raw FCM over HTTP with a token obtained from the Play Services
  Instance ID API.
- Register the token to `device_tokens` with `platform = "android_lite"`.
- The existing `send-push` edge function already fans out per-token, so no backend
  change is required.
- Notification payload carries `action_url`; Lite maps known paths
  (`/ad/:id`, `/chat/:id`, `/notifications`) to native screens and opens anything
  else in a Custom Tab.

---

## 7. Delivery plan

| Phase | Contents |
| --- | --- |
| 1 | Shell, auth, feed, listing detail, image caching, Room. |
| 2 | Search, filters, bookmarks, profile, my listings. |
| 3 | Publishing (product/service), image compression, moderation call. |
| 4 | Messaging + realtime/poll fallback, FCM push, deep links. |
| 5 | Offline polish, size audit (target ≤ 5 MB), Baseline Profile, low-RAM tuning. |

Ship as a separate Play listing ("EarlyMarket Lite") or as a low-RAM variant of the
same listing. Both apps share one Supabase backend, one auth system and one
`device_tokens` table, so a user can move between them freely.
