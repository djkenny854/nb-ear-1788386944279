# Deep Linking Setup Guide

## Overview
Deep linking allows your app to open directly to specific content when a user clicks a link (e.g., in WhatsApp, SMS, or a browser).

## Prerequisites
1. Run `npx cap add android` to create the Android project
2. Run `npx cap sync` after any web code changes

## Step 1: Configure AndroidManifest.xml

After running `npx cap add android`, edit `android/app/src/main/AndroidManifest.xml`.

Add the following `<intent-filter>` blocks **inside** the `<activity>` tag:

```xml
<activity
    android:name="com.earlymarket.app.MainActivity"
    ...>

    <!-- Existing intent filter -->
    <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
    </intent-filter>

    <!-- Deep Links: App Links (verified) -->
    <intent-filter android:autoVerify="true">
        <action android:name="android.intent.action.VIEW" />
        <category android:name="android.intent.category.DEFAULT" />
        <category android:name="android.intent.category.BROWSABLE" />
        <data android:scheme="https"
              android:host="earlymarketug.com" />
    </intent-filter>

    <!-- Deep Links: Also handle www subdomain -->
    <intent-filter android:autoVerify="true">
        <action android:name="android.intent.action.VIEW" />
        <category android:name="android.intent.category.DEFAULT" />
        <category android:name="android.intent.category.BROWSABLE" />
        <data android:scheme="https"
              android:host="www.earlymarketug.com" />
    </intent-filter>

    <!-- Deep Links: Custom scheme (fallback) -->
    <intent-filter>
        <action android:name="android.intent.action.VIEW" />
        <category android:name="android.intent.category.DEFAULT" />
        <category android:name="android.intent.category.BROWSABLE" />
        <data android:scheme="earlymarket" />
    </intent-filter>
</activity>
```

## Step 2: Digital Asset Links (assetlinks.json)

The file `public/.well-known/assetlinks.json` must be hosted at:
```
https://earlymarketug.com/.well-known/assetlinks.json
```

Content:
```json
[{
  "relation": ["delegate_permission/common.handle_all_urls"],
  "target": {
    "namespace": "android_app",
    "package_name": "com.earlymarket.app",
    "sha256_cert_fingerprints": ["19:3C:3F:E1:29:34:5D:1D:4C:2E:43:DB:61:E5:54:EA:DC:EB:12:C6:B0:BC:1F:59:41:8E:70:EC:0E:EC:6C:30"]
  }
}]
```

### Get your SHA-256 fingerprint:
```bash
# Debug keystore
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android

# Release keystore
keytool -list -v -keystore your-release-key.keystore
```

## Step 3: Google Sign-In Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com/apis/credentials)
2. Create an **Android** OAuth 2.0 Client ID
3. Enter package name: `com.earlymarket.app`
4. Enter SHA-1 fingerprint from your keystore
5. Download `google-services.json` and place in `android/app/`
6. The **Web Client ID** (already in `useNativeAuth.ts`) is separate — it's the Web application type client

## Step 4: Capacitor Config

The `capacitor.config.ts` already has `server.androidScheme: 'https'` configured, which is required for deep links to work properly.

## Step 5: Sync and Build

```bash
npx cap sync android
npx cap run android
```

## Supported Deep Link Paths

The app handles these paths (see `useDeepLinks.ts`):
- `/product/:id` — Product detail page
- `/seller/:id` — Seller profile
- `/business/:id` — Business page
- `/job/:id` — Job listing
- `/service/:id` — Service listing
- `/promotion/:id` — Promotion
- `/event/:id` — Event detail
- `/digital-product/:id` — Digital product
- `/profile/:id` — User profile
- `/messages` — Messages
- `/social` — Social feed
- `/discover` — Discover page

## Troubleshooting

1. **Links open in browser instead of app**: Verify `assetlinks.json` is accessible at `https://earlymarketug.com/.well-known/assetlinks.json` and SHA-256 matches
2. **App opens but goes to homepage**: Check that the URL path matches one of the patterns in `useDeepLinks.ts`
3. **Verify links work**: `adb shell am start -W -a android.intent.action.VIEW -d "https://earlymarketug.com/product/123" com.earlymarket.app`
