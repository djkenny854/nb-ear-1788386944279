# Android App Links Setup — earlymarketug.com

This guide wires up **Android App Links** so that tapping an `https://earlymarketug.com/...`
URL on a device with the app installed opens it directly in the EarlyMarket app
(no browser disambiguation dialog).

Package name: **`com.earlymarketug.app`**
Verified host: **`earlymarketug.com`** (and `www.earlymarketug.com`)

---

## 1. Get your SHA-256 certificate fingerprints

You need the SHA-256 of every keystore that will sign the APK/AAB.

### Debug keystore (local development)
```bash
keytool -list -v \
  -keystore ~/.android/debug.keystore \
  -alias androiddebugkey \
  -storepass android \
  -keypass android | grep "SHA256:"
```

### Release keystore (Play Store)
```bash
keytool -list -v \
  -keystore /path/to/your-release-key.jks \
  -alias your-key-alias | grep "SHA256:"
```

### Play App Signing (recommended)
If you've enrolled in Play App Signing, the **app signing certificate** SHA-256 is the one
that matters for installs from the Play Store. Get it from:

**Play Console → Your app → Setup → App integrity → App signing key certificate → SHA-256**

Copy *both* the "App signing key certificate" and the "Upload key certificate" SHA-256s.

---

## 2. Update `assetlinks.json`

Edit `public/.well-known/assetlinks.json` and replace the placeholders with the
fingerprints from step 1. You can list multiple fingerprints (release + upload + debug).

```json
[
  {
    "relation": ["delegate_permission/common.handle_all_urls"],
    "target": {
      "namespace": "android_app",
      "package_name": "com.earlymarketug.app",
      "sha256_cert_fingerprints": [
        "AA:BB:CC:...",
        "11:22:33:..."
      ]
    }
  }
]
```

Deploy the project. The file must be reachable at:

```
https://earlymarketug.com/.well-known/assetlinks.json
```

It must be served over HTTPS with `Content-Type: application/json` and **no redirects**.
The included `vercel.json` already rewrites `/.well-known/(.*)` to the static file, so this
works out of the box on Vercel.

---

## 3. Verify with Google's tester

```bash
curl -s "https://digitalassetlinks.googleapis.com/v1/statements:list?source.web.site=https://earlymarketug.com&relation=delegate_permission/common.handle_all_urls" | jq
```

Or open in a browser:
<https://digitalassetlinks.googleapis.com/v1/statements:list?source.web.site=https://earlymarketug.com&relation=delegate_permission/common.handle_all_urls>

You should see your `package_name` and SHA-256 echoed back with no errors.

---

## 4. AndroidManifest.xml

In `android/app/src/main/AndroidManifest.xml`, the `MainActivity` must contain an
intent filter with `android:autoVerify="true"` for the **correct** host:

```xml
<!-- HTTPS deep links — Android App Links -->
<intent-filter android:autoVerify="true">
    <action android:name="android.intent.action.VIEW" />
    <category android:name="android.intent.category.DEFAULT" />
    <category android:name="android.intent.category.BROWSABLE" />
    <data android:scheme="https" android:host="earlymarketug.com" />
    <data android:scheme="https" android:host="www.earlymarketug.com" />
</intent-filter>
```

> The current manifest in this project still references the old host
> `earlymarket.app` — change it to `earlymarketug.com` before publishing.

---

## 5. Re-run the App Links Assistant

In Android Studio: **Tools → App Links Assistant → Open URL Mapping Editor → Test App Links**.
Every test URL should report **"App link verified"**.

On a real device you can also force re-verification:

```bash
adb shell pm verify-app-links --re-verify com.earlymarketug.app
adb shell pm get-app-links com.earlymarketug.app
```

Look for `earlymarketug.com: verified`.

---

## 6. Common pitfalls

| Symptom | Fix |
|--------|-----|
| `assetlinks.json` returns 404 | Check the file is at `public/.well-known/` and that your host doesn't strip dotfiles. The `vercel.json` rewrite handles this. |
| `Content-Type` is `text/plain` | Ensure your host serves `.json` as `application/json`. Vercel does this automatically. |
| Verification keeps failing | Confirm SHA-256s match the **signing** certificate (not the upload key) when installed from Play Store. |
| Works on debug, not release | Add the **App signing key certificate** SHA-256 from Play Console. |
| Redirects from `www` → root | List both hosts in the manifest **and** in `assetlinks.json`'s host (Google fetches per-host). |
