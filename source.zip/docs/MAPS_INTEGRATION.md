# Maps Integration Research — Earlymarket

Reference library the user requested: **map.new / mapcn** style map components
(shadcn-flavoured wrappers around MapLibre GL JS + `react-map-gl`).
Docs: https://map.new/docs and the ecosystem it wraps
(https://maplibre.org/maplibre-gl-js/docs and https://visgl.github.io/react-map-gl).

This document is **research only** — nothing has been implemented yet.

---

## 1. Why maps change the product

### For buyers
- **Discovery by proximity.** "Show me sellers within 5 km selling phones."
  A radius filter around the user's location beats generic "location" text
  boxes and is the single biggest lift for cold-start users.
- **Trust through place.** A verified shop pinned on a real street feels
  legitimate. Fake / drop-ship listings that only give a district usually
  won't set a pin, which becomes a passive quality signal.
- **Route planning.** Tap a pin → get directions in Google/Apple Maps.
  This removes the "where actually is this shop?" step for physical pickup.
- **Cluster heat.** Clusters make dense markets (Kikuubo, Nakasero) legible
  at a glance and let buyers walk between many sellers in one trip.

### For sellers
- **Foot-traffic acquisition.** Pinned physical shops get discovered by
  buyers browsing an area, not just buyers searching a keyword.
- **Service-area drawing.** A plumber / caterer can draw the polygon they
  actually serve. Buyers outside it don't waste anyone's time.
- **Delivery-radius pricing.** Sellers can set tiers ("free < 3 km,
  UGX 5k up to 10 km") that the app can compute automatically at checkout.
- **Event / promo geotargeting.** A weekend market can appear as a pin
  with a live "open now" badge.
- **Analytics.** Heatmap of where a seller's profile visits / calls come
  from, so they know which neighbourhoods to run promotions in.

### Platform effects
- Location is the strongest signal we don't yet use for ranking. Adding a
  distance term to `feedRanking` will meaningfully improve CTR on the
  "Popular Near You" and Marketplace feeds.
- Enables future flows: local ads (radius-targeted boosts), rider matching
  for logistics, in-person events, verified pickup points.

---

## 2. What already exists in the database

Good news — the schema already has coordinate columns on the two tables
that matter most:

| Table              | Column          | Type              | Notes                                    |
| ------------------ | --------------- | ----------------- | ---------------------------------------- |
| `seller_profiles`  | `latitude`      | `numeric \| null` | Present, mostly unpopulated              |
| `seller_profiles`  | `longitude`     | `numeric \| null` | Present, mostly unpopulated              |
| `seller_profiles`  | `map_location`  | `text \| null`    | Free-text; usable as fallback label      |
| `seller_profiles`  | `street_address`| `text`            | Good for reverse-geocoding backfill      |
| `seller_profiles`  | `district`      | `text`            | Coarse fallback pin (district centroid)  |
| `seller_profiles`  | `sub_county`    | `text`            | Finer fallback centroid                  |
| `seller_profiles`  | `delivery_areas`| `text[]`          | Perfect input for a service polygon      |
| `user_locations`   | `lat`, `lng`    | (existing table)  | Per-user location for "near me"          |
| `locations`        | `lat`, `lng`    | (existing table)  | Named POIs                               |
| `ads`              | `location`      | `text`            | Only text — see §3                       |
| `events`           | (has lat/lng)   | (existing)        | Already map-ready                        |

So the "sellers on a map" experience is possible **today** for the subset
of sellers whose lat/long is set. Everything below is what's needed to
make it complete and reliable.

---

## 3. What's missing (and needs to be added)

### 3.1 Coordinates on listings
`ads.location` is text. For per-listing pins (products, jobs, services,
promos) we need:

```sql
ALTER TABLE public.ads
  ADD COLUMN latitude  double precision,
  ADD COLUMN longitude double precision,
  ADD COLUMN location_precision text
    CHECK (location_precision IN ('exact','approx','district','sub_county','hidden'));
```

`location_precision` is important for privacy: many sellers do **not** want
their home address exposed. UI collects exact, but for public display we
"jitter" to a ~500m grid when precision ≠ `exact`.

### 3.2 Postgres geospatial support
Two options:

- **Option A (recommended): PostGIS.** Enable the extension, add
  `geography(Point, 4326)` columns as generated from lat/long, and use
  `ST_DWithin` for radius queries. This scales to millions of pins and
  supports polygons for service areas / delivery zones cleanly.

  ```sql
  CREATE EXTENSION IF NOT EXISTS postgis;

  ALTER TABLE public.seller_profiles
    ADD COLUMN geog geography(Point, 4326)
    GENERATED ALWAYS AS (
      CASE WHEN latitude IS NOT NULL AND longitude IS NOT NULL
        THEN ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)::geography
      END
    ) STORED;
  CREATE INDEX seller_profiles_geog_gix ON public.seller_profiles USING GIST (geog);
  ```

- **Option B (lighter): bounding-box filter in SQL.** Compute lat/lng
  min/max from radius, filter in a plain B-tree index on `(latitude, longitude)`.
  Cheap, but no polygons and rough at the edges.

Recommendation: **PostGIS**, because delivery-radius / service-area polygons
and clustering benefit hugely from it.

### 3.3 Service-area polygons
For services and delivery-radius pricing:

```sql
ALTER TABLE public.seller_profiles
  ADD COLUMN service_area geography(Polygon, 4326),
  ADD COLUMN service_radius_km int;
```

Either a drawn polygon (accurate) or a simple radius (easy for the seller
to configure). Both feed the same query surface: "does this buyer's point
fall inside this seller's service coverage?"

### 3.4 RPCs for the app to call
Keep the client code simple by exposing SQL functions:

```sql
-- Sellers within `radius_km` of (lat,lng), optional category filter.
CREATE OR REPLACE FUNCTION public.sellers_near(
  lat double precision,
  lng double precision,
  radius_km double precision DEFAULT 5,
  category text DEFAULT NULL
) RETURNS SETOF public.seller_profiles
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
  SELECT *
  FROM seller_profiles
  WHERE geog IS NOT NULL
    AND ST_DWithin(
      geog,
      ST_SetSRID(ST_MakePoint(lng, lat), 4326)::geography,
      radius_km * 1000
    )
    AND (category IS NULL OR business_category ILIKE category)
    AND is_active = true;
$$;
```

Same shape for `ads_near`, `events_near`, `services_near`.

### 3.5 Backfill for existing sellers
Most rows have address / district but no lat/long. Two paths:

- **One-off migration:** run each `street_address, district` through
  Google Geocoding (already available via the Google Maps connector) in a
  batched edge function; store lat/long + `location_precision='approx'`.
- **Fallback centroids:** for rows we can't geocode, use district /
  sub-county centroids stored in the existing `districts` table (add
  `latitude`, `longitude` columns to `districts` and seed them once).

---

## 4. Library choice: `map.new` (shadcn-style) on MapLibre

`map.new` is a shadcn-CLI style component library that wraps `react-map-gl`
+ MapLibre. It gives us:

- Copy-paste React components that match our design system (Tailwind + shadcn).
- MapLibre under the hood → **no per-load billing**, open-source, works with
  any raster or vector tile source.
- All the primitives we need: `<Map>`, `<Marker>`, `<Popup>`,
  `<Source>` / `<Layer>` for GeoJSON, `<NavigationControl>`,
  `<GeolocateControl>`, clustering via `supercluster`.

Tile-provider options (pick one, all work with MapLibre):
- **MapTiler** — free tier ~100k map loads/mo; nicest street-level style.
- **Stadia Maps** — free for non-commercial; great dark theme.
- **Protomaps** — self-hostable single-file `.pmtiles`; near-zero cost at
  our scale, works well for Uganda-focused deployments.
- **Google Maps tiles** — usable via our existing Google Maps connector
  (Map Tiles API), but expensive and defeats the point of MapLibre.

Recommendation: **MapTiler** to launch (fast to wire, generous free tier),
migrate to **Protomaps** if traffic warrants it.

---

## 5. Customisation surface

Everything the user asked about is supported:

- **Custom markers.** Any React node — we can render our
  `UnifiedVerifiedBadge` inside a `<Marker>` so a verified shop looks
  different from a regular pin.
- **Radius / boundary circles.** Draw a circle GeoJSON polygon and render
  it via `<Source type="geojson">` + `<Layer type="fill">` with a soft
  stroke. Users see "search radius: 5 km" as a translucent disc.
- **Draw tools.** `@mapbox/mapbox-gl-draw` (compatible with MapLibre) lets
  sellers draw their service polygon by dragging.
- **Clustering.** `supercluster` collapses dense pins into count badges
  that expand as the user zooms in.
- **Themes.** MapLibre styles are JSON — light/dark/brand variants are a
  drop-in swap that follows our existing `next-themes` mode.
- **Popups.** Any React content — we can reuse our card components inside
  a `<Popup>` so a marker tap shows the same visual language as the feed.
- **Heatmaps.** Native `heatmap` layer type for "where activity is
  happening" analytics.

---

## 6. Privacy & policy considerations

- **Never expose a seller's exact home coordinates without consent.**
  Enforce `location_precision`; default to `approx` (500 m jitter) unless
  the seller has an actual storefront and opts in to `exact`.
- **User location is opt-in.** Use the browser Geolocation API only when
  the user taps "Near me"; cache with a short TTL; never persist without
  consent.
- **RLS.** `latitude` / `longitude` remain readable by anyone (needed for
  map display), but a nightly job should jitter values when
  `location_precision != 'exact'` so the raw exact value never leaves the
  database.
- **Data retention.** Don't store per-request user coordinates in logs.

---

## 7. Proposed rollout (three phases)

**Phase 1 — Data foundation** (backend only, no UI change)
- Enable PostGIS.
- Add `latitude`, `longitude`, `location_precision` to `ads`.
- Add `service_area`, `service_radius_km` to `seller_profiles`.
- Add `geog` generated column + GIST index on both tables.
- Add centroid columns to `districts` and seed them.
- Ship `sellers_near`, `ads_near`, `services_near` RPCs.
- Backfill existing seller lat/long via Google Geocoding batched job.

**Phase 2 — Consumption**
- Add lat/long capture step in the seller onboarding wizard and in
  `PostAd` / `PostJob` / `ServiceQuickWizard` (draggable pin on a map).
- Add a `distance_km` term to `feedRanking` so nearer results rise on
  Marketplace and "Popular Near You".
- Add a "Near me" chip on the Marketplace algorithm panel that actually
  filters, using the current user's geolocation.

**Phase 3 — Map surfaces**
- New `/marketplace/map` view: same filters as the list view, results
  rendered as clustered pins with cards in a popup.
- Map view on individual seller / service / event pages, with directions
  hand-off to the OS map app.
- Delivery-radius pricing on checkout (uses `service_area` /
  `service_radius_km`).
- Seller analytics: heatmap of profile visits by area.

Each phase ships independently and none blocks the next.

---

## 8. TL;DR of what we need to decide

1. **PostGIS on or off.** (Recommend: on.)
2. **Tile provider.** (Recommend: MapTiler to launch.)
3. **Precision default.** (Recommend: `approx` with a seller-facing
   toggle to opt into `exact`.)
4. **Backfill strategy.** (Recommend: Google Geocoding batched, then
   district centroid for the remainder.)
5. **Whether service-area polygons are Phase 1 (with the schema change)
   or Phase 3 (later, once we're sure sellers will draw them).**

Once these are decided we can turn Phase 1 into a migration + edge
function and start shipping.
